package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MyWorkbenchPage extends CommonUtility{

	public MyWorkbenchPage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//table[contains(@class,'assignedTo_mywrkbench') and contains(@id,'reqList')]")
	public WebElement myWorkbench_list;
	
	public By filterBtn = By.xpath("//div[contains(@aria-hidden,'false')]//a[text()='"+getLanguageProperty("Filter")+"']");
	
	@FindBy(xpath = "//th[contains(@class,'assignedTo')]//b")
	public WebElement assignedToXpath;
	

	public By backToContractListing = By.xpath("//a[contains(text(),'"+getLanguageProperty("Back to Contract Listing")+"')]");

	public By createProject = By.xpath("//input[@value='"+getLanguageProperty("Create Project")+"']");
	
	public String actionBtn = "//table[@id='reqList']/tbody/tr[td[2]/a[text()='<<RequestNo>>']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']";
	
	public String createActivity ="//table[@id='reqList']/tbody/tr[td[2]/a[text()='<<RequestNo>>']]/td[last()]//ul/li/a[text()='"+getLanguageProperty("Create Activity")+"']";
	
	@FindBy(id="reviewerDownArrowTo")
	public WebElement contractDropDown;
	
	@FindBy(id="contractOwnerList")
	public WebElement contractOwnerListInput;
	
	@FindBy(id="btnCreateActivity")
	public WebElement createActivityInReview;
	
	@FindBy(id="irequestContractOwnerList")
	public WebElement contractDropDownList;
	
	public By contractDropDownValue = By.xpath("//ul[@id='irequestContractOwnerList']//option[contains(text(),'"+getLanguageProperty("Self")+"')]");
	
	@FindBy(id="workflowTrailSection")
	public WebElement workFlowBtn;
	
	@FindBy(id="auditTrail")
	public WebElement auditTrailBtn;
	
	@FindBy(id="actDrop")
	public WebElement actionDropDown;
	
	@FindBy(id="printPdf")
	public WebElement print;
	
	@FindBy(id="savePdf")
	public WebElement savePdf;
	
	@FindBy(id="createEventBtn")
	public WebElement createEventBtn;
	
	@FindBy(id="selectAll")
	public WebElement selectAll;
	
	
	public String requesterName =getLanguageProperty("Requester Name");
	
	public String markComplete =  getLanguageProperty("Mark Complete");
	
	public String returnStatus =getLanguageProperty("Return");
	
	public String reviewStatus =getLanguageProperty("Review");
	
	public String withRm = getLanguageProperty("With RM");
}
