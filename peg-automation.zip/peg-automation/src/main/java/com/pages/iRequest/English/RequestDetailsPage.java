package com.pages.iRequest.English;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class RequestDetailsPage extends CommonUtility{
	
	public RequestDetailsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public String requestName = getLanguageProperty("Request Name");
	
	public String requestNumber = getLanguageProperty("Request Number");
	
	public String requestDefinationName = getLanguageProperty("Request Definition Name");
	
	public String requestType = getLanguageProperty("Request Type");
	
	public String createdBy = getLanguageProperty("Created By");
	
	public String requestTypeName = getLanguageProperty("Request Type Name");
}
