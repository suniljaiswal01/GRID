package com.pages.iRequest.English.crms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class CreateReportsPage extends CommonUtility{
	CommonUtility commonUtil;
	public CreateReportsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
	@FindBy(id="addFieldsPopup")
	public WebElement addFields_popup;
	
	@FindBy(id="productListingNext")
	public WebElement swipeNext_button;
	
	@FindBy(xpath="//div[@aria-describedby='addFieldsPopup']//button[contains(@class,'titlebar-close')]")
	public WebElement closePopUpBtn;
	
	@FindBy(xpath = "//div[contains(@id,'status_overlay_undefined')]")
	public WebElement loader;
	
	@FindBy(xpath = "//div[@class='loaderProgress']")
	public WebElement loaderInProgress;
	
	@FindBy(xpath = "//a[@data-id='irequest#requesttype#caption']")
	public WebElement requestType_filter_link;
	
	@FindBy(xpath = "//a[@class='clear-icon input-group-addon']")
	public WebElement clearSearchBox_button;
	
	@FindBy(id = "fieldSearch")
	public WebElement parameterSearch_input;
	
	@FindBy(id = "applyAddFields")
	public WebElement applySearch_button;
	
	public String productTab_link =  "//span[@class='product-name']/span[contains(text(),'<<ProductName>>')]";
	public String categoryTab = "//li[contains(@class,'list-group-item')]//span[contains(@data-original-title,'<<CategoryName>>')]";
	public String parameterLabel_checkbox = "//div[@class='custom-control-label']//span[@data-original-title='<<ParamValue>>']";
	public String parameter_checkbox = "//div[@class='custom-control-label'][span[@data-original-title='<<ParamValue>>']]//preceding-sibling::input";
	
}
