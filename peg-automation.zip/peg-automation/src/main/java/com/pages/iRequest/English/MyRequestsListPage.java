package com.pages.iRequest.English;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MyRequestsListPage extends CommonUtility{

	public MyRequestsListPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//table[@aria-describedby='reqList_info']")
	public WebElement myRequest_list;

	
	public  String myApproval = getLanguageProperty("Awaiting Approval");

	public  String withRM = getLanguageProperty("With RM");
	
	public String completed =getLanguageProperty("Completed");
}

