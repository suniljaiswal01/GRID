package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportsDetailPage extends CommonUtility{

	public ReportsDetailPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public By moreOption = By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More option")+"')]");

	public By share = By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Share")+"']");
	
	@FindBy(xpath = "(//table[@class='shareListTable_RMS']//div/ancestor::tr//input[not(@disabled)])[1]")
	public WebElement shareEmail;
	
	@FindBy(xpath = "(//table[@class='shareListTable_RMS']//div/ancestor::tr//input[not(@disabled)])[1]/ancestor::tr/td[3]/div")
	public WebElement shareEmailId;
	
	@FindBy( id = "btnconfirm")
	public WebElement confirmBtn;
	
	public By successMsg  = By.xpath("//div[@id='jqi'][div/div[text()='"+getLanguageProperty("Success")+"']]");

	public By goToReport = By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Go to report")+"'");
	
	public String checkBox = "//table[@class='shareListTable_RMS']//div[text()='<<email>>']/ancestor::tr//input";
	
	public String allEmailList  = "//ul[@id='ulUser']/li[@id='<<email>>']";
}
