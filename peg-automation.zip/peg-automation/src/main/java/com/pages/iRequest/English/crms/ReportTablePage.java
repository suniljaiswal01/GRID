package com.pages.iRequest.English.crms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportTablePage extends CommonUtility{

	CommonUtility commonUtil;
	public ReportTablePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
	@FindBy(id = "iRequest_RequestDefinition-PARENT_createdDate_th")
	public WebElement iRequest_createdOnSorting_button;
	
	@FindBy(id = "createReport")
	public WebElement createReport_button;
	
	@FindBy(className = "reportRightContentInner")
	public WebElement reportGrid;
	
	@FindBy(id = "SIM_Supplier-PARENT_CREATEDZON_th")
    public WebElement iSupplier_createdOnSorting_button;	
	
	public By betweenDate_button = By.xpath("//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content']//span[@value='DATE_FILTER_BETWEEN']");
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content']//span[contains(@class,'dateOne')]/input")
	public WebElement fromDate_input;

	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content']//span[contains(@class,'dateTwo')]/input")
	public WebElement toDate_input;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//input[@id='filterApply_date']")
	public WebElement applyFilterDate_button;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'txtFilterBtn')]//input[@id='filterApply_string']")
	public WebElement applyFilterTextString_button;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'listFilterBtn')]//input[@id='filterApply_string']")
	public WebElement applyFilterListString_button;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content'] //div[contains(@class,'selectedOption')]")
	public WebElement selectFilterType_dropdown;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'textFilterBlock')]")
	public  List <WebElement> textFilterList_div;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'listFilterBlock')]")
	public  List <WebElement> listFilterList_div;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'textFilterBlock')]")
	public WebElement textFilter_div;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'listFilterBlock')]")
	public  WebElement listFilter_div;
	
	@FindBy(xpath = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//input[contains(@id,'myInputVal')]")
	public WebElement listFilter_input;
	
	@FindBy(id = "devCloseReport")
	public WebElement backToListing_button;
	
	@FindBy(id="dontSaveBeforeClose")
	public WebElement doNotSaveReport_button;
	
	@FindBy(id = "saveas_Report")
	public WebElement saveAs_button;
	
	@FindBy(xpath = "//div[@aria-describedby='saveAsReportWrap'][contains(@style,'block')]//input[@id='reportname']")
	public WebElement reportName_input;
	
	@FindBy(xpath = "//div[@aria-describedby='saveAsReportWrap'][contains(@style,'block')]//a[@data-href='#createNewFolder']")
	public WebElement createNewFolder_button;
	
	@FindBy(xpath = "//div[@aria-describedby='saveAsReportWrap'][contains(@style,'block')]//input[@id='foldername']")
	public WebElement folderName_input;
	
	@FindBy(xpath = "//div[@aria-describedby='saveAsReportWrap'][contains(@style,'block')]//input[@id='savereport']")
	public WebElement saveFolder_button;
	
	@FindBy(xpath ="//div[@aria-describedby='saveAsReportWrap']")
	public WebElement saveAsPopUp_dialog;
	
	@FindBy(id="exportReport")
	public WebElement exportReport_button;
	
	@FindBy(xpath = "//ul[contains(@class,'exportDropdown')][contains(@style,'block')]")
	public WebElement exportReport_dropdown;
	
	@FindBy(id = "exportXlsx")
	public WebElement exportToExcel_button;
	
	@FindBy(id = "exportCsv")
	public WebElement exportToCsv_button;
	
	@FindBy(id = "exportPdf")
	public WebElement exportToPdf_button;
	
	@FindBy(xpath = "//div[@id='exportProgress']//div[contains(@class,'complete')]")
	public WebElement exportProgressBar_complete;
	
	@FindBy(xpath="//div[@id='exportProgress']//div[contains(@class,'progressBar') and contains(@style,'100')]")
	public WebElement percentageValue;
	
	@FindBy(id = "downloadReport")
	public WebElement downloadReport_button;

	public By clearFilter = By.xpath("//span[@title='"+getLanguageProperty("Clear Filter")+"' and not(contains(@style,'none'))]");
	
	
	public String valueLocator = "//span[@title='<<value>>']";
	public String column_header = "//th[div/div/span[contains(@title,'<<ColumnName>>')]]";
	public String columnFilter_button = "//th[div/div/span[contains(@title,'<<ColumnName>>')]]//span[contains(@class,'filter')]";
	public String  selectFilterType_dropdown_option = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content']//li[contains(@class,'<<optioncalssValue>>')]";
	public String selectStringFilterType_option = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content']//li[contains(@value,'<<optionValueParam>>')]";
	public String searchField_input = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'customDropdown')][//li[contains(@value,'<<optionValueParam>>')]]/following-sibling::div/input";
	public String selectStringFilterLongType_option = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[@class='qtip-content']//li[@value='<<optionValueParam>>']";
	public String searchFieldLong_input = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//div[contains(@class,'customDropdown')][//li[@value='<<optionValueParam>>']]/following-sibling::div/input";
	public String select_checkbox = "//div[contains(@class,'qtipfilterAuto') and contains(@style,'block')]//label[contains(@class,'mutliSelect')][text()='<<checkboxValue>>']";
	@FindBy(xpath = "(//div[@id='dev_DessortingSingle'])[2]")
	public WebElement sortDesending_button;
	
	@FindBy(id = "status_overlay_undefined")
	public WebElement processLoader;

}
