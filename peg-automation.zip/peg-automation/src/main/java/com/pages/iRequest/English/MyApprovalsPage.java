package com.pages.iRequest.English;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MyApprovalsPage extends CommonUtility{
	
	public MyApprovalsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//table[@aria-describedby='approvalList_info']")
	public WebElement myApprovals_list;
	
	@FindBy(id="actDrop")
	public WebElement actionDropDown;
	
	@FindBy(id="printPdf")
	public WebElement print;
	
	@FindBy(id="savePdf")
	public WebElement savePdf;
	
	@FindBy(id="txtrequestComments")
	public WebElement approvalComment;
	
	@FindBy(xpath="//a[contains(@class,'approveProcess')]")
	public WebElement approveBtn;
	
	public String ApprovalStatus = getLanguageProperty("In Approval");
	
	public String Approved = getLanguageProperty("Approved");

	public String approve = getLanguageProperty("Approve");
	
	public String reject = getLanguageProperty("Reject");
}
