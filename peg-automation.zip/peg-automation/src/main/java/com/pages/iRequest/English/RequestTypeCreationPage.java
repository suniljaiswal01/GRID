package com.pages.iRequest.English;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RequestTypeCreationPage {
	
	public RequestTypeCreationPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="txtRequestTypeName")
	public WebElement requestName_input; 
	
	@FindBy(id="selconfigured")
	public WebElement endPoint_dropdown;
	
	@FindBy(id = "txtRequestDescription")
	public WebElement description_input;
	
	@FindBy(id = "createRequestType")
	public WebElement createRequestType_button;

}
