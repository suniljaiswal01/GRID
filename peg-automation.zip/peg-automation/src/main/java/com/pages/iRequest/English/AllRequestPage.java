package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class AllRequestPage extends CommonUtility{
	
	public AllRequestPage(WebDriver driver) {
		super(driver);
	}
	

	
	public By allRequest_list = By.id("reqList");

	public String createActivity = "//following-sibling::ul/li/a[text()='"+getLanguageProperty("Create an activity")+"']";
	
	public By yesButton = By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Yes")+"']");
}
