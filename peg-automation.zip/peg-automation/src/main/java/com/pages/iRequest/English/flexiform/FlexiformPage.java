package com.pages.iRequest.English.flexiform;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class FlexiformPage extends CommonUtility{

	public FlexiformPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@id='zydf-dynamicForm']//a[@id='zydf-btnDevAddSection']")
	public WebElement addSection_button;
	
	public By addSection_popup = By.xpath("//div[div/span[text()='"+getLanguageProperty("Create Section")+"']]");
	
	@FindBy(id = "zydf-dfSectionName")
	public WebElement sectionName_input;
	
	@FindBy(id = "zydf-dfSectionDescription")
	public WebElement sectionDescription_input;
	
	@FindBy(id = "zydf-dfSectionSave")
	public WebElement sectionSave_button;

	public By customField_menuClosed = By.xpath("//div[@class='zydf-sb-pad']//h2[contains(text(),'"+getLanguageProperty("Custom Fields")+"') and not(contains(@class,'open')) and contains(@class,'zydf-devClsOuterColaps')]");
	
	public By customField_menuOpen = By.xpath("//div[@class='zydf-sb-pad']//h2[contains(text(),'"+getLanguageProperty("Custom Fields")+"') and contains(@class,'open') and contains(@class,'zydf-devClsOuterColaps')]");
	
	@FindBy(xpath = "//ul[@id='zydf-devLeftDragList']/li")
	public List<WebElement> customFields_list;
	
	public By fieldLibrary_menuClosed = By.xpath("//div[@class='zydf-sb-pad']//h2[contains(@class,'zydf-devClsOuterColaps') and contains(@class,'open')][text()='"+getLanguageProperty("Field Library")+"']");
	
	public By fieldLibrary_menuOpen = By.xpath("//div[@class='zydf-sb-pad']//h2[contains(@class,'zydf-devClsOuterColaps') and contains(@class,'open')][text()='"+getLanguageProperty("Field Library")+"']");
	
	@FindBy(id = "zydf-dfColTblName")
	public WebElement tableName_input;
	
	@FindBy(id = "zydf-dfColTblKey")
	public WebElement tableKey_input;
	
	@FindBy(id = "zydf-dfCollectionSave")
	public WebElement tableSave_button;
	
	public By saveFlexiForm_button = By.xpath("//input[@name='saveEform']");

	public By fieldInCollection  =By.xpath("//form[@id='zydf-frmCollectionPopUp']//label[span[text()='"+getLanguageProperty("Region")+"']]/input");
	
	public String customField = "//div[@class='zydf-sb-pad']//h2[contains(text(),'"+getLanguageProperty("Custom Fields")+"') and contains(@class,'open') and contains(@class,'zydf-devClsOuterColaps')]"; 
	
	public String column = "1 column";
	
}
