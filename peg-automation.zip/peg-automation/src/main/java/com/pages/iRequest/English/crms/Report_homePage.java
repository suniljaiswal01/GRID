package com.pages.iRequest.English.crms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class Report_homePage extends CommonUtility {
	CommonUtility commonUtility;
	public Report_homePage(WebDriver driver) {
		commonUtility = new CommonUtility(); 
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[@id='createReport']")
	public WebElement createReport_button;
}
