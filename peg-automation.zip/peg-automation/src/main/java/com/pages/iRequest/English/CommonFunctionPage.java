package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class CommonFunctionPage extends CommonUtility{

	public CommonFunctionPage(WebDriver driver) {
		super(driver);
	}
	
	public By selectCategory = By.xpath("//input[@value='"+getLanguageProperty("Select Category")+"']");
	
	public By selectCategoryPopUp = By.xpath("//div[@id='selectPopUp']/preceding-sibling::div/../div/span[text()='"+getLanguageProperty("Select Category")+"']/../..");
	
	public By selectBU = By.xpath("//input[@value='"+getLanguageProperty("Select Business Unit")+"']");
	
	public By selectBUPopUp = By.xpath("//div[@id='selectPopUp']/preceding-sibling::div/../div/span[text()='"+getLanguageProperty("Select Business Unit")+"']/../..");
	
	public By selectCategoryExact = By.xpath("//select[@id='searchCatSelect']/option[text()='"+getLanguageProperty("Exact")+"']");
	
	public By GoBtn = By.xpath("//input[@value='"+getLanguageProperty("Go")+"']");
	
	public By DoneBtn = By.xpath("//div[@id='selectPopUp']//input[@title='"+getLanguageProperty("Done")+"']");
	
	
	
	
}
