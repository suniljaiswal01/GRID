package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportsPage extends CommonUtility{

	public ReportsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@class='prepackagedRe_RMS']")
	public WebElement prePackagedReport_label;
	
	public By export = By.xpath("//a[contains(text(), '"+getLanguageProperty("Export")+"')]");
	
	public String  myReport = "//div[div[text()='"+getLanguageProperty("Reports")+"']]//a[@title='<<reportName>>']"; 
}
