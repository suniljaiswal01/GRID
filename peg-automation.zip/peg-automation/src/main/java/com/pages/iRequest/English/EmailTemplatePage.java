package com.pages.iRequest.English;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmailTemplatePage {
	
	public EmailTemplatePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="frmEmailTemplateConfig")
	public WebElement emailTemplatePage;
	
	@FindBy(xpath = "//div[@class='dataTables_processing']")
	public WebElement dataProcessing_loader;
	
	@FindBy(id="sidebar")
	public WebElement sidebar;
}
