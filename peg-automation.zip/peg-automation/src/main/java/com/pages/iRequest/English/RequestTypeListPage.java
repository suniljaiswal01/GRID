package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RequestTypeListPage {
	public RequestTypeListPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	public By createNewRequest_button = By.id("lnkAddRequestType");
	
	@FindBy(xpath = "//table[@id='reqList'][@aria-describedby='reqList_info']")
	public WebElement requestType_list;
	
	@FindBy(xpath = "//div[@class='dataTables_processing']")
	public WebElement dataProcessing_loader;
}
