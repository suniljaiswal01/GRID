package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class CustomizePage extends CommonUtility{
	
	public CustomizePage(WebDriver driver) {
		super(driver);
	}
	
	public By RequestType_link = By.xpath("//a[text()='"+getLanguageProperty("Request Type")+"']");

	public By dataProcessing_loader = By.xpath("//div[@class='dataTables_processing']");
		
	public By emailTemplate = By.id("emailtemplates");
	
	public By generalSettings = By.xpath("//a[text()='"+getLanguageProperty("General Settings")+"']");
}
