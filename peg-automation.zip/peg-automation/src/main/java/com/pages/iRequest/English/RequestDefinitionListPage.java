package com.pages.iRequest.English;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class RequestDefinitionListPage extends CommonUtility {
	
	public RequestDefinitionListPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "lnkAddRequestDef")
	public WebElement CreateReqDefinition_button;

	@FindBy(id = "reqList")
	public WebElement reqDefinition_table;

	public String active = getLanguageProperty("Active"); 

	public String draft = getLanguageProperty("Draft");  
	
	public String inActive = getLanguageProperty("Inactive");  

	public String deactivate = "//li/a[text()='"+getLanguageProperty("Deactivate")+"']";
	
	public String edit = "//li/a[text()='"+getLanguageProperty("Edit")+"']";
	
	public String view = "//li/a[text()='"+getLanguageProperty("View")+"']";
	
	public By deactivatePopUp = By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[text()='"+getLanguageProperty("Deactivate")+"']]");

	public String delete = "//li/a[text()='"+getLanguageProperty("Delete")+"']";

	public By confimPopUp = By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[text()='"+getLanguageProperty("Confirm")+"']]");
	
	public By okBtn = By.xpath("//div[contains(@style,'block')]//button/span[text()='"+getLanguageProperty("OK")+"']");
	
	@FindBy(id="auditTrail")
	public WebElement auditTrail;

	public By backButton = By.xpath("//a[@title='"+getLanguageProperty("Back to listing page")+"']");
	
	@FindBy(id="saveAsDraft")
	public WebElement saveAsDraft;
	
}
