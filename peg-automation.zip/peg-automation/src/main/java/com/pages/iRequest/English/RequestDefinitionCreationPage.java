package com.pages.iRequest.English;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RequestDefinitionCreationPage {

	public RequestDefinitionCreationPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="frmRequestDefCreation")
	public WebElement reqDef_form;
	
	
	@FindBy (id="lblisrequired")
	public WebElement requiredDuringRequestSubmission;
	
	@FindBy (id="autocompRequestManager")
	public WebElement autocompRequestManager;
	
	@FindBy(id="txtRequestDefName")
	public WebElement reqDefinition_input;
	
	@FindBy(id="isEditableManagerReq")
	public WebElement isEditableManagerReq;
	
	@FindBy(id="assignToRmGroup")
	public WebElement assignToRmGroup;
	
	@FindBy(id="selRequestDefinitionAvailableFor")
	public WebElement selectAvailableFor_dropdown;
	
	@FindBy(id= "txtRequestTypeName")
	public WebElement requestTypeName_dropdown;
	
	
	@FindBy(xpath = "//a[@for='dev_configure_eform']")
	public WebElement flexiform_switch;
	
	@FindBy(xpath = "//div[a[@id='eformConfigure']]")
	public WebElement configureFlexi_button;
	
	@FindBy(xpath = "//a[@for='dev_configure_linkedDocument']")
	public WebElement LinkedDocument_switch;
	
	@FindBy(xpath = "//div[a[@id='linkedDocumentConfigure']]")
	public WebElement configureLinkedDocument_button;
	
	@FindBy(id="createRequestDef")
	public WebElement createReqDef_button;
	
	@FindBy(id = "assignToRmIndividual")
	public WebElement assignToindividual_checkbox;
	
	@FindBy(id = "assignedToDropdown")
	public WebElement assignedto_dropdown;
	
	@FindBy(id="singleAssign")
	public WebElement singleAssign_option;
	
	@FindBy(id = "txtAssignedTo")
	public WebElement assignedTo_autocomplete;
	
	@FindBy(id="addReqType")
	public WebElement requestType;
	
	@FindBy(id="frmRequestTypeCreation")
	public WebElement newRequestDialog;
	
	@FindBy(id="txtDialogRequestTypeName")
	public WebElement requestName_input;
	
	@FindBy(id="selconfigured")
	public WebElement endPoint_dropdown;
	
	@FindBy(id="txtDialogRequestDescription")
	public WebElement description_input;
	
	@FindBy(id="btnRequestTypeCreate")
	public WebElement createRequestType_button;
}
