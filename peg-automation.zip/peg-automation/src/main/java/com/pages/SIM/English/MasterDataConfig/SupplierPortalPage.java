package com.pages.SIM.English.MasterDataConfig;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class SupplierPortalPage extends CommonUtility {

	public SupplierPortalPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	
	public List<WebElement> objSupplierPortal= driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Supplier Portal")+"']"));

}
