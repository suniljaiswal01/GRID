package com.pages.SIM.English.MyReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportsPage extends CommonUtility {

	public ReportsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	

	public By objMoreOptions= By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More Option")+"')]");
	
	
	public By objShareReport= By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Share")+"']");
	
	
	public By objSuccess= By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Go to report")+"']");
	
	
	public By objGoToReportBtn= By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Go to report")+"']");
	
	
	public By objModifyBtn= By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Modify")+"']");
	

	public By objNextBtn= By.xpath("//input[@title='"+getLanguageProperty("Next")+"']");
	
	
	public By objRunReportBtn= By.xpath("//div[@id='topbar-inner']//input[@title='"+getLanguageProperty("Run Report")+"']");
	

	public By objSaveAsBtn= By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Save As")+"']");
	
	
	public By objExportBtn= By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("Export")+"')]");
		
	
}
