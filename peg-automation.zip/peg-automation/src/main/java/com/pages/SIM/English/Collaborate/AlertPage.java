package com.pages.SIM.English.Collaborate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class AlertPage extends CommonUtility{

	public AlertPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public static By exactSearchType = By.xpath(
			"//select[@id='searchType']/option[text()='"+getLanguageProperty("Exact")+"']");
	
	public By alertDueDtLbl = By.xpath("//label[contains(text(),'"+getLanguageProperty("Alert Due Date")+"')]");
	
}
