package com.pages.SIM.English.UserManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ManageRolesPage extends CommonUtility {

	public ManageRolesPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	
	public By objManageRoles= By.xpath("//table//table//td[text()='"+getLanguageProperty("Manage Roles")+"']");
	
	
	public By objManageUsers= By.xpath("//div[@class='ScrollDivApprover']/table/tbody/tr[2]/td[last()]/label[@title='"+getLanguageProperty("Manage Users")+"']");
	
	
	
}
