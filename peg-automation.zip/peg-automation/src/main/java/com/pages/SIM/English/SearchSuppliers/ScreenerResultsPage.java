package com.pages.SIM.English.SearchSuppliers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ScreenerResultsPage extends CommonUtility {

	public ScreenerResultsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	/*@FindBy(xpath = "//h1[text()='"+getLanguageProperty("Screener Results")+"']")
	public WebElement objScreenerResPg;*/
	
	public String screenerResPgXpath = "//h1[text()='"+getLanguageProperty("Screener Results")+"']";
	
	/*@FindBy(xpath = "//input[@title='"+getLanguageProperty("Close")+"']")
	public WebElement objCloseBtn;*/
	
	public String closeBtnXpath = "//input[@title='"+getLanguageProperty("Close")+"']";
	
	
	public By objSaveAsBtn= By.xpath("//a[text()='"+getLanguageProperty("Save As")+"']");
	

	public By objSaveBtn= By.xpath("//input[@value='"+getLanguageProperty("Save")+"']");
	
	
	public By objExportBtn= By.xpath("//a[i[text()='"+getLanguageProperty("Export")+"']]");
	
	
	
}

