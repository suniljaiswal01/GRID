package com.pages.SIM.English.UserManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MyPreferencesPage extends CommonUtility {

	public MyPreferencesPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	
	public By objNotificationPrefs= By.xpath("//table//table//td[contains(text(),'"+getLanguageProperty("My Notification Preferences")+"')]");
	
}
