package com.pages.SIM.English.MasterDataConfig;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ApplicationConfigurationPage extends CommonUtility {

	public ApplicationConfigurationPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	
	public By objAppConfig= By.xpath("//table//table//td[text()='"+getLanguageProperty("Application Configuration")+"']");
	
	
	
}
