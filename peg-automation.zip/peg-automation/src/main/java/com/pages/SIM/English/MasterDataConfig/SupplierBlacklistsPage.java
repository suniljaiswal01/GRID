package com.pages.SIM.English.MasterDataConfig;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class SupplierBlacklistsPage extends CommonUtility {

	public SupplierBlacklistsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	
	public By objSupplierBlacklists= By.xpath("//table//table//td[text()='"+getLanguageProperty("Supplier Blacklists")+"']");
	
	
	public By objEditBtn= By.xpath("//div[@class='ScrollDivApprover']/table/tbody/tr[2]/td[last()]/a[@title='"+getLanguageProperty("Edit")+"']");
	

	public By objSaveBtn= By.xpath("//div[@class='ScrollDivApprover']/table/tbody/tr[2]/td[last()]/a[@title='"+getLanguageProperty("Save")+"']");
	
	
	public By objCancelBtn= By.xpath("//div[@class='ScrollDivApprover']/table/tbody/tr[2]/td[last()]/a[@title='"+getLanguageProperty("Cancel")+"']");
	
}
