package com.pages.SIM.English.ManageSuppliers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class CreateSupplierPage extends CommonUtility {

	public CreateSupplierPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	
	public By objAddrTab= By.xpath("//div[@id='container']//a[@class='OppTab'][span[text()='"+getLanguageProperty("Address")+"']]");
	
	
	public By objContactDetailsLink= By.xpath("//div[@class='LeftTabList']/a[span[text()='"+getLanguageProperty("Contact Details")+"']]");;
	
	
	public By objSaveSubmitBtn= By.xpath("//input[@value='"+getLanguageProperty("Save & Submit")+"']");;
	
	
	public By objSubmitReqPopup= By.xpath("//div[@id='pnl_SubmitAction'][div/div[text()='"+getLanguageProperty("Submit Request")+"']]");;
	
	
	public By objPurchasingDetailsLeftTab= By.xpath("//a[contains(@class,'LeftTab')][span[text()='"+getLanguageProperty("Purchasing Details")+"']]");
	
	
	public By objGlobalPaymentTermsLeftTab= By.xpath("//a[contains(@class,'LeftTab')][span[text()='"+getLanguageProperty("Global Payment Terms")+"']]");
	
	
	public By objLocalPaymentTermsLeftTab= By.xpath("//a[contains(@class,'LeftTab')][span[text()='"+getLanguageProperty("Local Payment Terms")+"']]");
	
	
	public By objNormalizedAddrPopup= By.xpath("//div[@class='modalDialog'][div/div[text()='"+getLanguageProperty("Normalized Address")+"']]");
	
	
	public By objNormalizedAddrPopupOkBtn= By.xpath("//div[@class='modalDialog'][div/div[text()='"+getLanguageProperty("Normalized Address")+"']]//input[@value='"+getLanguageProperty("Ok")+"']");;
	
	public String editSupplierXpath = ".//li/a[text()='"+getLanguageProperty("Edit")+"']";
	public String editRequestType = "Edit";
	
	public String approvedSupplierStatus = "Approved";
	public String addrLbl = "Address";
	public String HQAddrLbl = "Head Quarter Address (HQ)";
	
}
