package com.pages.SIM.English.SearchSuppliers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class StandardSearchPage extends CommonUtility {

	public StandardSearchPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	

	public By objMyFacilities= By.xpath("//select[@id='reloadGridDropDown']/option[text()='"+getLanguageProperty("My Facilities")+"']");
	

	public By objPotentialSuppliers= By.xpath("//select[@id='reloadGridDropDown']/option[text()='Potential Supplier(s)']");
	
	
	public By objOtherFacilities= By.xpath("//select[@id='reloadGridDropDown']/option[text()='"+getLanguageProperty("Other Facilities")+"']");
	
	public String extendSupplierXpath = "//a[text()='"+getLanguageProperty("Extend Supplier")+"']";
	

	public By objExtendPopup= By.xpath("//div[@role='dialog']//div[@id='pnl_extendOrInviteSupplier']");
	

	public By objOnboardSupplierPopup= By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Onboard Supplier")+"']]");
	
	public String onboardSupplierLink = "//table[@id='dataGrid']/tbody/tr[td[3]/a[text()='<<supplierName>>']]/td[last()]//a[text()='"+getLanguageProperty("Onboard Supplier")+"']";
	
	public String changeGlobalStatusSupplierLink = "//table[@id='dataGrid']/tbody/tr[td[3]/a[text()='<<supplierName>>']]/td[last()]//a[text()='"+getLanguageProperty("Change Global Status")+"']";
	
	public String deleteSupplierLink = "//table[@id='dataGrid']/tbody/tr[td[3]/a[text()='<<supplierName>>']]/td[last()]//a[text()='"+getLanguageProperty("Delete Supplier")+"']";
	
}
