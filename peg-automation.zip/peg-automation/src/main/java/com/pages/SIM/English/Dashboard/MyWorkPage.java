package com.pages.SIM.English.Dashboard;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MyWorkPage extends CommonUtility{

	public MyWorkPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public List<WebElement> proceedBtnList= driver.findElements(By.xpath("//table[@id='myApprovals-grid']/tbody/tr/td[last()]/label[@title='"+getLanguageProperty("Proceed")+"']"));
		
	public List<WebElement> potentialSuppProceedBtnList= driver.findElements(By.xpath("//table[@id='myPotentialSuplierApprovals-grid']/tbody/tr/td[last()]/label[@title='"+getLanguageProperty("Proceed")+"']"));
	
	public By objClrSearchResults= By.xpath("//div[@id='searchPanel_myRequests']//a[text()='"+getLanguageProperty("Clear search results")+"']");
		
	public By objViewArchivedReq = By.xpath("//div[@id='searchPanel_myRequests']//a[contains(text(),'"+getLanguageProperty("View Archived Requests")+"')]");
	
	public By objPurchasingTab= By.xpath( "//div[@id='container']//a[@class='OppTab'][span[text()='"+getLanguageProperty("Purchasing")+"']]");
	
	public By objAdressTab= By.xpath("//div[@id='container']//a[@class='OppTab'][span[text()='"+getLanguageProperty("Address")+"']]");
	
	public By objRuleTestingTab= By.xpath("//div[@id='container']//a[@class='OppTab'][span[text()='"+getLanguageProperty("RULE TESTING")+"']]");
	
	public By objRuleTestingSubView= By.xpath("//a[contains(@class,'LeftTab')][span[text()='"+getLanguageProperty("RULETESTINGSUBVIEW")+"']]");
		
	public By objPotentialSuppProceedBtn= By.xpath("//table[@id='myPotentialSuplierApprovals-grid']/tbody/tr[1]/td[last()]/label[@title='"+getLanguageProperty("Proceed")+"']");
	
	public String statusColLbl = "Status";
	public String editRequest = "//table[@id='<<gridID>>']/tbody/tr[1]/td[last()]/label[@title='"+getLanguageProperty("Edit Request")+"']";
	public String ruleTestingTabXpath = "//div[@id='container']//a[@class='OppTab'][span[text()='"+getLanguageProperty("RULE TESTING")+"']]";
	public String proceedBtnXpath = "//table[@id='myApprovals-grid']/tbody/tr[//td/a[contains(text(),'<<supplierName>>')]]/td[last()]/label[@title='"+getLanguageProperty("Proceed")+"']";
	
}
