package com.pages.iMaster;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import common.Functions.iRequest_CommonFunctions;

public class GenericMasterPage extends iRequest_CommonFunctions {
	public GenericMasterPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}

	
	@FindBy(xpath = "//input[@class='srchTxt']")
	public WebElement searchInput;
	
	public By goButton = By.xpath("//input[@value='"+getLanguageProperty("Go")+"']");

	public By currencyDropDown =By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Currency")+"')]");
	
	@FindBy(xpath = "//li[contains(@aria-controls,'confPurpose')]")
	public WebElement configureButton;
	
	public By addPurposeButton = By.xpath("//div[@id='confPurpose']//a[contains(text(),'"+getLanguageProperty("Add Purpose")+"')]");
	
	@FindBy(id="closeWizard")
	public WebElement closeWizard;
	
	@FindBy(id="txtUC1")
	public WebElement uniqueCode1;
	
	@FindBy(id="txtPurposeName")
	public WebElement purposeName;
	
	@FindBy(id="btnAddConfPurpose")
	public WebElement purposeButton;
	
	@FindBy(xpath="//div[@id='configurePurpose_wrapper']//input[@class='srchTxt']")
	public WebElement configureSearchInput;
	
	public By searchNameDropDown =By.xpath("//select/option[text()='"+getLanguageProperty("Name")+"']");
	
	public By configureGoButton = By.xpath("//div[@id='configurePurpose_wrapper']//input[@value='"+getLanguageProperty("Go")+"']");

	public By exchangeRate = By.xpath("//div[@id='exchangeRate']//a[contains(text(),'"+getLanguageProperty("Add Exchange Rate")+"')]");
	
	@FindBy(id="txtRate")
	public WebElement txtRate;
	
	@FindBy(id="btnAddExchangeRate")
	public WebElement addExchangeBtn;
	
	@FindBy(xpath="//div[@id='exchangeRateList_wrapper']//input[@class='srchTxt']")
	public WebElement exchangeRateSearch;

	public By purposeDropDown =By.xpath("//select/option[text()='"+getLanguageProperty("Purpose")+"']");

	public By exchangeRateGoBtn = By.xpath("//div[@id='exchangeRateList_wrapper']//input[@value='"+getLanguageProperty("Go")+"']");
	
	public By UOMbutton =By.xpath("//div[@id='addTab']//a[text()='"+getLanguageProperty("Add UoM")+"']");
	
	@FindBy(id="uomCode")
	public WebElement uomCode;
	
	@FindBy(id="descUOM")
	public WebElement uomDesc;

	public By UomIntegerDropDown=By.xpath("//select[@id='quantType']//option[text()='"+getLanguageProperty("Integer")+"']");
	
	@FindBy(id="erpId")
	public WebElement erpIdInput;
	
	@FindBy(id="btnAddUOM")
	public WebElement addUomBtn;
	
	@FindBy(xpath="//div[@id='unitMeasureListing_wrapper']//input[@class='srchTxt']")
	public WebElement uomSearchInput;
	
	public By uomDropDown=By.xpath("//select/option[text()='"+getLanguageProperty("UoM Code")+"']");
	
	public By uomGoBtn=By.xpath("//div[@id='unitMeasureListing_wrapper']//input[@value='"+getLanguageProperty("Go")+"']");
	
	public By countryDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Country")+"')]");
	
	@FindBy(xpath="//table[contains(@class,'zytbl')]/tbody/tr[1]/td[contains(@class,'iStatus')]/a")
	public WebElement countryStatus;
	
	@FindBy(xpath="//div[contains(@class,'iConfirmBox ')]")
	public WebElement countryConfirmBox;

	public By countryConfirmBoxYes=By.xpath("//div[contains(@class,'iConfirmBox ')]//span[text()='"+getLanguageProperty("Yes")+"']");
	
	public By stateDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("State")+"')]");
	
	public By categoryGroupDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Group Name")+"')]");
	
	@FindBy(xpath="//li[contains(@aria-controls,'newPaymentTerms')]")
	public WebElement paymentTerms;
	
	@FindBy(id="txtName")
	public WebElement txtName;
	
	@FindBy(id="txtCrdtDays")
	public WebElement txtCrdtDays;
	
	@FindBy(id="txtDscntDays")
	public WebElement txtDscntDays;
	
	@FindBy(id="txtDscntPer")
	public WebElement txtDscntPer;
	
	@FindBy(id="txtUC")
	public WebElement txtUC;
	
	@FindBy(id="txtTerms")
	public WebElement txtTerms;
	
	@FindBy(id="txtERPId")
	public WebElement txtERPId;
	
	@FindBy(id="txtErpId")
	public WebElement txtErpId;
	
	@FindBy(id="txtErpID")
	public WebElement txtErpID;
	
	@FindBy(id="txtCode")
	public WebElement txtCode;
	
	@FindBy(id="btnAddPaymentTerms")
	public WebElement addPaymentBtn;
	
	public By paymentTermsDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Payment Term")+"')]");
	
	@FindBy(xpath="//li[contains(@aria-controls,'newRegion')]")
	public WebElement regionBtn;
	
	@FindBy(id="btnAddDeliveryTerm")
	public WebElement addDeliveryTermBtn;
	
	public By dropdownByName=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Name")+"')]");
	
	@FindBy(xpath="//li[contains(@aria-controls,'newPurchaseType')]")
	public WebElement purchaseType;
		
	@FindBy(id="txtPurchaseTypeName")
	public WebElement txtPurchaseTypeName;
	
	@FindBy(id="btnAddPurchaseType")
	public WebElement btnAddPurchaseType;
	
	@FindBy(xpath="//li[contains(@aria-controls,'newSupplierCodeMap')]")
	public WebElement supplierCode;
	
	public By supplierCodeDropDownByCategory=By.xpath("//select[@id='selMapType']/option[@title='"+getLanguageProperty("Category")+"']");
	
	@FindBy(id="txtSupplierSideCode")
	public WebElement txtSupplierSideCode;
	
	@FindBy(id="txtSupplierDesc")
	public WebElement txtSupplierDesc;
	
	@FindBy(xpath="//span[@id='spanCategoryAutocomplete']/a[@class='showCategoryTree']")
	public WebElement supplierCategoryTree;
	
	
	@FindBy(xpath="//div[contains(@class,'diagCategoryTree') and contains(@style,'block')]//input[@id='btnSaveCategory']")
	public WebElement supplierCategoryTreeSaveBtn;
	
	
	@FindBy(id="chkPunchoutsInvoices")
	public WebElement chkPunchoutsInvoices;

	@FindBy(id="chkPurchaseOrders")
	public WebElement chkPurchaseOrders;
	
	@FindBy(id="chkCatalogs")
	public WebElement chkCatalogs;
	
	@FindBy(id="btnAddSupplierCodeMap")
	public WebElement btnAddSupplierCodeMap;

	public By supplierSideCodeDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[text()='"+getLanguageProperty("Supplier Side Code")+"']");
	
		
	@FindBy(xpath="//li[contains(@aria-controls,'newAddCollection')]")
	public WebElement customMaster;
	
	
	@FindBy(id="zydf-txtEntityName")
	public WebElement customMasterName;
	
	@FindBy(id="zydf-eformConfigure")
	public WebElement configureCustomMaster;
	
	@FindBy(id="zydf-createEntity")
	public WebElement addCustomMasterBtn;
	
	public By customMasterDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[text()='"+getLanguageProperty("Custom Master")+"']");
	
	
	@FindBy(xpath="//li[contains(@aria-controls,'newCategory')]")
	public WebElement category;
	
	@FindBy(id="btnAddCategory")
	public WebElement addCategoryBtn;
	
	
	@FindBy(xpath="//a[@class='showCategoryTree']")
	public WebElement categoryTree;
	
	
	@FindBy(id="txtCategoryDescription")
	public WebElement txtCategoryDescription;
	
	public By categoryNameDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Category Name")+"')]");
	
	@FindBy(xpath="//span[text()='Back to Home Page']")
	public List<WebElement> backToHomeButtons;
	
	public By backToHomeButton=By.xpath("//span[text()='"+getLanguageProperty("Back to Home Page")+"']");
	


	

}



