package com.pages.iMaster;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import common.Functions.iRequest_CommonFunctions;

public class OrganizationStructurePage extends iRequest_CommonFunctions {
	public OrganizationStructurePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}

	
	@FindBy(xpath = "//input[@class='srchTxt']")
	public WebElement searchInput;
	
	public By goButton=By.xpath("//input[@value='"+getLanguageProperty("Go")+"']");
	
	
	@FindBy(xpath="//li[contains(@aria-controls,'newRegion')]")
	public WebElement regionBtn;
	
	@FindBy(xpath = "//input[@id='txtUC' and @disabled]")
	public List<WebElement> uniqueCodeCheck;

	@FindBy(id="btnAddRegion")
	public WebElement addRegionBtn;
	
	@FindBy(id="txtUC")
	public WebElement txtUC;
	
	@FindBy(id="txtName")
	public WebElement txtName;
	
	public By dropdownByName=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Name")+"')]");
	

	@FindBy(id="closeWizard")
	public WebElement closeWizard;
	
	@FindBy(xpath="//li[contains(@aria-controls,'newAddress')]")
	public WebElement address;
	
	
	@FindBy(id="btnAddAddress")
	public WebElement addAddressButton;
	
	
	@FindBy(id="txtMaster_address_line1")
	public WebElement txtMaster_address_line1;
	
	@FindBy(id="txtMaster_address_line2")
	public WebElement txtMaster_address_line2;
	
	@FindBy(id="txtMaster_address_line3")
	public WebElement txtMaster_address_line3;
	
	@FindBy(id="txtMaster_address_line4")
	public WebElement txtMaster_address_line4;
	
	@FindBy(id="txtFax")
	public WebElement txtFax;
	
	@FindBy(id="txtPhone")
	public WebElement txtPhone;
	
	@FindBy(id="txtEmail")
	public WebElement txtEmail;
	
	@FindBy(id="txtCity")
	public WebElement txtCity;
	
	@FindBy(id="txtNumber")
	public WebElement txtNumber;
	
	@FindBy(id="chkBillTo")
	public WebElement chkBillTo;
	
	
	@FindBy(id="chkShipTo")
	public WebElement chkShipTo;
	
	
	@FindBy(xpath="//li[contains(@aria-controls,'newLocation')]")
	public WebElement  newLocation;
	
	@FindBy(id="btnAddLocation")
	public WebElement btnAddLocation;
	
	@FindBy(id="txtAPContact")
	public WebElement txtAPContact;
	
	@FindBy(xpath="//li[contains(@aria-controls,'newOrgLevel')]")
	public WebElement newCompany;
	
	@FindBy(id="btnAddLevelData")
	public WebElement addNewCompany;
	
	@FindBy(id="selectedLocation")
	public WebElement selectedLocation;
	
	
	@FindBy(xpath="//div[contains(@class,'ui-dialog-content')]//input[@class='srchTxt']")
	public WebElement dialogBoxPopUpSearchBox;
	
	public By dialogBoxPopUpGoBtn=By.xpath("//div[contains(@class,'ui-dialog-content')]//input[@value='"+getLanguageProperty("Go")+"']");
	
	@FindBy(xpath="//div[contains(@class,'ui-dialog-content')]//table//tbody//input")
	public WebElement dialogBoxInput;
	
	public By dropDownLocation=By.xpath("//option[text()='"+getLanguageProperty("Location name")+"']");
	
	public By dialogSaveBtn=By.xpath("//div[contains(@class,'ui-dialog-content')]//input[@value='"+getLanguageProperty("Save")+"']");
	
	
	@FindBy(id="erpId")
	public WebElement erpIdInput;
	
	@FindBy(id="txtLegalName")
	public WebElement txtLegalName;
	
	
	@FindBy(xpath="//li[contains(@aria-controls,'newDepartment')]")
	public WebElement newDepartment;
	
	
	@FindBy(id="txtDescription")
	public WebElement txtDescription;
	
	@FindBy(id="txtCostCenterCode")
	public WebElement txtCostCenterCode;
	
	@FindBy(id="btnAddCostCenter")
	public WebElement btnAddCostCenter;
	
	@FindBy(id="btnAddProject")
	public WebElement btnAddProject;

	public By projectTaskNameDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Project/Task Name")+"')]");
	
	@FindBy(id="txtTypeProject")
	public WebElement txtTypeProject;
	
	@FindBy(id="txtERPCode")
	public WebElement txtERPCode;
	
	@FindBy(xpath="//li[contains(@aria-controls,'newScope')]")
	public WebElement newScope;
	
	@FindBy(id="txtDefinitionName")
	public WebElement txtDefinitionName;
	
	@FindBy(id="btnAddScope")
	public WebElement btnAddScope;
	
	public By scopeNameDropDown=By.xpath("//select[@class='dev_dataTableFilter']/option[contains(text(),'"+getLanguageProperty("Scope Name")+"')]");
	
	@FindBy(id="txtScopeDes")
	public WebElement txtScopeDes;
	
	
	@FindBy(xpath="//li[contains(@aria-controls,'newDesignation')]")
	public WebElement newDesignation;
	
	@FindBy(id="txtLevel")
	public WebElement txtLevel;
	
	@FindBy(id="btnAddDesignation")
	public WebElement btnAddDesignation;
	
	@FindBy(xpath="//li[contains(@aria-controls,'newClientSystem')]")
	public WebElement newClientSystem;
	
	
	@FindBy(id="txtClientSystemDesc")
	public WebElement txtClientSystemDesc;
	
	@FindBy(id="btnAddClientSystem")
	public WebElement btnAddClientSystem;
	
	
	@FindBy(id="txtERPId")
	public WebElement txtERPId;
	
	@FindBy(id="txtErpId")
	public WebElement txtErpId;
	
	@FindBy(id="txtErpID")
	public WebElement txtErpID;

	@FindBy(id="btnAddDepartment")
	public WebElement btnAddDepartment;
	
}
