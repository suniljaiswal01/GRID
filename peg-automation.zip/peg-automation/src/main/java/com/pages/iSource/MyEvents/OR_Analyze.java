package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_Analyze extends CommonUtility {
	
	public OR_Analyze(WebDriver driver) {
		super(driver);
	}

	public By objAnalyzeBtn = By.xpath("//input[@value='"+getLanguageProperty("Analyze")+"']");

	public By objViewResponsesBtn = By.xpath("//input[@value='"+getLanguageProperty("View Responses")+"']");

	public By objCreateScoresheetBtn= By.xpath("//input[@value='"+getLanguageProperty("Create Scoresheet")+"']");

	public By objCreateScenarioBtn= By.xpath("//input[@value='"+getLanguageProperty("Create Scenario")+"']");

	public By objGoToBidOptimizationBtn= By.xpath("//input[@value='"+getLanguageProperty("Go to Bid Optimization")+"']");
	

	public By objShortCommAnalysisBtn= By.xpath("//input[@value='"+getLanguageProperty("Shortlist for Commercial Analysis")+"']");

}
