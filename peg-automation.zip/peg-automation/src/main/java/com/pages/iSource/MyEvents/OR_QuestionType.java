package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_QuestionType extends CommonUtility{
	
	public OR_QuestionType(WebDriver driver) {
		super(driver);
	}
	
	public By objSummaryOkBtn = By.xpath("//div[@class='impSummaryPopUp']//input[@value='"+getLanguageProperty("OK")+"']");
	
	public By objNextBtn = By.xpath("//div[@class='stickyButtonBar']//input[@value='"+getLanguageProperty("Next")+"']");

	public By objPopupOkBtn =By.xpath("//div[@id='zys-popup-container']//input[@value='"+getLanguageProperty("OK")+"']");
	
}
