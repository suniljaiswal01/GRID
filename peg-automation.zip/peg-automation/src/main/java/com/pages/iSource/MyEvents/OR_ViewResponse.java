package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_ViewResponse extends CommonUtility{
	
	public OR_ViewResponse(WebDriver driver) {
		super(driver);
	}

	public By objBackBtn = By.id("backDvId");

}
