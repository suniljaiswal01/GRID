package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_Collect extends CommonUtility {
	
	public OR_Collect(WebDriver driver) {
		super(driver);
	}
	
	public By objSendForApprovalBtn = By.xpath("//div[@id='docInfoBtns']//input[@value='"+getLanguageProperty("Send For Approval")+"']");
	
	public By objPublishBtn = By.xpath("//div[@id='docInfoBtns']//input[@value='"+getLanguageProperty("Publish")+"']");
	
	public By objPrepareResponseBtn = By.xpath("//input[@value='"+getLanguageProperty("Prepare Response")+"']");

	public By objAddBtn = By.xpath("//div[@class='stickyButtonBar']//input[@value='"+getLanguageProperty("Add")+"']");

	public By objNegotiateBtn = By.xpath("//input[@value='"+getLanguageProperty("Negotiate")+"']");
	
}
