package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_CreateTemplate extends CommonUtility{
	
	public OR_CreateTemplate(WebDriver driver) {
		super(driver);
	}
	
	public By objModifyDraftBtn = By.xpath("//input[@value='"+getLanguageProperty("Modify Draft")+"']");
	
	public By objSaveAndContinueBtn = By.xpath("//input[@value='"+getLanguageProperty("Save and Continue")+"']");
	
	public By objDoneBtn = By.xpath("//input[@value='"+getLanguageProperty("Done")+"']");

	public By objQuestNextBtn = By.xpath("//div[@id='questionDiv']//input[@value='"+getLanguageProperty("Next")+"']");
	
	public By objTNCNextBtn = By.xpath("//div[@id='tncMRDiv']//input[@value='"+getLanguageProperty("Next")+"']");
	
	public By objVendorNextBtn = By.xpath("//div[@id='vendorDiv']//input[@value='"+getLanguageProperty("Next")+"']");
	
	public By objScoresheetFinishBtn = By.xpath("//div[@id='scoreSheetDiv']//input[@value='"+getLanguageProperty("Finish")+"']");

}
