package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_AwardSummary extends CommonUtility  {
	
	public OR_AwardSummary(WebDriver driver) {
		super(driver);
	}
	
	public By objCreateContractBtn = By.xpath("//input[@id='sticky_award' and @value='Create Contract']");
	
	public By objSendForApprovalBtn = By.xpath("//input[@id='sticky_award' and @value='Send For Approval']");

	public By objAwardScenarioBtn = By.xpath("//input[@id='sticky_award' and @value='Award Scenario']");
}
