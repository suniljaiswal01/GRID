package com.pages.iSource.MyEvents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class OR_FullSource {
	
	public OR_FullSource(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
}
