package com.pages.iSource.MyEvents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class OR_ScoreResponses {
	
	public OR_ScoreResponses(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
}
