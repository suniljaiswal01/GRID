package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_ViewOptimizationResult extends CommonUtility{
	
	public OR_ViewOptimizationResult(WebDriver driver) {
		super(driver);
	}
	
	public By objGoToOptimizedScenariosBtn = By.xpath("//input[@value='"+getLanguageProperty("GoTo My Optimized Scenario List")+"']"); 

}
