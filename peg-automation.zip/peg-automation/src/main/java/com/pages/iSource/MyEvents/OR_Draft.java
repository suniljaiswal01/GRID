package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_Draft extends CommonUtility{
	
	public OR_Draft(WebDriver driver) {
		super(driver);
	}
	
	public By objCreateDraftBtn = By.xpath("//input[@value='Create Draft']");
	
	public By objModifyDraftBtn = By.xpath("//input[@value='"+getLanguageProperty("Modify Draft")+"']");
	
}
