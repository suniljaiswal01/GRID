package com.pages.iSource.MyEvents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class OR_TEB_AuthorisedUsers {
	
	public OR_TEB_AuthorisedUsers(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
}
