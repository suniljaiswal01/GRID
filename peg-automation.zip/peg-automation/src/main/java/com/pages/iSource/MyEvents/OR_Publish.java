package com.pages.iSource.MyEvents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Framework.CommonUtility;

public class OR_Publish extends CommonUtility{
	
	public OR_Publish(WebDriver driver) {
		super(driver);
	}
	

	By objPause = By.xpath("//input[@value='"+getLanguageProperty("Pause")+"']");
	

}
