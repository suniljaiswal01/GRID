package com.pages.iSource.MyEvents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class OR_BidOptimization {
	
	public OR_BidOptimization(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

}
