package com.pages.eInvoice.English.RecurringContracts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class RecurringContractDetailsPage {
	
	CommonUtility commonUtil;

	public RecurringContractDetailsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}


}
