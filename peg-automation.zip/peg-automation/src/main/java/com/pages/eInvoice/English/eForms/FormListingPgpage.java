package com.pages.eInvoice.English.eForms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class FormListingPgpage extends CommonUtility {
	
	CommonUtility commonUtil;

	public FormListingPgpage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

	/*@FindBy(how = How.XPATH, using="//div[div/span[text()='"+getLanguageProperty("Create Section")+"']]")
	public static WebElement createSection;*/
	private static By createSection = By.xpath("//div[div/span[text()='"+getLanguageProperty("Create Section")+"']]");

	
	private static By pgHead = By.xpath("//div[@class='zydf-page_label' and contains(text(),'"+getLanguageProperty("Form Listing Page")+"')]");

	
}
