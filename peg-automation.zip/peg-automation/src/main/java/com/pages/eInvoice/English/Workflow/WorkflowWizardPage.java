package com.pages.eInvoice.English.Workflow;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class WorkflowWizardPage {
	
	CommonUtility commonUtil;

	public WorkflowWizardPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}


}
