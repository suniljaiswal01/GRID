package com.pages.eInvoice.English.Reconciliation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReconcileNewStatementPage {

	CommonUtility commonUtil;

	public ReconcileNewStatementPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
}
