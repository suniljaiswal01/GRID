package com.pages.eInvoice.English.eForms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class AllFormsPage  extends CommonUtility {

	CommonUtility commonUtil;

	public AllFormsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
	private static By pgHead = By.xpath("//h1[@class='pgHead'][contains(text(),'"+getLanguageProperty("All Forms")+"')]");

}
