package com.pages.eInvoice.English.eForms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class FormWizardPage extends CommonUtility {
	
	CommonUtility commonUtil;

	public FormWizardPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

/*	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'"+getLanguageProperty("Form Details and Scope")+"')]")*/
	private static By formDetailsAndScope= By.xpath("//h1[contains(text(),'"+getLanguageProperty("Form Details and Scope")+"')]");
	
	@FindBy(how = How.XPATH, using = "//select[@id='slctProcess']/option[text()='<<relatedProcess>>']")
	private static WebElement relatedProcess;
	
	private static By saveContinueBtn= By.xpath("//input[@value='"+getLanguageProperty("Save and Continue")+"']");
	
/*	@FindBy(how = How.XPATH, using = "//div[@class='frmInpt'][contains(text(),'"+getLanguageProperty("level form")+"')]")
	private static WebElement levelForm;*/
	private static By levelForm= By.xpath("//div[@class='frmInpt'][contains(text(),'"+getLanguageProperty("level form")+"')]");
	
/*	@FindBy(how = How.XPATH, using = "//div[div/span[text()='"+getLanguageProperty("Create Section")+"']]")
	private static WebElement createSectionBtn;*/
	private static By createSectionBtn= By.xpath("//div[div/span[text()='"+getLanguageProperty("Create Section")+"']]");
	
	@FindBy(how = How.XPATH, using = "//select[@id='dfSectionLayout']/option[contains(text(),'<<layout>>')]")
	private static WebElement layout;
	
	@FindBy(how = How.XPATH, using = "//li[div/text()[contains(.,'<<sectionName>>')]]")
	private static WebElement sectionName;
	
	@FindBy(how = How.XPATH, using = "//li[div/div[contains(@class,'descriptive')]//div[text()='<<fieldName>>']]")
	private static WebElement fieldName;
	
	@FindBy(how = How.XPATH, using = "//input[@name='hide' and @value='false']")
	private static WebElement hideAndFalse;
	
	@FindBy(how = How.XPATH, using = "//input[@name='mandatory' and @value='true']")
	private static WebElement mandatoryAndTrue;
	
	@FindBy(how = How.XPATH, using = "//input[@name='dfNMDecimal']")
	private static WebElement dfNMDecimal;
	
	@FindBy(how = How.XPATH, using = "//input[@name='alphabetically']")
	private static WebElement alphabetically;
	
	/*@FindBy(how = How.XPATH, using = "//div[div/span[text()='"+getLanguageProperty("Select Companies & Business Units")+"']]")
	private static WebElement selectCompaniesBusinessUnits;*/
	private static By selectCompaniesBusinessUnits= By.xpath("//div[div/span[text()='"+getLanguageProperty("Select Companies & Business Units")+"']]");
	
	/*@FindBy(how = How.XPATH, using = "//div[contains(@style,'block')]//input[@value='"+getLanguageProperty("Save")+"']")
	private static WebElement saveBtn;*/
	private static By saveBtn= By.xpath("//div[contains(@style,'block')]//input[@value='"+getLanguageProperty("Save")+"']");
	
	/*@FindBy(how = How.XPATH, using = "//div[contains(@class,'promptbx')][//td[contains(text(),'"+getLanguageProperty("Please select atleast one scope")+"')]]")
	private static WebElement selectScopeMsg;*/
	private static By selectScopeMsg= By.xpath("//div[contains(@class,'promptbx')][//td[contains(text(),'"+getLanguageProperty("Please select atleast one scope")+"')]]");
	
}
