package com.pages.eInvoice.English.Invoice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ContractSummaryPage extends CommonUtility {
	
	CommonUtility commonUtil;

	public ContractSummaryPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

	
	/*@FindBy(how = How.XPATH, using = "//div[@id='changeInvSummaryTabs']//a[contains(text(),'"+getLanguageProperty("Cost Booking")+"')]")
	private static WebElement costBooking;*/
	private static By costBooking = By.xpath("//div[@id='changeInvSummaryTabs']//a[contains(text(),'"+getLanguageProperty("Cost Booking")+"')]");

}
