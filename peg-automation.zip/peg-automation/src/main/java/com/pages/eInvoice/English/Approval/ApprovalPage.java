package com.pages.eInvoice.English.Approval;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ApprovalPage extends CommonUtility{

	CommonUtility commonUtil;
	public ApprovalPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}



	/** Xpath for all the displayed Status in the Grid */
	//private static By statusXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
	@FindBys(@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[2]/div"))
	private static List<WebElement> objStatus;

	/** Xpath for all the displayed Document No in the Grid */
	//private static By documentNoXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[2]/div")
	private static List<WebElement> objDocumentNo;

	/** Xpath for all the displayed Date in the Grid */
	//private static By dateXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'receivedOn')]");
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[contains(@class,'receivedOn')]")
	private static List<WebElement> objDate;

	/** Xpath for all the displayed Amount in the Grid */
	//private static By amountXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'entityAmount')]");
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[contains(@class,'entityAmount')]")
	private static List<WebElement> objAmount;

	/** Xpath for the 'Filter' button associated with filter icons */
	/*private static By filterBtnXpath = By.xpath(
			"//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='"+getLanguageProperty("Filter")+"']");*/
	/*@FindBy(how = How.XPATH, using="//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='"+getLanguageProperty("Filter")+"']")
	private static WebElement objFilterBtn;*/
	private static By objFilterBtn = By.xpath("//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='"+getLanguageProperty("Filter")+"']");

	/** ID for the approval comments text area */
	//private static By approveCommentId = By.id("approvalComments");
	@FindBy(how = How.ID, using="approvalComments")
	private static WebElement objApproveComment;

	/** Xpath for the 'Approve' button */
	//private static By approveBtnXpath = By.xpath(".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]");
	@FindBy(how = How.XPATH, using=".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]")
	private static WebElement objApproveBtn;

	/** Xpath for green colored global message indicating Document is approved */
	//private static By approvedMsgXpath = By
	//.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]");
	/*@FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]")
	private static WebElement objApprovedMsg;*/
	private static By objApprovedMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]");

	/** ID for the reject comments text area */
	//private static By rejectCommentId = By.id("rejectComments");
	@FindBy(how = How.ID, using="rejectComments")
	private static WebElement objRejectComment;

	/** Xpath for the 'Reject' button */
	//private static By rejectBtnXpath = By.xpath("//*[@id='frmReject']//input[contains(@class,'dev_reject')]");
	@FindBy(how = How.XPATH, using="//*[@id='frmReject']//input[contains(@class,'dev_reject')]")
	private static WebElement objRejectBtn;

	/** Xpath for green colored global message indicating Document is rejected */
	//private static By rejectMsgXpath = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]");
	/*@FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]")
	private static WebElement objRejectMsg;*/
	private static By objRejectMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]");

	/** ID for the approval comments text area */
	//private static By delegateNameId = By.id("txtDelegateName");
	@FindBy(how = How.ID, using="txtDelegateName")
	private static WebElement objDelegateName;

	/** ID for the delegate comments text area */
	//private static By delegateCommentId = By.id("delegateComments");
	@FindBy(how = How.ID, using="delegateComments")
	private static WebElement objDelegateComment;

	/** Xpath for the 'Delegate' button */
	//private static By saveDelegateBtnId = By.id("btnDelegateSave");
	@FindBy(how = How.ID, using="btnDelegateSave")
	private static WebElement objSaveDelegateBtn;

	/** Xpath for green colored global message indicating Document is delegated */

	private static By objDelegateMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]");

	/** Xpath for Action button on first row */
	//private static By actionBtnXpath = By
	//.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	private static By objFirstRowActionBtn = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");

	private String delegateApprovalTo;
	//private String delegateApprovalTo = "Chaitali";
	
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//tr[1]//li/a[contains(text(),'<<action>>')]")
	private static WebElement actionLink;

}
