package com.pages.eInvoice.English.eForms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ConfigureFlexiFormPage  extends CommonUtility{
	
	CommonUtility commonUtil;

	public ConfigureFlexiFormPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

/*	@FindBy(how = How.XPATH, using="//div[div/span[text()='"+getLanguageProperty("Create Section")+"']]")
	public static WebElement createSection;*/
	private static By createSection = By.xpath("//div[div/span[text()='"+getLanguageProperty("Create Section")+"']");
	
	@FindBy(how = How.XPATH, using="//select[@id='zydf-dfSectionLayout']/option[contains(text(),'<<layout>>')]")
	public static WebElement layout;
	
	@FindBy(how = How.XPATH, using="//li/div/span[text()='<<sectionName>>']")
	public static WebElement sectionName;
	
	@FindBy(how = How.XPATH, using="//*[@id='zydf-devLeftDragList']//a/span[following-sibling::text()[contains(.,'<<fieldType>>')]]")
	public static WebElement fieldType;
	
/*	@FindBy(how = How.XPATH, using="//li/div[span[text()='"+getLanguageProperty("Auto_Section")+"']]/following-sibling::ul")
	public static WebElement autoSection;*/
	private static By autoSection = By.xpath("//li/div[span[text()='"+getLanguageProperty("Auto_Section")+"']]/following-sibling::ul");
	
/*	@FindBy(how = How.XPATH, using="//div[div/span[contains(text(),'"+getLanguageProperty("Field Properties")+"')]]")
	public static WebElement autoSection;*/
	private static By fieldProperty = By.xpath("//div[div/span[contains(text(),'"+getLanguageProperty("Field Properties")+"')]]");
	
	@FindBy(how = How.XPATH, using="//li[div/div[contains(@class,'descriptive')]//div[text()='<<fieldName>>']]")
	public static WebElement fieldName1;
	
	@FindBy(how = How.XPATH, using="//li[div/div[label/span[contains(text(),'<<fieldName>>')]]//input]")
	public static WebElement fieldName2;
	
	@FindBy(how = How.XPATH, using="//input[@name='saveEform']")
	public static WebElement saveEformBtn;
	
/*	@FindBy(how = How.XPATH, using="//form[@id='zydf-frmFieldProperty']//input[@value='"+getLanguageProperty("Save")+"']")
	public static WebElement autoSection;*/
	private static By saveEform = By.xpath("//form[@id='zydf-frmFieldProperty']//input[@value='"+getLanguageProperty("Save")+"']");
	

	
}
