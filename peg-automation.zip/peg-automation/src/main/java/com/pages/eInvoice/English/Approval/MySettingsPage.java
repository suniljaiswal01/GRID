package com.pages.eInvoice.English.Approval;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MySettingsPage extends CommonUtility {
	CommonUtility commonUtil;

	public MySettingsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
	private static By notificationMsgXpath = By
			.xpath("//*[@id='status_overlay_loading']/div[text()='"+getLanguageProperty("Approval Delegated successfully")+"']");
}
