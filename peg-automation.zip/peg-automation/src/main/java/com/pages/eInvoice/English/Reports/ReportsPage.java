package com.pages.eInvoice.English.Reports;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportsPage {

	CommonUtility commonUtil;

	public ReportsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

	
}
