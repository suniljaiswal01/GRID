package com.pages.eInvoice.English.Payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class NewPaymentBatchPage {
	
	CommonUtility commonUtil;

	public NewPaymentBatchPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

}
