package com.pages.eInvoice.English.Uploads;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class UploadsPage {

	CommonUtility commonUtil;

	public UploadsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

	
}
