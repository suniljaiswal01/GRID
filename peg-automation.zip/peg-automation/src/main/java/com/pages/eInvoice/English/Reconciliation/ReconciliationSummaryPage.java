package com.pages.eInvoice.English.Reconciliation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReconciliationSummaryPage {

	CommonUtility commonUtil;

	public ReconciliationSummaryPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
}
