package com.pages.eInvoice.English.Reports;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportDetailPage {
	
	CommonUtility commonUtil;

	public ReportDetailPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}


}
