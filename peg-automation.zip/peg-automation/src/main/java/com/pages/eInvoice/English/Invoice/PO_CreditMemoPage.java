package com.pages.eInvoice.English.Invoice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class PO_CreditMemoPage {
	CommonUtility commonUtil;

	public PO_CreditMemoPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
}
