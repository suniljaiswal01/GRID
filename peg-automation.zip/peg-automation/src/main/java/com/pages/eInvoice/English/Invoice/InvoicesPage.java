package com.pages.eInvoice.English.Invoice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class InvoicesPage {

	CommonUtility commonUtil;

	public InvoicesPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
}
