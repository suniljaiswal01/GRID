package com.pages.eInvoice.English.Invoice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class NewRecurringContractPage {

	CommonUtility commonUtil;

	public NewRecurringContractPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}
	
}
