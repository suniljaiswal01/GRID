package com.pages.eInvoice.English.RecurringContracts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ContractListPage extends CommonUtility {
	
	CommonUtility commonUtil;

	public ContractListPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		commonUtil = new CommonUtility();
	}

	
	
	@FindBys(@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[1]/div"))
	private static List<WebElement> objStatus;
	private String delegateApprovalTo = "Chaitali";

	/** Xpath for Action button on first row */
	//private static By actionBtnXpath = By
	//.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	/*@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")
	private static WebElement objFirstRowActionBtn;*/

	/** ID for the approval comments text area */
	@FindBy(how = How.ID, using="txtContractActivateComment")
	private static WebElement objActivateComment;
	
	/**ID for contract change comments*/
	@FindBy(how = How.ID, using="txtInvoiceStatusComments")
	private static WebElement changeComments;

	/** Xpath for the 'Approve' button */
	@FindBy(how = How.XPATH, using=".//*[@id='frmContractActivate']//input[contains(@class,'dev_contractActivate')]")
	private static WebElement objActivateBtn;

	@FindBy(how = How.ID, using="status_overlay_deactivating")
	private static WebElement objDeactivatingMsg;

	/** ID for the approval comments text area */
	@FindBy(how = How.ID, using="txtContractDeactivateComment")
	private static WebElement objDeactivateComment;

	/** Xpath for the 'Approve' button */
	@FindBy(how = How.XPATH, using=".//*[@id='frmContractDeactivate']//input[contains(@class,'dev_contractDeactivate')]")
	private static WebElement objDeactivateBtn;

	@FindBy(how = How.ID, using="status_overlay_activating")
	private static WebElement objActivatingMsg;
		
	
	/** ID for the approval comments text area */
	//private static By delegateNameId = By.id("txtDelegateName");
	@FindBy(how = How.ID, using="txtDelegateName")
	private static WebElement objDelegateName;
	
	/** ID for the delegate comments text area */
	//private static By delegateCommentId = By.id("delegateComments");
	@FindBy(how = How.ID, using="delegateComments")
	private static WebElement objDelegateComment;
	
	/** Xpath for the 'Delegate' button */
	//private static By saveDelegateBtnId = By.id("btnDelegateSave");
	@FindBy(how = How.ID, using="btnDelegateSave")
	private static WebElement objSaveDelegateBtn;
	
	/** Xpath for green colored global message indicating Document is delegated */
	//private static By delegateMsgXpath = By
			//.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]");
	private static By objDelegateMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]");
	
	/** Xpath for Action button on first row */
	//private static By actionBtnXpath = By
			//.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	private static By objFirstRowActionBtn = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	
	/** Xpath for Action button on first row */
	//private static By actionBtnXpath = By
			//.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	private static By objSecondRowActionBtn = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	
	By confirmationPopupXpath = By
			.xpath("//div[contains(@class,'workflowDialog ')]//input[contains(@class,'dev_submit')]");
	
	/** ID for the approval comments text area */
	//private static By approveCommentId = By.id("approvalComments");
	@FindBy(how = How.ID, using="approvalComments")
	private static WebElement objApproveComment;
	
	/** Xpath for the 'Approve' button */
	//private static By approveBtnXpath = By.xpath(".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]");
	@FindBy(how = How.XPATH, using=".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]")
	private static WebElement objApproveBtn;
	
	/** Xpath for green colored global message indicating Document is approved */
	//private static By approvedMsgXpath = By
			//.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]");
	private static By objApprovedMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]");
	
	/** ID for the reject comments text area */
	//private static By rejectCommentId = By.id("rejectComments");
	@FindBy(how = How.ID, using="rejectComments")
	private static WebElement objRejectComment;
	
	/** Xpath for the 'Reject' button */
	//private static By rejectBtnXpath = By.xpath("//*[@id='frmReject']//input[contains(@class,'dev_reject')]");
	@FindBy(how = How.XPATH, using="//*[@id='frmReject']//input[contains(@class,'dev_reject')]")
	private static WebElement objRejectBtn;
	
	

	/** Xpath for green colored global message indicating Document is rejected */
	//private static By rejectMsgXpath = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]");
	private static By objRejectMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]");
	

}
