package com.pages.French.iManage.Workbench;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ManageProject  extends CommonUtility{
	public ManageProject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[contains(@class,'actBxWrapOpen')]//ul[@class='actBxAll']//a[text()='<<action>>']")
	public WebElement taskActionDrpDwn;
	

	private static By taskApprovalTab = By.xpath("//li[contains(text(),'"+getLanguageProperty("Task Approval")+"')]");
	
	
	private static By selectApproverBtn = By.xpath("//div[@id='basketGridContainer']//tr[@class='filterGridTblTd'][1]//td/select//option[text()='"+getLanguageProperty("Approver")+"']");
	
	
	private static By strategicProjectBtn = By.xpath("//div[@id='selectPopUp']//tbody/tr/td/div[h2[text()='"+getLanguageProperty("Strategic Project")+"']]");
	
	
	private static By sendBtn = By.xpath("//table[@id='manage-task-approval-grid']//td/label[text()='"+getLanguageProperty("Send")+"']");
	
	
	private static By createNewEntityBtn = By.xpath("//input[@title='"+getLanguageProperty("Create New Entity")+"']");
	
	
	private static By saveAndContinueBtn = By.xpath("//input[@title='"+getLanguageProperty("Save & Continue")+"']");
	

	private static By saveAndNextBtn = By.xpath("//input[@title='"+getLanguageProperty("Save & Next")+"']");
	

	private static By removeDocumentBtn = By.xpath("(//tr/td//label[text()='"+getLanguageProperty("Remove")+"'])[1]");
	
	
	private static By quickProjectBtn = By.xpath("//div[@id='selectPopUp']//tbody/tr/td/div[h2[text()='"+getLanguageProperty("Quick Project")+"']]");
	
	
	private static By initiateProjectBtn = By.xpath("//input[@value='"+getLanguageProperty("Initiate Project")+"']");
	
	
	private static By uploadSaveBtn = By.xpath("//input[@value='"+getLanguageProperty("Save")+"'][contains(@onclick,'saveUpdateDocHistory')]");
	
	
	private static By sendBtnFirstRow = By.xpath("//label[@class='icon submit'][@title='"+getLanguageProperty("Send")+"'][1]");
}
