package com.pages.French.iManage.MyConfiguration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ProjectConfiguration extends CommonUtility {
	public ProjectConfiguration(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By createAndLinkCustProjectTxtBx = By.xpath("//td[input[contains(@class,'createNewCustProject')]]/following-sibling::td/a[text()='"+getLanguageProperty("Create & Link")+"']");

	private static By createAndLinkCustTaskTxtBx = By.xpath("//td[input[contains(@class,'createNewCustTask')]]/following-sibling::td/a[text()='"+getLanguageProperty("Create & Link")+"']");
	
	private static By successMsg = By.xpath("//div[text()='"+getLanguageProperty("Success")+"']");
	
	private static By associateTemplateBtn = By.xpath("(//table[@id='zydf-formList']//tr//td/a[text()='"+getLanguageProperty("Associate")+"'])[1]");

	private static By defaultFlexiLinkFormBtn = By.xpath("//table[@id='defaultFlexiformGridTable']//td[text()='<<Templatetype>>']//..//a[@title='"+getLanguageProperty("Link Form")+"']");	
	
	private static By defaultFlexiDeLinkFormBtn = By.xpath("//table[@id='defaultFlexiformGridTable']//td[text()='<<Templatetype>>']//..//a[@title='"+getLanguageProperty("Delink Form")+"']");
	
	private static By customProjectExistingLinkFormBtn = By.xpath("//table[@id='customProjectTypeTable']//td[text()='"+getLanguageProperty("Value Engineering")+"']//..//a[@title='"+getLanguageProperty("Link Form")+"']");
		
	private static By customTaskExistingLinkFormBtn = By.xpath("//div[contains(@class,'customTaskTypescrollTop')]//td[text()='"+getLanguageProperty("To Do")+"']//..//a[@title='"+getLanguageProperty("Link Form")+"']");
	
	@FindBy(xpath = "//table[@id='defaultFlexiformGridTable']//td[text()='<<Templatetype>>']")
	public WebElement deaultFlexiTemplatetype;
	
	@FindBy(xpath = "//table[@id='defaultFlexiformGridTable']//td[text()='<<Templatetype>>']//..//a[@class='buttons moreAction']")
	public WebElement deaultFlexiTemplatetypeActionBtn;
}
