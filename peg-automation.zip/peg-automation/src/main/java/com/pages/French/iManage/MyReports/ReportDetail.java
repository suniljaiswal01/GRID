package com.pages.French.iManage.MyReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ReportDetail  extends CommonUtility{
	public ReportDetail(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	private static By reportSucessMsg = By.xpath("//div[@id='jqi'][div/div[text()='"+getLanguageProperty("Success")+"']]");
	

	private static By goToReportBtn = By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Go to report")+"']");
	

	private static By reportMoreOptionDwn = By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More Option")+"')]");
	
	private static By reportShareBtn = By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Share")+"']");
	

	private static By reportMoreOptionBtn = By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More Option")+"')]");
	
	@FindBy(xpath = "//table[@class='shareListTable_RMS']//div[text()='<<sharedUserEmail>>']/ancestor::tr//input")
	public WebElement emailID;
	

}
