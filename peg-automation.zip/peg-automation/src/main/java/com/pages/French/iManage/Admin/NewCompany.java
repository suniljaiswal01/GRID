package com.pages.French.iManage.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class NewCompany {
	public NewCompany(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


}
