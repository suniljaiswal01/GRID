package com.pages.French.iManage.MyReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class Reports  extends CommonUtility{
	public Reports(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By createNewRequest_button = By.xpath("//div[div[text()='"+getLanguageProperty("My Reports")+"']]//a[@title='<<reportName>>']");
	
	
}
