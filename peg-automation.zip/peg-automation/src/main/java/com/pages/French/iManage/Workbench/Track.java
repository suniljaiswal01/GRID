package com.pages.French.iManage.Workbench;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class Track  extends CommonUtility{
	public Track(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By postCommentsBtn = By.xpath("//input[@value='"+getLanguageProperty("Post Comments")+"']");
	
	@FindBy(xpath = "//table[@id='projectJournalComment_table_ID']//div[contains(text(),'<<comments>>')]")
	public WebElement commentsTxt;
	
	@FindBy(xpath = "//li[@class='ContentTreeLi']/input[@value='<<entity>>']")
	public WebElement entityBtn;
	
	private static By okBtn = By.xpath("//input[@type='button'][@value='"+getLanguageProperty("OK")+"']");
	
	@FindBy(xpath = "//input[@type='radio'][contains(@value,'CREATE_EVENT_FROM_START')]")
	public WebElement createEventFromStartRFIRadioBtn;
	
	@FindBy(xpath = "//div[contains(text(),'Activity Linked successfully !')]")
	public WebElement activityLinkSuccessMsg;
	
	
	private static By quickEditSuccessMsg = By.xpath("//div[@class='toasterMsgHeader'][text()='"+getLanguageProperty("Saved")+"']");
	

	private static By activityLinkingActionsBtn = By.xpath("//table[@id='project-list-grid']/tbody/tr[1]/td[last()]//a[contains(text(),'"+getLanguageProperty("Actions")+"')]");
	
	
	private static By linkActivityBtn = By.xpath("//table[@id='project-list-grid']/tbody/tr[1]/td[last()]//ul/li/a[text()='"+getLanguageProperty("Link Activity")+"']");
	
	@FindBy(xpath = "//select[@name='activityType']/option[text()='<<activityType>>']")
	public WebElement activityTypeBtn;
	
	@FindBy(xpath = "/select[@id='requestType']/option[@title='<<requestType>>']")
	public WebElement requestTypeBtn;
	
	@FindBy(xpath = "//select[@id='contractTypeId1']/option[@title='<<contractType>>']")
	public WebElement contractTypeBtn;
	
	@FindBy(xpath = "//select[@id='contractSubTypeId1']/option[@title='<<contractSubType>>']")
	public WebElement contractSubTypeBtn;
	
	@FindBy(xpath = "//table[@id='dataGrid']/tbody/tr[td[2]/label[text()='<<eventIDToLink>>']]/td[1]/input")
	public WebElement eventIDLnk;
	

	private static By filteredMsg = By.xpath("//th[@id='taskCheckBox_filterColumn']/div/div/span[text()='"+getLanguageProperty("Filtered")+"']");
	

	private static By manageInitiatedProjectBtn = By.xpath("//table[@id='project-list-grid']/tbody/tr[1]/td[last()]//ul/li/a[text()='"+getLanguageProperty("Manage Initiated Project")+"']");
	
	
	private static By taskActionsDrpDwn = By.xpath("//tr[td[@class='filterGridTblTd tdEllipsis']/span[@title='<<taskTitle>>']]/td[last()]/div/div/a[contains(text(),'"+getLanguageProperty("Actions")+"')]");
	

	private static By taskLinkActivityBtn = By.xpath("//tr[td[@class='filterGridTblTd tdEllipsis']/span[@title='<<taskTitle>>']]/td[last()]/div/div/a[contains(text(),'"+getLanguageProperty("Actions")+"')]//..//ul//a[@id='linkActivity']");
	
	private static By addNewTaskBtn = By.xpath("//div[@class='contractOutline']/label[text()='"+getLanguageProperty("Add New Task")+"']");
	
	@FindBy(xpath = "//td[contains(text(),'Task Title:')]/following-sibling::td/input[@type='text']")
	public WebElement taskTitleTxtBx;
	
	@FindBy(xpath = "//td[contains(text(),'Task Type:')]/following-sibling::td/select[@id='typeID']")
	public WebElement taskTypeTxtBx;
	
	@FindBy(xpath = "//td[contains(text(),'Task Description:')]/following-sibling::td/textarea[@id='description']")
	public WebElement descriptionTxtBx;

	private static By quickprojectEditBtn = By.xpath("//table[@id='project-list-grid']/tbody/tr[1]/td[last()]//ul/li/a[text()='"+getLanguageProperty("Edit")+"']");
	

	private static By quickProjectSavingsTab = By.xpath("//div[@class='zys-default-tab']//li[contains(text(),'"+getLanguageProperty("Savings")+"')]");
	
	@FindBy(xpath = "//table[@id='newTableGridId']//td[contains(text(),'<<projName>>')]")
	public WebElement projNameLstSavings;
	
	
	private static By linkSavingsProjectBtn = By.xpath("//span[contains(text(),'"+getLanguageProperty("Link Savings Project")+"')]");
	
	@FindBy(xpath = "//span[@class='common_modalBtn'][text()='Link Existing Projects/s']")
	public WebElement linkExistingProjectBtn;
	
	
	private static By createNewActivityBtn = By.xpath("//li[@id='navigation2'][text()='"+getLanguageProperty("Create New Activity")+"']");
	
	@FindBy(xpath = "//div[@id='subtab2']//select[@name='activityType']/option[text()='<<activityType>>']")
	public WebElement activityTypeDrpDwn;
	
	
	private static By manageInitiatedProjectDrpDwn = By.xpath("//div[contains(@class,'actBxWrapOpen')]//ul[@class='actBxAll']//a[text()='"+getLanguageProperty("Manage Initiated Project")+"']");
	
	@FindBy(xpath = "//li[text()='<<action>>']")
	public WebElement manageInitiatedProjectActions;
	

	private static By trackPageHeader = By.xpath("//div[@class='breadCrumb' and contains(text(),'"+getLanguageProperty("Track")+"')]");
	
	@FindBy(xpath = "//div[@id='selectPopUp']//tbody/tr/td/div[h2[text()='<<entityType>>']]")
	public WebElement entityTypeBtn;

	private static By createNewEntityBtn = By.xpath("//input[@title='"+getLanguageProperty("Create New Entity")+"']");
	
	@FindBy(xpath = "//div[contains(@class,'actBxWrapOpen')]//ul[@class='actBxAll']//a[text()='<<action>>']")
	public WebElement actionsOnStrategicProject;
	
	
	private static By strategicProjectActionsBtn = By.xpath("//table[@id='project-list-grid']/tbody/tr[1]/td[last()]//a[contains(text(),'"+getLanguageProperty("Actions")+"')]");
	
	@FindBy(xpath = "//label[text()='<<actionPhases>>']")
	public WebElement manageProjectActionPhases;
	

	private static By linkActivityCancelBtn = By.xpath("//div[@id='addIsourceEventSaveButtonDiv']/following-sibling::a[@title='"+getLanguageProperty("Cancel")+"']");
	
	
	private static By taskCancelBtn = By.xpath("//a[@title='"+getLanguageProperty("Cancel")+"'][contains(@onclick,'clearAndClosePopup()')]");
	

}
