package com.pages.French.iManage.MyConfiguration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OwnershipManagement {
	public OwnershipManagement(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='breadCrumb'][contains(text(),'You are here : My Configuration > Ownership Management ')]")
	public WebElement ownershipManagementHeader;
	
	@FindBy(xpath = "//li[contains(text(),'<<user>>')]")
	public WebElement userTxtBx;
	
	@FindBy(xpath = "//div[@class='dataTables_processing']")
	public WebElement dataProcessing_loader;
}
