package com.pages.French.iManage.Workbench;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class ProjectSummary  extends CommonUtility{
	public ProjectSummary(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By pgNameIdentifier = By.xpath("//div[@class='breadCrumb' and contains(text(),'"+getLanguageProperty("Project Summary")+"')]");
	
	
	private static By programSummaryOfTxt = By.xpath("//span[contains(text(),'"+getLanguageProperty("Project Summary of")+"')]");
	
	
	private static By exportProjectSummaryBtn = By.xpath("//a[@title='"+getLanguageProperty("Export Project Summary")+"']");
	

	private static By initiateProjectBtn = By.xpath("//input[@title='"+getLanguageProperty("Initiate Project")+"']");
	

}
