package com.pages.French.iManage.MyTemplates;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class CreateNewTemplate  extends CommonUtility{
	public CreateNewTemplate(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	private static By saveAndContinueBtn = By.xpath("//input[@title='"+getLanguageProperty("Save & Continue")+"']");
	

	private static By nextBtn = By.xpath("//input[@title='Next'");
	

	private static By publishTemplateBtn = By.xpath("//input[@value='"+getLanguageProperty("Publish Template")+"']");
	
	
	private static By valueBtn = By.xpath("(//input[@value='"+getLanguageProperty("Save")+"'])[4]");
}
