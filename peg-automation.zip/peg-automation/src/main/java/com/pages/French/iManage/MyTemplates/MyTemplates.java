package com.pages.French.iManage.MyTemplates;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MyTemplates  extends CommonUtility{
	public MyTemplates(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By createNewTemplateBtn = By.xpath("//input[@title='"+getLanguageProperty("Create New Template")+"']");
	
	@FindBy(xpath = "//div[contains(@class,'leftMenuDiv')]//li[@title='<<source>>']")
	public WebElement sourceBtn;
	
	@FindBy(xpath = "//div[@class='dataTables_processing']")
	public WebElement dataProcessing_loader;
}
