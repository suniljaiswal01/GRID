package com.pages.French.iManage.Workbench;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class Approval  extends CommonUtility{
	public Approval(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By approvalViewBtn = By.xpath("//table[@id='approver-grid']//tbody/tr[td[2]//span[@title='<<projectTitle>>']]//td[last()]/a[contains(text(),'"+getLanguageProperty("View")+"')]");
	
	@FindBy(xpath = "//table[@id='approver-grid']/tbody/tr[td[2]/span[@title='<<+projectTitle>>']]/td[last()-1]")
	public WebElement projectTitleRow;
	

	private static By phaseActionBtn = By.xpath("//table[@id='approver-grid']/tbody/tr[td[2]/a/span[@title='<<phaseTitle>>']]/td[last()]//a[contains(text(),'"+getLanguageProperty("Actions")+"')]");
	

	private static By approveBtn = By.xpath("//a[@class='approveBtn'][text()='"+getLanguageProperty("Approve")+"']");
	

	private static By pendingItemRow = By.xpath("//table[@id='approver-grid']/tbody/tr[td[last()-1][label[contains(text(),'"+getLanguageProperty("Pending")+"')]]]");
	

	private static By pendingProjectTitleRow = By.xpath("//table[@id='approver-grid']/tbody/tr[td[last()-1][label[contains(text(),'"+getLanguageProperty("Pending")+"')]]][1]/td[2]//span");
	
	@FindBy(xpath = "//div[@class='breadCrumb'][contains(text(),'You are here : Review')]")
	public WebElement reviewPageHeader;
}
