package com.pages.French.iManage.Dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class CommonDashboard  extends CommonUtility{
	public CommonDashboard(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

/*	@FindBy(xpath = "//strong[text()='"+getLanguageProperty("More Options")+"']")
	public WebElement moreOptionsDrpDwn;*/
	private static By moreOptionsDrpDwn = By.xpath("//strong[text()='"+getLanguageProperty("More Options")+"']");
	
/*	@FindBy(xpath = "//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Added Successfully")+"']]")
	public WebElement dashboardDefaultSuccessfulMsg;*/
	private static By dashboardDefaultSuccessfulMsg = By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Added Successfully")+"']]");
	
	/*@FindBy(xpath = "//h1[text()='"+getLanguageProperty("Dashboard deleted")+"']")
	public WebElement dashboardDeletedMsg;*/
	private static By dashboardDeletedMsg = By.xpath("//h1[text()='"+getLanguageProperty("Dashboard deleted")+"']");
	
	@FindBy(xpath = "//span[text()='<<action>>']")
	public WebElement dashboardActionsDrDwn;
	
	@FindBy(xpath = "//div[@class='boxLayoutsDv']//a[text()='<<dashboardLayout>>']")
	public WebElement dashboardLayoutBtn;
	
	@FindBy(xpath = "//div[@class='reportContainerParent']//a[@title='<<widgetName>>']")
	public WebElement widgetName;
	
	@FindBy(xpath = "//div[@title='<<exportFormat>>']")
	public WebElement exportFormatDrpdwn;
}
