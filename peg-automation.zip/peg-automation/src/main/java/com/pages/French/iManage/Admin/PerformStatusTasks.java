package com.pages.French.iManage.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class PerformStatusTasks {
	public PerformStatusTasks(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


}
