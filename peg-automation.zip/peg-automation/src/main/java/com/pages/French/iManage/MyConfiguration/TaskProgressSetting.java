package com.pages.French.iManage.MyConfiguration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class TaskProgressSetting extends CommonUtility{
	public TaskProgressSetting(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	private static By editBtn = By.xpath("//div[@class='actionBtnHolderPopup']//input[@value='"+getLanguageProperty("Edit")+"']");
	
	@FindBy(xpath = "//table/tbody/tr[td[text()='<<iSourceStatus>>']]/td[<<itr>>+1]/input")
	public WebElement isourceStatusTxb;
	
}
