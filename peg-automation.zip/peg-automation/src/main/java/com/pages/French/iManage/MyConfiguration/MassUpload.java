package com.pages.French.iManage.MyConfiguration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class MassUpload extends CommonUtility {
	public MassUpload(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By submitBtn = By.xpath("//input[@value='"+getLanguageProperty("Submit")+"']");
	

	private static By okBtn = By.xpath("//input[@id='popup_ok'][@value='"+getLanguageProperty("OK")+"']");
	

}
