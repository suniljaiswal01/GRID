package com.pages.French.iManage.MyConfiguration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SyncTMSUser {
	public SyncTMSUser(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='breadCrumb'][contains(text(),'You are here: My Configuration > Sync TMS User')]")
	public WebElement syncTMSUserHeader;
	

}
