package com.pages.French.iManage.MyConfiguration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class MassUpdate {
	public MassUpdate(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


}
