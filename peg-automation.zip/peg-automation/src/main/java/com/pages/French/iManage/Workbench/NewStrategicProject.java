package com.pages.French.iManage.Workbench;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Framework.CommonUtility;

public class NewStrategicProject  extends CommonUtility{
	public NewStrategicProject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	private static By saveAndNextBtn = By.xpath("//input[@value='"+getLanguageProperty("Save & Next")+"']");
	

	private static By saveAndContinueBtn = By.xpath("//input[@title='"+getLanguageProperty("Save & Continue")+"']");
	
	
	private static By fromScratchBtn = By.xpath("//li[@title='"+getLanguageProperty("From Scratch")+"']");
	

	private static By goBtn = By.xpath("//input[@value='"+getLanguageProperty("Go")+"']");
	
	@FindBy(xpath = "//select[@id='searchSelect']/option[text()='<<searchBy>>']")
	public WebElement searchByValue;
	

}
