package com.pages.sideMenu;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SideMenuPage {

	public SideMenuPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@id='rbShowCRMS']")
	public WebElement reportStudio_div;
	
	@FindBy(id="z-menu-crms_reports")
	public WebElement reportStudio_appLink;
	
	
}
