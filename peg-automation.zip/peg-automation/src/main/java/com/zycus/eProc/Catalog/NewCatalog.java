package com.zycus.eProc.Catalog;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.SupplierDetails;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> NewCatalog.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.enterCatalogDetails: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class NewCatalog extends eProc_CommonFunctions {

  private static By newCatalogLbl = By.xpath("//h1[@class='pgHead' and text()='Catalog Details']");
  
  private String catalogName;
  private String supplier;
  private String serviceNum;
  private String shortDesc;
  private String prodCategory;
  private String price;
  
  eInvoice_CommonFunctions objFunctions = new eInvoice_CommonFunctions(driver, logger);

  private String Datasheet_SupplierContacts;
  private List<String> listOfSupplierContact = new ArrayList<String>();
  private List<String> listOfSupplierCompany = new ArrayList<String>();
  
  private String contractingParty;
	private String contactPerson;
	
  /**
   * Constructor for the class
   * 
   * @param driver
   * @throws Exception 
   */

  public NewCatalog(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    this.catalogName = "AutoCatalog_"+generateNo();
   
    SupplierDetails supplierDetails = new SupplierDetails();
  	supplierDetails.setSupplierData(0);
  	this.contractingParty = supplierDetails.getCompanyName();
  	this.contactPerson = supplierDetails.getContactingPerson();
  	this.listOfSupplierCompany.add(contractingParty);
  	this.listOfSupplierContact.add(contactPerson);
  	supplierDetails.setSupplierData(1);
  	this.listOfSupplierCompany.add(supplierDetails.getCompanyName());
  	this.listOfSupplierContact.add(supplierDetails.getContactingPerson());
  	
   /* for(int i=0;i<abc2.length;i++) {
      listOfSupplierCompany.add(abc2[i][0]);
      listOfSupplierContact.add(abc2[i][1]);
    }

    */
  
	
	
    //this.supplier = objConfig.getProperty("supplier");
  }

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  /*public NewCatalog(WebDriver driver, ExtentTest logger, String catalogName, String supplier) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
    this.catalogName = catalogName;
    this.supplier = supplier;
  }*/

  /**
   * <b>Function:</b> enterCatalogDetails
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param None
   * @return None
   */
  
  public String enterCatalogDetails(String contractNo, boolean addItemFromFile) throws Exception{
  //public void enterCatalogDetails(String serviceNum, String shortDesc, String prodCategory, String price) {
    ConfigurationProperties config = ConfigurationProperties.getInstance();
    //String filePath = System.getProperty("user.dir") + config.getProperty("eProc_CatalogItemsfile_path");
    
    String nameOfCatalog = null;
    driver.findElement(By.id("txtCatalogName")).sendKeys(catalogName);
    LogScreenshot("Info", "Supplier to be selected is "+listOfSupplierCompany.get(0));
    enterText_AutoComplete_eProc(By.id("txtSupplierName"), listOfSupplierCompany.get(0));
    LogScreenshot("Pass", "Supplier Details entered");
    selectSupplierAddress();
    if (contractNo != ""){
      enterText_AutoComplete(By.id("dev_contractNo"), contractNo);
      //findElement(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']")).click();
      waitUntilVisibilityOfElement(By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Catalog Details")+"']"));
      //clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Catalog Details']"));
//      waitUntilVisibilityOfElement(By.id("previewSection"));
      LogScreenshot("Pass", "Contract "+contractNo+ " selected");
      selectSupplierAddress();
      clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Item Details")+"']"));
      ItemDetails objDetails = new ItemDetails(driver, logger);
     
      waitUntilVisibilityOfElement(By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Item Details")+"']"));
      Thread.sleep(3000);
      findElement(By.id("addOnlineItem")).click();
      waitUntilVisibilityOfElement(By.id("addItemDialog"));
      objDetails.enterItemDetails();
      
     /* if (driver.findElements(By.id("errorBox")).size() > 0){
        List<WebElement> listOfErrors = driver.findElements(By.xpath("//div[@id='errorBox']//li"));
        for(WebElement errorRow : listOfErrors){
          switch(errorRow.getAttribute("id")){
          case "CATEGORY_CODE-MISSING_VALUE":
            errorRow.findElement(By.xpath("./span")).click();
            waitUntilInvisibilityOfElement(processingLoader,4);
            WebElement actionBtn = driver.findElement(By.xpath("//table[@id='itemListGrid']/tbody/tr[1]//td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
            actionBtn.click();
            actionBtn.findElement(By.xpath("./following-sibling::ul/li/a[text()='"+getLanguageProperty("Edit")+"']")).click();
            Thread.sleep(3000);
            String linkedErrFieldName = "Product Category";
            By linkedFieldLocator = By.id("txtCatName");
            objDetails.editItemDetails(linkedErrFieldName, linkedFieldLocator);
            break;
          }
        }
      }*/
      waitUntilInvisibilityOfElement(By.id("itemListGrid_processing"),4);
      findElement(By.xpath("//table[@id='itemListGrid']/thead/tr/th/input")).click();
    } else {
      clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Item Details")+"']"));
      LogScreenshot("Info", "Next button clicked");
      ItemDetails objDetails = new ItemDetails(driver, logger);
      waitUntilVisibilityOfElement(
          By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Item Details")+"']"));
      LogScreenshot("Pass", "Navigated to Item Details section");
      if (addItemFromFile){
        String filePath = config.getProperty("eProc_CatalogItemsfile_path");
        findElement(By.id("uploaditemsviafile")).click();
        waitUntilVisibilityOfElement(By.id("uploadcatalogfilepop"));
        driver.findElement(By.id("attachmentInput_catalogUpload")).sendKeys(filePath);
        Thread.sleep(4000);
        LogScreenshot("Info", "File selected to upload");
        findElement(By.id("btnUploadCatalog")).click();
        waitUntilVisibilityOfElement(By.id("columnmapping"));
        LogScreenshot("Info", "Upload button clicked");
        findElement(By.id("btnMapColumns"),"Ok button").click();
        Thread.sleep(2000);
        waitUntilInvisibilityOfElement(By.xpath("//div[@id='showProcess']"),4);
        LogScreenshot("Info", "Ok button clicked to map columns");
        waitUntilInvisibilityOfElement(processingLoader);
        Thread.sleep(6000);
        if (driver.findElements(By.id("errorBox")).size() > 0){
          List<WebElement> listOfErrors = driver.findElements(By.xpath("//div[@id='errorBox']//li"));
          for(WebElement errorRow : listOfErrors){
            switch(errorRow.getAttribute("id")){
            case "CATEGORY_CODE-INVALID_VALUE":
              errorRow.findElement(By.xpath("./span")).click();
              waitUntilInvisibilityOfElement(processingLoader,4);
              Thread.sleep(2000);
              WebElement actionBtn = driver.findElement(By.xpath("//table[@id='itemListGrid']/tbody/tr[1]//td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
              scroll_into_view_element(actionBtn);
              actionBtn.click();
              actionBtn.findElement(By.xpath("./following-sibling::ul/li/a[text()='"+getLanguageProperty("Edit")+"']")).click();
              Thread.sleep(3000);
              String linkedErrFieldName = "Product Category";
              By linkedFieldLocator = By.id("txtCatName");
              objDetails.editItemDetails(linkedErrFieldName, linkedFieldLocator);
              break;
            }
          }
        }
        waitUntilInvisibilityOfElement(By.id("itemListGrid_processing"),4);
        //findElement(By.xpath("//table[@id='itemListGrid']/thead/tr/th/input")).click();
      } else {
        findElement(By.id("addOnlineItem")).click();
        waitUntilVisibilityOfElement(By.id("addItemDialog"));
        objDetails.enterItemDetails();
      }
    }
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(3000);
    findElement(By.xpath("//a[@id='lnkScopeValidity']"),"Next button").click();
    LogScreenshot("Info", "Next button clicked");
    waitUntilVisibilityOfElement(
        By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Scope & Validity")+"']"));

    // Select organization Unit
    findElement(By.id("linkScopeSelected"),"Select Organization Units").click();
    waitUntilVisibilityOfElement(By.id("diagBoxScopeDefConfig"));
    LogScreenshot("Info", "Select Organization Units button clicked");
    Thread.sleep(6000);
    //if (driver.findElements(By.xpath("//div[@aria-describedby='diagBoxScopeDefConfig']/div/span[text()='Select Organization Units']")).size() > 0)
    if (driver.findElements(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Regions")+"']")).size() > 0){
      selectRegions();
      Thread.sleep(3000);
      selectCompaniesWithRegions();
    }else
      selectCompaniesWithoutRegions();
    Thread.sleep(3000);
    selectBusinessUnits();
    Thread.sleep(3000);
    selectLocations();
    Thread.sleep(3000);
    findElement(By.id("saveSelectedScope")).click();
    Thread.sleep(6000);
    findElement(By.id("lnkSubmit")).click();
    Thread.sleep(6000);
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process' and text()='"+getLanguageProperty("Catalog is ready for processing")+"']"),4);
    Thread.sleep(6000);
    if (driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Submit for approval")+"']]")).isDisplayed()){
      findElement(By.id("approvalSubmitBtn")).click();
      waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='"+getLanguageProperty("Submiting Catalog for approval")+"']"),4);
      //waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='Submiting Catalog for approval']"));
      Thread.sleep(3000);
      nameOfCatalog = catalogName;
    }  
    return nameOfCatalog;
  }
  
  private void selectSupplierAddress(){
	  try{
	    // Select Address
	    WebElement addrSelectorDropDown = driver.findElement(By.name("btnMyAddress"));
	    scroll_into_view_element(addrSelectorDropDown);
	        Thread.sleep(3000);
	    //findElement(By.name("btnMyAddress")).click();
	        driver.findElement(By.name("btnMyAddress")).click();
	    findElement(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]/li[1]")).click();
	   }catch(Exception e){}
  }
  
  public void selectRegions(){
    findElement(By.xpath("//ul[@id='zytree_scope_regions_tree']/li/label[not(contains(@class,'disable'))]/input")).click();
  }
  
  public void selectCompaniesWithRegions() throws Exception{
    findElement(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Companies")+"']")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    findElement(By.xpath("//a[text()='"+getLanguageProperty("Select Organization Unit")+"']")).click();
    waitUntilVisibilityOfElement(By.id("basketWrapper"));
    waitUntilInvisibilityOfElement(processingLoader,4);
    //Select All Companies
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"),4);
    Thread.sleep(3000);
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"),4);
        
    findElement(By.xpath("//table[contains(@id,'ListTable')]/thead/tr[1]/th[1]//input")).click();
    findElement(By.id("saveSelectedOUs")).click();
    waitUntilInvisibilityOfElement(By.id("basketWrapper"),4);
  }
  
  public void selectCompaniesWithoutRegions() throws InterruptedException{
    //Select All Companies
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"),4);
    Thread.sleep(3000);
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"),4);
        
    findElement(By.xpath("//table[contains(@id,'ListTable')]/thead/tr[1]/th[1]//input")).click();
  }
  
  public void selectBusinessUnits() throws InterruptedException{
    findElement(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Business Units")+"']")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(5000);
    //Select All Business Units
    findElement(By.xpath("//a[text()='"+getLanguageProperty("Select All Business Units")+"']")).click();
    Thread.sleep(1500);
  }
  
  public void selectLocations() throws InterruptedException{
    findElement(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Locations")+"']")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(5000);
    //Select All Locations
    findElement(By.xpath("//a[text()='"+getLanguageProperty("Select All Locations")+"']")).click();
    Thread.sleep(1500);
  }

  public void selectOrgUnit() throws Exception{
  /*  //Select All Companies
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"));
    Thread.sleep(3000);
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"));
    
    //findElement(By.xpath("//div[@id='diagBoxScopeDefConfig']//table[contains(@id,'ListTable')]/thead/tr[1]/th[1]//input")).click();
    findElement(By.xpath("//ul[@role='tablist']//a[text()='Companies']")).click();
    waitUntilInvisibilityOfElement(processingLoader);
    findElement(By.xpath("//a[text()='Select Organization Unit']")).click();
    waitUntilVisibilityOfElement(By.id("basketWrapper"));
    waitUntilInvisibilityOfElement(processingLoader);
    findElement(By.xpath("//table[contains(@id,'ListTable')]/thead/tr[1]/th[1]//input")).click();
    findElement(By.id("saveSelectedOUs")).click();
    waitUntilInvisibilityOfElement(By.id("basketWrapper"));*/
    findElement(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Business Units")+"']")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(4000);
    //Select All Business Units
    findElement(By.xpath("//a[text()='"+getLanguageProperty("Select All Business Units")+"']")).click();
    Thread.sleep(1500);
    /*findElement(By.xpath("//table[contains(@id,'ListGrid')]/tbody//a[text()='Select Organization Unit']")).click();*/
    findElement(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Locations")+"']")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(4000);
    //Select All Locations
    findElement(By.xpath("//a[text()='"+getLanguageProperty("Select All Locations")+"']")).click();
    Thread.sleep(1500);
    findElement(By.id("saveSelectedScope")).click();
  }
  
  public void updateCatalogDetailsReceivedFromZSN(String catalogName) throws Exception{						
		waitUntilVisibilityOfElement(By.id("txtDescription"));					
		driver.findElement(By.id("txtDescription")).sendKeys("Updating catalog");					
		LogScreenshot("Pass", "Catalog description updated");					
		Thread.sleep(2000);			
		try{					
			selectSupplierAddress(); //Select address				
		}catch(Exception e) {					
			LogScreenshot("INFO","Address not selected");				
		}					
		findElement(By.id("btnLnkNext"),"Next Button").click();					
		waitUntilInvisibilityOfElement(By.xpath("//div[@id='itemListGrid_processing'][contains(@style,'block')]"));					
					
							
		findElement(By.xpath("//a[@id='lnkScopeValidity']"),"Scope Next button").click();					
							
		waitUntilVisibilityOfElement(By.id("frmScopeValidity"));					
		selectOrganizationUnit();					
		LogScreenshot("Pass", "OU details entered");					
		waitUntilInvisibilityOfElement(processingLoader);					
		Thread.sleep(4000);					
				
		findElement(By.id("lnkSubmit")).click();					
		LogScreenshot("Pass", "Submit button clicked");					
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process' and text()='"+getLanguageProperty("Catalog is ready for processing")+"']"),4);					
		waitUntilVisibilityOfElement(By.xpath("//div[contains(@class,'po-workflowDialog')]"));					
		if (driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Submit for approval")+"']]")).isDisplayed()){					
			findElement(By.id("approvalSubmitBtn")).click();				
			LogScreenshot("Pass", "Submit button clicked");				
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='"+getLanguageProperty("Submiting Catalog for approval")+"']"),4);				
		}					
	} 						
	public void selectOrganizationUnit() throws Exception {						
		try {					
		NewCatalog objNewCatalog= new NewCatalog(driver, logger);					
		// Select organization Unit					
		findElement(By.id("linkScopeSelected"),"Select Organization Units").click();					
		LogScreenshot("Info", "Select Organization Units button clicked");					
							
		if (driver.findElements(By.xpath("//ul[@role='tablist']//a[text()='"+getLanguageProperty("Regions")+"']")).size() > 0){					
			objNewCatalog.selectRegions();				
			Thread.sleep(3000);				
			objNewCatalog.selectCompaniesWithRegions();				
		}else					
			objNewCatalog.selectCompaniesWithoutRegions();				
		Thread.sleep(3000);					
		objNewCatalog.selectBusinessUnits();					
		Thread.sleep(3000);					
		objNewCatalog.selectLocations();					
		Thread.sleep(3000);					
		findElement(By.id("saveSelectedScope")).click();					
		}catch(Exception e) {					
			LogScreenshot("FAIL","Organisation unit selection failed");				
		}					
	}		

  /**
   * @return the newCatalogLbl
   */
  public static By getNewCatalogLbl() {
    return newCatalogLbl;
  }

  /**
   * @param newCatalogLbl
   *            the newCatalogLbl to set
   */
  public void setNewCatalogLbl(By newCatalogLbl) {
    this.newCatalogLbl = newCatalogLbl;
  }
}
