package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;


public class Customize extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;

  public Customize(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  
  public boolean navigateToSettingsPage(String pgName){
    boolean result = false;
    try {
      WebElement pgLinkXpath = driver.findElement(By.xpath("//div[@class='configLinks']//a[text()='"+pgName+"']"));
      pgLinkXpath.click();
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public int getAllowedItemPriceOnAmendingPO(){
    JavascriptExecutor js = (JavascriptExecutor) driver;
    int allowedQty = Integer.valueOf((String) js.executeScript("return document.getElementById('EPROC_PURCHASE_ORDER_ITEM_PRICE_TOLERANCE_val').value"));
    try {
		LogScreenshot("info","Allowed Item Price :"+allowedQty);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    return allowedQty;
  }
  
  public int getAllowedItemQtyOnAmendingPO(){
    JavascriptExecutor js = (JavascriptExecutor) driver;
    int allowedQty = Integer.valueOf((String) js.executeScript("return document.getElementById('EPROC_PURCHASE_ORDER_ITEM_QUANTITY_TOLERANCE_val').value"));
    try {
		LogScreenshot("info","Allowed Item Quantity :"+allowedQty);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    return allowedQty;
  }

}
