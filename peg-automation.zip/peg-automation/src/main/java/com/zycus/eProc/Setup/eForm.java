package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class eForm extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By eFormLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='eForm']");
  
  public eForm(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterSettings() {
    boolean result = true;
    
    String requisitionEForm = "";
    String purchaseOrderEForm = "";
    
    try {
      //findElement(eFormLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //Requisition
      driver.findElement(By.xpath("//select[@name='EPROC_EFROM_REQUISITION_VIEW_POSITION']/option[text()='"+requisitionEForm+"']")).click();
      
      //Purchase Order
      driver.findElement(By.xpath("//select[@name='EPROC_EFROM_PURCHASE_ORDER_VIEW_POSITION']/option[text()='"+purchaseOrderEForm+"']")).click();
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
