package com.zycus.eProc.Requisition;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eProc.Category_FreeTextItem;
import com.zycus.eProc.Catalog.AllCatalogs;
import com.zycus.eProc.GuidedProcurement.GuidedProcurement_SearchEform;
import com.zycus.eProc.Punchout.CDW_page;
import com.zycus.eProc.Punchout.Punchouts_SearchPunchout;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Requisition_OnlineStore.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.selectItemFromCategoriesSideBar: 
 * <br>
 * 2.searchItemFromCatalog: 
 * <br>
 * 3.viewAllGuidedProcurements: 
 * <br>
 * 4.selectEForm: 
 * <br>
 * 3.searchItemFromCatalog: 
 * <br>
 * 4.viewAllPunchouts: 
 * <br>
 * 5.selectPunchouts: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class OnlineStore extends eProc_CommonFunctions {

	private String GLAccount;

	private String Datasheet_SupplierContacts;
	private List<String> listOfSupplierContact = new ArrayList<String>();
	private List<String> listOfSupplierCompany = new ArrayList<String>();

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @throws Exception 
	 */

	public OnlineStore(WebDriver driver, ExtentTest logger) throws Exception { 
		super(driver, logger);
		// Remove CNS-Notification, if displayed
		if (driver.findElements(By.xpath("//div[@class='cns_NotificationBox' and contains(@style,'block')]"))
				.size() > 0) {
			findElement(By.xpath("//label[@class='cns_CancelNotification']")).click();
			Thread.sleep(1500);
		}
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("ItemDetails", Datasheet_eInvoice);
		this.GLAccount = abc[0][5];


		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		this.listOfSupplierCompany.add(supplierDetails.getCompanyName());
		this.listOfSupplierContact.add(supplierDetails.getContactingPerson());
		supplierDetails.setSupplierData(1);
		this.listOfSupplierCompany.add(supplierDetails.getCompanyName());
		this.listOfSupplierContact.add(supplierDetails.getContactingPerson());
	
}

/**
 * <b>Function:</b> selectItemFromCategoriesSideBar -
 * 
 * @author Varun Khurana
 * @since April 2018
 * @param category
 * @param subCategory
 * @param searchItem
 * @return result - True/False
 */

public boolean selectItemFromCategoriesSideBar(String category, String subCategory, String searchItem) {
	boolean result = false;
	try {
		if (findElement(By.id("sideBarBox"))  !=  null) {
			findElement(By.xpath("//ul[@id='categoryLinks']/li[span[contains(text(),'" + category + "')]]")).click();
			findElement(By.xpath("//ul[@class='catPop-list devCatgeoryPopUp']/li[div[contains(text(),'" + subCategory
					+ "')]]/div[2]/a[contains(text(),'" + searchItem + "')]")).click();
			OnlineStore_SearchResults objReqSrchRes = new OnlineStore_SearchResults(driver, logger);
			if (findElement(objReqSrchRes.getNo_catalog_items_found()) == null) {
				LogScreenshot("Info", "No catalog items found message displayed");
			} else if (driver.findElements(objReqSrchRes.getSearch_results()).size() > 0) {
				result = true;
			}
		} else {
			LogScreenshot("Info", "Side bar category is not displayed");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return result;
}

/**
 * <b>Function:</b> searchItemFromCatalog -
 * 
 * @author Varun Khurana
 * @since April 2018
 * @param searchItem
 * @return result - True/False
 * @throws Exception 
 */

public void searchItemFromCatalog(String searchItem) throws Exception {
	if (driver.findElements(By.xpath("//div[@class='cns_NotificationBox']")).size() > 0)
		findElement(By.xpath("//label[@class='cns_CancelNotification']")).click();
	// Enter Search Item and click Search button
	driver.findElement(By.id("searchTerm")).sendKeys(searchItem);
	findElement(By.id("btnBigSearch")).click();
	OnlineStore_SearchResults objReqSrchRes = new OnlineStore_SearchResults(driver, logger);
	waitUntilInvisibilityOfElement(processingLoader);
	if (driver.findElements(objReqSrchRes.getNo_catalog_items_found()).size() == 0) {
		LogScreenshot("Fail","No catalog items found message displayed");
	} else if (driver.findElements(objReqSrchRes.getSearch_results()).size() > 0) {
		LogScreenshot("Pass","catalog items searched with : "+ searchItem);
	}
}


public void selectCatalog(String catalogName) throws Exception {
	/*if (driver.findElements(By.xpath("//div[@class='cns_NotificationBox']")).size() > 0)
		findElement(By.xpath("//label[@class='cns_CancelNotification']")).click();
*/
	//8 minutes of Waiting time for the approved catalog to display 
	Thread.sleep(120000);
	viewAllCatalogs();
	AllCatalogs objCatalogs = new AllCatalogs(driver, logger);
	objCatalogs.searchAndSelectCatalog(catalogName);
	OnlineStore_SearchResults objReqSrchRes = new OnlineStore_SearchResults(driver, logger);
	if (driver.findElements(objReqSrchRes.getSearch_results()).size() > 0)
		LogScreenshot("Pass","catalog items searched with : "+ catalogName);
	/*if (driver.findElements(objReqSrchRes.getNo_catalog_items_found()).size() > 0) {
      LogScreenshot("Fail","No catalog items found message displayed");
    } else if (driver.findElements(objReqSrchRes.getSearch_results()).size() > 0) {
      LogScreenshot("Pass","catalog items searched with : "+ catalogName);
    }*/
	else
		LogScreenshot("Fail","No catalog items displayed with Catalog : "+ catalogName);
}

public boolean viewAllCatalogs() {
	boolean result = false;
	try {
		// Click View All - Catalogs
		findElement(By.xpath("(//div[@class='boxLayout punchWrap']//span[text()='"+getLanguageProperty("View All")+"'])[2]")).click();
		if (driver.findElement(AllCatalogs.getCatalogs_popUp())  !=  null){
			LogScreenshot("Pass", "All catalogs pop up displayed");
			result = true;
		}else
			LogScreenshot("Info", "All catalogs pop up not displayed");
	} catch (Exception e) {
		e.printStackTrace();
	}
	return result;
}

/**
 * <b>Function:</b> viewAllGuidedProcurements -
 * 
 * @author Varun Khurana
 * @since April 2018
 * @param None
 * @return result - True/False
 */

public boolean viewAllGuidedProcurements() {
	boolean result = false;
	try {
		// Click View All - Guided Procurement
		findElement(By.xpath("//div[@class='boxLayout guidedWrap']//span[text()='"+getLanguageProperty("View All")+"']")).click();
		Thread.sleep(3000);
		GuidedProcurement_SearchEform objGPSrchEFrms = new GuidedProcurement_SearchEform(driver, logger);
		if (driver.findElement(objGPSrchEFrms.getEForms_popUp())  !=  null){
			LogScreenshot("Pass", "All eForms pop up displayed");
			result = true;
		}else
			LogScreenshot("Info", "All eForms pop up not displayed");
	} catch (Exception e) {
		e.printStackTrace();
	}
	return result;
}

/**
 * <b>Function:</b> selectEForm -
 * 
 * @author Varun Khurana
 * @since April 2018
 * @param EForm
 * @param shortDesc
 * @param quantity
 * @param uom
 * @param price
 * @param itemType
 * @param sourcingStatus
 * @param receiveBillBy
 * @param currency
 * @return result - True/False
 */

public String selectEFormFromDisplayedForms(String EForm) {
	String requisitionNum = null;
	String newRequisition = null;
	try {
		// Select a displayed eForm or select 1st eForm
		if (EForm  !=  "")
			findElement(By.xpath("//div[@class='bullet']//a[text()='" + EForm + "']")).click();
		else
			findElement(By.xpath("(//div[@class='bullet']//a)[1]")).click();

		Category_FreeTextItem objCategItem = new Category_FreeTextItem(driver, logger);
		if (driver.findElement(Category_FreeTextItem.getGuidedProc_createItemPg())  !=  null){
			objCategItem.selectExistingSupplier(listOfSupplierCompany.get(0));
			objCategItem.addItemToCart();
			newRequisition = objCategItem.checkOut();
			requisitionNum = newRequisition;
		}else
			LogScreenshot("Info", "Create free-item for category page not displayed");
	} catch (Exception e) {
		e.printStackTrace();
	}
	return requisitionNum;
}


/*public String selectEFormFromAllForms(String EForm) {
    String requisitionNum = null;
    String newRequisition = null;
    try {
      driver.findElement(By.id("txtSearchEform")).sendKeys(EForm);
      findElement(By.xpath("//a[div[@class='efrmVal' and @title='"+EForm+"']]")).click();
      Category_FreeTextItem objCategItem = new Category_FreeTextItem(driver, logger);
      waitUntilVisibilityOfElement(Category_FreeTextItem.getGuidedProc_createItemPg());
      LogScreenshot("Pass", "Navigated to Create free-item for category page");
      objCategItem.selectExistingSupplier(listOfSupplierCompany.get(0));
      objCategItem.addItemToCart();
      newRequisition = objCategItem.checkOut();
      requisitionNum = newRequisition;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return requisitionNum;
  }*/

public void selectEFormFromAllForms(String EForm) {
	String requisitionNum = null;
	String newRequisition = null;
	try {
		driver.findElement(By.id("txtSearchEform")).sendKeys(EForm);
		findElement(By.xpath("//a[div[@class='efrmVal' and @title='"+EForm+"']]")).click();
		Category_FreeTextItem objCategItem = new Category_FreeTextItem(driver, logger);
		waitUntilVisibilityOfElement(Category_FreeTextItem.getGuidedProc_createItemPg());
		LogScreenshot("Pass", "Navigated to Create free-item for category page");
		/*objCategItem.selectExistingSupplier(listOfSupplierCompany.get(0));
      objCategItem.addItemToCart();
      newRequisition = objCategItem.checkOut();
      requisitionNum = newRequisition;*/
	} catch (Exception e) {
		e.printStackTrace();
	}
	//return requisitionNum;
}

/**
 * <b>Function:</b> viewAllPunchouts -
 * 
 * @author Varun Khurana
 * @since April 2018
 * @param None
 * @return result - True/False
 */

public boolean viewAllPunchouts() {
	boolean result = false;
	try {
		// Click View All - Punchouts
		findElement(By.xpath("//div[@class='boxLayout punchWrap']//span[text()='"+getLanguageProperty("View All")+"']")).click();

		Punchouts_SearchPunchout objPnsSrchPnchout = new Punchouts_SearchPunchout(driver, logger);
		if (findElement(objPnsSrchPnchout.getAllPunchouts_popUp())  !=  null)
			result = true;
		else
			LogScreenshot("Info", "All Punchouts pop up not displayed");
	} catch (Exception e) {
		e.printStackTrace();
	}
	return result;
}

/**
 * <b>Function:</b> selectPunchouts -
 * 
 * @author Varun Khurana
 * @since April 2018
 * @param strPunchout
 * @return result - True/False
 */

public boolean selectPunchouts(String strPunchout) {
	boolean result = false;
	try {
		// Select a displayed Punchout or select 1st Punchout
		if (strPunchout  !=  "")
			findElement(By.xpath("//div[contains(@class,'punchImgWrap')]//a[@title='" + strPunchout + "']")).click();
		else
			findElement(By.xpath("(//div[contains(@class,'punchImgWrap')]//a)[1]")).click();

		CDW_page objCDWPg = new CDW_page(driver, logger);
		if (findElement(objCDWPg.getCDWPg())  !=  null)
			result = true;
		else
			LogScreenshot("Info", "Create free-item for category page not displayed");
	} catch (Exception e) {
		e.printStackTrace();
	}
	return result;
}

public void emptyCart() throws Exception{
	WebElement objCartItems = driver.findElement(By.xpath("//span[@class='bld cart_items']"));
	int itemsCount = Integer.parseInt(objCartItems.getText());
	if (itemsCount>0){
		objCartItems.click();
		waitUntilVisibilityOfElement(By.id("cart_itemsContainer"));
		LogScreenshot("Pass","Emptying Cart");
		findElement(By.xpath("//a[@title='"+getLanguageProperty("Empty cart")+"']")).click();
		findElement(By.xpath("//div[@role='dialog'][div//td[text()='"+getLanguageProperty("Are you sure you want to delete all Items from cart?")+"']]//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
		waitUntilVisibilityOfElement(By.id("cart_noItemsContainer"));
		LogScreenshot("Pass","Cart emptied");
		findElement(By.id("noCartContinueBtn")).click();
		waitUntilInvisibilityOfElement(By.id("cart_noItemsContainer"),4);
		itemsCount = Integer.parseInt(objCartItems.getText());
		if (itemsCount==0)
			LogScreenshot("Pass","No items in cart after emptying");
		else
			LogScreenshot("Fail","Cart still shows items even after emptying");
	}
}

}
