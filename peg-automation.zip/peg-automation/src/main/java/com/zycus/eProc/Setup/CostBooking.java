package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class CostBooking extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By costBookingLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Cost Booking']");
  
  public CostBooking(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterGeneralSettings() {
    boolean result = true;
    
    String budgetFormat = "";
    String seqNumStartsAt = "";
    String allowBudgetUtilization = "";
    String reserveBudgetForOrderOn = "";
    
    try {
      //findElement(costBookingLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //Numbering
      driver.findElement(By.id("EPROC_BUDGET_FORMAT")).sendKeys(budgetFormat);
      driver.findElement(By.id("EPROC_BUDGET_START_SEQUENCE_NUMBER")).sendKeys(seqNumStartsAt);
      
      //Control
      findElement(By.xpath("//input[@name='EPROC_BUDGET_UTILIZATION'][following-sibling::text()[contains(.,'"+allowBudgetUtilization+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_BUDGET_CONSUME_AMOUNT_ON'][following-sibling::text()[contains(.,'"+reserveBudgetForOrderOn+"')]]")).click();
      
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
