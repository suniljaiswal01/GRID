package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class BuyerDesk extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By buyersDeskLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Buyer's Desk']");
  private static By allowSubTotalChngID = By.id("txtAllowSubtotalChange");
  private static By increaseQtyApprovedPRVersionID = By.id("EPROC_BUYER_ALLOW_QUANTITY_ITEMS_QUANTITY_CHANGE_to");
  private static By increaseAmtApprovedPRVersionID = By.id("EPROC_BUYER_ALLOW_AMOUNT_ITEMS_QUANTITY_CHANGE_to");
  private static By allowNonCatalogPriceApprovedPRVersionID = By.id("EPROC_BUYER_ALLOW_NON_CATALOG_ITEMS_PRICE_CHANGE_to");
  private static By allowCatalogPriceApprovedPRVersionID = By.id("EPROC_BUYER_ALLOW_CATALOG_ITEMS_PRICE_CHANGE_to");
  
  public BuyerDesk(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterRequisitionSettings() {
    boolean result = true;
    
    String notifyRequesterOnChngsByBuyer ="";
    String allowBuyerToAddNewItem ="";
    String allowPRAmntToExceed ="";
    String allowPRAmntToExceedValue ="";
    String buyerToReplaceExistItems ="";
    String submitReqWithoutSavingAsDraft ="";
    String buyerToProceedWithUnassignedCatItems = "";
    String additionalItemDetailInQS = "";
    String provideContOrderInfoForTxtItems = "";
    String subTotalChngValue = "";
    String PRVersionApprovedQty = "";
    String PRVersionApprovedAmt = "";
    String PRVersionNonCatlogPrice = "";
    String PRVersionCatalogPrice = "";
    
    try {
      //findElement(buyersDeskLinkXpath).click();
      /********************************Tenant Level Customization*******************/
      //Control
      findElement(By.xpath("//input[@name='EPROC_BUYER_NOTIFY_REQUESTOR'][following-sibling::text()[contains(.,'"+notifyRequesterOnChngsByBuyer+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_BUYER_ALLOW_ADD_ITEMS'][following-sibling::text()[contains(.,'"+allowBuyerToAddNewItem+"')]]")).click();
      findElement(By.xpath("//input[@name='exceedType_radio'][following-sibling::text()[contains(.,'"+allowPRAmntToExceed+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_BUYER_ALLOW_REPLACE_ITEMS'][following-sibling::text()[contains(.,'"+buyerToReplaceExistItems+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_BUYER_ALLOW_SUBMIT_REQ_WITHOUT_SAVING_AS_DRAFT'][following-sibling::text()[contains(.,'"+submitReqWithoutSavingAsDraft+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_ALLOW_BUYERS_TO_PROCEED_WITH_UNASSIGNED_CATEGORIES'][following-sibling::text()[contains(.,'"+buyerToProceedWithUnassignedCatItems+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ADDITIONAL_ITEM_DETAILS_QS'][following-sibling::text()[contains(.,'"+additionalItemDetailInQS+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_BUYER_CONTRACT_NUBMER_MANDATORY'][following-sibling::text()[contains(.,'"+provideContOrderInfoForTxtItems+"')]]")).click();
      
      //Sub-total amount control for existing & replacement items
      driver.findElement(allowSubTotalChngID).sendKeys(subTotalChngValue);
      
      //Quantity Control for existing & replacement items
      driver.findElement(increaseQtyApprovedPRVersionID).sendKeys(PRVersionApprovedQty);
      driver.findElement(increaseAmtApprovedPRVersionID).sendKeys(PRVersionApprovedAmt);
      
      //Price Control for existing & replacement items
      driver.findElement(allowNonCatalogPriceApprovedPRVersionID).sendKeys(PRVersionNonCatlogPrice);
      driver.findElement(allowCatalogPriceApprovedPRVersionID).sendKeys(PRVersionCatalogPrice);
      
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }

}
