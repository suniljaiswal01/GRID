package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;


public class Catalog extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By catalogLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Catalog']");
  
  public Catalog(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterGeneralSettings() {
    boolean result = true;
    
    String editPunchoutItemsQty = "";
    String classifyItemsAutomatically = "";
    String decimalPlacesForItemPrice = "";
    
    try {
      //findElement(catalogLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //Control
      findElement(By.xpath("//input[@name='EPROC_ALLOW_PUNCHOUT_QUANTITY_EDIT'][following-sibling::text()[contains(.,'"+editPunchoutItemsQty+"')]]")).click();
      findElement(By.xpath("//select[@id='EPROC_CATALOG_VALID_DECIMAL_PLACES']/option[@value='"+decimalPlacesForItemPrice+"']")).click();
      findElement(By.xpath("//input[@name='EPROC_CATALOG_DEFAULT_AUTOCLASSIFY_FILE'][following-sibling::text()[contains(.,'"+classifyItemsAutomatically+"')]]")).click();
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
