package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;


public class Requisition extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By requisitionLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Requisition']");
  private static By reqNumFormatID = By.id("EPROC_REQUISITION_FORMAT");
  private static By reqSeqNoID = By.id("EPROC_REQUISITION_SEQUENCE_NO");
  private static By reqMaxSeqNoID = By.id("EPROC_REQUISITION_MAX_SEQUENCE_NO");
  private static By reqDefaultReqNameFormatID = By.id("EPROC_REQUISITION_NAME");
  private static By reqFreqSearchedItemsID = By.id("EPROC_REQUISITION_SEARCH_TERMS");
  private static By reqItemQtyThresholdID = By.id("EPROC_REQUISITION_ITEM_QUANTITY_THRESHOLD");
  private static By quotedBySupplierXpath = By.xpath("//input[@name='EPROC_REQUISITION_ALLOWED_SOURCING_STATUS[]'][following-sibling::text()[contains(.,'Quoted by supplier')]]");
  private static By estimatedPriceXpath = By.xpath("//input[@name='EPROC_REQUISITION_ALLOWED_SOURCING_STATUS[]'][following-sibling::text()[contains(.,'Estimated price')]]");
  private static By needAQuoteXpath = By.xpath("//input[@name='EPROC_REQUISITION_ALLOWED_SOURCING_STATUS[]'][following-sibling::text()[contains(.,'Need a Quote')]]");
  
  public Requisition(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterRequisitionSettings() {
    boolean result = true;
    
    String reqNumFormat ="";
    String reqSeqNo ="";
    String reqMaxSeqNo = "";
    String reqDefaultReqNameFormat = "";
    String reqFreqSearchedItems = "";
    String reqItemQtyThreshold = "";
    String orderFreeTxtItems = "";
    String requestFreeTxtItemWithoutCat = "";
    String submitReqWithoutRequiredByDt = "";
    String headerLvlReqByDtAutoCalc = "";
    String buyerToModifyRequiredByDt = "";
    String displayGLAcctInfoToRequester = "";
    String requesterToProvGLAcctInfo = "";
    String catItemsNotConfiguredOnPunchout = "";
    String cartWithPrevReqItems = "";
    String overrideDefGLAcct = "";
    String buyerAssignOnReqSubmission = "";
    String buyerAssignDefaultOption = "";
    String allowExistingPOTaggingToReq = "";
    String requesterToSuggSupplForBuyReview = "";
    String asyncWorkflowCreationOnReqSubmit = "";
    String autoCalcRequiredByDtPerLeadTime = "";
    String disbursementAsSettlementOption = "";
    String sendPOToSupplier = "";
    boolean quotedBySupplier = true;
    boolean estimatedPrice = true;
    boolean needAQuote = true;
    
    try {
      //findElement(requisitionLinkXpath).click();
      /********************************Tenant Level Customization*******************/
      //Numbering
      driver.findElement(reqNumFormatID).sendKeys(reqNumFormat);
      driver.findElement(reqSeqNoID).sendKeys(reqSeqNo);
      driver.findElement(reqMaxSeqNoID).sendKeys(reqMaxSeqNo);
      driver.findElement(reqDefaultReqNameFormatID).sendKeys(reqDefaultReqNameFormat);
      
      //Display
      driver.findElement(reqFreqSearchedItemsID).sendKeys(reqFreqSearchedItems);
      
      //Control
      driver.findElement(reqItemQtyThresholdID).sendKeys(reqItemQtyThreshold);
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ALLOW_REQUESTERS_TO_ORDER_FREE_TEXT_ITEMS'][following-sibling::text()[contains(.,'"+orderFreeTxtItems+"')]]")).click();
      if (!orderFreeTxtItems.equals("Never"))
        findElement(By.xpath("//input[@name='EPROC_REQUISITION_GUIDED_WITHOUT_CATEGORY'][following-sibling::text()[contains(.,'"+requestFreeTxtItemWithoutCat+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ALLOW_WITHOUT_REQUIRED_BY'][following-sibling::text()[contains(.,'"+submitReqWithoutRequiredByDt+"')]]")).click();
      findElement(By.xpath("//select[@name='EPROC_REQUISITION_REQUIRED_BY_DATE_AUTO_CALCULATION_DAY']/option[text()='"+headerLvlReqByDtAutoCalc+"']")).click();
      if (!submitReqWithoutRequiredByDt.equals("Yes"))
        findElement(By.xpath("//input[@name='EPROC_REQUISITION_ALLOW_BUYER_TO_MODIFY_REQUIRED_BY'][following-sibling::text()[contains(.,'"+buyerToModifyRequiredByDt+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_CHECKOUT_SHOW_GL_ACCOUNT'][following-sibling::text()[contains(.,'"+displayGLAcctInfoToRequester+"')]]")).click();
      if (!displayGLAcctInfoToRequester.equals("No"))
        findElement(By.xpath("//input[@name='EPROC_REQUISITION_CHECKOUT_REQUIRED_ACCOUNTING'][following-sibling::text()[contains(.,'"+requesterToProvGLAcctInfo+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_PUNCHOUT_ITEM_CATEGORY'][following-sibling::text()[contains(.,'"+catItemsNotConfiguredOnPunchout+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_PUNCHOUT_COPY_PREVENTION'][following-sibling::text()[contains(.,'"+cartWithPrevReqItems+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ALLOW_OVERRIDE_GL_ACCOUNT'][following-sibling::text()[contains(.,'"+overrideDefGLAcct+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ALLOW_SUBMIT_REQ_WITHOUT_BUYER'][following-sibling::text()[contains(.,'"+buyerAssignOnReqSubmission+"')]]")).click();
      if (!buyerAssignOnReqSubmission.equals("Hidden"))
        findElement(By.xpath("//input[@name='EPROC_REQUISITION_ASSIGN_BUYER_DEFAULT_TYPE'][following-sibling::text()[contains(.,'"+buyerAssignDefaultOption+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_TAGGING_EXISTING_PO_TO_REQUISITION'][following-sibling::text()[contains(.,'"+allowExistingPOTaggingToReq+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ALLOW_REQUESTER_TO_SUGGEST_SUPPLIER'][following-sibling::text()[contains(.,'"+requesterToSuggSupplForBuyReview+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_ASYNC_WORKFLOW_CREATE'][following-sibling::text()[contains(.,'"+asyncWorkflowCreationOnReqSubmit+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_USE_LEAD_TIME'][following-sibling::text()[contains(.,'"+autoCalcRequiredByDtPerLeadTime+"')]]")).click();
      
      //Disbursement
      findElement(By.xpath("//input[@name='EPROC_REQUISITION_USE_LEAD_TIME'][following-sibling::text()[contains(.,'"+disbursementAsSettlementOption+"')]]")).click();
      if (!disbursementAsSettlementOption.equals("No"))
        findElement(By.xpath("//input[@name='EPROC_REQUISITION_USE_LEAD_TIME'][following-sibling::text()[contains(.,'"+sendPOToSupplier+"')]]")).click();
      
      //Sourcing Status
      WebElement objQuotedBySupplier = findElement(quotedBySupplierXpath);
      if ((quotedBySupplier && !objQuotedBySupplier.isSelected())||(!quotedBySupplier && objQuotedBySupplier.isSelected()))
        objQuotedBySupplier.click();
      
      WebElement objEstimatedPrice = findElement(estimatedPriceXpath);
      if ((estimatedPrice && !objEstimatedPrice.isSelected())||(!estimatedPrice && objEstimatedPrice.isSelected()))
        objQuotedBySupplier.click();
      
      WebElement objNeedAQuote = findElement(needAQuoteXpath);
      if ((needAQuote && !objNeedAQuote.isSelected())||(!needAQuote && objNeedAQuote.isSelected()))
        objQuotedBySupplier.click();
      
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }

}
