package com.zycus.eProc.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class ReceiptsList extends eProc_CommonFunctions{
  
  private String receiptDt;
  
  private static By selectItemsChkbox     = By.id("chkAllItems");
  private static By consignNoId         = By.id("txt_consign");
  private static By shippedViaId       = By.id("txt_shipped_via");
  private static By airwayBillId       = By.id("txt_air_bill");
  private static By commentsId         = By.id("comment");
  private static By submitBtnId         = By.id("submitForm");
  private static By HeaderReqNum       = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName       = By.xpath("//h1[@class='pgHead']/span[3]");
  private static By addAttachmentsLink     = By.xpath("//a[@title='Add Attachments']");
  private static By attachFilePopUp       = By.xpath("//*[@id='addAttachment']/parent::div");
  static By receiptsListTable =  By.id("tblReceiptListing");
  
  private String consignmentNo;
  private String shippedVia;
  private String AirwayBillNo;
  private String Comments;
  
  public ReceiptsList(WebDriver driver, ExtentTest logger) throws Exception { 
    super(driver, logger);
    this.consignmentNo = "consignmentNo_"+generateNo();
    this.shippedVia = "shippedVia_"+generateNo();
    this.AirwayBillNo = "airwayBill_"+generateNo();
    this.Comments = "receiptComments";
  }
  
  public ReceiptsList(WebDriver driver, ExtentTest logger, String receiptDt) { 
    super(driver, logger);
    this.receiptDt = receiptDt;
    this.consignmentNo = "consignmentNo_"+generateNo();
    this.shippedVia = "shippedVia_"+generateNo();
    this.AirwayBillNo = "airwayBill_"+generateNo();
    this.Comments = "receiptComments";
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    this.HeaderReqNum = headerReqNum;
  }

  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    this.HeaderReqName = headerReqName;
  }
  
  public boolean filterByStatus(String checkBoxLbl) {
    boolean result = false;
    try {
      String colName = "Status";
      // findElement(By.xpath("//th[contains(@class,'postatusFltrHdr')]//b"));
      int colNo = getColNum(colName);
      findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
      filterByChkbox(checkBoxLbl);
      result = verifyFilteredStatus(colName, colNo, checkBoxLbl);
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public void cancelReceipt(String receiptNum) throws Exception{
    findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+receiptNum+"']]/td[last()]/a[text()='"+getLanguageProperty("Cancel")+"']")).click();
    if (driver.findElements(By.id("cancelReceiptBox")).size() > 0){
      driver.findElement(By.id("txtReceiptCancelComments")).sendKeys("Receipt cancel comments");
      findElement(By.id("cancelReceiptAction")).click();
      waitUntilInvisibilityOfElement(processingLoader,4);
      if (driver.findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[1]/td[last()-1]")).getText().equals(getLanguageProperty("Cancelled")))
        LogScreenshot("Pass","Receipt cancelled successfully");
      else
        LogScreenshot("Fail","Receipt not cancelled successfully");
    }else
      LogScreenshot("Fail","Cancel Receipt pop up not displayed");
  }
  
  public void deleteReceipt(String receiptNum) throws Exception{
    findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+receiptNum+"']]/td[last()]/a[text()='"+getLanguageProperty("Delete")+"']")).click();
    WebElement objConfirmDialog = driver.findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']]"));
    if (objConfirmDialog.isDisplayed())
      objConfirmDialog.findElement(By.xpath(".//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(8000);
    if (!(driver.findElements(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+receiptNum+"']]")).size() > 0))
      LogScreenshot("Pass","Receipt : "+receiptNum+" deleted");
    else
      LogScreenshot("Fail","Receipt : "+receiptNum+" not deleted");
  }
  
  public void downloadReturnNote(String returnNote, String PONum) throws Exception{
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    if (PONum != "")
      objOrders.filterByPONumber(PONum);
    else{
      PONum = driver.findElement(PurchaseOrders.poNumTxtXpath).getText(); 
      objOrders.filterByPONumber(PONum);
    }
    //objOrders.takeAction("Create Receipt");
    objOrders.viewPO(PONum);
    PurchaseOrder objPO = new PurchaseOrder(driver, logger);
    objPO.navigateToPOTabs("Receipt");
    String filePath = "C:/Users/"+System.getProperty("user.name")+"/Downloads";
    String filePartName = returnNote;
    String fileExtension = "pdf";
    LogScreenshot("Info","Return Note to Download is "+returnNote);
    if (!(driver.findElements(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+returnNote+"']]/td[contains(@class,'status') and text()='Returned']")).size() > 0)){
      LogScreenshot("Info", "Waiting for 3 min for Return Note to be in Returned status");
      Thread.sleep(180000);
      driver.navigate().refresh();
    }
    if (driver.findElements(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+returnNote+"']]/td[contains(@class,'status') and text()='Returned']")).size() > 0){
      findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+returnNote+"']]/td[last()]/a[text()='"+getLanguageProperty("Download as PDF")+"']")).click();
      Thread.sleep(5000);
      String modifiedFileName = filePartName.replace("/", "");
      if (checkFileExists(filePath, modifiedFileName, fileExtension))
        LogScreenshot("Pass", "Return Note : "+returnNote+" downloaded as pdf");
      else
        LogScreenshot("Fail", "Return Note : "+returnNote+" not downloaded");
    }else
      LogScreenshot("Fail", "Return Note : "+returnNote+" not in Returned status");
  }
  
  public void deleteReturnNote(String returnNote) throws Exception{
    findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+returnNote+"']]/td[last()]/a[text()='"+getLanguageProperty("Delete")+"']")).click();
    WebElement objConfirmDialog = driver.findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']]"));
    if (objConfirmDialog.isDisplayed())
      objConfirmDialog.findElement(By.xpath(".//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(15000);
    if (!(driver.findElements(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[1]/a[text()='"+returnNote+"']]")).size() > 0))
      LogScreenshot("Pass","Return Note : "+returnNote+" deleted");
    else
      LogScreenshot("Fail","Return Note : "+returnNote+" not deleted");
  }
  
  /*public void createNewReceipt() throws Exception{
    findElement(By.xpath("//a[span[text()='Create']]")).click();
    findElement(By.xpath("//a[span[text()='Create Receipt']]")).click();
    CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
    objReceipt.submitNewReceipt();
  }
  
  public void createNewReturnNote() throws Exception{
    findElement(By.xpath("//a[span[text()='Create']]")).click();
    findElement(By.xpath("//a[span[text()='Create Return Note']]")).click();
    CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
    objReceipt.submitNewReceipt();
  }*/
  
  public String submitNewReceipt() throws Exception{
    /*findElement(By.xpath("//a[span[text()='Create']]")).click();
    findElement(By.xpath("//a[span[text()='Create Receipt']]")).click();*/
    CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
    return objReceipt.createNewReceipt("submit");
  }
  
  public String saveNewReceiptAsDraft(String PONum) throws Exception{
    String newReceipt = null;
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    if (PONum != "")
      objOrders.filterByPONumber(PONum);
    else{
      PONum = driver.findElement(PurchaseOrders.poNumTxtXpath).getText(); 
      objOrders.filterByPONumber(PONum);
    }
    objOrders.takeAction(PONum, "Create Receipt");
    //ReceiptsList objList = new ReceiptsList(driver, logger);
    /*findElement(By.xpath("//a[span[text()='Create']]")).click();
    findElement(By.xpath("//a[span[text()='Create Receipt']]")).click();*/
    CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
    newReceipt = objReceipt.createNewReceipt("saveAsDraft");
    if (newReceipt != null)
      LogScreenshot("Pass", "New Receipt "+newReceipt+" created against PO : "+PONum);
    else
      LogScreenshot("Fail", "No receipt created against PO : "+PONum);
    //Verify if receipt created
    return newReceipt;
  }
  
  public String submitNewReturnNote(String PONum) throws Exception{
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    if (PONum != "")
      objOrders.filterByPONumber(PONum);
    else{
      PONum = driver.findElement(PurchaseOrders.poNumTxtXpath).getText(); 
      objOrders.filterByPONumber(PONum);
    }
    //objOrders.takeAction("Create Receipt");
    objOrders.viewPO(PONum);
    PurchaseOrder objPO = new PurchaseOrder(driver, logger);
    objPO.navigateToPOTabs("Receipt");
    findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Create")+"']]")).click();
    findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Create Return Note")+"']]")).click();
    CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
    return objReceipt.createNewReturnNote("submit",1);
  }
  
  public String saveNewReturnNoteAsDraft(String PONum) throws Exception{
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    if (PONum != "")
      objOrders.filterByPONumber(PONum);
    else{
      PONum = driver.findElement(PurchaseOrders.poNumTxtXpath).getText(); 
      objOrders.filterByPONumber(PONum);
    }
    //objOrders.takeAction("Create Receipt");
    objOrders.viewPO(PONum);
    PurchaseOrder objPO = new PurchaseOrder(driver, logger);
    objPO.navigateToPOTabs("Receipt");
    findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Create")+"']]")).click();
    findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Create Return Note")+"']]")).click();
    CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
    return objReceipt.createNewReturnNote("saveAsDraft",1);
  }
  
}
