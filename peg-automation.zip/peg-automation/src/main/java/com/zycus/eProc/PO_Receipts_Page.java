package com.zycus.eProc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class PO_Receipts_Page extends eProc_CommonFunctions{
  
  private By createReceiptXpath     = By.xpath("//a[@class='scLnk createReceipt']");
  private By createReturnNoteId     = By.id("createReturnNote");
  
  public PO_Receipts_Page(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }
  
  public boolean createReceipt() throws Exception{
    findElement(createReceiptXpath).click();
    //Validate Create Receipts page opened
    return true;  
  }
  
  public boolean createReturnNote() throws Exception{
    findElement(createReturnNoteId).click();
    return true;
  }
   
}
