package com.zycus.eProc.BuyersDesk;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

public class Requisitions extends eProc_CommonFunctions {
  
  private String StartDt;
  private String EndDt;
  private String periodName;
  private static By statusXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
  private static By dateXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'receivedOn')]");
  eInvoice_CommonFunctions objFunctions = null;
  private String GLAccount;
  
  public Requisitions(WebDriver driver, ExtentTest logger) throws Exception { 
    super(driver, logger);
    objFunctions = new eInvoice_CommonFunctions(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
    ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
    String eInvoiceDatasheet = configurationProperties.getProperty("Datasheet_eInvoice");
    String[][] abc = (String[][]) objFunctions.dataProvider("ItemDetails", eInvoiceDatasheet);
    this.GLAccount = abc[0][5];
  }
  
  /**
   * <b>Function:</b> addPeriod
   * @author Varun Khurana
   * @since April 2018
   * @param description
   * @return result
   * @throws Exception 
   */
  
  public String addPeriod(String...description) throws Exception{
    String addedPeriod = null;
    String desc = description.length==0?"Budget Period Description":description[0];
    String period = periodName;
    try {
      findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'"+getLanguageProperty("Start Date")+"')]]//img")).click();
      selectDate_v1(StartDt);
      findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'"+getLanguageProperty("End Date")+"')]]//img")).click();
      selectDate_v1(EndDt);
      if (periodName  !=  "")
        driver.findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'"+getLanguageProperty("Period Name")+"')]]//input")).sendKeys(periodName);
      else{
        period = driver.findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'"+getLanguageProperty("Period Name")+"')]]//input")).getText();
        if (period  !=  this.getPeriodName(StartDt, EndDt))
          LogScreenshot("Info", "Incorrect Period Name displayed or is blank");
      }
      if (desc != "")
        driver.findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'"+getLanguageProperty("Description")+"')]]//textarea")).sendKeys(desc);
      findElement(By.xpath("//*[@id='addNewPeriod']//input[@value='Add']")).click();
      if (findElement(By.xpath("//*[@id='budgerPeriodDropDown']//a[text()='"+period+"']")) != null)
        addedPeriod = period;
      else
        LogScreenshot("Info", "Period not added to the list");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return addedPeriod;
  }
  
  /**
   * <b>Function:</b> getPeriodName
   * @author Varun Khurana
   * @since April 2018
   * @param StartDt
   * @param EndDt
   * @return periodName
   */
  
  public String getPeriodName(Date StartDt, Date EndDt){
    int Start_dd = Integer.parseInt(StartDt.toString().split("/")[0]);
    int Start_mm = Integer.parseInt(StartDt.toString().split("/")[1]);
    int Start_yr = Integer.parseInt(StartDt.toString().split("/")[2].substring(2));
    
    int End_dd = Integer.parseInt(EndDt.toString().split("/")[0]);
    int End_mm = Integer.parseInt(EndDt.toString().split("/")[1]);
    int End_yr = Integer.parseInt(EndDt.toString().split("/")[2].substring(2));

    String periodName = "FY"+Start_yr+"-"+End_yr+"-"+Month.of(Start_mm).name()+"/"+Start_dd+"-"+Month.of(End_mm).name()+"/"+End_dd;
    return periodName;
  }
  
  private String getPeriodName(String StartDt, String EndDt){
    String Start_dd = StartDt.split("/")[0];
    int Start_mm = Integer.parseInt(StartDt.split("/")[1]);
    String Start_yr = StartDt.split("/")[2].substring(2);
    
    String End_dd = EndDt.split("/")[0];
    int End_mm = Integer.parseInt(EndDt.split("/")[1]);
    String End_yr = EndDt.split("/")[2].substring(2);

    String periodName = "FY"+Start_yr+"-"+End_yr+"-"+Month.of(Start_mm).name()+"/"+Start_dd+"-"+Month.of(End_mm).name()+"/"+End_dd;
    return periodName;
  }
  
  public boolean filterByStatus(String checkBoxLbl) throws Exception {
    findElement(By.xpath("//th[contains(@class,'statusFilter')]//b")).click();
    return objFunctions.filterByChkbox(checkBoxLbl, statusXpath);
  }
  
  public boolean filterByReceivedOn(Date fromDt, Date ToDt) throws Exception {
    findElement(By.xpath("//th[contains(@class,'receivedOnFilter')]//b")).click();
    return objFunctions.filterByDateRange(fromDt, ToDt, dateXpath);
  }  

  public boolean filterByRequisitionNo(String requisitionNo) {
    return objFunctions.filterByText("Requisition No", requisitionNo);
  }
  
  public boolean filterByRequisitionName(String requisitionName) {
    return objFunctions.filterByText("Requisition Name", requisitionName);
  }
  
  public boolean filterByRequester(String requester) {
    return objFunctions.filterByText_AutoComplete("Requester", requester);
  }
  
  public String convertToPO(String RequisitionNum) throws Exception{
    String convertedPO = null;
    waitUntilInvisibilityOfElement(processingLoader,4);
    findElement(By.xpath("//table[@id='buyerlisting']/tbody/tr[td[3]/a[text()='"+RequisitionNum+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")).click();
    findElement(By.xpath("//table[@id='buyerlisting']/tbody/tr[td[3]/a[text()='"+RequisitionNum+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']/following-sibling::ul/li/a[text()='"+getLanguageProperty("Convert to PO")+"']")).click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(3000);
    if (driver.findElements(By.id("validationErrorMessage")).size() > 0){
      
      //Navigate to Requisition Number
      Thread.sleep(3000);
      findElement(By.xpath("//table[@id='buyerlisting']/tbody/tr/td[3]/a[text()='"+RequisitionNum+"']")).click();
      waitUntilVisibilityOfElement(By.xpath("//span[@class='chkoutlbl'][contains(text(),'"+getLanguageProperty("Edit Requisition")+"')]"));
      
      //Select all items
      WebElement objSelectItems = driver.findElement(By.xpath("//div[@class='groupDetail']//input[@class='autoCheckAll']"));
      scroll_into_view_element(objSelectItems);
      Thread.sleep(2000);
      objSelectItems.click();
      driver.findElement(By.id("txtChangeComments")).sendKeys("Requisition change comments");
      LogScreenshot("Info", "Requisition change comments entered");
      findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Convert to PO")+"']]")).click();
      Thread.sleep(3000);
      scroll_to_TopofPage();
      Thread.sleep(2000);
      LogScreenshot("Info", "Convert to PO button clicked");
      // As GL Account gets invisible on editing Billing,Delivery Info, hence adding GL Account again
      try {
    	  //Expand All items
    	WebElement expandAll = findElement(By.xpath("//div[@id='requisitionItemGroups']//a[text()='Expand All']"));
    	scroll_into_view_element(expandAll);
      	Thread.sleep(2000);
    	expandAll.click();
    	Thread.sleep(2000);
        if (!(driver.findElements(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Submit for approval")+"']]")).size() > 0)){
          //Removing Filters on items
          
         /* //Assigned Buyer
          WebElement assignedBuyerFilter = driver.findElement(By.xpath("//div[contains(@class,'assignedBuyerFltrHdr')]"));
          if(assignedBuyerFilter.getAttribute("class").contains("fltr-active"))
        	  assignedBuyerFilter.findElement(By.xpath(".//span[@title='Clear Filter']")).click();
          Thread.sleep(1000);
          
          //Item Order Status Filtered
          WebElement itemOrderStatusFilter = driver.findElement(By.xpath("//div[contains(@class,'itemOrderStatusFilterDiv')]"));
          if(itemOrderStatusFilter.getAttribute("class").contains("fltr-active"))
        	  itemOrderStatusFilter.findElement(By.xpath(".//span[@title='Clear Filter']")).click();
          Thread.sleep(1000);
          
          //Expand Item
          List<WebElement> itemsList = driver.findElements(By.xpath("//tbody[@class='requisitionItems']//tr[contains(@class,'requisitionItem') and not(contains(@id,'item_summary'))]"));
          for(WebElement objItem : itemsList){
        	  if(!(objItem.getAttribute("class").contains("isSplitOpen"))){
        		  objItem.findElement(By.xpath(".//span[@title='Expand Item']")).click();
        	  }
          }
          Thread.sleep(2000);*/
          
          WebElement accountingEditBtn  = driver.findElement(By.xpath("//table/tbody/tr[contains(@id,'item_summary')]//table//td[contains(@class,'error')]//a[text()='"+getLanguageProperty("Edit")+"']"));
          scroll_into_view_element(accountingEditBtn);
          Thread.sleep(2000);
          accountingEditBtn.click();
          waitUntilVisibilityOfElement(By.id("itemSummary"));
          LogScreenshot("info","Selecting GL Account");
          //driver.findElement(By.xpath("//input[contains(@id,'generalLedger')]")).click();
          //waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
          //driver.findElement(By.xpath("//input[contains(@id,'generalLedger')]")).sendKeys(GLAccount);
          //Thread.sleep(2000);
          //waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
          //Thread.sleep(1500);
          //findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
          try{
        	  driver.findElement(By.xpath("//input[contains(@id,'generalLedger')]")).click();
              waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
              Thread.sleep(1500);
        	  findElement(By.xpath("(//ul[li][1]/li/a[.|@span][contains(.,'"+GLAccount+"')])[1]")).click();
        	  Thread.sleep(4000);
        	  LogScreenshot("info","GL Account selected");
          }catch(Exception e){
        	  try{
	        	  driver.findElement(By.xpath("//input[contains(@id,'generalLedger')]")).click();
	              waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
	              Thread.sleep(1500);
	        	  findElement(By.xpath("(//ul[li]/li/a[.|@span][contains(.,'"+GLAccount+"')])[1]")).click();
	              Thread.sleep(4000);
	              LogScreenshot("info","Tried again - GL Account selected");
        	  }catch(Exception ex){
        		  driver.findElement(By.xpath("//input[contains(@id,'generalLedger')]")).sendKeys(GLAccount);
                  waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
                  Thread.sleep(1500);
            	  findElement(By.xpath("(//ul[li]/li/a[.|@span][contains(.,'"+GLAccount+"')])[1]")).click();
                  Thread.sleep(4000);
                  LogScreenshot("info","Tried for third time - GL Account selected");
        	  }
          }
          try{
        	  WebElement okBtn = driver.findElement(By.id("saveRequisitionItemSummary"));
        	  JavascriptExecutor js  = (JavascriptExecutor)driver;
        	  js.executeScript("arguments[0].click();", okBtn);
        	  Thread.sleep(5000);
              LogScreenshot("info","Ok button clicked");
        	  //findElement(By.id("saveRequisitionItemSummary"), "Ok button").click();
        	  waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='itemSummary' and contains(@style,'none')]"));
        	  if(!(driver.findElements(By.xpath("//div[@aria-describedby='itemSummary' and contains(@style,'none')]")).size()>0)){
        		  findElement(By.id("saveRequisitionItemSummary"), "Ok button").click();
    	          //waitUntilInvisibilityOfElement(By.id("itemSummary"),4);
    	          waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='itemSummary' and contains(@style,'none')]"));
    	          Thread.sleep(3000);
    	          LogScreenshot("info","Ok button clicked again");
        	  }
          }catch(Exception ex){
        	  findElement(By.id("saveRequisitionItemSummary"), "Ok button").click();
	          //waitUntilInvisibilityOfElement(By.id("itemSummary"),4);
	          waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='itemSummary' and contains(@style,'none')]"));
	          Thread.sleep(3000);
	          LogScreenshot("info","Ok button clicked again");
          }
          
          /*try{
	          findElement(By.id("saveRequisitionItemSummary"), "Ok button").click();
	          //waitUntilInvisibilityOfElement(By.id("itemSummary"),4);
	          waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='itemSummary' and contains(@style,'none')]"));
	          Thread.sleep(3000);
	          LogScreenshot("info","Ok button clicked");
          }catch(Exception e){
        	  WebElement okBtn = driver.findElement(By.id("saveRequisitionItemSummary"));
        	  JavascriptExecutor js  = (JavascriptExecutor)driver;
        	  js.executeScript("arguments[0].click();", okBtn);
        	  //findElement(By.id("saveRequisitionItemSummary"), "Ok button").click();
        	  waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='itemSummary' and contains(@style,'none')]"));
              Thread.sleep(3000);
              LogScreenshot("info","Ok button clicked again");
          }*/
          Thread.sleep(3000);
          findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Convert to PO")+"']]")).click();
          Thread.sleep(3000);
          scroll_to_TopofPage();
          Thread.sleep(2000);
          LogScreenshot("Info", "Convert to PO button clicked");
        }
      } catch (Exception e) {
      e.printStackTrace();
      }
      waitUntilInvisibilityOfElement(By.id("status_overlay_updateRequisition"),4);
      if(driver.findElements(By.xpath("//tr[contains(@class,'suggestedPoRow')]/td/input[@type='checkbox']")).size()>0)
      	findElement(By.xpath("//tr[contains(@class,'suggestedPoRow')]/td/input[@type='checkbox']")).click();
      findElement(By.id("releasePO"), "Submit POs for processing button").click();
      waitUntilInvisibilityOfElement(By.id("status_overlay_convertProgress"),4);
      Thread.sleep(3000);
      if (driver.findElements(By.xpath("//div[@id='messageContainer']/div/div[contains(@class,'iconError')]")).size() > 0){
        //if (driver.findElements(By.id("//td[contains(@class,'errorBlock')]")).size() > 0){
        List<WebElement> listOfErrors = driver.findElements(By.xpath("//td[contains(@class,'errorBlock')]/span"));
        for(WebElement errorRow : listOfErrors){
          switch(errorRow.getAttribute("data-qtipmsg")){
          case "Invalid base exchange rate":
            Random rnd = new Random();
            errorRow.findElement(By.xpath("./preceding-sibling::input[contains(@id,'baseExchangeRate')]")).clear();
            errorRow.findElement(By.xpath("./preceding-sibling::input[contains(@id,'baseExchangeRate')]")).sendKeys(String.valueOf(1+rnd.nextInt()));
            findElement(By.id("releasePO"), "Submit POs for processing button").click();
            waitUntilInvisibilityOfElement(By.id("status_overlay_convertProgress"),4);
            Thread.sleep(3000);
            break;
          }
        }
        //}
      }
      LogScreenshot("Pass", "Requisition converted to Purchase Order");
      convertedPO = driver.findElement(By.xpath("//tr[contains(@class,'convertedPoRow')]/td/a[@class='scLnk']")).getText().trim();
      //findElement(By.id("closeSummary"),"Back button").click();
    }
    return convertedPO;
  }
  
  
  public void editRequisition(String requisitionNum) throws Exception{
    WebElement actionBtn = driver.findElement(By.xpath("//table[@id='buyerlisting']//tr[td[contains(@class,'requisitionNo')]/a[text()='"+requisitionNum+"']]/td[last()]//a[text()='Actions']"));
    actionBtn.click();
    LogScreenshot("Info", "Actions button clicked");
    actionBtn.findElement(By.xpath("./following-sibling::ul//a[text()='Edit']")).click();
    waitUntilVisibilityOfElement(By.xpath("//span[@id='lblRequisitionNo' and text()='"+requisitionNum+"']"));
    Thread.sleep(4000);
    
    WebElement deliveryOn = driver.findElement(By.xpath("//input[@id='deliveryOn_header_summary']/following-sibling::img"));
    scroll_into_view_element(deliveryOn);
    clickElement(deliveryOn);
    LogScreenshot("info","Delivery On Date Selected");
    String dt = DateTimeFormatter.ofPattern("dd/MM/YYYY").format(LocalDate.now());
    selectDate_v1(dt);
    
    WebElement objChangeComments = driver.findElement(By.id("txtChangeComments"));
    scroll_into_view_element(objChangeComments);
    Thread.sleep(2000);
    objChangeComments.sendKeys("requisition change comments");
    LogScreenshot("pass","Requisition Change comment added");
    findElement(By.xpath("//span[@id='footerGroupActions']/a[span[text()='Send for Approval']]"), "Send for Approval button").click();
    LogScreenshot("info","Send for approval button clicked");
    waitUntilInvisibilityOfElement(By.xpath("//div[@id='status_overlay_updateRequisition']"));
    waitUntilVisibilityOfElement(By.id("buyerlisting"));
    Thread.sleep(2000);
  }
  
  public boolean verifyRequisitionStatus(String requisitionNum, String status){
    boolean result = false;
    String currStatus = driver.findElement(By.xpath("//table[@id='reqList']//tr[td[contains(@class,'requisitionNo')]/a[text()='"+requisitionNum+"']]/td[contains(@class,'status')]//em")).getText().trim().substring(1,status.length()-1);
    if (currStatus.equals(status))
      result= true;
    return result;
  } 
  
  public String getRequisitionNumber(String requisitionName) throws Exception{
      String reqNo = driver.findElement(By.xpath("//table[@id='reqList'|@id='buyerlisting']/tbody/tr[td[contains(@class,'name') and contains(text(),'"+requisitionName+"')]]/td[contains(@class,'requisitionNo')]/a")).getText();
      if (reqNo != "") {
    	  LogScreenshot("Info", "Requisition Number for the Requisition "+requisitionName+ " is "+reqNo);
  }
      return reqNo;
    }
  
  
  public String getRequisitionStatusByName(String requisitionNum) throws Exception{
    String tempStatus = driver.findElement(By.xpath("//table[@id='reqList']//tr[td[contains(@class,'name')][text()='"+requisitionNum+"']]/td[contains(@class,'status')]//em")).getText().trim();
    return tempStatus.substring(1,tempStatus.length()-1);
	  } 
}
