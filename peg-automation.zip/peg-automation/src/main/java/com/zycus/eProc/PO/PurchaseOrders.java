package com.zycus.eProc.PO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;
import com.main.eProcFlows.BudgetCreation;
//import com.zycus.eInvoice.Invoice.PurchaseOrder;
import com.zycus.eProc.CheckoutPg;
import com.zycus.eProc.eInvoice.InvoiceAgainstPO;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> PurchaseOrders.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.filterByStatus: user shall be able to filter by Status 
 * <br>
 * 2.filterByReceivedOn: user shall be able to filter by Received On 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class PurchaseOrders extends eProc_CommonFunctions {

	private static By recallApprovalCmmntId = By.id("txtComment");
	private static By recallBtnId = By.id("recallBtn");
	private static By recallReqActionMsgId = By.id("status_overlay_savingComment");
	private static By closeCmmntId = By.id("closeCommentTextArea");
	private static By closeBtnId = By.id("closeAction");
	//private static By statusTxtXpath = By.xpath("(//table[contains(@class,'dataTable')]//td/div[contains(@class,'statusTxt')])[1]");
	//private static By actionsLinkXpath = By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]");
	static By poNumTxtXpath = By.xpath("(//table[contains(@class,'dataTable')]//td[2]/a)[1]/../following-sibling::td/a");
	//private static By poNameTxtXpath = By.xpath("(//table[contains(@class,'dataTable')]//td[3]/a)[1]/../following-sibling::td");
	private static By deletePopUpXpath = By.xpath("//div[div//td[text()='Are you sure want to delete this Purchase Order?']]");
	private static By deletePopUpYesLink = By.xpath(
			"//div[div//td[text()='Are you sure want to delete this Purchase Order?']]//button/span[text()='Yes']");

	private static By closePopUpXpath = By.xpath("//div[@aria-describedby='closePOBox']");
	private static By closePOBtn = By.id("closePOAction");

	private static By reminderMsgSentXpath = By.xpath("//*[@id='status_overlay_sendingReminder']/div");
	private static By recallApprovalReqPopUp = By.xpath("//*[@id='saveCommentDOM']/parent::div");
	private static By closeReqPopUp = By.xpath("//*[@id='closeBox']/parent::div");
	//private String supplier;
	private String GLAccount;

	private String Datasheet_SupplierContacts;
	private List<String> listOfSupplierContact = new ArrayList<String>();
	private List<String> listOfSupplierCompany = new ArrayList<String>();
	private String contractingParty;
	private String contactPerson;

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @throws Exception 
	 */

	public PurchaseOrders(WebDriver driver, ExtentTest logger) throws Exception { 
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("ItemDetails", Datasheet_eInvoice);
		this.GLAccount = abc[0][5];

		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		this.listOfSupplierCompany.add(supplierDetails.getCompanyName());
		this.listOfSupplierContact.add(supplierDetails.getContactingPerson());
		supplierDetails.setSupplierData(1);
		this.listOfSupplierCompany.add(supplierDetails.getCompanyName());
		this.listOfSupplierContact.add(supplierDetails.getContactingPerson());
		/*  Datasheet_SupplierContacts = configurationProperties.getProperty("Datasheet_SupplierContacts");
    String environment = configurationProperties.getProperty("Environment");
    String[][] abc2 = (String[][]) objFunctions.dataProvider(environment, Datasheet_SupplierContacts);

    for(int i=0;i<abc2.length;i++) {
      listOfSupplierCompany.add(abc2[i][0]);
      listOfSupplierContact.add(abc2[i][1]);
    }*/
	}

	eInvoice_CommonFunctions objFunctions = new eInvoice_CommonFunctions(driver, logger);

	/**
	 * <b>Function:</b> filterByStatus - To filter by Status
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param checkBoxLbl
	 *            - Label of the checkbox which is to be selected
	 * @return result - True/False
	 */

	public boolean filterByStatus(String checkBoxLbl) {
		boolean result = false;
		try {
			String colName = "Status";
			// findElement(By.xpath("//th[contains(@class,'postatusFltrHdr')]//b"));
			int colNo = getColNum(colName);
			findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
			filterByChkbox(checkBoxLbl);
			result = verifyFilteredStatus(colName, colNo, checkBoxLbl) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByType - To filter by Type
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param checkBoxLbl
	 *            - Label of the checkbox which is to be selected
	 * @return result - True/False
	 */

	public boolean filterByType(String checkBoxLbl) {
		boolean result = false;
		try {
			String colName = "Type";
			// findElement(By.xpath("//th[contains(@class,'potypeFltrHdr')]//b"));
			int colNo = getColNum(colName);
			findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
			filterByChkbox(checkBoxLbl);
			result = verifyFilteredStatus(colName, colNo, checkBoxLbl) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByPODate -
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromDt
	 *            - From Date , ToDt - To Date
	 * @return result - True/False
	 */

	public boolean filterByPODate(Date fromDt, Date ToDt) {
		boolean result = false;
		try {
			String colName = "PO Date";
			// findElement(By.xpath("//th[contains(@class,'podateFltrHdr')]//b"));
			int colNo = getColNum(colName);
			findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
			filterByDateRange(fromDt, ToDt);
			result = verifyFilteredDates(colNo, fromDt, ToDt) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByPONumber(String PONum) {
		return objFunctions.filterByText("PO Number", PONum);
	}

	public boolean filterByOrderDesc(String orderDesc) {
		return objFunctions.filterByText("Order Description", orderDesc);
	}

	public boolean filterBySupplier(String supplier) {
		return objFunctions.filterByText_AutoComplete("Supplier", supplier);
	}

	public boolean filterByBuyer(String buyer) {
		return objFunctions.filterByText_AutoComplete("Buyer", buyer);
	}

	/**
	 * <b>Function:</b> filterByAmount
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromAmt
	 *            - From Amount , ToAmt - To Amount
	 * @return result - True/False
	 */

	public boolean filterByAmount(float fromAmt, float ToAmt) {
		boolean result = false;
		try {
			String colName = "Amount";
			int colNo = getColNum(colName);
			findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
			// findElement(By.xpath("//th[contains(@class,'poamountFltrHdr')]//b"));
			filterByAmtRange(fromAmt, ToAmt);
			result = verifyFilteredAmount(colNo, fromAmt, ToAmt) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByAmount
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromAmt
	 *            - From Amount , ToAmt - To Amount, currType - Type of currency
	 * @return result - True/False
	 */

	public boolean filterByAmount(float fromAmt, float ToAmt, String currType) {
		boolean result = false;
		String colName = "Amount";
		try {
			int colNo = getColNum(colName);
			findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
			// findElement(By.xpath("//th[contains(@class,'poamountFltrHdr')]//b"));
			filterByAmtRange(fromAmt, ToAmt, currType);
			result = verifyFilteredAmount(colNo, fromAmt, ToAmt, currType) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	protected boolean verifyDisplayedActionForBPO(String BPONum, String action) throws Exception{
		boolean result = false;
		//try {
		String status = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+BPONum+"']]//div[contains(@class,'statusTxt')]")).getText();

		switch (action.toLowerCase()) {
		case "create release":
			if (status.equals("Released"))
				result = true;
			else if (status.equals("Parked")){
				takeActionForBPO(BPONum, "Release");
				takeActionForBPO(BPONum, "Create Release");
			}
			break;
		case "copy":
			if (status.equals("Closed") || status.equals("In Approval") || status.equals("Parked")
					|| status.equals("Rejected") || status.equals("Released") || status.equals("Cancelled")
					|| status.equals("Expired"))
				result = true;
			break;
		case "close":
			if (status.equals("Released") || status.equals("In Process(Ordering)"))
				result = true;
			break;
		case "amend po":
			if (status.equals("Released") || status.equals("Expired"))
				result = true;
			break;
		case "delete":
			if (status.equals("Draft") || status.equals("Expired"))
				result = true;
			break;
		case "recall approval request":
		case "remind approver":
			if (status.equals("In Approval"))
				result = true;
			break;
		case "view":
			if (status.equals("Expired"))
				result = true;
			break;
		case "create receipt":
			if (status.equals("Expired"))
				result = true;
			break;
		default :
			break;
		}
		/*} catch (Exception e) {
    e.printStackTrace();
    }*/
		if (result==false)
			LogScreenshot("Fail", "BPO "+BPONum+" not in required status for the requested action -> Current Status "+status);
		return result;

	}


	/**
	 * <b>Function:</b> verifyDisplayedAction
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param action
	 * @return result - True/False
	 * @throws Exception 
	 */

	protected boolean verifyDisplayedAction(String PONum, String action) throws Exception {
		boolean result = false;
		String status = null;
		//try {
		status = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+PONum+"']]//div[contains(@class,'statusTxt')]")).getText();
		switch (action.toLowerCase()) {
		case "view":
			if (status.equals("Expired"))
				result = true;
			break;
		case "delete":
			if (status.equals("Draft"))
				result = true;
			break;
		case "copy":
			if (status.equals("Closed") || status.equals("In Approval") || status.equals("Parked")
					|| status.equals("Rejected") || status.equals("Released") || status.equals("Cancelled")
					|| status.equals("Expired"))
				result = true;
			break;
		case "review and submit":
			if (status.equals("Ready for approval"))
				result = true;
			break;
		case "close":
			if (status.equals("Released") || status.equals("In Process(Ordering)"))
				result = true;
			break;
		case "create receipt":
			if (status.equals("Released"))
				result = true;
			break;
		case "add invoice":
			if (status.equals("Released"))
				result = true;
			break;
		case "amend po":
			if (status.equals("Released") || status.equals("Expired"))
				result = true;
			else if(status.equals("Parked")){
				takeAction(PONum, "Release");
			}  
			break;
		case "recall approval request":
		case "remind approver":
			if (status.equals("In Approval"))
				result = true;
			break;
		case "release":
			if (status.equals("Parked"))
				result = true;
			break;
		case "cancel":
			if (status.equals("Parked") || status.equals("Rejected"))
				result = true;
			break;
		case "download":
			if (status.equals("Closed"))
				result = true;
			break;
		case "re-open":
			if (status.equals("Closed"))
				result = true;
			break;
		default :
			break;
		}
		/*} catch (Exception e) {
    e.printStackTrace();
    }*/
		if (result==false)
			LogScreenshot("Fail", "PO "+PONum+" not in required status for the requested action -> Current Status "+status);
		return result;

	}

	/**
	 * <b>Function:</b> takeAction
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param action
	 * @return result - True/False
	 * @throws Exception 
	 * @throws InterruptedException 
	 */

	/*public boolean takeAction(String action) {
    boolean result = false;
    try {
      if (verifyDisplayedAction(action)) {

        WebElement objPONum = driver.findElement(poNumTxtXpath);
        String poNum = objPONum.getText();

        WebElement objPOName = driver.findElement(poNameTxtXpath);
        String poName = objPOName.getText().replaceAll("\\s{2,}", " ").trim();;

        findElement(actionsLinkXpath).click();
        findElement(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"
            + action + "']")).click();

        switch (action.toLowerCase()) {

        case "view":
          BlanketPurchaseOrder objBlanketPO = new BlanketPurchaseOrder(driver, logger,listOfSupplierCompany.get(0));
          if (driver.findElement(objBlanketPO.getHeaderReqNum()).getAttribute("value") == poNum
              && driver.findElement(objBlanketPO.getHeaderReqName()).getAttribute("value") == poName)
            result = true;
          else
            LogScreenshot("Info", "Requested PO not opened for viewing");
          break;
        case "add Invoice":
          String POIdentifier = poNum + " - " + poName;
          InvoiceAgainstPO objInvoice = new InvoiceAgainstPO(driver, logger);
          String invoice =  objInvoice.createNewInvoice(POIdentifier);
          if (invoice != null)
            result = true;
          else
            LogScreenshot("Info", "Requested PO not opened for viewing");
          break;
        case "close":
          if (driver.findElement(closePopUpXpath).getAttribute("style").contains("block")){
            findElement(closePOBtn).click();
            Thread.sleep(3000);
            if (driver.findElements(By.xpath("//tr[td[3]/a[text()='"+poNum+"']]//td[2]/a[@class='icon po-closed']")).size()==1)
              LogScreenshot("Pass", "Purchase Order : "+poNum+" closed");
            else
              LogScreenshot("Fail", "Purchase Order : "+poNum+" not closed");
          } else
            LogScreenshot("Fail", "Close Purchase Order popup not displayed");
          break;
        case "delete":
          if (driver.findElement(deletePopUpXpath).getAttribute("style").contains("block"))
            findElement(deletePopUpYesLink).click();
          if (driver.findElement(By.xpath("//div/em[contains(text(),'Deleting Purchase order')]"))  !=  null) {
            WebElement objDeletedPONum = findElement(
                By.xpath("//table[@id='polisting']//td[2]/a[text()='" + poNum + "']"));
            if (objDeletedPONum == null)
              result = true;
            else
              LogScreenshot("Info", "Deleted PO still exists");
          } else
            LogScreenshot("Info", "Are you sure want to delete this requisition - message not displayed");
          break;
        case "copy":

	 * PurchaseOrder objPO = new PurchaseOrder(driver);
	 * if (findElement(objPO.getRequisitionNm()).getAttribute(
	 * "value") == poName) result = true; else{ System.out.
	 * println("Requested Requisition not opened for editing");
	 * result = false; } break;


        case "edit":
          CheckoutPg objReqCheckout = new CheckoutPg(driver, logger);
          if (driver.findElement(objReqCheckout.getRequisitionNm()).getAttribute("value") == poName)
            result = true;
          else
            LogScreenshot("Info", "Requested Requisition not opened for editing");
          break;
        case "review and submit":

	 * RequisitionSubmitPg objReqSubmit = new
	 * RequisitionSubmitPg(driver);
	 * if (findElement(objReqSubmit.getpoName()).getText() ==
	 * poName) result = true; else{ System.out.
	 * println("Requested Requisition not opened for review & submit"
	 * ); result = false; }

          break;
        case "create receipt":
          CreateReceipt_page objCreateReceipt = new CreateReceipt_page(driver, logger);
          if (driver.findElement(objCreateReceipt.getHeaderReqNum()).getText().equals(poNum)
              && driver.findElement(objCreateReceipt.getHeaderReqName()).getText().equals(poName)){
              //objCreateReceipt.createNewReceipt();
              result = true;
          }else
            LogScreenshot("Info", "Requested PO not opened for Create Receipt");
          break;
        case "remind approver":
          if (driver.findElement(reminderMsgSentXpath)  !=  null)
            result = true;
          else
            LogScreenshot("Info", "Reminder message has been sent not displayed");
          break;
        case "Amend PO":

          break;
        }
      } else
        LogScreenshot("Info", "PO not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }*/

	public boolean takeAction(String poNum, String action) throws InterruptedException, Exception {
		boolean result = false;
		//try {
		//if (verifyDisplayedAction(poNum, action)) {
		verifyDisplayedAction(poNum, action);
		/*WebElement objPONum = driver.findElement(poNumTxtXpath);
        String poNum = objPONum.getText();*/

		WebElement objPOName = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[contains(@class,'purchaseOrderDesc')]"));
		String poName = objPOName.getText().replaceAll("\\s{2,}", " ").trim();

		findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']")).click();
		LogScreenshot("Info", "Actions button clicked");
		Thread.sleep(3000);
		findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']/following-sibling::ul//a[text()='"
				+ action + "']")).click();
		LogScreenshot("Info", action + " button clicked");
		Thread.sleep(6000);
		switch (action.toLowerCase()) {

		case "view":
			BlanketPurchaseOrder objBlanketPO = new BlanketPurchaseOrder(driver, logger,listOfSupplierCompany.get(0));
			if (driver.findElement(objBlanketPO.getHeaderReqNum()).getAttribute("value") == poNum
					&& driver.findElement(objBlanketPO.getHeaderReqName()).getAttribute("value") == poName)
				result = true;
			else
				LogScreenshot("Info", "Requested PO not opened for viewing");
			break;
		case "add Invoice":
			String POIdentifier = poNum + " - " + poName;
			InvoiceAgainstPO objInvoice = new InvoiceAgainstPO(driver, logger);
			String invoice =  objInvoice.createNewInvoice(POIdentifier);
			if (invoice != null)
				result = true;
			else
				LogScreenshot("Info", "Requested PO not opened for viewing");
			break;
		case "close":
			if (driver.findElement(closePopUpXpath).getAttribute("style").contains("block")){
				findElement(closePOBtn).click();
				Thread.sleep(3000);
				if (driver.findElements(By.xpath("//tr[td[3]/a[text()='"+poNum+"']]//td[2]/a[@class='icon po-closed']")).size()==1)
					LogScreenshot("Pass", "Purchase Order : "+poNum+" closed");
				else
					LogScreenshot("Fail", "Purchase Order : "+poNum+" not closed");
			} else
				LogScreenshot("Fail", "Close Purchase Order popup not displayed");
			break;
		case "delete":
			if (driver.findElement(deletePopUpXpath).getAttribute("style").contains("block"))
				findElement(deletePopUpYesLink).click();
			if (driver.findElement(By.xpath("//div/em[contains(text(),'Deleting Purchase order')]"))  !=  null) {
				WebElement objDeletedPONum = findElement(
						By.xpath("//table[@id='polisting']//td[2]/a[text()='" + poNum + "']"));
				if (objDeletedPONum == null)
					result = true;
				else
					LogScreenshot("Info", "Deleted PO still exists");
			} else
				LogScreenshot("Info", "Are you sure want to delete this requisition - message not displayed");
			break;
		case "copy":
			/*
			 * PurchaseOrder objPO = new PurchaseOrder(driver);
			 * if (findElement(objPO.getRequisitionNm()).getAttribute(
			 * "value") == poName) result = true; else{ System.out.
			 * println("Requested Requisition not opened for editing");
			 * result = false; } break;
			 */

		case "edit":
			CheckoutPg objReqCheckout = new CheckoutPg(driver, logger);
			if (driver.findElement(objReqCheckout.getRequisitionNm()).getAttribute("value") == poName)
				result = true;
			else
				LogScreenshot("Info", "Requested Requisition not opened for editing");
			break;
		case "review and submit":
			/*
			 * RequisitionSubmitPg objReqSubmit = new
			 * RequisitionSubmitPg(driver);
			 * if (findElement(objReqSubmit.getpoName()).getText() ==
			 * poName) result = true; else{ System.out.
			 * println("Requested Requisition not opened for review & submit"
			 * ); result = false; }
			 */
			break;
		case "create receipt":
			CreateReceipt_page objCreateReceipt = new CreateReceipt_page(driver, logger);
			if (driver.findElement(objCreateReceipt.getHeaderReqNum()).getText().equals(poNum)
					&& driver.findElement(objCreateReceipt.getHeaderReqName()).getText().equals(poName)){
				//objCreateReceipt.createNewReceipt();
				result = true;
			}else
				LogScreenshot("Info", "Requested PO not opened for Create Receipt");
			break;
		case "remind approver":
			if (driver.findElement(reminderMsgSentXpath)  !=  null)
				result = true;
			else
				LogScreenshot("Info", "Reminder message has been sent not displayed");
			break;
		case "Amend PO":
			break;
		case "Release":
			findElement(By.xpath("//button[span[text()='Release PO']]")).click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='updFlash']"));
			Thread.sleep(2000);
			findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Release PO")+"']]//button[span[text()='"+getLanguageProperty("Release PO")+"']]")).click();
			Thread.sleep(5000);
			String status = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]//div[contains(@class,'statusTxt')]")).getText().trim();
			if(status.equals("Released")){
				result = true;
				LogScreenshot("Pass", "PO "+poNum+" status changed to Released");
			}else
				LogScreenshot("Fail", "PO "+poNum+" status not changed to Released");
			break;
		default :
			break;
		}
		/*} else
        LogScreenshot("Info", "PO not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }*/
		return result;

	}

	public void amendPOByItemAmount(String PONumber, String amtCategory,int allowedPercent) throws Exception{
		PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
		takeAction(PONumber, "Amend PO");
		objOrder.amendPOByItemprice(amtCategory, allowedPercent);
	}

	public void amendPOByItemQty(String PONumber, String qtyCategory,int allowedPercent) throws Exception{
		PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
		takeAction(PONumber,"Amend PO");
		objOrder.amendPOByItemQty(qtyCategory, allowedPercent);
	}

	/*public void amendPO(int allowedValue, int newValue) throws Exception{
    PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
    objOrder.amendPOByItemQty(allowedValue, newValue);
  }

  public void amendPO(double allowedValue, double newValue) throws Exception{
    PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
    objOrder.amendPOByItemprice(allowedValue, newValue);
  }*/

	public boolean closePOAndAddInvoice(String poNum) throws Exception{
		boolean result= false;
		try {
			filterByPONumber(poNum);
			closePO(poNum, true);
			waitUntilInvisibilityOfElement(processingLoader,4);
			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'overlay')]"),4);
			Thread.sleep(3000);
			PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
			objOrders.viewPO(poNum);
			PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
			objOrder.navigateToPOTabs("Invoice");
			LogScreenshot("Pass", "Navigated to Invoice tab - waiting for 2 min Add Invoice tab to display");
			Thread.sleep(120000);
			driver.navigate().refresh();
			Thread.sleep(4000);
			LogScreenshot("Info", "Adding New Invoice");
			InvoicesList objList = new InvoicesList(driver, logger);
			objList.addNewInvoice(poNum);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("Info",e.getMessage());
		}
		return result;
	}

	public boolean closePOAndVerifyInvoiceNotAllowed(String poNum) throws Exception{
		boolean result= false;
		try {
			filterByPONumber(poNum);
			closePO(poNum, false);
			waitUntilInvisibilityOfElement(processingLoader,4);
			Thread.sleep(3000);
			PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
			objOrders.viewPO(poNum);
			PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
			objOrder.navigateToPOTabs("Invoice");
			InvoicesList objList = new InvoicesList(driver, logger);
			if (!objList.verifyInvoiceAdditionAllowed())
				LogScreenshot("Pass","Invoice creation not allowed for closed PO");
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private boolean closePO(String poNum, boolean invoiceCreationAllowed) throws Exception{
		boolean result = false;
		findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']")).click();
		findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']/following-sibling::ul//a[text()='"+getLanguageProperty("Close")+"']")).click();
		if (driver.findElement(closePopUpXpath).getAttribute("style").contains("block")){
			if (invoiceCreationAllowed)
				findElement(By.id("poAllowInvoice")).click();
			LogScreenshot("Info", "Closing PO and allowing invoice creation");
			findElement(closePOBtn).click();
			waitUntilInvisibilityOfElement(closePopUpXpath,4);
			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'overlay')]"),4);
			Thread.sleep(12000);
			LogScreenshot("Info", "Close PO button clicked");
			if (driver.findElements(By.xpath("//tr[td[3]/a[text()='"+poNum+"']]//td[2]/a[@class='icon po-closed']")).size()==1){
				LogScreenshot("Pass", "Purchase Order : "+poNum+" closed");
				result = true;
			}else
				LogScreenshot("Fail", "Purchase Order : "+poNum+" not closed");
		} else
			LogScreenshot("Fail", "Close Purchase Order popup not displayed");
		return result;
	}


	public boolean takeActionForBPO(String poNum, String action) throws Exception{
		boolean result = false;
		//try {
		//if (verifyDisplayedActionForBPO(poNum, action)) {

		verifyDisplayedActionForBPO(poNum, action);
		/*WebElement objPONum = driver.findElement(poNumTxtXpath);
      String poNum = objPONum.getText();*/

		WebElement objPOName = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[contains(@class,'purchaseOrderDesc')]"));
		String poName = objPOName.getText().replaceAll("\\s{2,}", " ").trim();

		findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']")).click();
		LogScreenshot("Info", "Actions button clicked");
		findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']/following-sibling::ul//a[text()='"
				+ action + "']")).click();
		LogScreenshot("Info", action+ " link clicked");
		switch (action.toLowerCase()) {

		case "create release":
			BlanketPurchaseOrder objBlanketPO = new BlanketPurchaseOrder(driver, logger,listOfSupplierCompany.get(0));
			//waitUntilVisibilityOfElement(objBlanketPO.getHeaderReqNum());
			Thread.sleep(8000);
			/*if (driver.findElement(objBlanketPO.getHeaderReqNum()).getAttribute("value") == poNum
            && driver.findElement(objBlanketPO.getHeaderReqName()).getAttribute("value") == poName){*/
			if (driver.findElement(By.xpath("//div[@id='lblBpoNumber']/a")).getText().equals(poNum)){
				//enterFlexiFields();
				eInvoice_CommonFunctions objFunc = new eInvoice_CommonFunctions(driver, logger);
				objFunc.flexiFormDetails(false);
				Thread.sleep(3000);
				if(driver.findElements(By.xpath("//span[@id='spnCurrencyEditNxt' and not(contains(@style,'none'))]")).size()>0){
					Random rnd = new Random();
					driver.findElement(By.id("txtBaseExchangeRate")).sendKeys(String.valueOf(1+rnd.nextInt(10)));
				}
				Thread.sleep(2000);
				submitPO();
				//findElement(By.xpath("//a[span[@title='Submit PO for processing']]")).click();
				result = true;
			}else
				LogScreenshot("Fail", "Requested PO not opened to Create Release");
			break;
		case "close":
			if (driver.findElement(closePopUpXpath).getAttribute("style").contains("block")){
				findElement(closePOBtn).click();
				Thread.sleep(3000);
				if (driver.findElements(By.xpath("//tr[td[3]/a[text()='"+poNum+"']]//td[2]/a[@class='icon po-closed']")).size()==1)
					LogScreenshot("Pass", "Purchase Order : "+poNum+" closed");
				else
					LogScreenshot("Fail", "Purchase Order : "+poNum+" not closed");
			} else
				LogScreenshot("Fail", "Close Purchase Order popup not displayed");
			break;
		case "Release":
			findElement(By.xpath("//div[div/table//td[contains(text(),'purchase order will be released to the supplier')]]//button[span[text()='Release PO']]")).click();
			Thread.sleep(5000);
			if(driver.findElement(By.xpath("//tr[td[3]/a[text()='AutoPO_3501105']]//td[2]/div")).getText().trim().equals("Released"))
				LogScreenshot("Pass", "Purchase Order : "+poNum+" release");
			else
				LogScreenshot("Fail", "Purchase Order : "+poNum+" not released");
		default :
			break;

		}
		/*} else
        LogScreenshot("Info", "Blanket Purchase Order is not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }*/
		return result;

	}

	/**
	 * <b>Function:</b> takeAction
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param action
	 * @param actionBasedReq_Comment
	 * @return result - True/False
	 */

	/*public boolean takeAction(String action, String actionBasedReq_Comment) {
    boolean result = false;
    try {
      findElement(actionsLinkXpath).click();
      findElement(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"
          + action + "']")).click();

      if (verifyDisplayedAction(action)) {

        WebElement objPONum = findElement(poNumTxtXpath);
        String poNum = objPONum.getText();

        switch (action.toLowerCase()) {
        case "recall approval request":
          if (findElement(recallApprovalReqPopUp)  !=  null) {
            driver.findElement(recallApprovalCmmntId).sendKeys(actionBasedReq_Comment);
            findElement(recallBtnId).click();
            if (findElement(recallReqActionMsgId)  !=  null) {
              WebElement objRecalledReqNum = findElement(
                  By.xpath("//table[contains(@class,'dataTable')]//td[2]/a[text()='" + poNum + "']"));
              if (objRecalledReqNum == null)
                result = true;
            }
          } else {
            LogScreenshot("Info", "Recall Approval Request pop up not displayed");
            result = false;
          }
          break;
        case "close":
          if (findElement(closeReqPopUp)  !=  null) {
            driver.findElement(closeCmmntId).sendKeys(actionBasedReq_Comment);
            findElement(closeBtnId).click();

            // Add code for validating the closed Requisition

	 * if (findElement(By.id("status_overlay_savingComment"))
	 *  !=  null){ WebElement objRecalledReqNum =
	 * findElement(By.xpath(
	 * "//table[@id='polisting']//td[2]/a[text()='"+poNum+
	 * "']")) ; if (objRecalledReqNum==null) result = true; }


          } else {
            LogScreenshot("Info", "Recall Approval Request pop up not displayed");
            result = false;
          }
          break;
        }
      } else
        LogScreenshot("Info", "Requisition is not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }*/

	public boolean takeAction(String poNum, String action, String actionBasedReq_Comment) {
		boolean result = false;
		try {
			findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']")).click();
			findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'purchaseOrderNumber')]/a[text()='"+poNum+"']]/td[last()]//a[@class='icon actLnk']/following-sibling::ul//a[text()='"
					+ action + "']")).click();

			if (verifyDisplayedAction(poNum, action)) {

				/*WebElement objPONum = findElement(poNumTxtXpath);
        String poNum = objPONum.getText();*/

				switch (action.toLowerCase()) {
				case "recall approval request":
					if (findElement(recallApprovalReqPopUp)  !=  null) {
						driver.findElement(recallApprovalCmmntId).sendKeys(actionBasedReq_Comment);
						findElement(recallBtnId).click();
						if (findElement(recallReqActionMsgId)  !=  null) {
							WebElement objRecalledReqNum = findElement(
									By.xpath("//table[contains(@class,'dataTable')]//td[2]/a[text()='" + poNum + "']"));
							if (objRecalledReqNum == null)
								result = true;
						}
					} else {
						LogScreenshot("Info", "Recall Approval Request pop up not displayed");
						result = false;
					}
					break;
				case "close":
					if (findElement(closeReqPopUp)  !=  null) {
						driver.findElement(closeCmmntId).sendKeys(actionBasedReq_Comment);
						findElement(closeBtnId).click();

						// Add code for validating the closed Requisition
						/*
						 * if (findElement(By.id("status_overlay_savingComment"))
						 *  !=  null){ WebElement objRecalledReqNum =
						 * findElement(By.xpath(
						 * "//table[@id='polisting']//td[2]/a[text()='"+poNum+
						 * "']")) ; if (objRecalledReqNum==null) result = true; }
						 */

					} else {
						LogScreenshot("Info", "Recall Approval Request pop up not displayed");
						result = false;
					}
					break;
				default :
					break;  
				}
			} else
				LogScreenshot("Info", "Requisition is not in required status for the requested action");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*public String addStandardPO_old(){
    String createdPO = null;
    try {
      Actions action = new Actions(driver);
      WebElement addPO = driver.findElement(By.xpath("//div[contains(@class,'mnBtn-drop')]"));
      action.moveToElement(addPO).build().perform();
      WebElement stdPOLink = driver.findElement(By.xpath("//div[@class='droppnlpad']/a[span[text()='"+getLanguageProperty("Standard PO")+"']]"));
      action.moveToElement(stdPOLink).click().build().perform();
      waitUntilInvisibilityOfElement(processingLoader,4);
      PurchaseOrder objPO = new PurchaseOrder(driver, logger, listOfSupplierCompany.get(0));
      String draftedPO = objPO.enterPODetails();
      waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
      Thread.sleep(2000);
      findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
      waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]"));
      Thread.sleep(5000);
      waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']"));
      int approvalsReqCount = getApproversCount();
      findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']")).click();
      waitUntilInvisibilityOfElement(processingLoader,4);
      waitUntilVisibilityOfElement(PurchaseOrder.backBtn);
      findElement(PurchaseOrder.backBtn).click();
      waitUntilVisibilityOfElement(By.id("polisting"));    
      createdPO = draftedPO;
    } catch (Exception e) {
    e.printStackTrace();
      String screenshotPath = objFunctions.getScreenhot(driver, "screenshot_error");
      try {
        logger.addScreenCaptureFromPath(screenshotPath);
      } catch (IOException e1) {
        // TODO Auto-generated catch block
        e1.printStackTrace();
      }
      if (driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')]")).size() > 0)
        findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
    }
    return createdPO;
  }*/

	private void selectPOType(String POType) throws Exception{
		Actions action = new Actions(driver);
		WebElement addPO = driver.findElement(By.xpath("//div[contains(@class,'mnBtn-drop')]"));
		action.moveToElement(addPO).build().perform();
		WebElement stdPOLink = driver.findElement(By.xpath("//div[@class='droppnlpad']/a[span[text()='"+POType+"']]"));
		action.moveToElement(stdPOLink).click().build().perform();
		waitUntilInvisibilityOfElement(processingLoader,4);
	}

	private void correctErrorInBilling(String field) throws Exception{
		String fieldId = null;
		By fieldTxtXpath = null;
		switch(field){
		case "Company":
			fieldId = "companyAutoComplete";
			fieldTxtXpath = By.xpath("//input[@id='companyAutoComplete']/following-sibling::div");
			break;
		case "Business Unit":
			fieldId = "buAutoComplete";
			fieldTxtXpath = By.xpath("//input[@id='buAutoComplete']/following-sibling::div");
			break;
		case "Location":
			fieldId = "locationAutoComplete";
			fieldTxtXpath = By.xpath("//input[@id='locationAutoComplete']/following-sibling::div");
			break;  
		case "Cost Center":
			findElement(By.xpath("//form[@id='frmPOSummary']//ul[@role='tablist']/li/a[contains(text(),'Cost Allocation')]")).click();
			fieldId = "costCenter_summary";
			fieldTxtXpath = By.xpath("(//input[@id='costCenter_summary']/following-sibling::span)[1]");
			break;
		case "Project":
			fieldId = "project_summary";
			fieldTxtXpath = By.xpath("(//input[@id='project_summary']/following-sibling::span)[1]");
			break;
		case "Budget":
			fieldId = "budget_summary";
			fieldTxtXpath = By.xpath("(//input[@id='budget_summary']/following-sibling::span)[1]");
			break;
		default :
			break;

		}
		if (driver.findElement(fieldTxtXpath).getAttribute("innerText").equals("-")|driver.findElement(fieldTxtXpath).getAttribute("innerText").isEmpty()){
			System.out.println(fieldId +" i am here");
			if (driver.findElements(By.xpath("(//input[@id='"+fieldId+"']/../..)[not(contains(@style,'none'))]")).size() > 0){
				LogScreenshot("Info", "Entering "+field+" info");
				try{
					if(field.equals("Budget")) {
									
						if(BudgetCreation.budgetLineName!=null) {
							LogScreenshot("info","Entering Newly Created Budget:"+BudgetCreation.budgetLineName);
							driver.findElement(By.id("budget_summary")).clear();
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							driver.findElement(By.id("budget_summary")).sendKeys(BudgetCreation.budgetLineName);
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							Thread.sleep(2000);
							findElement(By.xpath("//div[@aria-describedby='changePOSummary']//ul[contains(@style,'block')]/li[1]")).click();
							Thread.sleep(5000);
						}else {
							LogScreenshot("info","Entering available budget");
							driver.findElement(By.id("budget_summary")).click();
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							List<String> value = new ArrayList<String>();
							List<WebElement> budgetList = driver.findElements(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]//a"));		
							
							for(WebElement budget : budgetList) {
								value.add(budget.getText().split(":")[0]);						
							}
							
							for(String budgetValue : value) {
								driver.findElement(By.id("budget_summary")).clear();
								waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
								driver.findElement(By.id("budget_summary")).sendKeys(budgetValue);
								waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
								Thread.sleep(2000);
								findElement(By.xpath("//div[@aria-describedby='changePOSummary']//ul[contains(@style,'block')]/li[1]")).click();
								Thread.sleep(5000);
								
								if(driver.findElements(By.xpath("//span[contains(@class,'budgetLineHelp') and contains(@class,'hasQtip') and contains(@style,'block')]")).size() == 0) {
									break;
								}
								
							}
						}
						
					}else {
						driver.findElement(By.id(fieldId)).click();
						waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
						Thread.sleep(2000);
						findElement(By.xpath("//div[@aria-describedby='changePOSummary']//ul[contains(@style,'block')]/li[1]")).click();
						Thread.sleep(2000);
					}
					
				}catch(Exception e){
					enterText_AutoComplete_eProc(By.id(fieldId));
				}
				LogScreenshot("Pass", field + " value selected");
			}
		}
	}

	public void submitPO() throws Exception{
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
		Thread.sleep(2000);
		findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
		Thread.sleep(10000);
		scroll_to_TopofPage();
		LogScreenshot("Info", "Submit PO for processing button clicked");

		
		
		if(driver.findElements(By.xpath("//span[contains(@class,'inlineError') and @title='Please select required by date']")).size()>0) {
			
			WebElement requiredBy = driver.findElement(By.id("deliveryOn_header"));
			scroll_into_view_element(requiredBy);

			String date= getTodayDate();
			selectDate_v1(date);
			LogScreenshot("pass","Required By Date Selected");
			findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
			Thread.sleep(5000);
			scroll_to_TopofPage();
			LogScreenshot("Info", "Submit PO for processing button clicked");
		}		
		
		//In case of error in Billing, Delivery and Cost Allocation Info
		if (driver.findElements(By.xpath("//div[@class='addBox billToBox']//span[@class='icon inlineError' and @title]")).size() > 0){
			WebElement editBtn = driver.findElement(By.id("changeDelBillingSumm"));
			scroll_into_view_element(editBtn);
			Thread.sleep(2000);
			editBtn.click();
			waitUntilVisibilityOfElement(By.id("changePOSummary"));

			String[] billingLocationRelatedFields = {"Company", "Business Unit", "Location", "Cost Center", "Project", "Budget"};

			for(String field : billingLocationRelatedFields){
				correctErrorInBilling(field);
			}
			findElement(By.id("savePOSummary")).click();
			waitUntilInvisibilityOfElement(By.id("changePOSummary"),4);
			findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
			Thread.sleep(5000);
			scroll_to_TopofPage();
			LogScreenshot("Info", "Submit PO for processing button clicked");

			// As GL Account gets invisible on editing Billing,Delivery Info, hence adding GL Account again
			try {
				if (!(driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[text()='"+getLanguageProperty("Submit for approval")+"']]")).size() > 0)){
					WebElement expandBtn = driver.findElement(By.id("lnkExpandItems"));
					scroll_into_view_element(expandBtn, "Expand button");
					Thread.sleep(2000);
					expandBtn.click();
					driver.findElement(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[contains(@id,'item_summary')]//table//td[contains(@class,'error')]//a[text()='"+getLanguageProperty("Edit")+"']")).click();
					waitUntilVisibilityOfElement(By.id("changeItemSummary"));
					driver.findElement(By.xpath("//input[contains(@id,'generalLedger')]")).click();
					findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
					findElement(By.id("saveItemSummary")).click();
					waitUntilInvisibilityOfElement(By.id("changeItemSummary"),4);
					Thread.sleep(3000);
					findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}  
		}
		Thread.sleep(4000);
		if (driver.findElements(By.xpath("//label[@id='txtBaseExchangeRate-error' and contains(@style,'block')]")).size() > 0){
			Random rnd = new Random();
			driver.findElement(By.id("txtBaseExchangeRate")).sendKeys(String.valueOf(1+rnd.nextInt(10)));
			findElement(By.id("savePOSummary")).click();
			waitUntilInvisibilityOfElement(By.id("changePOSummary"),4);
			findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
			Thread.sleep(8000);
			scroll_to_TopofPage();
			LogScreenshot("Info", "Submit PO for processing button clicked");
		}
		if (driver.findElements(By.xpath("//div[@role='dialog']/div[contains(@style,'block')]//tr/td[contains(text(),'Cost center') and contains(text(),'is no longer') and contains(text(),'scope')]")).size() > 0){
			findElement(By.xpath("//div[@role='dialog']/div[contains(@style,'block')][//tr/td[contains(text(),'Cost center') and contains(text(),'is no longer') and contains(text(),'scope')]]/following-sibling::div//button")).click();
			WebElement editBtn = driver.findElement(By.id("changeDelBillingSumm"));
			scroll_into_view_element(editBtn);
			Thread.sleep(2000);
			editBtn.click();
			waitUntilVisibilityOfElement(By.id("changePOSummary"));
			findElement(By.xpath("//form[@id='frmPOSummary']//ul[@role='tablist']/li/a[contains(text(),'Cost Allocation')]")).click();
			driver.findElement(By.id("costCenter_summary")).clear();
			Thread.sleep(2000);
			driver.findElement(By.id("costCenter_summary")).sendKeys(Keys.TAB);
			Thread.sleep(2000);

			//correctErrorInBilling("Cost Center");
			driver.findElement(By.id("costCenter_summary")).click();
			waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
			Thread.sleep(2000);
			findElement(By.xpath("//div[@aria-describedby='changePOSummary']//ul[contains(@style,'block')]/li[1]")).click();
			Thread.sleep(2000);
			LogScreenshot("Pass"," Cost Center value selected");

			//correctErrorInBilling("Budget");
			if(!(driver.findElements(By.xpath("//li[contains(@class,'budgetSection') and contains(@style,'none')]")).size() > 0)){
				
				if(BudgetCreation.budgetLineName!=null) {
					LogScreenshot("info","Entering Newly Created Budget:"+BudgetCreation.budgetLineName);
					driver.findElement(By.id("budget_summary")).clear();
					waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
					driver.findElement(By.id("budget_summary")).sendKeys(BudgetCreation.budgetLineName);
					waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
					Thread.sleep(2000);
					findElement(By.xpath("//div[@aria-describedby='changePOSummary']//ul[contains(@style,'block')]/li[1]")).click();
					Thread.sleep(5000);
				}else {
					LogScreenshot("info","Entering available budget");
					driver.findElement(By.id("budget_summary")).click();
					waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
					List<String> value = new ArrayList<String>();
					List<WebElement> budgetList = driver.findElements(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]//a"));		
					
					for(WebElement budget : budgetList) {
						value.add(budget.getText().split(":")[0]);						
					}
					
					for(String budgetValue : value) {
						driver.findElement(By.id("budget_summary")).clear();
						waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
						driver.findElement(By.id("budget_summary")).sendKeys(budgetValue);
						waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
						Thread.sleep(2000);
						findElement(By.xpath("//div[@aria-describedby='changePOSummary']//ul[contains(@style,'block')]/li[1]")).click();
						Thread.sleep(5000);
						
						if(driver.findElements(By.xpath("//span[contains(@class,'budgetLineHelp') and contains(@class,'hasQtip') and contains(@style,'block')]")).size() == 0) {
							break;
						}
						
					}
				}
				
			}

			findElement(By.id("savePOSummary")).click();
			waitUntilInvisibilityOfElement(By.id("changePOSummary"),4);
			findElement(By.xpath("//a[span[text()='"+getLanguageProperty("Submit PO for processing")+"']]")).click();
			Thread.sleep(5000);
			scroll_to_TopofPage();
			LogScreenshot("Info", "Submit PO for processing button clicked");
		}

		/*JavascriptExecutor js = (JavascriptExecutor)driver;
    System.out.println("Form data ::::::: "+js.executeScript("return formElement;var formElement = document.querySelector('form');"));*/

		try {
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]"));
			Thread.sleep(8000);
			if(driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']")).size()>0) {
				waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']"));
				LogScreenshot("Info", "PO approval list displayed");
				int approvalsReqCount = getApproversCount();
				findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']")).click();
				waitUntilInvisibilityOfElement(processingLoader,4);
				waitUntilVisibilityOfElement(PurchaseOrder.backBtn);
			}				
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}


		if (driver.findElements(By.xpath("//div[@id='status_overlay_processingRequest']/div/span[@id='forwardClock']")).size() > 0){
			LogScreenshot("Info", "Do not refresh popup displayed - waiting for at least 4 minutes");
			Thread.sleep(240000);
			waitUntilVisibilityOfElement(By.xpath("//button[span[text()='"+getLanguageProperty("Go to Order Listing")+"']]"));
		}
		if (driver.findElements(By.xpath("//button[span[text()='"+getLanguageProperty("Go to Order Listing")+"']]")).size() > 0){  
			LogScreenshot("Info", "Go to Order listing button displayed");
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Go to Order Listing")+"']]")).click();
			waitUntilVisibilityOfElement(By.id("polisting"));
			Thread.sleep(300000);
			LogScreenshot("Info", "Purchase Orders page displayed - refreshing page now after waiting for 2 min");
			driver.navigate().refresh();
			LogScreenshot("Info", "Purchase Orders page refreshed");
			waitUntilInvisibilityOfElement(processingLoader,4);
			Thread.sleep(120000);      
		} else {
			LogScreenshot("Info", "Purchase Order submitted");
			Thread.sleep(4000);
			findElement(PurchaseOrder.backBtn).click();
			waitUntilVisibilityOfElement(By.id("polisting"));    
			Thread.sleep(3000);
		}
	}


	public String addPO(String POType) throws Exception{
		String createdPO = null;
		String draftedPO = null;
		String supplier = listOfSupplierCompany.get(0);
		selectPOType(POType);
		if (POType.equals("Standard PO")){
			PurchaseOrder objPO = new PurchaseOrder(driver, logger, supplier);
			draftedPO = objPO.enterPODetails();
		}else if (POType.equals("Blanket PO")){
			BlanketPurchaseOrder objPO = new BlanketPurchaseOrder(driver, logger, supplier);
			draftedPO = objPO.enterPODetails();
		}
		submitPO();
		clrAllFilters();
		LogScreenshot("Info", "PO submitted - expected to display in PO listing page - PO : "+draftedPO);
		if (driver.findElements(By.xpath("//table[@id='polisting']/tbody/tr/td[contains(@class,'purchaseOrderNumber')]/a[text()='"+draftedPO+"']")).size() > 0){
			LogScreenshot("Pass", "PO "+ draftedPO + " created successfully");
			createdPO = draftedPO;
		}else
			LogScreenshot("Fail", "PO "+ draftedPO + " not created ");
		return createdPO;
	}

	public int getApproversCount(){
		int count = 0;
		try {
			count = driver.findElements(By.xpath("//ul[@class='wrkflwUl']/li")).size()-2;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

	public String createReceiptAgainstPO(String PONum) throws Exception{
		String newReceipt = null;
		if (PONum != "")
			filterByPONumber(PONum);
		else{
			PONum = driver.findElement(poNumTxtXpath).getText(); 
			filterByPONumber(PONum);
		}
		takeAction(PONum, "Create Receipt");
		ReceiptsList objList = new ReceiptsList(driver, logger);
		newReceipt = objList.submitNewReceipt();
		if (newReceipt != null)
			LogScreenshot("Pass", "New Receipt "+newReceipt+" created against PO : "+PONum);
		else
			LogScreenshot("Fail", "No receipt created against PO : "+PONum);
		//Verify if receipt created
		return newReceipt;
	}

	public String createReceiptAgainstPO() throws Exception{
		return createReceiptAgainstPO("");
	}
	
	public String getReceiptStatus(String receiptNum){
		String status = null;
		try{
			status = driver.findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[contains(@class,'iTitle')]/a[@title='"+receiptNum+"']]/td[contains(@class,'status')]")).getText().trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}

	public boolean addInvoiceAgainstReleasedPO(String PONum){
		boolean result = false;
		try {
			filterByStatus("Released");
			filterByType("Standard");
			if (takeAction(PONum, "Add Invoice"))
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean downloadPO(String PoNum){
		boolean result = false;
		String fileDownloadedPath = "C:/Users/"+System.getProperty("user.name")+"/Downloads";
		String fileExtension = "pdf";
		try {
			//Download link exists only when a PO is both 'Unconfirmed' and 'Not invoiced'
			filterByStatus("Unconfirmed");
			filterByType("Standard");
			WebElement requiredRow = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]/tbody/tr[td[a[@class='icon notinvoicedpo']]and td/a[text()='"+PoNum+"']]"));
			//String PONumber = requiredRow.findElement(By.xpath("//td[2]/a")).getText();
			String modifiedPONum = PoNum.replace("/", "").replace(" ", "_");
			WebElement requiredActionLink = requiredRow.findElement(By.xpath("//td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
			deleteFiles(fileDownloadedPath, modifiedPONum, fileExtension);
			requiredActionLink.click();
			LogScreenshot("Pass", "Actions button clicked");
			requiredActionLink.findElement(By.xpath("//a[text()='"+getLanguageProperty("Download")+"']")).click();
			LogScreenshot("Pass", "Download button clicked");
			if (checkFileExists(fileDownloadedPath, modifiedPONum, fileExtension))
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void viewPO(String PONum) throws Exception{
		findElement(By.xpath("//table[@id='polisting']/tbody/tr/td[3]/a[text()='"+PONum+"']")).click();
		Thread.sleep(3000);
		waitUntilVisibilityOfElement(PurchaseOrder.backBtn);
		LogScreenshot("Pass","Navigatd to PO "+PONum);
	}

	public String getPOStatus(String PONumber){
		return driver.findElement(By.xpath("//table[@id='polisting']/tbody/tr[td[3]/a[text()='"+PONumber+"']]/td[2]/div")).getText().trim();
	}


}
