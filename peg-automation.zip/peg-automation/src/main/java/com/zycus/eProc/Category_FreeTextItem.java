package com.zycus.eProc;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eProc.Requisition.Checkout;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
//import com.aventstack.extentreports.Status;
import common.Functions.eProc_CommonFunctions;

public class Category_FreeTextItem extends eProc_CommonFunctions{
	private By shortDescID             = By.id("name");
	private By partNumID             = By.id("supplierPartId");
	private By quantityID             = By.id("quantity");
	private By longDescID             = By.id("description");
	private By uomID               = By.id("uom");
	private By priceCheckbox           = By.id("zeroPriceCheckbox");
	private By priceID               = By.id("price");
	private By suppQuotedSourcingStatus     = By.id("sourcingStatus_requester");
	private By estimatedPriceSrcStatus       = By.id("sourcingStatus_budgetary");
	private By needQuoteSrcStatus         = By.id("sourcingStatus_quote");
	private By qtyReceiveBy           = By.id("receivedBy_quantity");
	private By amtReceiveBy           = By.id("receivedBy_amount");
	private By noReceiptReceiveBy         = By.id("receivedBy_noReceipt");
	private By currencyID             = By.id("currency");
	private By addAttachmentsLink         = By.id("lnkGuidedAttachments");
	private By manufactNameID           = By.id("manufacturerName");
	private By imgURLID             = By.id("imageUrl");
	private By suppProdURLID           = By.id("supplierProductURL");
	private By manufactProdURLID         = By.id("manufacturerProductURL");
	private By manufactPartID           = By.id("manufacturerPartId");
	private By specificNameID           = By.id("guidedParametricName");
	private By existPhnInputID           = By.id("existingPhoneInput");
	private By newSuppAddLinkID         = By.id("newSupplierAddition");
	private By name_newSuppID           = By.id("dev_newSupplierInput");
	private By addr_newSuppID           = By.id("slctNewSupplierAddress");
	private By contact_newSuppID         = By.id("txtNewSupplierContact");
	private By email_newSuppID           = By.id("txtNewSupplierContactEmailId");
	private By phn_newSuppID           = By.id("newSupplierPhoneInput");
	private By contractNo_newSuppID       = By.id("dev_newContractNo");
	private By othrDet_newSuppID         = By.id("newSupplierOtherDetails");
	private By addSuppBtn             = By.id("addFreeTextSupplier");
	private By existSuppOtheDetID         = By.id("existingSupplierOtherDetails");
	private By existSuppAddLinkID         = By.id("existingSupplierAddition");
	private By disabledAddr_ExistSupp       = By.xpath("//*[@id='slctExistingSupplierAddress'][@disabled]");
	private By disabledContact_ExistSupp     = By.xpath("//*[@id='txtExistingSupplierContact'][@disabled]");
	private By disabledEmail_ExistSupp       = By.xpath("//*[@id='txtExistingSupplierEmailId'][@disabled]");
	private By disabledContractNo_ExistSupp   = By.xpath("//*[@id='dev_existingContractNo'][@disabled]");
	private By addSpecificBtn           = By.xpath("(//div[@id='dev_guidedParametricDataContainer']//a[@title='Add'])[1]");
	private By attachFilePopUp           = By.xpath("//*[@id='guidedAttachmentsDOM']/parent::div");
	private static By GuidedProc_createItemPg       = By.xpath("//div[@class='guidemepage clearfix']");

	private float price;
	private String shortDesc;
	private int quantity;
	private String uom;
	private String itemType;
	private String sourcingStatus;
	private String receiveBillBy;
	private String currency;

	public Category_FreeTextItem(WebDriver driver, ExtentTest logger) throws Exception { 
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
		String[][] abc = (String[][]) objFunctions.dataProvider("FreeTextItem", Datasheet_eProc);
		this.shortDesc = abc[0][0];
		this.quantity = Integer.parseInt(abc[0][1]);
		this.uom = abc[0][2];
		this.price = Float.parseFloat(abc[0][3]);
		this.itemType = abc[0][4];
		this.sourcingStatus = abc[0][5];
		this.receiveBillBy = abc[0][5];
		this.currency = abc[0][6];
	}

	/**
	 * @return the guidedProc_createItemPg
	 */
	public static By getGuidedProc_createItemPg() {
		return GuidedProc_createItemPg;
	}

	/**
	 * @param guidedProc_createItemPg the guidedProc_createItemPg to set
	 */
	public void setGuidedProc_createItemPg(By guidedProc_createItemPg) {
		GuidedProc_createItemPg = guidedProc_createItemPg;
	}

	/**
	 * ---------------------------------------------------------------------------------
	 * Function : createFreeTextItem
	 * @param partNumber
	 * @param longDesc
	 * @param filePath
	 * @return result
	 * @throws Exception 
	 */

	public boolean createFreeTextItem(String sourcingStatus) throws Exception{
		boolean result = false;
		String partNumber = "partNo_"+generateNo();
		String longDesc = "itemDesc";
		String filePath = "";
		try {
			//Enter Item Details
			sendKeys(shortDescID, shortDesc);
			sendKeys(partNumID, partNumber);
			sendKeys(quantityID, String.valueOf(quantity));
			sendKeys(longDescID, longDesc);
			sendKeys(uomID, uom);
			if (price==0)
				findElement(priceCheckbox).click();
			else
				sendKeys(priceID, String.valueOf(price));
			findElement(By.id("itemType_"+itemType.toLowerCase())).click();
			switch(sourcingStatus){
			case "Quoted by supplier":
				findElement(suppQuotedSourcingStatus).click();
				break;
			case "Estimated price":
				findElement(estimatedPriceSrcStatus).click();
				break;
			case "Need a quote":
				findElement(needQuoteSrcStatus).click();
				break;
			}
			switch(receiveBillBy){
			case "Quoted by supplier":
				findElement(qtyReceiveBy).click();
				break;
			case "Estimated price":
				findElement(amtReceiveBy).click();
				break;
			case "Need a quote":
				findElement(noReceiptReceiveBy).click();
				break;
			default:
				break;
			}
			enterText_AutoComplete_eProc(currencyID, currency);
			//sendKeys(currencyID, currency);
			//Add Attachments
			/*findElement(addAttachmentsLink).click();
      if (driver.findElement(attachFilePopUp) != null){
        uploadFile(filePath);
        findElement(By.xpath("//*[contains(@id,'closeGuidedAttachmentsBtn')]")).click();
      }*/
			//Flexi fields if exist
			eInvoice_CommonFunctions objFunc = new eInvoice_CommonFunctions(driver, logger);
			objFunc.flexiFormDetails(false);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}


	/**
	 * ---------------------------------------------------------------------------------
	 * Function : addExtraFields
	 * @param manufacturerName
	 * @param imageURL
	 * @param supProductURL
	 * @param manufactProductURL
	 * @param manufactPartURL
	 * @param isGreen
	 * @param isPreferred
	 * @param specificationsName
	 * @param specifications
	 * @return result
	 * ---------------------------------------------------------------------------------
	 * @throws Exception 
	 */

	public boolean addExtraFields(String manufacturerName, String imageURL, String supProductURL, String manufactProductURL, String manufactPartURL, String isGreen, String isPreferred, String specificationsName, List<String> specifications) throws Exception{
		boolean result = false;
		//int i=1;
		try {
			sendKeys(manufactNameID, manufacturerName);
			sendKeys(imgURLID, imageURL);
			sendKeys(suppProdURLID, supProductURL);
			sendKeys(manufactProdURLID, manufactProductURL);
			sendKeys(manufactPartID, manufactPartURL);
			findElement(By.id("dev_isGreen_"+isGreen.toLowerCase())).click();
			findElement(By.id("dev_isPreferred_"+isPreferred.toLowerCase())).click();
			sendKeys(specificNameID, specificationsName);
			if (specifications.size()>2)
				findElement(addSpecificBtn).click();
			for(String spec:specifications){
				sendKeys(By.xpath("//div[@id='dev_guidedParametricDataContainer']//input[i]"), spec);
				//i++;
			}
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * ---------------------------------------------------------------------------------
	 * Function : selectExistingSupplier
	 * @param searchBy
	 * @param searchByValue
	 * @param suppPhone
	 * @param suppOthrDetails
	 * @return result
	 * ---------------------------------------------------------------------------------
	 * @throws Exception 
	 */
	public boolean selectExistingSupplier(String searchBy, String searchByValue, String suppPhone, String suppOthrDetails) throws Exception{
		boolean result = false;
		try {
			findElement(existSuppAddLinkID).click();
			findElement(By.xpath("//*[@id='supplierNameDropdown']/div/a/span[text()='"+searchBy+"']")).click();
			sendKeys(By.id("dev_existingSupplierInput"), searchByValue);
			//if (findElement(By.xpath("//li[@class='ui-menu-item']/parent::ul")).getAttribute("style").contains("block")){
			//Select first menu item from the list
			findElement(By.xpath("//li[@class='ui-menu-item'][1]")).click();
			if (driver.findElement(disabledAddr_ExistSupp) != null)
				LogScreenshot("Pass", "Address field gets enabled");
			else  
				LogScreenshot("Fail", "Address field does not get enabled");
			if (driver.findElement(disabledContact_ExistSupp) != null)
				LogScreenshot("Pass", "Supplier Contact field gets enabled");
			else  
				LogScreenshot("Fail", "Supplier Contact field does not get enabled");
			if (driver.findElement(disabledEmail_ExistSupp) != null)
				LogScreenshot("Pass", "Supplier Email ID field gets enabled");
			else  
				LogScreenshot("Fail", "Supplier Email ID field does not get enabled");
			if (driver.findElement(disabledContractNo_ExistSupp) != null)
				LogScreenshot("Pass", "Contract/OrderNo field gets enabled");
			else  
				LogScreenshot("Fail", "Contract/OrderNo field does not get enabled");

			sendKeys(existPhnInputID, suppPhone);
			sendKeys(existSuppOtheDetID, suppOthrDetails);
			result = true;
		} catch (Exception e) {
			LogScreenshot("Info", "Search By Menu list is not displayed");

		}
		return result;
	}

	public void selectExistingSupplier(String supplierName) throws Exception{
		//Select Existing Supplier link
		WebElement objSelectExistingSupplier = driver.findElement(By.id("existingSupplierAddition"));
		scroll_into_view_element(objSelectExistingSupplier);
		Thread.sleep(2000);
		objSelectExistingSupplier.click();
		Thread.sleep(2000);
		enterText_AutoComplete_eProc(By.id("dev_existingSupplierInput"), supplierName);
		waitUntilInvisibilityOfElement(processingLoader,4);
		// To be executed in case supplier has more than 1 address - generally supplier has only 1 address, 
		// hence enclosing in try-catch block
		try{
			findElement(By.id("slctExistingSupplierAddress")).click();
			findElement(By.xpath("//ul[contains(@style,'block') and contains(@class,'ui-autocomplete')]/li[1]")).click();
			Thread.sleep(2000);
		}catch(Exception e){
			System.out.println("Unable to select supplier address");
		}
		findElement(By.id("addExistingSupplier")).click();
		Thread.sleep(2000);
		scroll_into_view_element(driver.findElement(By.xpath("//table[@id='tblSelectedSuppliers']/tbody")));
		Thread.sleep(2000);
		if (driver.findElements(By.xpath("//table[@id='tblSelectedSuppliers']/tbody//td[span/span[text()='"+supplierName.toUpperCase()+"']]")).size()==1)
			LogScreenshot("Pass", "Supplier added to Requester Suggested Suppliers list");
		else
			LogScreenshot("Fail", "Supplier not added to Requester Suggested Suppliers list");
	}

	public void addItemToCart() throws Exception{
		Thread.sleep(3000);
		findElement(By.id("btnAddToCart"),"Add to Cart").click();
		try {
			waitUntilVisibilityOfElement(By.id("checkoutDiag"));
			if (driver.findElements(By.id("checkoutDiag")).size() > 0){
				LogScreenshot("Pass", "Checkout dialog popup displayed");
			}else
				LogScreenshot("Fail", "Checkout dialog popup not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public String checkOut() throws Exception{
		findElement(By.xpath("//div[@id='checkoutDiag']//a[text()='"+getLanguageProperty("Checkout")+"']")).click();
		Checkout objChkOut  = new Checkout(driver, logger);
		waitUntilVisibilityOfElement(objChkOut.getPgHead());
		LogScreenshot("Pass", "Navigated to Checkout page to create Requisition");
		return objChkOut.createRequisition("");
	}

	/**
	 * ---------------------------------------------------------------------------------
	 * Function : addNewSupplier
	 * @param supplierType
	 * @param suppName
	 * @param suppAddr
	 * @param suppContact
	 * @param suppEmail
	 * @param suppPhone
	 * @param suppOrderNum
	 * @param suppOthrDetails
	 * @return result
	 * ---------------------------------------------------------------------------------
	 * @throws Exception 
	 */
	public boolean addNewSupplier(String supplierType, String suppName, String suppAddr, String suppContact, String suppEmail, String suppPhone, String suppOrderNum, String suppOthrDetails) throws Exception{
		boolean result = false;
		try {
			findElement(newSuppAddLinkID).click();
			sendKeys(name_newSuppID, suppName);
			sendKeys(addr_newSuppID, suppAddr);
			sendKeys(contact_newSuppID, suppContact);
			sendKeys(email_newSuppID, suppEmail);
			sendKeys(phn_newSuppID, suppPhone);
			sendKeys(contractNo_newSuppID, suppOrderNum);
			sendKeys(othrDet_newSuppID, suppOthrDetails);
			findElement(addSuppBtn).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	public void guideMeWithoutSelectingCategory(){
		if (driver.findElements(By.id("guideDiag")).size() > 0){
			findElement(By.xpath("//a[text()='"+getLanguageProperty("Continue without selecting a category")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("guideDiag"),4);
		}
	}

	public void guideMe(String category){
		findElement(By.xpath("//div[@id='selectedEform']/div[2]//li/a[@title='"+category+"']")).click();
		findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Confirm")+"']][div//b[contains(text(),'"+category+"')]]//button[span[text()='"+getLanguageProperty("Continue")+"']]")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@aria-describedby='status_overlay_save_guided_loading']"),4);
	}

	public void guideMe(){
		findElement(By.xpath("//div[@id='selectedEform']/div[2]//li[1]/a")).click();
		findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Confirm")+"']]//button[span[text()='"+getLanguageProperty("Continue")+"']]")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@aria-describedby='status_overlay_save_guided_loading']"),4);
	}



}
