package com.zycus.eProc.Budget;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eProc_CommonFunctions;

public class BudgetDetails extends eProc_CommonFunctions{



	private String budgetDimension;
	private String businessUnit;
	private String plannedAmount;
	private By budgetLineCodeLabel= By.xpath("//td[@class=' budgetLineId_column']/input");
	private By budgetLineNameLabel= By.xpath("//td[contains(@class,'budgetLineName')]/input");
	private By budgetlabel = By.id("viewBudgetNameLabel");
	private By plannedAmtLabel = By.xpath("//td[contains(@class,'plannedAmount')]/input");


	public BudgetDetails(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eProc");
		String[][] abc = (String[][]) objFunctions.dataProvider("NewBudgetLine", Datasheet_eInvoice);
		this.budgetDimension= abc[0][0];
		this.businessUnit = abc[0][1];
		this.plannedAmount = abc[0][2];
	}

	/**
	 * @return the budgetlabel
	 */
	public By getBudgetlabel() {
		return budgetlabel;
	}

	/**
	 * @param budgetlabel the budgetlabel to set
	 */
	public void setBudgetlabel(By budgetlabel) {
		this.budgetlabel = budgetlabel;
	}

	public void selectBudgetDimension() throws Exception {
		Select select= new Select(driver.findElement(By.xpath("//select[@class='primaryDimension dimensionSelect']")));
		select.selectByValue(budgetDimension);
		Thread.sleep(2000);
		LogScreenshot("PASS", budgetDimension+ ":Budget dimension selected");
		clickElement(By.id("generateDimensions"),"Generate button");
		LogScreenshot("INFO", "Clicked on Generate button");
	}

	public String addBudgetLine() throws Exception {
		String budgetLineName=null;
		try {
			waitUntilVisibilityOfElement(By.id("budgetLineListingTable_budgetlistbx_wrapper"));
			findElement(By.xpath("//div[@id='budgetlistbx']//a[@title='Add Budget Line']"),"Add Budget Line Button").click();
			LogScreenshot("INFO", "Clicked on Add Budget Line Button button");
			Thread.sleep(4000);
			//		enterAutoCompleteTextBusinessUnit(businessUnit);
			enterAutoCompleteTextBusinessUnit(By.xpath("//input[contains(@class,'BUSINESS_UNIT')]"), businessUnit);
			if(driver.findElement(By.xpath("//input[contains(@class,'BUSINESS_UNIT')]")).getAttribute("value").isEmpty()) {
				LogScreenshot("info","Retrying to enter business unit");
				enterAutoCompleteTextBusinessUnit(By.xpath("//input[contains(@class,'BUSINESS_UNIT')]"), businessUnit);
			}
			driver.findElement(budgetLineCodeLabel).click();
			driver.findElement(budgetLineCodeLabel).clear();
			driver.findElement(budgetLineCodeLabel).sendKeys("#LineCode_"+generateNo());
			LogScreenshot("INFO", "Budget Line code entered");

			budgetLineName= "BudgetLine_"+generateNo();
			driver.findElement(budgetLineNameLabel).sendKeys(budgetLineName);
			LogScreenshot("INFO", "Budget Line Name entered");
			String owner= getUserName();
			enterText_AutoComplete_eProc(By.xpath("//input[contains(@class,'ownerUserId')]"), owner);
			driver.findElement(plannedAmtLabel).sendKeys(plannedAmount);
			LogScreenshot("INFO", plannedAmount+" :Planned Amount Name entered");
			findElement(By.xpath("//a[contains(@class,'saveRow')]"),"Save link").click();
			Thread.sleep(2000);
		}catch(Exception e) {
			LogScreenshot("FAIL", "Unable to add budget line");
			throw e;		
		}
		return budgetLineName;
	}

	/*	public void enterAutoCompleteTextBusinessUnit(String text) throws Exception {
		driver.findElement(By.xpath("//input[contains(@class,'BUSINESS_UNIT')]")).clear();
		driver.findElement(By.xpath("//input[contains(@class,'BUSINESS_UNIT')]")).sendKeys(text);	
		Thread.sleep(4000);
		waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
		Thread.sleep(1000);
		LogScreenshot("Info", "Text entered into the field is "+text);
		clickElement(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]/li[1]/a"));
		//			findElement(By.xpath("(//ul[contains(@style,'block')]//*[text()='" + text + "'])[1]")).click();
		Thread.sleep(1000);
		LogScreenshot("Info", "Text entered into the field is "+text);
	}*/


	public void enterAutoCompleteTextBusinessUnit(By buisnessUnitLabel, String text) throws Exception {

		int counter =0;
		while(true) {
			try {
				scroll_into_view_element(driver.findElement(buisnessUnitLabel));
				Thread.sleep(2000);
				driver.findElement(buisnessUnitLabel).clear();
				Thread.sleep(1500);
				driver.findElement(buisnessUnitLabel).sendKeys(text);
				waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
				Thread.sleep(4000);
				driver.findElement(By.xpath("//ul[contains(@style,'block')]//*[text()='"+text+"']")).click();
				LogScreenshot("Info", "Text entered into the field is "+text);
				break;
			}catch (Exception e) {
				counter++;
				LogScreenshot("info","Retrying to enter data:"+text);
				if(counter>5) {
					break;
				}		
			}
		}
	}
}
