package com.zycus.eProc.Catalog;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> NewCatalog.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.enterCatalogDetails: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class ItemDetails extends eProc_CommonFunctions {

  private String serviceNum;
  private String shortDesc;
  private String prodCategory;
  private int price;
  private String discountType;
  private int discountedPercent;
  private int discountedPrice;
  private int tiered_minQty;
  private int tiered_value;

  /**
   * Constructor for the class
   * 
   * @param driver
   * @throws Exception 
   */

  public ItemDetails(WebDriver driver, ExtentTest logger) throws Exception { 
    super(driver, logger);
    Random rnd = new Random();
    CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
        String[][] abc = (String[][]) objFunctions.dataProvider("NewItem", Datasheet_eProc);
        this.serviceNum = "serviceNum_"+generateNo();
        this.shortDesc = "item_desc";
        this.prodCategory = abc[0][0];
        this.price = 1+rnd.nextInt(3000);
        this.discountType = abc[0][1];
        this.discountedPercent = 1+rnd.nextInt(99);
        this.discountedPrice = 1+rnd.nextInt(price);
        this.tiered_minQty = 1+rnd.nextInt(1000);
        this.tiered_value = 1+rnd.nextInt(1000);
  }
  
  public void editItemDetails(String linkedErrFieldName, By linkedFieldLocator) throws Exception{
    switch(linkedErrFieldName){
    case "Product Category":
      WebElement elem = driver.findElement(linkedFieldLocator);
      scroll_into_view_element(elem);
      elem.click();
      enterText_AutoComplete_eProc(linkedFieldLocator, prodCategory);
      break;
	default:
		break;
    }
    findElement(By.id("updateItem"),"Update button").click();
    Thread.sleep(10000);
  }
  
  public void editItemDetails(String linkedErrFieldName, String fieldValue, By linkedFieldLocator) throws Exception{
    switch(linkedErrFieldName){
    case "Product Category":
      WebElement elem = driver.findElement(linkedFieldLocator);
      scroll_into_view_element(elem);
      enterText_AutoComplete(linkedFieldLocator, fieldValue);
      break;
	default:
		break;
    }
    findElement(By.id("updateItem")).click();
    Thread.sleep(5000);
  }

  /**
   * <b>Function:</b> enterItemDetails
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param None
   * @return None
   */

  public boolean enterItemDetails() throws Exception{
    boolean result = false;
    driver.findElement(By.id("txtItemNumber")).sendKeys(serviceNum);
    driver.findElement(By.id("txtItemname")).sendKeys(shortDesc);
    WebElement objProdCategory = driver.findElement(By.id("txtCatName"));
    scroll_into_view_element(objProdCategory, "Product Category");
    Thread.sleep(2000);
    enterText_AutoComplete_eProc(By.id("txtCatName"), prodCategory);
    driver.findElement(By.id("txtPrice")).sendKeys(String.valueOf(price));
    if (discountType.toLowerCase().equals("discounted percentage")){
      if (driver.findElements(By.xpath("//input[@class='discount_percent']")).size() > 0){
        findElement(By.xpath("//input[@class='discount_percent']")).click();
        driver.findElement(By.xpath("//input[@name='discntoptval']")).sendKeys(String.valueOf(discountedPercent)+Keys.TAB);
        Thread.sleep(2000);
        if (driver.findElement(By.xpath("//div[@class='pricediv']")).isDisplayed())
          LogScreenshot("Pass","Discounted price displayed");
        else
          LogScreenshot("Fail","Discounted price not displayed");
      }
    }else if (discountType.toLowerCase().equals("discounted price")){
      if (driver.findElements(By.xpath("//input[@class='discount_price']")).size() > 0){
        findElement(By.xpath("//input[@class='discount_price']")).click();
        driver.findElement(By.xpath("//input[@name='discntoptvalprice']")).sendKeys(String.valueOf(discountedPrice)+Keys.TAB);
        Thread.sleep(2000);
        /*driver.findElement(By.xpath("//input[@name='discntoptvalprice']")).sendKeys(Keys.TAB);
        Thread.sleep(2000);*/
        findElement(By.xpath("//div[@role='dialog']/div/span[text()='"+getLanguageProperty("Item Details")+"']")).click();
        Thread.sleep(2000);
        if (driver.findElement(By.xpath("//div[@class='pricediv']")).isDisplayed())
          LogScreenshot("Pass","Discounted price displayed");
        else
          LogScreenshot("Fail","Discounted price not displayed");
      }
    }else if (discountType.toLowerCase().equals("tiered pricing")){
      if (driver.findElements(By.xpath("//input[@class='tieredradio']")).size() > 0){
        findElement(By.xpath("//input[@class='tieredradio']")).click();
        driver.findElement(By.xpath("//input[@name='quantity']")).sendKeys(String.valueOf(tiered_minQty));
        driver.findElement(By.xpath("//input[@name='discval']")).sendKeys(String.valueOf(tiered_value));
      }
    }
    Thread.sleep(3000);
    LogScreenshot("Pass", "Item Details entered");
    findElement(By.xpath("//input[@id='addItem']|//input[@id='addContinueItem']")).click();
    //findElement(By.id("addItem")).click();
    //waitUntilInvisibilityOfElement(By.id("addItemDialog"));
    Thread.sleep(5000);
    waitUntilVisibilityOfElement(By.xpath("(//table[@id='itemListGrid']/tbody/tr/td[contains(@class,'supplierPartId')])[1]"));
    String addedServiceNum = driver.findElement(By.xpath("(//table[@id='itemListGrid']/tbody/tr/td[contains(@class,'supplierPartId')])[1]")).getText();
    if (addedServiceNum.equals(serviceNum)){
      LogScreenshot("Pass", "Item added to Catalog");
      result = true;
    }
      
    return result;
  }
  
  public boolean enterItemDetails_ZSN() throws Exception{
    boolean result = false;
    driver.findElement(By.id("txtItemNumber")).sendKeys(serviceNum);
    driver.findElement(By.id("txtItemname")).sendKeys(shortDesc);
    
    WebElement objProdCategory = driver.findElement(By.id("txtCatName"));
    scroll_into_view_element(objProdCategory, "Product Category");
    Thread.sleep(2000);
    enterText_AutoComplete_eProc(By.id("txtCatName"), prodCategory);
    
    findElement(By.id("txtUOM")).clear();
    enterText_AutoComplete(By.id("txtUOM"), "EA");
    Thread.sleep(2000);
    driver.findElement(By.id("txtPrice")).sendKeys(String.valueOf(price));
    Thread.sleep(3000);
    LogScreenshot("Pass", "Item Details entered");
    findElement(By.id("addItem")).click();
    //waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='additemDialog' and contains(@style,'none')]"));
    Thread.sleep(8000);
    LogScreenshot("Info", "Add button clicked");
    waitUntilVisibilityOfElement(By.xpath("//table[@id='catalogGrid']/tbody/tr/td[contains(@class,'itemName')]"));
    String addedServiceNum = driver.findElement(By.xpath("(//table[@id='catalogGrid']/tbody/tr/td[contains(@class,'SupplierPartId')])[1]")).getText();
    if (addedServiceNum.equals(serviceNum)){
      LogScreenshot("Pass", "Item added to Catalog");
      result = true;
    }else{
    	driver.navigate().refresh();
    	Thread.sleep(8000);
    	if (addedServiceNum.equals(serviceNum)){
	      LogScreenshot("Pass", "Item added to Catalog");
	      result = true;
	    }else{
	    	LogScreenshot("Fail", "Item not added to Catalog");
	    }
    }
    return result;
  }

}
