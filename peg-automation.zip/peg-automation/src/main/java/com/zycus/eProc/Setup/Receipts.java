package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;


public class Receipts extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By receiptsLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Receipts']");
  
  public Receipts(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterGeneralSettings() {
    boolean result = true;
    String category = "";
    String categoriesRequiringReceipts = "";
    String receiptCreationForPOFromExtSys = "";
    String receiptCreationForPOFromEproc = "";
    
    try {
      //findElement(receiptsLinkXpath).click();
    
      //General Settings
      findElement(By.xpath("//input[@name='category'][following-sibling::text()[contains(.,'"+categoriesRequiringReceipts+"')]]")).click();
      if (categoriesRequiringReceipts.equals("Select")){
        findElement(By.xpath("//a[text()='Select Category']")).click();
        waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='Select Category']]"));
        findElement(By.xpath("//input[@name='txtSearch']")).sendKeys(category);
        findElement(By.xpath("//div[@class='treeRslt']/a[span/span[text()='"+category+"']]")).click();
        findElement(By.xpath("//input[@value='Save']")).click();
      }
      findElement(By.xpath("//input[@name='EPROC_RECEIPT_GENERAL_ALLOW_UI_ACTIONS'][following-sibling::text()[contains(.,'"+receiptCreationForPOFromExtSys+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_RECEIPT_GENERAL_ALLOW_UI_ACTIONS_ZYCUS'][following-sibling::text()[contains(.,'"+receiptCreationForPOFromEproc+"')]]")).click();
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean enterNumbering() {
    boolean result = true;
    
    String receiptFormat = "";
    String receiptSeqNo = "";
    String receiptMaxSeqNo = "";
    
    try {
      findElement(By.xpath("//div[@id='stpsBlck']/p/a[@title='Numbering']")).click();
      driver.findElement(By.id("EPROC_RECEIPT_FORMAT")).sendKeys(receiptFormat);
      driver.findElement(By.id("EPROC_RECEIPT_SEQUENCE_NO")).sendKeys(receiptSeqNo);
      driver.findElement(By.id("EPROC_RECEIPT_MAX_SEQUENCE_NO")).sendKeys(receiptMaxSeqNo);
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean enterDesktopCentralReceiving() {
    boolean result = true;
    
    String exceedPOQtyByPercent = "";
    String daysBeforeDelDtToRestrictCreation = "";
    String daysAfterDelDtToRestrictCreation = "";
    String daysAfterExpDtToRestrictCreation = "";
    
    try {
      findElement(By.xpath("//div[@id='stpsBlck']/p/a[@title='Desktop / Central Receiving']")).click();
      driver.findElement(By.id("txtExceedOrderQty")).sendKeys(exceedPOQtyByPercent);  
      driver.findElement(By.id("txtEarlyDelivery")).sendKeys(daysBeforeDelDtToRestrictCreation);
      driver.findElement(By.id("txtLateDelivery")).sendKeys(daysAfterDelDtToRestrictCreation);
      driver.findElement(By.id("txtLateClosedExpired")).sendKeys(daysAfterExpDtToRestrictCreation);
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }

}
