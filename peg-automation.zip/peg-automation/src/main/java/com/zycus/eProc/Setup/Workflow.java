package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class Workflow extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By workflowLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Workflow']");
  
  public Workflow(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }

  public boolean enterGeneralSettings() {
    boolean result = true;
    
    String allowNewTags = "";
    String autoApproveAdminRouted = "";
    String addreplaceDelegUserAsApprover = "";
    String enableCostCenter = "";
    String replacingOwnerWithHighLimit = "";
    String replacingOwnerWithDiffDesig = "";
    String replacingOwnerWithHighDesig = "";
    String replacingWithNonOverlapScope = "";
    String preventRecursiveDelegation = "";
    String allowDelegationTo = "";
    
    try {
      //findElement(workflowLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //Control
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_ALLOW_NEW_TAGS'][following-sibling::text()[contains(.,'"+allowNewTags+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_AUTO_APPROVE_IF_WORKFLOW_ADMIN'][following-sibling::text()[contains(.,'"+autoApproveAdminRouted+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_ADD_REPLACE_DELEGATE_ANY_USER_AS_APPROVER'][following-sibling::text()[contains(.,'"+addreplaceDelegUserAsApprover+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_ENABLE_COST_CENTER_OWNER_ROUTING_CONDITION'][following-sibling::text()[contains(.,'"+enableCostCenter+"')]]")).click();
      
      //Approver Modification
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_REPLACE_HIGHER_APPROVER_LIMIT'][following-sibling::text()[contains(.,'"+replacingOwnerWithHighLimit+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_REPLACE_DIFFERENT_DESIGNATION'][following-sibling::text()[contains(.,'"+replacingOwnerWithDiffDesig+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_REPLACE_HIGHER_DESIGNATION_LEVEL'][following-sibling::text()[contains(.,'"+replacingOwnerWithHighDesig+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_REPLACE_NON_OVERLAPING_SCOPE'][following-sibling::text()[contains(.,'"+replacingWithNonOverlapScope+"')]]")).click();
      
      //Delegation
      findElement(By.xpath("//input[@name='EPROC_WORKFLOW_PREVENT_RECURSIVE_DELEGATION'][following-sibling::text()[contains(.,'"+preventRecursiveDelegation+"')]]")).click();
      findElement(By.xpath("//select[@name='EPROC_WORKFLOW_ALLOW_DELEGATION_TO']/option[@value='"+allowDelegationTo+"']")).click();
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
