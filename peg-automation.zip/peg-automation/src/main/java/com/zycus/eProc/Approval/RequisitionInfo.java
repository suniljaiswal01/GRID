package com.zycus.eProc.Approval;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class RequisitionInfo extends eProc_CommonFunctions{

  private static By HeaderReqNum   = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName   = By.xpath("//h1[@class='pgHead']/span[3]");
  
  public RequisitionInfo(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    this.HeaderReqNum = headerReqNum;
  }

  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    HeaderReqName = headerReqName;
  }

}
