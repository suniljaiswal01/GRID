package com.zycus.eProc.Budget;

import java.time.Month;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eProc_CommonFunctions;

public class Budget_AddPeriod extends eProc_CommonFunctions{
  
  private String StartDt;
  private String EndDt;
  private String periodName;
  
  public Budget_AddPeriod(WebDriver driver, ExtentTest logger) throws Exception { 
    super(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eProc");
        String[][] abc = (String[][]) objFunctions.dataProvider("NewBudgetPeriod", Datasheet_eInvoice);
        this.StartDt = abc[0][0];
    this.EndDt = abc[0][1];
    this.periodName = abc[0][2];
  }
  
  /**
   * <b>Function:</b> addPeriod
   * @author Varun Khurana
   * @since April 2018
   * @param description
   * @return result
   * @throws Exception 
   */
  
  public String addPeriod(String...description) throws Exception{
    String addedPeriod = null;
    String desc = description.length==0?"Budget Period Description":description[0];
    String period = periodName;
    try {
      findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'Start Date')]]//img")).click();
      String todayDate= getTodayDate();
      selectDate_v1(todayDate);
      findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'End Date')]]//img")).click();
      String nextDate= selectNextDate();
      selectDate_v1(nextDate);
      if (periodName  !=  ""){
        driver.findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'Period Name')]]//input")).clear();
        driver.findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'Period Name')]]//input")).sendKeys(periodName);
      } else {
        period = findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'Period Name')]]//input")).getText();
        if (period  !=  this.getPeriodName(StartDt, EndDt))
          LogScreenshot("Info", "Incorrect Period Name displayed or is blank");
      }
      if (desc != "")
        driver.findElement(By.xpath("//form[@id='budgetPeriodForm_createBudget']//li[label/text()[contains(.,'Description')]]//textarea")).sendKeys(desc);
      findElement(By.xpath("//*[@id='addNewPeriod']//input[@value='Add']")).click();
      if (driver.findElement(By.xpath("//*[@id='budgerPeriodDropDown']//a[text()='"+period+"']")) != null)
        addedPeriod = period;
      else
        LogScreenshot("Info", "Period not added to the list");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return addedPeriod;
  }
  
  /**
   * <b>Function:</b> getPeriodName
   * @author Varun Khurana
   * @since April 2018
   * @param StartDt
   * @param EndDt
   * @return periodName
   */
  
  public String getPeriodName(Date StartDt, Date EndDt){
    int Start_dd = Integer.parseInt(StartDt.toString().split("/")[0]);
    int Start_mm = Integer.parseInt(StartDt.toString().split("/")[1]);
    int Start_yr = Integer.parseInt(StartDt.toString().split("/")[2].substring(2));
    
    int End_dd = Integer.parseInt(EndDt.toString().split("/")[0]);
    int End_mm = Integer.parseInt(EndDt.toString().split("/")[1]);
    int End_yr = Integer.parseInt(EndDt.toString().split("/")[2].substring(2));

    String periodName = "FY"+Start_yr+"-"+End_yr+"-"+Month.of(Start_mm).name()+"/"+Start_dd+"-"+Month.of(End_mm).name()+"/"+End_dd;
    return periodName;
  }
  
  private String getPeriodName(String StartDt, String EndDt){
    String Start_dd = StartDt.split("/")[0];
    int Start_mm = Integer.parseInt(StartDt.split("/")[1]);
    String Start_yr = StartDt.split("/")[2].substring(2);
    
    String End_dd = EndDt.split("/")[0];
    int End_mm = Integer.parseInt(EndDt.split("/")[1]);
    String End_yr = EndDt.split("/")[2].substring(2);

    String periodName = "FY"+Start_yr+"-"+End_yr+"-"+Month.of(Start_mm).name()+"/"+Start_dd+"-"+Month.of(End_mm).name()+"/"+End_dd;
    return periodName;
  }
  
  
  
}
