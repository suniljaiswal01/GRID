package com.zycus.eProc.PO;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eInvoice.Invoice.ItemDetails;
import com.zycus.iSupplier.ManageSuppliers.CreateSupplier;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;
import common.Functions.eProc_eIvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> BlanketPurchaseOrder.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class BlanketPurchaseOrder extends eProc_CommonFunctions {

  private static By HeaderReqNum = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName = By.xpath("//h1[@class='pgHead']/span[3]");
  
  private static By pgHeader = By.xpath("//h1[@class='pgHead']/span[text()='Purchase Order']");
  private String supplier;
  private String purchaseType;
  private String orderDesc;
  private String buyer;
  private String itemAdditionProcess;
  private String deliveryTerms;
  private String orderValue;
  private String fromDt;
  private String toDt;
  private String acceptInvoicesUntil;
  private String businessUnit;
  private String location;
  private String costCenter;
  static By backBtn = By.xpath("//a[@title='Back to Purchase Order listing']");

  /**
   * Constructor for the class
   * 
   * @param driver
   * @throws Exception 
   */
  
  public BlanketPurchaseOrder(WebDriver driver, ExtentTest logger, String supplier) throws Exception { 
    super(driver, logger);
    this.supplier = supplier;
    CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
        String[][] abc = (String[][]) objFunctions.UntrimmedDataProvider("BlanketPurchaseOrder", Datasheet_eProc);
        this.deliveryTerms = abc[0][0];
        this.purchaseType = abc[0][1];
        this.orderDesc = abc[0][2];
        this.buyer = abc[0][3];
        this.itemAdditionProcess = abc[0][4];
        this.orderValue = abc[0][5];
        this.fromDt = abc[0][6];
        this.toDt = abc[0][7];
        this.acceptInvoicesUntil = abc[0][8];
        this.businessUnit = abc[0][9];
        this.location = abc[0][10];
        this.costCenter = abc[0][11];
  }
  
  public String enterPODetails() throws Exception{
    String generatedPO = null;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    //WebEdit obj = new WebEdit();
    By purchaseTypeXpath = By.xpath("//*[@id='selPurchaseType']/option[text()='" + purchaseType + "']");
    eProc_eIvoice_CommonFunctions objCommon = new eProc_eIvoice_CommonFunctions(driver, logger);
    try {
      waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
      String PO = "AutoPO_" + generateNo();
      //obj.setWebEditValue(By.id("txtPurchaseOrderNumber"), PO);
      driver.findElement(By.id("txtPurchaseOrderNumber")).clear();
      driver.findElement(By.id("txtPurchaseOrderNumber")).sendKeys(PO);
      
      //Flexi fields if exist
      eInvoice_CommonFunctions objFunc = new eInvoice_CommonFunctions(driver, logger);
      objFunc.flexiFormDetails(false);
      
      if (supplier==null){
        try {
          String state = driver.findElement(By.id("orgUnit_location")).getText();
          findElement(By.xpath("//a[text()='"+getLanguageProperty("Add Supplier")+"']")).click();
          // Code for switching to iSupplier tab
          String parent = driver.getWindowHandle();
          switchWindowHandles(parent, "Zycus SIM : Create Supplier");
          CreateSupplier objSupplier = new CreateSupplier(driver, logger, state);
          //if (objSupplier.createNewSupplier("Operational"))
          supplier = objSupplier.createNewSupplier("Operational");
        } catch (Exception e) {
          LogScreenshot("Info", "SIM Supplier not created");
        }
      }else
        System.out.println("Driver used here is "+ driver);
        //obj.setAutoCompleteTxt(driver, By.id("txtSupplierName"), supplier);
        enterText_AutoComplete_eProc(By.id("txtSupplierName"), supplier);
      objCommon.selectAddress();
      
      //Currency - Exchange Rate
      Random rnd = new Random();
      if (driver.findElements(By.xpath("//input[@id='txtBaseExchangeRate' and not(contains(@style,'none'))]")).size() > 0)
        driver.findElement(By.id("txtBaseExchangeRate")).sendKeys(String.valueOf(1+rnd.nextInt(10)));
      
      //Delivery Terms
      WebElement objDeliveryTerm = driver.findElement(By.id("slctDeliveryTerm"));
      /*((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", objDeliveryTerm);
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-200);");*/
            scroll_into_view_element(objDeliveryTerm);
            objDeliveryTerm.click();
      findElement(By.xpath("//select[@id='slctDeliveryTerm']/option[@title='"+deliveryTerms+"']")).click();
      try {
        // findElement(By.id("slctPurchaseType")).click();
        js.executeScript("arguments[0].click();", driver.findElement(purchaseTypeXpath));
        findElement(purchaseTypeXpath).click();
      } catch (Exception e) {
      e.printStackTrace();
      }
      //obj.setWebEditValue(driver, By.id("txtOrderDescription"), oderDesc);
      driver.findElement(By.id("txtOrderDescription")).sendKeys(orderDesc);
      Thread.sleep(3000);
      WebElement objBuyer = driver.findElement(By.id("txtBuyer"));
      scroll_into_view_element(objBuyer, "Buyer text field");
      Thread.sleep(3000);
      LogScreenshot("Info", "Entering buyer as "+buyer);
      enterText_AutoComplete_eProc(By.id("txtBuyer"), buyer);
      scroll_into_view_element(objBuyer, "Buyer text field");
      LogScreenshot("Info", "Buyer value entered as "+buyer);
      //obj.setAutoCompleteTxt(driver, By.id("txtBuyer"), buyer);
      //Remove all taxes
      WebElement objRemoveTaxes = driver.findElement(By.xpath("//div[@id='taxDetailCompleteBlock']//a[contains(@class,'scLnk dev_removeAllTaxes')]"));
      scroll_into_view_element(objRemoveTaxes);
      objRemoveTaxes.click();
      addItem(itemAdditionProcess);
      LogScreenshot("Pass", "Item added successfully");
      enterAgreementDetails(orderValue);
      //defineBuyingScope(businessUnit, location, costCenter);
      defineBuyingScope(getBusinessUnit(), getLocation(), getCostCenter());
      selectValidity(fromDt, toDt, acceptInvoicesUntil);
        
      generatedPO = PO;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return generatedPO;
  }
  
  private String getBusinessUnit(){
	  return driver.findElement(By.id("orgUnit_businessUnit")).getText();
  }
  
  private String getLocation(){
	  return driver.findElement(By.id("orgUnit_location")).getText();
  }
  
  private String getCostCenter(){
	  return driver.findElement(By.id("costCenter_header")).getText().split(":")[0].trim();
  }
  
  private void defineBuyingScope(String businessUnit, String location, String costCenter) throws Exception{
    
    WebElement objBuyingScope = driver.findElement(By.id("lnkBPOPurchasingScope"));
    scroll_into_view_element(objBuyingScope);
    findElement(By.id("lnkBPOPurchasingScope")).click();
    waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("BPO Buying Scope")+"']]"));
    enterText_AutoComplete_eProc(By.xpath("//div[contains(@class,'bpoPurchasingScope') and @style]//input[contains(@name,'businessUnit')]"), businessUnit);
    enterText_AutoComplete_eProc(By.xpath("//div[contains(@class,'bpoPurchasingScope') and @style]//input[contains(@name,'location')]"), location);
    enterText_AutoComplete_eProc(By.xpath("//div[contains(@class,'bpoPurchasingScope') and @style]//input[contains(@name,'costCenter')]"), costCenter);
    //enterText_AutoComplete_eProc(By.xpath("//div[contains(@class,'bpoPurchasingScope') and @style]//input[contains(@name,'costCenter')]"), costCenter);
    LogScreenshot("Pass","Buying scope details entered");
    findElement(By.xpath("//div[contains(@class,'bpoPurchasingScope') and @style]//input[contains(@class,'savePurchasingScope')]")).click();
    waitUntilInvisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("BPO Buying Scope")+"']]"),4);
    LogScreenshot("Pass","Buying scope defined");
  }
  
  private void enterAgreementDetails(String orderValue){
    //Agreement Details
    if (orderValue.equals("Auto Update")){
      if (driver.findElement(By.xpath("//input[@id='txtOrderValue' and @disabled]"))==null)
        findElement(By.id("chkAutoUpdate")).click();
    } else {
      if (driver.findElement(By.xpath("//input[@id='txtOrderValue' and @disabled]")) != null){
          findElement(By.id("chkAutoUpdate")).click();
          driver.findElement(By.id("txtOrderValue")).sendKeys(orderValue);
        }
    }
  }
  
  private void selectValidity(String fromDt, String ToDt, String acceptInvoicesUntil) throws Exception{
    WebElement objFromValidity =  driver.findElement(By.xpath("//input[@id='txtValidityFromDate']/following-sibling::img"));
    objFromValidity.click();
    if (fromDt != "")
      selectDate_v1(fromDt);
    else
      selectDate_v1(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/YYYY")));
    findElement(By.xpath("//input[@id='txtValidityToDate']/following-sibling::img")).click();
    if (ToDt != "")
      selectDate_v1(ToDt);
    else
      selectDate_v1(LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/YYYY")));
    findElement(By.xpath("//input[@id='txtValidityUntilDate']/following-sibling::img")).click();
    if (acceptInvoicesUntil != "")
      selectDate_v1(acceptInvoicesUntil);
    else
      selectDate_v1(LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/YYYY")));
  }
  
  public void selectValidity(String ToDt, String acceptInvoicesUntil) throws Exception{
    selectValidity("", ToDt, acceptInvoicesUntil);
  }
  
  public void selectValidity() throws Exception{
    selectValidity("", "", "");
  }
  
  private boolean addItem(String itemAdditionProcess) {
    boolean result = false;
    Actions action = new Actions(driver);
    //JavascriptExecutor js = (JavascriptExecutor) driver;
    try {
      WebElement objAddItem = driver.findElement(By.id("addItemBttn"));
      /*js.executeScript("arguments[0].scrollIntoView(true);", objAddItem);
      js.executeScript("window.scrollBy(0,-100)");
      Thread.sleep(500);*/
      scroll_into_view_element(objAddItem);
      action.moveToElement(objAddItem).build().perform();
      WebElement objItemAdditionProcess = driver.findElement(
          By.xpath("//div[@id='addItemBttn']/div//a[span[text()='" + itemAdditionProcess + "']]"));
      action.moveToElement(objItemAdditionProcess).click().build().perform();
      Thread.sleep(3000);
      switch (itemAdditionProcess) {
      case "Search Item":
        waitUntilVisibilityOfElement(By.id("searchTerm_addCollpsBxPad"));
        driver.findElement(By.id("searchTerm_addCollpsBxPad")).sendKeys("Freight"+Keys.ENTER);
        waitUntilInvisibilityOfElement(processingLoader,4);
        waitUntilVisibilityOfElement(By.id("itemList_addCollpsBxPad"));
        //Search Item Name
        break;
      case "Create a free-text Item":
        int existingItems = driver
        .findElements(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[contains(@id,'itemRow')]"))
        .size();
        ItemDetails objItem = new ItemDetails(driver, logger);
        objItem.add_item();  
        int noOfItems = driver
            .findElements(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[contains(@id,'itemRow')]"))
            .size();
        if (noOfItems == existingItems + 1) {
          result = true;
        }
        break;
      case "Add Items via file":
        break;
      case "Punchouts":
        break;
      default : 
          break;
      }
      
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName
   *            the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    HeaderReqName = headerReqName;
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum
   *            the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    HeaderReqNum = headerReqNum;
  }

}
