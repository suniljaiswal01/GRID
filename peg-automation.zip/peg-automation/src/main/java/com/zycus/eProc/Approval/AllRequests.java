package com.zycus.eProc.Approval;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

/**
 * <b> Title: </b> AllRequests.java
 * <br>
 * <b> Description: </b> Approval - Approval Requests related class
 * <br>
 * <b> Functions: </b> None
 * 
 * @author Varun Khurana
 * @since April 2018
 */ 

public class AllRequests extends ApprovalDetails{

  /**
   * Constructor for the class
   * @param driver
   */
  
  public AllRequests(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

}
