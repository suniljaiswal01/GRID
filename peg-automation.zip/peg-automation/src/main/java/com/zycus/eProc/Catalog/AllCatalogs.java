package com.zycus.eProc.Catalog;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> GuidedProcurement_SearchEform.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.searchEForm: 
 * <br>
 * 2.filterByReceivedOn: user shall be able to filter by Received On 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class AllCatalogs extends eProc_CommonFunctions {

  private static By Catalogs_popUp = By.xpath("//div[@aria-describedby='allCatalogDiag']");

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public AllCatalogs(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the EForms_popUp
   */
  public static By getCatalogs_popUp() {
    return Catalogs_popUp;
  }

  /**
   * @param eForms_popUp
   *            the eForms_popUp to set
   */
  public void setCatalogs_popUp(By catalog_popUp) {
    this.Catalogs_popUp = catalog_popUp;
  }

  /**
   * <b>Function:</b> searchEForm -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param eForm
   * @return result - True/False
   */

  public boolean searchAndSelectCatalog(String catalog) throws Exception{
    boolean result = false;
    waitUntilInvisibilityOfElement(By.id("tblSearchCatalogList_processing"));
    driver.findElement(By.id("txtSearchCatalog")).sendKeys(catalog+Keys.ENTER);
    waitUntilInvisibilityOfElement(processingLoader,4);
    Thread.sleep(3000);
    List<WebElement> objItemsFound = driver.findElements(By.xpath("//table[@id='tblSearchCatalogList']//td[contains(@id,'item_grid_row')]"));
    if (objItemsFound.size()>= 1) {
      LogScreenshot("Pass", "Catalog : "+ catalog + "searched successfully");
      try{
    	  objItemsFound.get(0).click();
    	  waitUntilVisibilityOfElement(By.id("tblSearchItemList_wrapper"));
    	  LogScreenshot("Pass", "Catalog : "+ catalog + " selected");
    	  result = true;
      }catch(Exception e){
    	  LogScreenshot("Fail", "Catalog : "+ catalog + " not selected");
      }
    } else
      LogScreenshot("Fail", " No catalog displayed for the search item : "+catalog + "even after waiting for 8 min");
    return result;

  }

}
