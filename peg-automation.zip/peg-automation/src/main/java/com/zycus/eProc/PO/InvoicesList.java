package com.zycus.eProc.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eProc.eInvoice.InvoiceAgainstPO;

import common.Functions.eProc_CommonFunctions;

public class InvoicesList extends eProc_CommonFunctions{
  
  private String receiptDt;
  
  private static By selectItemsChkbox     = By.id("chkAllItems");
  private static By consignNoId         = By.id("txt_consign");
  private static By shippedViaId       = By.id("txt_shipped_via");
  private static By airwayBillId       = By.id("txt_air_bill");
  private static By commentsId         = By.id("comment");
  private static By submitBtnId         = By.id("submitForm");
  private static By HeaderReqNum       = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName       = By.xpath("//h1[@class='pgHead']/span[3]");
  private static By addAttachmentsLink     = By.xpath("//a[@title='Add Attachments']");
  private static By attachFilePopUp       = By.xpath("//*[@id='addAttachment']/parent::div");
  static By receiptsListTable =  By.id("tblReceiptListing");

  public InvoicesList(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    this.HeaderReqNum = headerReqNum;
  }

  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    this.HeaderReqName = headerReqName;
  }
  
  
  public String addNewInvoice(String PO) throws Exception{
    String newInvoice = null;
    findElement(By.id("createInvoice")).click();
    Thread.sleep(8000);
    InvoiceAgainstPO objInvoice = new InvoiceAgainstPO(driver, logger);
    newInvoice = objInvoice.createNewInvoice(PO);
    return newInvoice;
  }
  
  public boolean verifyInvoiceAdditionAllowed() throws Exception{
    return driver.findElements(By.id("createInvoice")).size() > 0;

  }
  
  
  
}
