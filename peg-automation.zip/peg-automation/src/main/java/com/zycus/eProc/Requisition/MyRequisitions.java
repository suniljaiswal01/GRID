package com.zycus.eProc.Requisition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

/**
 * <p>
 * <b> Title: </b> Requisition_MyRequisitions.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None<br>
 * @author Varun Khurana
 * @since April 2018
 */

public class MyRequisitions extends RequisitionDetails{
  private static By pgHead = By.xpath("//h1[@class='pgHead' and text()='My Requisitions']");
  private static By headerSuccessBox = By.id("hedaerSuccessBox");
  /**
   * Constructor for the class
   * 
   * @param driver
   */
    
  public MyRequisitions(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the pgHead
   */
  public static By getPgHead() {
    return pgHead;
  }

  /**
   * @param pgHead the pgHead to set
   */
  public static void setPgHead(By pgHead) {
    MyRequisitions.pgHead = pgHead;
  }

  public static By getHeaderSuccessBox() {
    return headerSuccessBox;
  }

  public static void setHeaderSuccessBox(By headerSuccessBox) {
    MyRequisitions.headerSuccessBox = headerSuccessBox;
  }
  
  /*public int getRequisitionNumber(){
    String headerTxt = driver.findElement(headerSuccessBox).getText();
    return Integer.parseInt(headerTxt.split("Requisition")[1].split("has")[0].trim());
  }*/
  
  public String getRequisitionNumber(){
    String headerTxt = driver.findElement(headerSuccessBox).getText();
    return headerTxt.split("Requisition")[1].split("has")[0].trim();
  }
  
  
  public String getDraftedRequisitionNumber(){
    return driver.findElement(By.xpath("//table[@id='reqList']/tbody/tr[1]/td[2]/a")).getText();
  }
}
