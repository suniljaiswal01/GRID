package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class Contracts extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By contractsLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Contracts']");
  
  public Contracts(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterSettings() {
    boolean result = true;
    
    String reserveAmtFrmContValTransactOn = "";
    
    try {
      //findElement(contractsLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //Control
      findElement(By.xpath("//input[@name='EPROC_CONTRACT_RESERVE_AMOUNT_ON'][following-sibling::text()[contains(.,'"+reserveAmtFrmContValTransactOn+"')]]")).click();
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
