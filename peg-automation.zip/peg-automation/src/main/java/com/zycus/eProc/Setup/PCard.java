package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class PCard extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By pCardAdminLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='P-card']");
  
  public PCard(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterSettings() {
    boolean result = true;
    
    String pCardAdminDispName = "";
    String contactDetails = "";
    
    try {
      //findElement(pCardAdminLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //P-card Administrator 
      enterText_AutoComplete(By.id("pCardAdminDisplayName"), pCardAdminDispName);
      driver.findElement(By.id("contactDetails")).sendKeys(contactDetails);

      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
