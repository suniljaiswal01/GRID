package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;


public class ReturnNote extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By returnNoteLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Return Note']");
  
  public ReturnNote(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterGeneralSettings() {
    boolean result = true;
    
    String returnReason = "";
    String returnNoFormat = "";
    String seqNumStartsAt = "";
    String seqNumEndsAt = "";
    String returnNoteDescFormat = "";
    
    try {
      //findElement(returnNoteLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //General Settings
      driver.findElement(By.id("EPROC_RETURN_NOTE_RETURN_REASON")).sendKeys(returnReason);
      
      //Return Note Numbering and Description
      driver.findElement(By.id("EPROC_RETURN_NOTE_NUMBER_FORMAT")).sendKeys(returnNoFormat);
      driver.findElement(By.id("EPROC_RETURN_NOTE_SEQUENCE_NUMBER_START")).sendKeys(seqNumStartsAt);
      driver.findElement(By.id("EPROC_RETURN_NOTE_SEQUENCE_NUMBER_END")).sendKeys(seqNumEndsAt);
      driver.findElement(By.id("EPROC_RETURN_NOTE_DESCRIPTION_FORMAT")).sendKeys(returnNoteDescFormat);
      
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
