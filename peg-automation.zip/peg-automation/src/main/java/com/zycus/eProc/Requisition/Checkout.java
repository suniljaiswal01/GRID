package com.zycus.eProc.Requisition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;
import com.main.eProcFlows.BudgetCreation;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Checkout.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.takeAction: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class Checkout extends eProc_CommonFunctions {

	private By pgHead=By.xpath("//form[@id='frmRequisition']/h1/span[@class='chkoutlbl']");
	private boolean isUrgentReq;
	private String reasonForOrdering;
	private String onBehalfOf;
	private String assignedBuyerOrGrp;
	private String settlementVia;
	private boolean isAssignedBuyerGroup;
	private String budget;

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @throws Exception 
	 */

	public Checkout(WebDriver driver, ExtentTest logger) throws Exception { 
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
		System.out.println(Datasheet_eProc);
		String[][] abc = (String[][]) objFunctions.UntrimmedDataProvider("Requisition_Info", Datasheet_eProc);
		this.isUrgentReq = Boolean.parseBoolean(abc[0][0]);
		this.reasonForOrdering = abc[0][1];
		this.onBehalfOf = abc[0][2];
		this.isAssignedBuyerGroup = Boolean.parseBoolean(abc[0][3]); 
		this.assignedBuyerOrGrp = abc[0][4];
		this.settlementVia = abc[0][5];
		this.budget = abc[0][6];
	}

	public String createRequisition(String purchaseType) throws Exception{
		String newRequisitionName = null;
		String requisitionName;
		requisitionName = enterRequisitionInfo(purchaseType);
		Thread.sleep(2000);
		//try {
		submitRequisition();
		//} catch (Exception e) {
		if (driver.findElements(By.id("submitRequisition")).size() > 0){
			List<WebElement> billToAddrInlineErrors = driver.findElements(By.xpath("//div[@class='delBillSummary']//tr/td[2]/div/div/div/span[@class='icon inlineError' and @title]"));
			if (billToAddrInlineErrors.size() > 0){
				correctBillToAddrInlineErrors();
				submitRequisition();
			}
			List<WebElement> itemSectionsWithErrors = driver.findElements(By.xpath("//div[@id='requisitionItemGroups']//tbody[@class='requisitionItems']/tr//span[a[contains(@class,'inlineError') and @title and not(contains(@style,'none'))]]"));
			if (itemSectionsWithErrors.size() > 0) {
				correctItemSectionErrors();
				submitRequisition();
			}
			else{
				List<WebElement> itemRowsWithInlineErrors = driver.findElements(By.xpath("//div[@id='requisitionItemGroups']//tbody[@class='requisitionItems']/tr[td[5]/span[@class='icon curDef inlineError ']]"));
				if (itemRowsWithInlineErrors.size() > 0){
					correctItemInlineErrors();
					submitRequisition();
				}
			}
			Thread.sleep(3000);
		}
		//}
		//waitUntilVisibilityOfElement(MyRequisitions.getHeaderSuccessBox());
		waitUntilVisibilityOfElement(By.xpath("//table[@id='reqList']//td[contains(@class,'requisitionNo')]"));
		/*MyRequisitions objReq = new MyRequisitions(driver, logger);
    requisitionNo = objReq.getRequisitionNumber();*/
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//table[@id='reqList']//td[contains(@class,'name')][contains(text(),'"+requisitionName+"')]")).size()>0){
			newRequisitionName = requisitionName;
			LogScreenshot("Pass", "Requisition "+requisitionName+" created");
		}else
			LogScreenshot("Fail", "Requisition "+requisitionName+" not created");
		//LogScreenshot("Pass", "Requisition Name : "+ newRequisitionName + " created");
		return newRequisitionName;
	}


	public void submitRequisition() throws Exception{
		Thread.sleep(5000);
		findElement(By.id("submitRequisition"),"Im Done button").click();
		Thread.sleep(3000);
		LogScreenshot("Info", "I'm Done button clicked");
		/*WebElement objSubmitRequisition = driver.findElement(By.xpath("//div[div/span[text()='Confirm']][div//td[contains(text(),'You are about to submit the requisition')]]"));
    objSubmitRequisition.findElement(By.xpath(".//button[span[text()='Continue']]")).click();
		 */
		waitUntilInvisibilityOfElement(processingLoader,4);
		Thread.sleep(5000);
		if (driver.findElements(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']][div//td[contains(text(),'"+getLanguageProperty("You are about to submit the requisition")+"')]]")).size() > 0){
			WebElement objSubmitRequisition = driver.findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']][div//td[contains(text(),'"+getLanguageProperty("You are about to submit the requisition")+"')]]"));
			objSubmitRequisition.findElement(By.xpath(".//button[span[text()='"+getLanguageProperty("Continue")+"']]")).click();
			LogScreenshot("Info", "Continue button clicked");
			waitUntilInvisibilityOfElement(By.xpath("//div[@id='status_overlay_updateRequisition']"),4);
			Thread.sleep(60000);
		}
		if (driver.findElements(By.xpath("//div[@id='status_overlay_processingRequest']/div/span[@id='forwardClock']")).size() > 0){
			LogScreenshot("Info", "Do not refresh popup displayed - waiting for at least 4 minutes");
			Thread.sleep(270000);
			//waitUntilVisibilityOfElement(By.xpath("//button[span[text()='"+getLanguageProperty("Go to Order Listing")+"']]"));
			LogScreenshot("Info", "Go to Requisition listing button should displayed");
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Go to Requisition Listing")+"']]")).click();
			//waitUntilVisibilityOfElement(By.id("polisting"));
			Thread.sleep(300000);
			driver.navigate().refresh();
			waitUntilInvisibilityOfElement(processingLoader,4);
			Thread.sleep(12000);
			LogScreenshot("Info", "Go to Requisition listing button clicked");
		} else {
			if (driver.findElements(By.xpath("//div[@role='dialog'][div//td[contains(text(),'should the requisition groups(s) be directly sent for approval')]]//button[span[text()='"+getLanguageProperty("Yes, send for approval")+"']]")).size() > 0){
				LogScreenshot("Info", "Send For Approval button displayed");
				findElement(By.xpath("//div[@role='dialog'][div//td[contains(text(),'should the requisition groups(s) be directly sent for approval')]]//button[span[text()='"+getLanguageProperty("Yes, send for approval")+"']]")).click();
				LogScreenshot("Info", "Send For Approval button clicked");
			}
			waitUntilInvisibilityOfElement(By.xpath("status_overlay_updateRequisition"),4);
			//if (driver.findElements(By.xpath("//div[@id='requisitionItemGroups']//tbody[@class='requisitionItems']//span[@class='icon curDef inlineError ']")).size() > 0)
			Thread.sleep(40000);
		}

	}

	private void correctItemSectionErrors() throws Exception{
		Actions action = new Actions(driver);
		eInvoice_CommonFunctions objCommonFunc = new eInvoice_CommonFunctions(driver, logger);
		List<WebElement> itemSectionsWithInlineErrors = driver.findElements(By.xpath("//div[@id='requisitionItemGroups']//tbody[@class='requisitionItems']/tr//span[a[contains(@class,'inlineError') and @title]]"));
		if (itemSectionsWithInlineErrors.size() > 0){
			for(WebElement inlineErrItemSection : itemSectionsWithInlineErrors) {
				String errorMsg =  inlineErrItemSection.findElement(By.xpath("./a[1]")).getAttribute("title");
				System.out.println("Item Section Error Message : "+ errorMsg);
				WebElement editBtn = inlineErrItemSection.findElement(By.xpath("./following-sibling::a[text()='Edit']"));
				scroll_into_view_element(editBtn);
				editBtn.click();
				waitUntilInvisibilityOfElement(processingLoader,4);
				waitUntilVisibilityOfElement(By.id("itemSummary"));
				switch(errorMsg){
				case "Please enter a valid assigned buyer information":
					WebElement objNewTaskUI = driver.findElement(By.xpath("//div[@aria-describedby='itemSummary']/div"));
					waitUntilInvisibilityOfElement(By.xpath("//div[@class='zydf-dispProcessing']"),4);
					action.dragAndDropBy(objNewTaskUI, 50, 60).build().perform();
					Thread.sleep(3000);
					enterText_AutoComplete_eProc(By.xpath("//input[contains(@id,'assignedBuyer')]"), assignedBuyerOrGrp);
					scroll_into_view_element(driver.findElement(By.id("saveRequisitionItemSummary")));
					findElement(By.id("saveRequisitionItemSummary"),"OK button on Item Summary popup").click();
					Thread.sleep(2000);
					List<WebElement> tabsWithError =driver.findElements(By.xpath("//div[@id='itemSummary']//ul[@role='tablist']/li[not(contains(@style,'none'))][a[contains(@class,'error')]]"));
					if (tabsWithError.size() > 0){
						for(WebElement errTab : tabsWithError) {
							String errTabTxt =  errTab.findElement(By.xpath("./a[1]")).getText().trim();
							switch(errTabTxt){
							case "Miscellaneous":
								findElement(By.xpath("//form[@id='frmItemSummary']//li[@role='tab']/a[text()='"+getLanguageProperty("Miscellaneous")+"']")).click();
								objCommonFunc.flexiFormDetails(true);
								break;
							default :
								break;
							}
						}
						scroll_into_view_element(driver.findElement(By.id("saveRequisitionItemSummary")));
						findElement(By.id("saveRequisitionItemSummary"),"OK button on Item Summary popup").click();
					}
					waitUntilInvisibilityOfElement(By.id("itemSummary"),4);
					break;
				default :
					break;  
				}

			}
		}
	}


	private void correctItemInlineErrors() throws Exception{
		Actions action = new Actions(driver);
		eInvoice_CommonFunctions objCommonFunc = new eInvoice_CommonFunctions(driver, logger);
		List<WebElement> itemRowsWithInlineErrors = driver.findElements(By.xpath("//div[@id='requisitionItemGroups']//tbody[@class='requisitionItems']/tr[td[5]/span[@class='icon curDef inlineError ']]"));
		if (itemRowsWithInlineErrors.size() > 0){
			for(WebElement inlineErrItemRow : itemRowsWithInlineErrors) {
				String errMsg = inlineErrItemRow.findElement(By.xpath("./td[5]/span[@class='icon curDef inlineError ']")).getAttribute("title");
				System.out.println("Error Message : "+ errMsg);
				Thread.sleep(2000);
				WebElement editBtn = inlineErrItemRow.findElement(By.xpath(".//td[last()]/a[@title='Edit']"));
				scroll_into_view_element(editBtn);
				editBtn.click();
				waitUntilInvisibilityOfElement(processingLoader,4);
				waitUntilVisibilityOfElement(By.id("itemSummary"));
				Thread.sleep(2000);
				switch(errMsg){
				case "Miscellaneous values not selected/entered for this item.":
					findElement(By.xpath("//form[@id='frmItemSummary']//li[@role='tab']/a[text()='"+getLanguageProperty("Miscellaneous")+"']")).click();


					WebElement objNewTaskUI = driver.findElement(By.xpath("//div[@aria-describedby='itemSummary']/div"));
					waitUntilInvisibilityOfElement(By.xpath("//div[@class='zydf-dispProcessing']"),4);
					action.dragAndDropBy(objNewTaskUI, 50, 60).build().perform();
					Thread.sleep(3000);

					//enterFlexiFields();
					objCommonFunc.flexiFormDetails(true);

					break;
				default :
					break;
				}
				scroll_into_view_element(driver.findElement(By.id("saveRequisitionItemSummary")));
				findElement(By.id("saveRequisitionItemSummary"),"OK button on Item Summary popup").click();
				waitUntilInvisibilityOfElement(By.id("itemSummary"),4);
			}
		}
	}

	private void correctBillToAddrInlineErrors() throws Exception{
		List<WebElement> billToAddrInlineErrors = driver.findElements(By.xpath("//div[@class='delBillSummary'][//tr/td[2]/div/div/div/span[@class='icon inlineError' and @title]]"));
		if (billToAddrInlineErrors.size() > 0){
			for(WebElement errRow : billToAddrInlineErrors) {
				String errMsg = errRow.findElement(By.xpath(".//span[@class='icon inlineError' and @title]")).getAttribute("title");
				System.out.println("Error Message : "+ errMsg);
				Thread.sleep(2000);
				WebElement editbtn = errRow.findElement(By.xpath(".//a[@id='changeDelBillingSumm']"));
				scroll_into_view_element(editbtn, "Edit button");
				editbtn.click();
				waitUntilInvisibilityOfElement(processingLoader,4);
				waitUntilVisibilityOfElement(By.id("changeRequisitionSummary"));
				switch(errMsg){
				case "Please enter a valid budget information":
					findElement(By.xpath("//div[@id='changeRequisitionSummary']//li[@role='tab']/a[text()='"+getLanguageProperty("Cost Allocation")+"']")).click();


					if(BudgetCreation.budgetLineName!=null) {
						LogScreenshot("info","Entering Newly Created Budget:"+BudgetCreation.budgetLineName);
						driver.findElement(By.id("budget_summary")).clear();
						waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
						driver.findElement(By.id("budget_summary")).sendKeys(BudgetCreation.budgetLineName);
						waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
						Thread.sleep(2000);
						try {
							findElement(By.xpath("//div[@aria-describedby='changeRequisitionSummary']//ul[contains(@style,'block')]/li[1]")).click();
						}catch (Exception e) {
							driver.findElement(By.id("budget_summary")).clear();
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							driver.findElement(By.id("budget_summary")).sendKeys(BudgetCreation.budgetLineName);
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							findElement(By.xpath("//div[@aria-describedby='changeRequisitionSummary']//ul[contains(@style,'block')]/li[1]")).click();
						}

						Thread.sleep(5000);
					}else {
						LogScreenshot("info","Entering Available Budget");
						driver.findElement(By.id("budget_summary")).click();
						waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
						List<String> value = new ArrayList<String>();
						List<WebElement> budgetList = driver.findElements(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]//a"));		

						for(WebElement budget : budgetList) {
							value.add(budget.getText().split(":")[0]);						
						}

						for(String budgetValue : value) {
							driver.findElement(By.id("budget_summary")).clear();
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							driver.findElement(By.id("budget_summary")).sendKeys(budgetValue);
							waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"),4);
							Thread.sleep(2000);
							findElement(By.xpath("//div[@aria-describedby='changeRequisitionSummary']//ul[contains(@style,'block')]/li[1]")).click();
							Thread.sleep(5000);

							if(driver.findElements(By.xpath("//span[contains(@class,'budgetLineHelp') and contains(@class,'hasQtip') and contains(@style,'block')]")).size() == 0) {
								break;
							}

						}
					}

					break;
				default :
					break;
				}
				scroll_into_view_element(driver.findElement(By.id("saveRequisitionSummary")));
				findElement(By.id("saveRequisitionSummary"),"OK button on Item Summary popup").click();
				waitUntilInvisibilityOfElement(By.id("changeRequisitionSummary"),4);
			}
		}
	}

	public String saveRequisitionAsDraft(String purchaseType) throws Exception{
		String requisitionNo;
		enterRequisitionInfo(purchaseType);
		findElement(By.id("draftRequisition"),"Save as Draft button").click();
		waitUntilInvisibilityOfElement(By.xpath("status_overlay_updateRequisition"),4);
		waitUntilVisibilityOfElement(MyRequisitions.getHeaderSuccessBox());
		MyRequisitions objReq = new MyRequisitions(driver, logger);
		requisitionNo = objReq.getDraftedRequisitionNumber();
		LogScreenshot("Pass", "Requisition "+ requisitionNo + " saved as Draft");
		return requisitionNo;
	}

	/**
	 * <b>Function:</b> enterRequisitionInfo -
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param action
	 * @return result - True/False
	 * @throws Exception 
	 * @throws Exception 
	 */

	public String enterRequisitionInfo(String purchaseType) throws Exception{
		String requisitionName = "AutoRequisition_"+generateNo();
		String commentsForSupplier = "Comments for Supplier";
		findElement(By.xpath("//input[@id='deliveryOn_header_summary']/following-sibling::img")).click();
		//selectDate_v1(LocalDate.now().toString());
		String dt = DateTimeFormatter.ofPattern("dd/MM/YYYY").format(LocalDate.now());
		//Date dt = format.parse(LocalDate.now().toString());
		//selectDate_v1(LocalDate.now().toString());
		//selectDate(dt);
		selectDate_v1(dt);
		try {
			WebElement objRequisitionName = driver.findElement(By.id("txtRequisitionName"));
			objRequisitionName.clear();
			objRequisitionName.sendKeys(requisitionName);
			if (isUrgentReq)
				findElement(By.id("radUrgentYes")).click();
			driver.findElement(By.id("txtBuyingJustification")).sendKeys(reasonForOrdering);
			driver.findElement(By.id("txtSupplierComment")).sendKeys(commentsForSupplier);
			//enterText_AutoComplete(By.id("txtBehalfUser"), onBehalfOf);

			Select select = new Select(driver.findElement(By.xpath("//select[@id='selPurchaseType']")));
			WebElement option = select.getFirstSelectedOption();
			String defaultItem = option.getText();
			if (!(defaultItem.contains("Select")))
				LogScreenshot("Info","Already selected Purchase Type "+ defaultItem );
			else{
				if (purchaseType != ""){
					findElement(By.xpath("//select[@id='selPurchaseType']/option[@title='"+purchaseType+"']")).click();
					String selectedOption = select.getFirstSelectedOption().getText();
					LogScreenshot("Info","Selected Purchase Type "+ selectedOption );
				}else {
					findElement(By.xpath("//select[@id='selPurchaseType']/option[2]")).click();
				}

			}
			if (driver.findElements(By.id("selectBuyer")).size() > 0){
				WebElement objSelectBuyer = driver.findElement(By.id("selectBuyer"));
				scroll_into_view_element(objSelectBuyer, "Select Buyer link");
				Thread.sleep(2000);
				objSelectBuyer.click();
				waitUntilInvisibilityOfElement(processingLoader,4);
				waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='diagApplyToMultiple']"));
				if (isAssignedBuyerGroup)
					selectBuyerGroup(assignedBuyerOrGrp);
				else
					selectBuyer(assignedBuyerOrGrp);
				findElement(By.id("btnApplyToMultiple"),"Apply button").click();
			}
			if (!(driver.findElements(By.xpath("//select[@id='selPaymentMethod' and contains(@style,'none')]")).size() > 0)){
				findElement(By.xpath("//select[@id='selPaymentMethod']/option[text()='"+settlementVia+"']")).click();
				if (settlementVia.equals("User P-card"))
					findElement(By.xpath("//select[@id='selPCard']/option[@title='"+settlementVia+"']")).click();
			}
			eInvoice_CommonFunctions objFunc = new eInvoice_CommonFunctions(driver, logger);
			objFunc.flexiFormDetails(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requisitionName;
	}


	private void selectBuyer(String assignedBuyer) throws Exception{
		try {
			WebElement updateAllLinesForm = driver.findElement(By.id("frmApplyToMultiple"));
			if (updateAllLinesForm.isDisplayed()){
				updateAllLinesForm.findElement(By.xpath("//li/a[text()='"+getLanguageProperty("Buyer")+"']")).click();
				enterText_AutoComplete(By.id("multiAssignedBuyer"), assignedBuyer);
				//findElement(By.id("btnApplyToMultiple"),"Apply button").click();
			}
		} catch (Exception e) {
			LogScreenshot("Info", "Unable to select buyer : "+assignedBuyer);
			findElement(By.id("closeApplyToMultiple"),"Close button").click();
		}
	}

	private void selectBuyerGroup(String assignedGroup) throws Exception{
		try {
			WebElement updateAllLinesForm = driver.findElement(By.id("frmApplyToMultiple"));
			if (updateAllLinesForm.isDisplayed()){
				updateAllLinesForm.findElement(By.xpath("//li/a[text()='"+getLanguageProperty("Buyer")+"']")).click();
				findElement(By.xpath("//div[@id='multiAssignedBuyerDropdown']/a")).click();
				findElement(By.xpath("//a[@value='ASSIGNED_BUYER_GROUP']")).click();
				enterText_AutoComplete(By.id("multiAssignedBuyer"), assignedGroup);
				//findElement(By.id("btnApplyToMultiple"),"Apply button").click();
			}
		} catch (Exception e) {
			LogScreenshot("Info", "Unable to select buyer group: "+assignedGroup);
			findElement(By.id("closeApplyToMultiple"),"Close button").click();
		}
	}

	public void deleteItem(){
		findElement(By.xpath("//tbody[@class='requisitionItems']/tr[2]/td[last()]//a[@title='"+getLanguageProperty("Delete item")+"']")).click();
		if (driver.findElements(By.xpath("//div[contains(@class,'promptbx')][div/span[text()='"+getLanguageProperty("Confirm")+"']]")).size() > 0){
			clickAndWaitUntilLoaderDisappears(By.xpath("//div[contains(@class,'promptbx')][div/span[text()='"+getLanguageProperty("Confirm")+"']]//button[span[text()='"+getLanguageProperty("Yes")+"']]"));
		}
	}

	public void linktoPOs(String PONum) throws Exception{
		findElement(By.id("linkPOLnk")).click();
		waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='dev_POGridDialog']"));
		WebElement purchaseOrderList = driver.findElement(By.id("poListing_wrapper"));
		if (purchaseOrderList.isDisplayed()){
			if (searchByPONumber(PONum)){
				purchaseOrderList.findElement(By.xpath("//table[@id='poListing']/tbody//input[1]")).click();
				findElement(By.id("selectPOBtn")).click();
			}
		}
	}

	public void deliverItemsToMultiple() throws Exception{
		//Expand Item
		findElement(By.xpath("//tbody[@class='requisitionItems']/tr[2]/td[3]/div/span[1]")).click();
		findElement(By.xpath("//tr[contains(@style,'table-row')]//td[contains(@class,'itemsdeliverysplit deliveries')]//a[text()='"+getLanguageProperty("Edit")+"']")).click();
		waitUntilVisibilityOfElement(By.id("itemSummary"));
		findElement(By.id("optMultiSplit")).click();
		findElement(By.id("saveRequisitionItemSummary")).click();
		waitUntilInvisibilityOfElement(By.id("itemSummary"),4);
	}

	public void createAuditTrailDisussion(String discussionWith, String msg) throws Exception{
		findElement(By.id("addNewDiscussion")).click();
		waitUntilVisibilityOfElement(By.xpath("//div[contains(@class,'discussionForm')][div/span[text()='"+getLanguageProperty("Start new discussion")+"']]"));
		NewAuditTrailDiscussion objDiscussion = new NewAuditTrailDiscussion(driver, logger, discussionWith, msg);
		objDiscussion.createNewDiscussion();
		//Validate if discussion created
	}

	public void createQuickSourceEvent() throws Exception{
		Actions action = new Actions(driver);
		WebElement actionsBtn = driver.findElement(By.xpath("//div[@id='requisitionItemGroups']//div[contains(@class,'groupActionsMenu')]"));
		action.moveToElement(actionsBtn).build().perform();
		WebElement stdPOLink = driver.findElement(By.xpath("//div[@class='droppnlpad groupActions']/a[span[text()='"+getLanguageProperty("Create Quick Source Event")+"']]"));
		action.moveToElement(stdPOLink).click().build().perform();
		waitUntilVisibilityOfElement(By.id("dev_createQuickSourceDialog"));
	}

	public boolean searchByPONumber(String PONumber){
		return filterByText("PO Number", PONumber);
	}

	public By getPgHead() {
		return pgHead;
	}

	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

}
