package com.zycus.eProc.Catalog;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> NewCatalog.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.enterCatalogDetails: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class NewCatalog_old extends eProc_CommonFunctions {

  private static By newCatalogLbl = By.xpath("//h1[@class='pgHead' and text()='Catalog Details']");
  
  private String catalogName;
  private String supplier;
  private String serviceNum;
  private String shortDesc;
  private String prodCategory;
  private String price;
  
  eInvoice_CommonFunctions objFunctions = new eInvoice_CommonFunctions(driver, logger);

  private String Datasheet_SupplierContacts;
  private List<String> listOfSupplierContact = new ArrayList<String>();
  private List<String> listOfSupplierCompany = new ArrayList<String>();
  

  /**
   * Constructor for the class
   * 
   * @param driver
   * @throws Exception 
   */

  public NewCatalog_old(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    this.catalogName = "AutoCatalog_"+generateNo();
    ConfigurationProperties objConfig = ConfigurationProperties.getInstance();
    Datasheet_SupplierContacts = objConfig.getProperty("Datasheet_SupplierContacts");
    String environment = objConfig.getProperty("Environment");
    String[][] abc2 = (String[][]) objFunctions.dataProvider(environment, Datasheet_SupplierContacts);
    for(int i=0;i<abc2.length;i++) {
      listOfSupplierCompany.add(abc2[i][0]);
      listOfSupplierContact.add(abc2[i][1]);
    }

    //this.supplier = objConfig.getProperty("supplier");
  }

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  /*public NewCatalog(WebDriver driver, ExtentTest logger, String catalogName, String supplier) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
    this.catalogName = catalogName;
    this.supplier = supplier;
  }*/

  /**
   * <b>Function:</b> enterCatalogDetails
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param None
   * @return None
   */
  
  public String enterCatalogDetails(String contractNo, boolean addItemFromFile) throws Exception{
  //public void enterCatalogDetails(String serviceNum, String shortDesc, String prodCategory, String price) {
    ConfigurationProperties config = ConfigurationProperties.getInstance();
    //String filePath = System.getProperty("user.dir") + config.getProperty("eProc_CatalogItemsfile_path");
    
    String nameOfCatalog = null;
    driver.findElement(By.id("txtCatalogName")).sendKeys(catalogName);
    objFunctions.enterText_AutoComplete(By.id("txtSupplierName"), listOfSupplierCompany.get(0));
    LogScreenshot("Pass", "Supplier selected");
    // Select Address
    WebElement addrSelectorDropDown = driver.findElement(By.name("btnMyAddress"));
    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addrSelectorDropDown);
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-200);");
        Thread.sleep(3000);
    //findElement(By.name("btnMyAddress")).click();
        driver.findElement(By.name("btnMyAddress")).click();
    findElement(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]/li[1]")).click();
    
    if (contractNo != ""){
      enterText_AutoComplete_eProc(By.id("dev_contractNo"), contractNo);
      //findElement(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']")).click();
      waitUntilVisibilityOfElement(By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Catalog Details']"));
      //clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Catalog Details']"));
      waitUntilVisibilityOfElement(By.id("previewSection"));
      // Select Address
      WebElement addrSelectorDropDown1 = driver.findElement(By.name("btnMyAddress"));
      /*((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addrSelectorDropDown1);
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-200);");*/
            scroll_into_view_element(addrSelectorDropDown1,"Address dropdown arrow");
      Thread.sleep(3000);
      //findElement(By.name("btnMyAddress")).click();
      addrSelectorDropDown1.click();
      findElement(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]/li[1]")).click();
      clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Item Details']"));
      ItemDetails objDetails = new ItemDetails(driver, logger);
      waitUntilVisibilityOfElement(
          By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Item Details']"));
      Thread.sleep(3000);
      waitUntilInvisibilityOfElement(processingLoader);
      LogScreenshot("Pass","Moved to item Details section");
      Thread.sleep(3000);
      if (driver.findElements(By.xpath("//table[@id='itemListGrid']/tbody/tr/td[text()='No results found']")).size() > 0){
        findElement(By.id("addItemTabLink")).click();
        Thread.sleep(4000);
        objDetails.enterItemDetails();
      } else {
        if (driver.findElements(By.id("errorBox")).size() > 0){
          List<WebElement> listOfErrors = driver.findElements(By.xpath("//div[@id='errorBox']//li"));
          for(WebElement errorRow : listOfErrors){
            switch(errorRow.getAttribute("id")){
            case "CATEGORY_CODE-MISSING_VALUE":
              errorRow.findElement(By.xpath("./span")).click();
              waitUntilInvisibilityOfElement(processingLoader);
              WebElement actionBtn = driver.findElement(By.xpath("//table[@id='itemListGrid']/tbody/tr[1]//td[last()]//a[text()='Actions']"));
              actionBtn.click();
              actionBtn.findElement(By.xpath("./following-sibling::ul/li/a[text()='Edit']")).click();
              Thread.sleep(3000);
              String linkedErrFieldName = "Product Category";
              By linkedFieldLocator = By.id("txtCatName");
              objDetails.editItemDetails(linkedErrFieldName, linkedFieldLocator);
              break;
            }
          }
        }
      }
      waitUntilInvisibilityOfElement(By.id("itemListGrid_processing"));
      findElement(By.xpath("//table[@id='itemListGrid']/thead/tr/th/input")).click();
    } else {
      clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Item Details']"));
      ItemDetails objDetails = new ItemDetails(driver, logger);
      waitUntilVisibilityOfElement(
          By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Item Details']"));
      if (addItemFromFile){
        String filePath = config.getProperty("eProc_CatalogItemsfile_path");
        findElement(By.id("uploaditemsviafile")).click();
        waitUntilVisibilityOfElement(By.id("uploadcatalogfilepop"));
        driver.findElement(By.id("attachmentInput_catalogUpload")).sendKeys(filePath);
        Thread.sleep(4000);
        findElement(By.id("btnUploadCatalog")).click();
        waitUntilVisibilityOfElement(By.id("columnmapping"));
        findElement(By.id("btnMapColumns")).click();
        Thread.sleep(2000);
        waitUntilInvisibilityOfElement(By.xpath("//div[@id='showProcess']"));
        if (driver.findElements(By.id("errorBox")).size() > 0){
          List<WebElement> listOfErrors = driver.findElements(By.xpath("//div[@id='errorBox']//li"));
          for(WebElement errorRow : listOfErrors){
            switch(errorRow.getAttribute("id")){
            case "CATEGORY_CODE-INVALID_VALUE":
              errorRow.findElement(By.xpath("./span")).click();
              waitUntilInvisibilityOfElement(processingLoader);
              Thread.sleep(2000);
              WebElement actionBtn = driver.findElement(By.xpath("//table[@id='itemListGrid']/tbody/tr[1]//td[last()]//a[text()='Actions']"));
              scroll_into_view_element(actionBtn);
              actionBtn.click();
              actionBtn.findElement(By.xpath("./following-sibling::ul/li/a[text()='Edit']")).click();
              Thread.sleep(3000);
              String linkedErrFieldName = "Product Category";
              By linkedFieldLocator = By.id("txtCatName");
              objDetails.editItemDetails(linkedErrFieldName, linkedFieldLocator);
              break;
            }
          }
        }
        waitUntilInvisibilityOfElement(By.id("itemListGrid_processing"));
        //findElement(By.xpath("//table[@id='itemListGrid']/thead/tr/th/input")).click();
      } else {
        findElement(By.id("addOnlineItem")).click();
        waitUntilVisibilityOfElement(By.id("addItemDialog"));
        objDetails.enterItemDetails();
      }
    }
    
    findElement(By.xpath("//a[@id='lnkScopeValidity']"),"Next button").click();
    waitUntilVisibilityOfElement(
        By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='Scope & Validity']"));

    // Select organization Unit
    findElement(By.id("linkScopeSelected"),"Select Organization Units").click();
    selectOrgUnit();
    findElement(By.id("lnkSubmit")).click();
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process' and text()='Catalog is ready for processing']"));
    Thread.sleep(2000);
    if (driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='Submit for approval']]")).isDisplayed()){
      findElement(By.id("approvalSubmitBtn")).click();
      waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='Submiting Catalog for approval']"));
      //waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='Submiting Catalog for approval']"));
      nameOfCatalog = catalogName;
    }  
    return nameOfCatalog;
  }

  public void selectOrgUnit() throws Exception{
    //Select All Companies
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"));
    Thread.sleep(3000);
    waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing']"));
    findElement(By.xpath("//div[@id='diagBoxScopeDefConfig']//table[contains(@id,'ListTable')]/thead/tr[1]/th[1]//input")).click();
    findElement(By.xpath("//ul[@role='tablist']//a[text()='Business Units']")).click();
    waitUntilInvisibilityOfElement(processingLoader);
    //Select All Business Units
    findElement(By.xpath("//a[text()='Select All Business Units']")).click();
    Thread.sleep(1500);
    /*findElement(By.xpath("//table[contains(@id,'ListGrid')]/tbody//a[text()='Select Organization Unit']")).click();*/
    findElement(By.xpath("//ul[@role='tablist']//a[text()='Locations']")).click();
    waitUntilInvisibilityOfElement(processingLoader);
    //Select All Locations
    findElement(By.xpath("//a[text()='Select All Locations']")).click();
    Thread.sleep(1500);
    findElement(By.id("saveSelectedScope")).click();
  }

  /**
   * @return the newCatalogLbl
   */
  public static By getNewCatalogLbl() {
    return newCatalogLbl;
  }

  /**
   * @param newCatalogLbl
   *            the newCatalogLbl to set
   */
  public void setNewCatalogLbl(By newCatalogLbl) {
    this.newCatalogLbl = newCatalogLbl;
  }
}
