package com.zycus.eProc.eForms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> AllForms.java
 * <br>
 * <b> Description: </b> To perform select New eForm 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewForm: user shall be able to filter by Status 
 * <br>
 * 2.addSection: user shall be able to filter by Received On 
 * <br>
 * 3.addfield 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class AllForms extends eInvoice_CommonFunctions {

	private static By pgHead = By.xpath("//h1[@class='pgHead'][contains(text(),'All Forms')]");
	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public AllForms(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> selectNewFormCreationProcess
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param formCreationProcess
	 * @return result - True/False
	 * @throws Exception
	 */

	/*public boolean selectNewFormCreationProcess(String formCreationProcess, String formName, String formType,
      String formRelatedProcess, String businessUnit, String sectionName, String fieldToDisplayInSection, String fieldName, String formDescription, String sectionDescription, String sectionLayout, String defaultValue, String maxChar, String hideField, String enterSpace, String enterSplChar,
      String mandatory) throws Exception {
    boolean result = false;
    Actions builder = new Actions(driver);
    try {
      WebElement hoverElem = findElement(By.xpath("//a[span[text()='New eForm']]"));
      builder.moveToElement(hoverElem).build().perform();
      findElement(By.xpath("//a[span[text()='"+formCreationProcess+"']]")).click();
      FormWizard objWizard = new FormWizard(driver, logger, formName, formType, formRelatedProcess,
          businessUnit, sectionName, fieldToDisplayInSection, fieldName, "Auto_display_Name"); 
      if (objWizard.getPgHead() != null){
        objWizard.createNewForm(formDescription, sectionDescription, sectionLayout, defaultValue, Integer.parseInt(maxChar), Boolean.parseBoolean(hideField), Boolean.parseBoolean(enterSpace), Boolean.parseBoolean(enterSplChar), Boolean.parseBoolean(mandatory));
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }*/

	public String selectNewFormCreationProcess(String formCreationProcess, String formType) throws Exception {
		String newFormName = null;
		String formName = "Form_"+generateNo();
		Actions builder = new Actions(driver);
		try {
			WebElement hoverElem = findElement(By.xpath("//a[span[text()='"+getLanguageProperty("New eForm")+"']]"));
			builder.moveToElement(hoverElem).build().perform();
			findElement(By.xpath("//a[span[text()='"+ formCreationProcess +"']]")).click();
			if (formCreationProcess.toLowerCase().equals(getLanguageProperty("online editor"))){
				FormWizard objWizard = new FormWizard(driver, logger); 
				if (objWizard.getPgHead() != null){
					objWizard.createNewForm(formName,formType);
					Thread.sleep(3000);
					//Publish Form
					if (formType.equals(getLanguageProperty("Header level form")))
						findElement(By.id("publishEform")).click();
					//waitUntilVisibilityOfElement(By.id("hedaerSuccessBox"));
					LogScreenshot("Pass","Process form "+formName+" created");
					//newFormName = formName;
				}else
					LogScreenshot("Fail","'Form Wizard' page not opened");
			} else {
				if (formCreationProcess.toLowerCase().equals(getLanguageProperty("file upload"))){
					Import_Eforms_via_File objImport = new Import_Eforms_via_File(driver, logger);
					if (objImport.getPgHead() != null){
						objImport.createFileUpload();
						//newFormName = formName;
					}else
						LogScreenshot("Fail","'Import eForms via File' page not opened");
				}
			}

			//Verify form created
			waitUntilVisibilityOfElement(By.xpath("//table[@id='processFormGrid']//tr[2]"));
			if (driver.findElements(By.xpath("//table[@id='processFormGrid']/tbody/tr/td/div/a[text()='"+formName+"']")).size() > 0)
				newFormName = formName;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newFormName;
	}

	public String saveFormAsDraft(String formCreationProcess, String formCategory) throws Exception {
		String newFormName = null;
		String formName = "Form_"+generateNo();
		Actions builder = new Actions(driver);
		try {
			WebElement hoverElem = findElement(By.xpath("//a[span[text()='"+getLanguageProperty("New eForm")+"']]"));
			builder.moveToElement(hoverElem).build().perform();
			findElement(By.xpath("//a[span[text()='"+ formCreationProcess +"']]")).click();
			if (formCreationProcess.toLowerCase().equals("online editor")){
				FormWizard objWizard = new FormWizard(driver, logger); 
				if (objWizard.getPgHead() != null){
					if (formCategory.equals("Process Form"))
						objWizard.enterHdrLvlProcessFormDetails(formName);
					else if (formCategory.equals("Category Form"))
						objWizard.enterCategoryFormDetails(formName);
					Thread.sleep(3000);
					//Save eForm as Draft
					findElement(By.id("saveEform")).click();
				}else
					LogScreenshot("Fail","'Form Wizard' page not opened");
			} else {
				if (formCreationProcess.toLowerCase().equals("file upload")){
					Import_Eforms_via_File objImport = new Import_Eforms_via_File(driver, logger);
					if (objImport.getPgHead() != null){
						objImport.createFileUpload();
						//newFormName = formName;
					}else
						LogScreenshot("Fail","'Import eForms via File' page not opened");
				}
			}

			waitUntilVisibilityOfElement(By.id("categoryFormGrid"));
			Thread.sleep(6000);
			waitUntilInvisibilityOfElement(processingLoader,4);
			//Verify form created
			if (driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div/a[text()='"+formName+"']")).size() > 0){
				LogScreenshot("Pass", "Form "+formName + " saved as Draft");
				newFormName = formName;
			}else
				LogScreenshot("Fail", "Unable to save form as Draft");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newFormName;
	}

	/*public String saveCategoryFormAsDraft(String formCreationProcess) throws Exception {
    String newFormName = null;
    String formName = "Form_"+generateNo();
    Actions builder = new Actions(driver);
    try {
      WebElement hoverElem = findElement(By.xpath("//a[span[text()='New eForm']]"));
      builder.moveToElement(hoverElem).build().perform();
      findElement(By.xpath("//a[span[text()='"+ formCreationProcess +"']]")).click();
      if (formCreationProcess.toLowerCase().equals("online editor")){
        FormWizard objWizard = new FormWizard(driver, logger); 
        if (objWizard.getPgHead() != null){
          objWizard.enterHdrLvlProcessFormDetails(formName);
          Thread.sleep(3000);
          //Save eForm as Draft
          findElement(By.id("saveEform")).click();
        }else
          LogScreenshot("Fail","'Form Wizard' page not opened");
      } else {
        if (formCreationProcess.toLowerCase().equals("file upload")){
          Import_Eforms_via_File objImport = new Import_Eforms_via_File(driver, logger);
          if (objImport.getPgHead() != null){
            objImport.createFileUpload();
            //newFormName = formName;
          }else
            LogScreenshot("Fail","'Import eForms via File' page not opened");
        }
      }

      //Verify form created
      if (driver.findElements(By.xpath("//table[@id='processFormGrid']/tbody/tr/td/div/a[text()='"+formName+"']")).size() > 0)
        newFormName = formName;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return newFormName;
  }*/

	public String selectNewFormCreationProcess(String formCreationProcess) throws Exception {
		String newFormName = null;
		String formName = "Form_"+generateNo();
		Actions builder = new Actions(driver);
		WebElement hoverElem = findElement(By.xpath("//a[span[text()='"+getLanguageProperty("New eForm")+"']]"));
		builder.moveToElement(hoverElem).build().perform();
		LogScreenshot("Pass", "selecting "+formCreationProcess);
		findElement(By.xpath("//a[span[text()='"+ formCreationProcess +"']]"),formCreationProcess+" link").click();
		LogScreenshot("Pass", formCreationProcess + "link clicked");
		if (formCreationProcess.toLowerCase().equals("online editor")){
			FormWizard objWizard = new FormWizard(driver, logger); 
			waitUntilVisibilityOfElement(objWizard.getPgHead());
			if (objWizard.getPgHead() != null){
				objWizard.createNewForm(formName);
				LogScreenshot("Pass","Form Details entered");
				//Publish Form
				findElement(By.id("publishEform")).click();
				waitUntilVisibilityOfElement(By.id("hedaerSuccessBox"));
				LogScreenshot("Pass","Form : "+formName+" published");
				//newFormName = formName;
			}else
				LogScreenshot("Fail", "'Form Wizard' page not opened");
		} else {
			if (formCreationProcess.toLowerCase().equals("file upload")){
				Import_Eforms_via_File objImport = new Import_Eforms_via_File(driver, logger);
				if (objImport.getPgHead() != null){
					objImport.createFileUpload();
					//newFormName = formName;
				}else
					LogScreenshot("Fail","'Import eForms via File' page not opened");
			}
		}

		//Verify form created
		waitUntilVisibilityOfElement(By.id("categoryFormGrid"));
		Thread.sleep(6000);
		waitUntilInvisibilityOfElement(processingLoader,4);
		if (driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div/a[text()='"+formName+"']")).size() > 0){
			newFormName = formName;
		}
		return newFormName;
	}

	public boolean exportForm(String formCategory, String formName) throws Exception{
		boolean result= true;
		String fileExtension = null;
		String filePath = "C:/Users/"+System.getProperty("user.name")+"/Downloads";
		String filePartName = formName.replace(" ", "_");
		if (formCategory.equals("Process Form"))
			fileExtension = "pform";
		else if (formCategory.equals("Category Form"))
			fileExtension = "cform";
		try {
			Thread.sleep(6000);
			performAction(formName, "Export");
			if (checkFileExists(filePath, filePartName, fileExtension)){
				LogScreenshot("pass","File : "+filePartName+"."+fileExtension+" exported");
				result = true;
			}else
				LogScreenshot("fail","File : "+filePartName+"."+fileExtension+" not exported");
			//deleteFiles(filePath, filePartName, fileExtension);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void deleteForm(String formName) throws Exception{
		performAction(formName, "Delete");
		if (!(driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]")).size() > 0))
			LogScreenshot("Pass","Form : "+formName+" in draft status is deleted");
		else
			LogScreenshot("Fail","Form : "+formName+" in draft status could not be deleted");
	}

	public void copyCategoryForm(String formName) throws Exception{
		performAction(formName, "Copy");
		FormWizard objWizard = new FormWizard(driver, logger);
		objWizard.updateCategoryFormDisplayName();
		findElementsWithWait(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div/a[text()='Copy of "+formName+"']"),"Form : "+formName+" copied and published", "Form : "+formName+" could not be copied or published");
		/*if (driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div/a[text()='Copy of "+formName+"']")).size() > 0)
      LogScreenshot("Pass","Form : "+formName+" copied and published");
    else
      LogScreenshot("Fail","Form : "+formName+" could not be copied or published");*/
	}

	public void copyProcessForm(String formName) throws Exception{
		performAction(formName, "Copy");
		FormWizard objWizard = new FormWizard(driver, logger);
		objWizard.updateProcessForm();
		findElementsWithWait(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div[@class='itmName']/a[text()='Copy of "+formName+"']"),"Form : "+formName+" copied and published", "Form : "+formName+" could not be copied or published");
		/*if (driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div[@class='itmName']/a[text()='Copy of "+formName+"']")).size() > 0)
      LogScreenshot("Pass","Form : "+formName+" copied and published");
    else
      LogScreenshot("Fail","Form : "+formName+" could not be copied or published");*/
	}

	public void deactivateForm(String formName) throws Exception{
		performAction(formName, "Deactivate");
		//Thread.sleep(2000);
		findElementsWithWait(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]/div[2]/div[1][text()[contains(.,'Inactive')]]"), "Form : "+formName+" deactivated", "Form : "+formName+" could not be deactivated");
		/*if (driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]/div[2]/div[1][text()[contains(.,'Inactive')]]")).size() > 0)
      LogScreenshot("Pass","Form : "+formName+" deactivated");
    else
      LogScreenshot("Fail","Form : "+formName+" could not be deactivated");*/
	}

	public void activateForm(String formName) throws Exception{
		performAction(formName, "Activate");
		//Thread.sleep(2000);
		findElementsWithWait(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]/div[2]/div[1][text()[contains(.,'Active')]]"), "Form : "+formName+" activated", "Form : "+formName+" could not be activated");
		/*if (driver.findElements(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]/div[2]/div[1][text()[contains(.,'Active')]]")).size() > 0)
      LogScreenshot("Pass","Form : "+formName+" activated");
    else
      LogScreenshot("Fail","Form : "+formName+" could not be activated");*/
	}

	private void performAction(String formName, String action) throws Exception{
		Actions objAction = new Actions(driver);
		WebElement objFormName = driver.findElement(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td/div[1]/a[text()='"+formName+"']"));
		objAction.moveToElement(objFormName).build().perform();
		Thread.sleep(2000);
		WebElement deleteBtn = driver.findElement(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]/div[3]/a[text()='"+action+"']"));
		objAction.moveToElement(deleteBtn).click().build().perform();
		/*WebElement relatedActionBtn = driver.findElement(By.xpath("//table[contains(@id,'FormGrid')]/tbody/tr/td[div[1]/a[text()='"+formName+"']]/div[3]/a[text()='"+action+"']"));
    JavascriptExecutor js = (JavascriptExecutor)driver;
    js.executeScript("arguments[0].click()", relatedActionBtn);
		 */
		if (action.equals("Deactivate")|action.equals("Activate")|action.equals("Delete"))
			findElement(By.xpath("//div[@role='dialog']//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
		waitUntilInvisibilityOfElement(processingLoader,4);
		LogScreenshot("Info",action + " Action performed on Form : "+formName);
		waitUntilInvisibilityOfElement(By.xpath("//div[@id='categoryFormGrid_processing' and contains(@style,'')]"));
		Thread.sleep(4000);
	}


	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	public void deleteAllForm() throws Exception {


		By lineLevelForm = By.xpath("//a[@title='Line level form']");
		clickElement(lineLevelForm);
		Thread.sleep(5000);

		while(true) {
			try {
				String formName = driver.findElement(By.xpath("(//div[@class='itmName']/a)[3]")).getText();
				try {
					performAction(formName,"Deactivate");
					performAction(formName,"Delete");
				}catch (Exception e) {
					performAction(formName,"Delete");
				}
			}catch (Exception e) {
				// TODO: handle exception
			}

		}


	}

}
