package com.zycus.eProc.Approval;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

/**
 * <b> Title: </b> Approval.java
 * <br>
 * <b> Description: </b> Approval - Approval related class
 * <br>
 * <b> Functions: </b> None
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class Approval extends ApprovalDetails{

  /**
   * Constructor for the class
   * @param driver
   */
  
  public Approval(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

}
