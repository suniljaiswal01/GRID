package com.zycus.eProc.BuyersDesk;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class QuickSourceEvent extends eProc_CommonFunctions{

	String itemname = "AutoPen" + generateNo();
	String quickSourceName = "AutoEvent" + generateNo();
	String currhour = getcurrhour();
	String domain;

	public QuickSourceEvent(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		/*CommonFunctions1 objFunctions = new CommonFunctions1();
	        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();*/
		/*tring Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
	        String[][] abc = (String[][]) objFunctions.dataProvider("QuickSourceEvent", Datasheet_eProc);
		 */
	}


	public String createInquiry(String supplierEmail, String supplierCompanyName, String supplierContactName) throws Exception {

		waitUntilVisibilityOfElement(By.xpath("//a[@id='addQuickSourceEvent']"));
		driver.findElement(By.xpath("//a[@id='addQuickSourceEvent']")).click();
		Thread.sleep(3000);
		waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='dev_createQuickSourceDialog']"));

		createEnquiry(supplierEmail,supplierCompanyName,supplierContactName);

		WebElement createButton = driver.findElement(By.xpath("//a[@id='createQuickSource']"));
		//scroll_into_view_element(createButton);
		createButton.click();

		waitUntilInvisibilityOfElement(By.id("status_overlay_processingEvent"));
		waitUntilInvisibilityOfElement(By.xpath("//div[contains(@id,'tblEventList_processing')]"));

		waitUntilVisibilityOfElement(By.xpath("//div[@id='tblEventList_wrapper']"));

		driver.findElement(By.xpath("//input[@id='txtFltrName']")).sendKeys(quickSourceName + Keys.ENTER);

		waitUntilVisibilityOfElement(By.xpath("//div[@id='tblEventList_wrapper']"));

		if(driver.findElements(By.xpath("//a[contains(text(),'"+quickSourceName+"')]")).size()>0)
			LogScreenshot("Pass", "QuickSource event : " + quickSourceName + " Created");
		else 
			LogScreenshot("Fail", "QuickSource event not present in list "+quickSourceName);


		return quickSourceName;

	}


	private void createEnquiry(String supplierEmail, String supplierCompanyName, String supplierContactName) throws Exception {

		driver.findElement(By.xpath("//input[@id='txtEventName']")).sendKeys(quickSourceName);
		enterClosingDate();
		enterItemDetails();
		enterSupplierQuestion();
		enterSupplierOpeningMsg();
		inviteSuppliersToBid(supplierEmail,supplierCompanyName,supplierContactName);

	}


	private void inviteSuppliersToBid(String supplierEmail, String supplierCompanyName, String supplierContactName) throws Exception {

		WebElement supplierToBid = driver.findElement(By.xpath("//div[@class='splitAdd']//input[contains(@name,'company')]"));
		By supplierContactNameElement = By.xpath("//div[@class='splitAdd']//input[contains(@name,'suppContact')]");
		WebElement supplierEmailElement = driver.findElement(By.xpath("//div[@class='splitAdd']//input[contains(@name,'suppEmailId')]"));

		scroll_into_view_element(supplierToBid);
		enterText_AutoComplete(supplierToBid, supplierCompanyName);

		String enteredSupplierCompanyName = supplierToBid.getAttribute("value");


		Thread.sleep(1000);
		if (enteredSupplierCompanyName.equalsIgnoreCase(supplierCompanyName)) {
			LogScreenshot("Pass", "Supplier: " + supplierCompanyName + " selected");
			enterText_AutoComplete_eProc(supplierContactNameElement, supplierContactName);

			if(driver.findElement(supplierContactNameElement).getAttribute("value").equalsIgnoreCase(supplierContactName)) {
				String supplierEmailValue= supplierEmailElement.getAttribute("value");
				LogScreenshot("Pass", "Supplier email : " + supplierEmailValue + " selected");
			}
			else {
				LogScreenshot("Fail", "Supplier not added");
			}
		} 
		else {
			LogScreenshot("Fail", "Supplier not invited");
		}
	}

	private void enterClosingDate() throws Exception {

		WebElement closingDate = driver.findElement(By.xpath("//input[contains(@id,'closeDate')]"));
		scroll_into_view_element(closingDate);
		closingDate.click();
		String date= selectNextDate();
		selectDate_v1(date);
		
		if(driver.findElements(By.xpath("//select[@id='meridiem' and contains(@style,'block')]")).size()>0)
			selectMeridian(domain);
		else
			selectMeridian();



	}


	private void selectMeridian() throws Exception {


		driver.findElement(By.xpath("//input[@id='txtHours']")).sendKeys("12");
		driver.findElement(By.xpath("//input[@id='txtMin']")).sendKeys("30");

		LogScreenshot("info", "Time selected with 24 Hrs TIME FORMAT");

	}


	private void selectMeridian(String domain) throws Exception {
		Select meridian = new Select(driver.findElement(By.xpath("//select[@id='meridiem']")));

		if (Integer.parseInt(currhour) > 12) {
			domain = "PM";
			int newcurrhour = Integer.parseInt(currhour) - 12;
			currhour = newcurrhour + "";

			driver.findElement(By.xpath("//input[@id='txtHours']")).sendKeys(currhour);
			driver.findElement(By.xpath("//input[@id='txtMin']")).sendKeys("30");

			meridian.selectByValue(domain);
			LogScreenshot("info", "Time selected with 12 Hrs TIME FORMAT");

		} else {
			domain = "AM";
			if (Integer.parseInt(currhour) == 0) {
				currhour = "12";}

			driver.findElement(By.xpath("//input[@id='txtHours']")).sendKeys(currhour);
			driver.findElement(By.xpath("//input[@id='txtMin']")).sendKeys("30");

			meridian.selectByValue(domain);
			LogScreenshot("info", "Time selected with 12 Hrs TIME FORMAT");

		}

	}


	private void enterSupplierOpeningMsg() throws Exception {

		Thread.sleep(2000);
		WebElement supplierOpeneingMsg = driver.findElement(By.xpath("//textarea[contains(@name,'openingMessage')]"));
		moveToElementAndEnterData(supplierOpeneingMsg, "Hi This is Auto QS Event");

		LogScreenshot("info", "opening message Added");

	}


	private void enterSupplierQuestion() throws Exception {


		WebElement supplierQuestion = driver.findElement(By.xpath("//div[@class='splitAdd']//input[contains(@name,'question')]"));
		moveToElementAndEnterData(supplierQuestion, "Auto entered question");

		driver.findElement(By.xpath("//div[@class='splitAdd']//a[contains(@class,'addQuestion')]")).click();
		LogScreenshot("info", "Supplier Question Details Added");

	}


	private void enterItemDetails() throws Exception {

		WebElement itemNameElement = driver.findElement(By.xpath("//div[@class='splitAdd']//input[contains(@name,'itemName')]"));
		moveToElementAndEnterData(itemNameElement, itemname);

		WebElement itemQtyElement = driver.findElement(By.xpath("//div[@class='splitAdd']//input[contains(@name,'quantity')]"));
		moveToElementAndEnterData(itemQtyElement, "10");

		By itemUom = By.xpath("//div[@class='splitAdd']//input[contains(@name,'uom')]");

		enterText_AutoComplete_eProc(itemUom, "Each");
		//enterText_AutoComplete(, );

		if(driver.findElement(itemUom).getAttribute("value").equalsIgnoreCase("EACH") || driver.findElement(itemUom).getAttribute("value").equalsIgnoreCase("EA"))    
			LogScreenshot("Pass", "Item Details Added");
		else
			LogScreenshot("Fail", "Item Details Not Added");



	}

	private void moveToElementAndEnterData(WebElement element, String data) throws Exception {

		try {
			element.clear();
			element.click();
			element.sendKeys(data);
			Thread.sleep(2000);
		} catch (ElementClickInterceptedException e) {
			scroll_into_view_element(element);
			element.click();
			element.sendKeys(data);
			Thread.sleep(2000);
		}

	}


	public void verifyEventIniSource(String eventName) throws Exception {

		if(driver.findElements(By.xpath("//p[@title='" + eventName + "']//span[@class='md-caption']")).size()>0){
			String eventid = driver.findElement(By.xpath("//p[@title='" + eventName + "']//span[@class='md-caption']")).getText();
			LogScreenshot("Pass", "QuickSource event : " + eventid + " Created and visible in QuickSource");
		}
		else
			LogScreenshot("Fail", "QuickSource event : " + eventName + " is not present in QuickSource page");

	}




}
