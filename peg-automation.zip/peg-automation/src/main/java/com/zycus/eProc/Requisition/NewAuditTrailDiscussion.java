package com.zycus.eProc.Requisition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

/**
 * <p>
 * <b> Title: </b> Requisition_ViewOrders.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.takeAction: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class NewAuditTrailDiscussion extends RequisitionDetails {

  private String discussionWith;
  private String msg;

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public NewAuditTrailDiscussion(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }
  
  public NewAuditTrailDiscussion(WebDriver driver, ExtentTest logger, String discussionWith, String msg) { 
    super(driver, logger);
    this.discussionWith = discussionWith;
    this.msg = msg;
  }

  public void createNewDiscussion() throws Exception{
    findElement(By.id("addNewDiscussion")).click();
    enterText_AutoComplete(By.xpath("//div[@id='viewNewDiscussionDOMComponent']//input[@class='toEmail']/preceding-sibling::input"), discussionWith);
    driver.findElement(By.xpath("//div[@id='viewNewDiscussionDOMComponent']//textarea[@name='msgBox']")).sendKeys(msg);
    
  }
}
