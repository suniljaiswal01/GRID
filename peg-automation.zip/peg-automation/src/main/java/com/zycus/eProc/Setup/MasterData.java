package com.zycus.eProc.Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

public class MasterData extends eProc_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  //private static By masterDataLinkXpath = By.xpath("//div[@class='configLinks']//a[text()='Master Data']");
  
  public MasterData(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }
  

  public boolean enterSettings() {
    boolean result = true;
    
    String genDisplayNameFormat = "";
    String chargeDistribInCAR = "";
    String autoCloseReqFullInvoiced = "";
    String allowReopeningClosedInv = "";
    String supplierList = "";
    String backdateDaysForRetroPurchase = "";
    String cardTypes = "";
    
    try {
      //findElement(masterDataLinkXpath).click();
      /**************************Tenant Level Customization*******************************/
      //Display
      driver.findElement(By.id("EPROC_GENERAL_DEFAULT_DISPLAY_NAME_FORMAT")).sendKeys(genDisplayNameFormat);
      
      //Control
      findElement(By.xpath("//input[@name='EPROC_PCARD_ENABLE_CAHRGE_DISTRIBUTION'][following-sibling::text()[contains(.,'"+chargeDistribInCAR+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_AUTOCLOSE_REQ_PO'][following-sibling::text()[contains(.,'"+autoCloseReqFullInvoiced+"')]]")).click();
      findElement(By.xpath("//input[@name='EPROC_REOPEN_CLOSED_PO'][following-sibling::text()[contains(.,'"+allowReopeningClosedInv+"')]]")).click();
      enterText_AutoComplete(By.id("gCardSupplier"), supplierList);
      driver.findElement(By.id("txtBackdateDays")).sendKeys(backdateDaysForRetroPurchase);
      
      //Masters
      driver.findElement(By.id("EPROC_ENTITY_PCARD_TYPE")).sendKeys(cardTypes);
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

}
