package com.zycus.eProc.Budget;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Budget.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewBudget_ByLink: 
 * <br>
 * 2.createNewBudget_ByAddbtn: 
 * <br>
 * 3.selectPeriod: 
 * <br>
 * 4.addPeriod: 
 * <br>
 * 4.filterByStatus: 
 * <br>
 * 4.filterByPlannedAmount: 
 * <br>
 * 4.filterByReservedAmount: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class Budgets extends eProc_CommonFunctions {

	private static By createBudgetBtn = By.id("createBudgetBtn");
	private static By createNewBudgetLink = By.xpath("//table[contains(@class,'dataTable')]//a[@title='Create new budget']");
	//private By processingLoader = By.id("budgetList_processing");
	private static By statusXpath = By.xpath("//table[contains(@class,'dataTable')]//td[1]/div");
	private static By plannedAmountXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'totalAmountReq')]");
	private static By reservedAmountXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'totalAmountReq')]");
	private static By actionsLinkXpath = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='Actions']");

	public Budgets(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	eInvoice_CommonFunctions objFunctions = new eInvoice_CommonFunctions(driver, logger);

	/**
	 * <b>Function:</b> createNewBudget_ByLink
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param None
	 * @return result - true/false
	 */

	@Deprecated
	public boolean createNewBudget_ByLink() {
		boolean result = false;
		try {
			findElement(createNewBudgetLink).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> createNewBudget_ByAddbtn
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param None
	 * @return result - true/false
	 * @throws Exception 
	 */

	public String createNewBudget_ByAddbtn() throws Exception {
		String budgetLineName=null;
		String newBudgetLineName=null;
		try {
			findElement(createBudgetBtn).click();
			LogScreenshot("INFO", "Clicked on Create Budget button");
			Budget_NewBudget objNewBudget = new Budget_NewBudget(driver, logger);
			if (driver.findElement(objNewBudget.getNewBudgetLbl()) != null){
				String budgetName = objNewBudget.enterBudgetDetails();
				objNewBudget.enterSettings();   
				objNewBudget.selectPeriod();
				BudgetDetails onjBudgetDetails= new BudgetDetails(driver, logger);
				onjBudgetDetails.selectBudgetDimension();
				budgetLineName= onjBudgetDetails.addBudgetLine();  
				findElement(objNewBudget.getSaveFreezeBtn()).click();
				waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'dataTables_processing')][contains(@style,'block')]"));
				clrAllFilters();
				waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'dataTables_processing')][contains(@style,'block')]"));
				Thread.sleep(5000);
				System.out.println(budgetName);
				if(filterByBudgetName(budgetName)) {
					LogScreenshot("PASS",budgetName+" :Budget created and searched successfully");
					newBudgetLineName = budgetLineName;
				}else
					LogScreenshot("FAIL",budgetName+" :Budget not searched");	
			}
		} catch (Exception e) {
			LogScreenshot("FAIL", "Unable to create budget");
			e.printStackTrace();
		}
		return newBudgetLineName;
	}

	/**
	 * <b>Function:</b> filterByStatus - To filter by Status
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param checkBoxLbl
	 *            - Label of the checkbox which is to be selected
	 * @return result - True/False
	 */

	/*
	 * public boolean filterByStatus(String checkBoxLbl){ boolean result =
	 * false; try { String colName = "Status";
	 * //click(By.xpath("//th[contains(@class,'budgetStatusFltrHdr')]//b")); int
	 * colNo = getColNum(colName);
	 * findElement(By.xpath("//tr[2]/th["+colNo+"]//b")).click();
	 * filterByChkbox(checkBoxLbl); result = verifyFilteredStatus(colName,
	 * colNo, checkBoxLbl)?true:false; } catch (Exception e) { e.printStackTrace();
	 * } return result; }
	 */
	public boolean filterByStatus(String checkBoxLbl) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'budgetStatusFltrHdr')]//b")).click();
			result = objFunctions.filterByChkbox(checkBoxLbl, statusXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByPlannedAmount - To filter by 'Planned Amount'
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromAmt
	 *            - From Amount , ToAmt - To Amount
	 * @return result - True/False
	 */

	/*
	 * public boolean filterByPlannedAmount(float fromAmt, float ToAmt){ boolean
	 * result = false; try { String colName = "Amount to be approved"; int colNo
	 * = getColNum(colName);
	 * findElement(By.xpath("//tr[2]/th["+colNo+"]//b")).click();
	 * //click(By.xpath("//th[contains(@class,'budgetAmountFltrHdr')]//b"));
	 * filterByAmtRange(fromAmt, ToAmt); result = verifyFilteredAmount(colNo,
	 * fromAmt, ToAmt)?true:false; } catch (Exception e) { e.printStackTrace(); }
	 * return result; }
	 */

	public boolean filterByPlannedAmount(float fromAmt, float ToAmt) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'budgetAmountFltrHdr')]//b")).click();
			result = objFunctions.filterByAmtRange(fromAmt, ToAmt, plannedAmountXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByReservedAmount - To filter by 'Reserved Amount'
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromAmt
	 *            - From Amount , ToAmt - To Amount
	 * @return result - True/False
	 */

	/*
	 * public boolean filterByReservedAmount(float fromAmt, float ToAmt){
	 * boolean result = false; try { String colName = "Amount to be approved";
	 * int colNo = getColNum(colName);
	 * findElement(By.xpath("//tr[2]/th["+colNo+"]//b")).click();
	 * //click(By.xpath("//th[contains(@class,'budgetUtilizationFltrHdr')]//b"))
	 * ; filterByAmtRange(fromAmt, ToAmt); result = verifyFilteredAmount(colNo,
	 * fromAmt, ToAmt)?true:false; } catch (Exception e) { e.printStackTrace(); }
	 * return result; }
	 */

	public boolean filterByReservedAmount(float fromAmt, float ToAmt) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'budgetUtilizationFltrHdr')]//b")).click();
			result = objFunctions.filterByAmtRange(fromAmt, ToAmt, reservedAmountXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByBudgetName(String budgetName) {
		boolean result = false;
		try {
			result = objFunctions.filterByText("Budget Name", budgetName) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByCompany(String company) {
		boolean result = false;
		try {
			result = objFunctions.filterByText_AutoComplete("Company", company) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByOwner(String owner) {
		boolean result = false;
		try {
			result = objFunctions.filterByText_AutoComplete("Owner", owner) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean selectAction(String action) {
		boolean result = false;
		try {
			findElement(actionsLinkXpath).click();
			findElement(By
					.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"
							+ action + "']")).click();
			switch (action) {
			case "View":
				WebElement objbudgetName = findElement(By.xpath("//td[contains(@class,'name qtipFltrHdr')]"));
				String budgetName = objbudgetName.getText();

				BudgetDetails objDetails = new BudgetDetails(driver, logger);
				if (findElement(objDetails.getBudgetlabel()).getText() == budgetName)
					result = true;
				break;
			case "Deactivate":
				if (driver.findElements(By.xpath("//div[contains(@class,'promptbx')][div/span[text()='Confirm']]")).size() > 0){
					/*findElement(By.xpath("//div[contains(@class,'promptbx')][div/span[text()='Confirm']]//button[span[text()='Yes']]")).click();
          waitUntilInvisibilityOfElement(processingLoader);*/
					clickAndWaitUntilLoaderDisappears(By.xpath("//div[contains(@class,'promptbx')][div/span[text()='Confirm']]//button[span[text()='Yes']]"));
				}
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	public boolean selectAction(String action, String updatedEndDt) {
		boolean result = false;
		try {
			findElement(actionsLinkXpath).click();
			findElement(By
					.xpath("(//*[@id='workflowApproval']//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"
							+ action + "']")).click();
			switch (action) {
			case "Update validity":
				findElement(By.xpath("//input[@id='updateValidityEndDate']/following-sibling::img")).click();
				selectDate_v1(updatedEndDt);
				findElement(By.xpath("//input[@value ='Update']")).click();
				waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'overlay')]"),4);
				result = true;
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}
}
