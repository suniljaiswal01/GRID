package com.zycus.eProc.Requisition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Requisition_OnlineStore_AddToBasket.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * @author Varun Khurana
 * @since April 2018
 */

public class OnlineStore_AddToBasket extends eProc_CommonFunctions{
  
  private static By AddToBasketPg     = By.xpath("//div[div/span[text()='Add to basket']]");
  
  /**
   * Constructor for the class
   * 
   * @param driver
   */
  
  public OnlineStore_AddToBasket(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the addToBasketPg
   */
  public By getAddToBasketPg() {
    return AddToBasketPg;
  }

  /**
   * @param addToBasketPg the addToBasketPg to set
   */
  public void setAddToBasketPg(By addToBasketPg) {
    AddToBasketPg = addToBasketPg;
  }
  
}
