package com.zycus.eProc.Budget;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eProc_CommonFunctions;

public class Budget_NewBudget extends eProc_CommonFunctions {

	private static By NewBudgetLbl = By.xpath("//h2[contains(@class,'pgHead') and contains(text(),'New Budget')]");
	private static By saveFreezeBtn = By.id("saveAndFreezeBudget");

	private String ownerName;
	private String budgetName;
	private String companyName;
	private String currType;
	private String ToDate;
	private boolean dispUtilizationToRequesters;
	private boolean dispUtilizationToApprovers;
	private int ObserverPercentage;
	private int ApproverPercentage;
	private boolean notifyBudgetOwner; 

	public Budget_NewBudget(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eProc");
		String[][] abc = (String[][]) objFunctions.dataProvider("NewBudget", Datasheet_eInvoice);
		this.ownerName = abc[0][0];
		this.budgetName = "Budget_"+generateNo();
		this.companyName = abc[0][1];
		this.currType = abc[0][2];
		this.ToDate = abc[0][3];
		this.dispUtilizationToRequesters = Boolean.parseBoolean(abc[0][4]);
		this.dispUtilizationToApprovers = Boolean.parseBoolean(abc[0][5]);
		this.ObserverPercentage = Integer.parseInt(abc[0][6]);
		this.ApproverPercentage = Integer.parseInt(abc[0][7]);
		this.notifyBudgetOwner = Boolean.parseBoolean(abc[0][8]);

	}

	/**
	 * <b>Function:</b> enterBudgetDetails
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @return result - true/false
	 */

	public String enterBudgetDetails(String...budgetDescription) {
		String budgetDesc = budgetDescription.length==0?"Budget Description":budgetDescription[0];
		try {
			String ownerName= getUserName();
			enterText_AutoComplete_eProc(By.xpath("//input[@name='ownerNameText']"), ownerName);
			//driver.findElement(By.xpath("//input[@name='ownerNameText']")).sendKeys(ownerName);
			driver.findElement(By.xpath("//input[@name='budgetNameText']")).sendKeys(budgetName);
			enterText_AutoComplete_eProc(By.xpath("//input[@name='companyNameText']"), companyName);
			//driver.findElement(By.xpath("//input[@name='companyNameText']")).sendKeys(companyName);
			driver.findElement(By.xpath("//textarea[@name='budgetDescriptionText']")).sendKeys(budgetDesc);
			driver.findElement(By.xpath("//input[@name='currencyTypeText']")).clear();
			//driver.findElement(By.xpath("//input[@name='currencyTypeText']")).sendKeys(currType);
			enterText_AutoComplete_eProc(By.xpath("//input[@name='currencyTypeText']"), currType);
			findElement(By.xpath("(//form[@id='budgetDetailsForm']//li[label/text()[contains(.,'Validity')]]//img)[2]")).click();
			String nextDate= selectNextDate();
			selectDate_v1(nextDate);
			LogScreenshot("PASS", "Budget INFO details added");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return budgetName;
	}

	/**
	 * <b>Function:</b> enterSettings
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param dispUtilizationToRequesters
	 * @param dispUtilizationToApprovers
	 * @param ObserverPercentage
	 * @param ApproverPercentage
	 * @param notifyBudgetOwner
	 * @return result - true/false
	 * @throws Exception 
	 */

	public boolean enterSettings() throws Exception {
		boolean result = false;
		try {
			if (dispUtilizationToRequesters)
				findElement(By.id("displayUtilApprover")).click();
			if (dispUtilizationToApprovers)
				findElement(By.id("displayUtilRequester")).click();
			sendKeys(By.id("ownerAsObserver"), String.valueOf(ObserverPercentage));
			sendKeys(By.id("ownerAsApprover"), String.valueOf(ApproverPercentage));
			if (notifyBudgetOwner)
				findElement(By.xpath("(//*[@id='radioNotifyOwner']//input)[1]")).click();
			result = true;
			LogScreenshot("PASS", "Settings selected");
		} catch (Exception e) {
			LogScreenshot("Info", e.getMessage());
		}
		return result;
	}


	/**
	 * <b>Function:</b> selectPeriod
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param period
	 * @return result - true/false
	 */

	public boolean selectPeriod(String period) {
		boolean result = false;
		try {
			findElement(By.xpath("//div[@id='budgerPeriodDropDown']/div/ol/li/a[text()='" + period + "']")).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean selectPeriod() {
		boolean result = false;
		try {
			Actions actions = new Actions(driver);
			WebElement period = driver.findElement(By.id("periodDrpDown"));
			actions.moveToElement(period).perform();
			findElement(By.xpath("//div[contains(@class,'budgetPeriodContainer')]/a[1]")).click();
			result = true; 
			LogScreenshot("PASS", "Period selected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> addPeriod
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param StartDt
	 * @param EndDt
	 * @param periodName
	 * @param description
	 * @return result - true/false
	 */

	public boolean addAndSelectPeriod() {
		boolean result = false;
		try {
			findElement(By.id("addBudgetPeriod")).click();
			Budget_AddPeriod objAddPeriod = new Budget_AddPeriod(driver, logger);
			String addedPeriod = objAddPeriod.addPeriod();
			if (addedPeriod != null){
				if (selectPeriod(addedPeriod))
					result = true;
			}else
				LogScreenshot("Info", "Period not added to the list");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	/**
	 * <b>Function:</b> addPeriod
	 * @author Varun Khurana
	 * @since April 2018
	 * @param StartDt
	 * @param EndDt
	 * @param periodName
	 * @param description
	 * @return result - true/false
	 */

	/*public boolean addPeriod() {
    boolean result = false;
    try {
      findElement(By.id("addBudgetPeriod")).click();
      Budget_AddPeriod objAddPeriod = new Budget_AddPeriod(driver, logger);
      if (objAddPeriod.addPeriod())
        result = true;
      else
        LogScreenshot("Info", "Period not added to the list");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }*/

	/**
	 * @return the newBudgetLbl
	 */
	public By getNewBudgetLbl() {
		return NewBudgetLbl;
	}

	/**
	 * @param newBudgetLbl the newBudgetLbl to set
	 */
	public void setNewBudgetLbl(By newBudgetLbl) {
		NewBudgetLbl = newBudgetLbl;
	}

	/**
	 * @return the saveFreezeBtn
	 */
	public By getSaveFreezeBtn() {
		return saveFreezeBtn;
	}

	/**
	 * @param saveFreezeBtn the saveFreezeBtn to set
	 */
	public void setSaveFreezeBtn(By saveFreezeBtn) {
		this.saveFreezeBtn = saveFreezeBtn;
	}

}
