package com.zycus.eProc.PO;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eInvoice.Invoice.ItemDetails;
import com.zycus.iSupplier.ManageSuppliers.CreateSupplier;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;
import common.Functions.eProc_eIvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> PurchaseOrder.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class PurchaseOrder extends eProc_CommonFunctions {

	private static By pgHeader = By.xpath("//h1[@class='pgHead']/span[text()='Purchase Order']");
	private String supplier;
	private String purchaseType;
	private String oderDesc;
	private String buyer;
	private String itemAdditionProcess;
	private String deliveryTerms;
	static By backBtn = By.xpath("//div[@class='catFltr catFltr-tabbed']/a[@title='Back to Purchase Order listing']");

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @throws Exception 
	 */

	public PurchaseOrder(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
	}

	public PurchaseOrder(WebDriver driver, ExtentTest logger, String supplier) throws Exception {
		super(driver, logger);
		this.supplier = supplier;
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
		String[][] abc = (String[][]) objFunctions.dataProvider("StandardPurchaseOrder", Datasheet_eProc);
		this.deliveryTerms = abc[0][0];
		this.purchaseType = abc[0][1];
		this.oderDesc = abc[0][2];
		this.buyer = abc[0][3];
		this.itemAdditionProcess = abc[0][4];
	}

	public void navigateToPOTabs(String tabName) throws Exception{
		String tabID = null;
		switch(tabName){
		case "Delivery":
			tabID = "lnkDelivery";
			break;
		case "Receipt":
			tabID = "lnkReceipt";
			break;
		case "Invoice":
			tabID = "lnkInvoice";
			break;
		case "Payment":
			tabID = "lnkPayment";
			break;
		}
		findElement(By.id(tabID)).click();
		waitUntilInvisibilityOfElement(processingLoader,4);
		waitUntilVisibilityOfElement(By.xpath("//*[@class='orgTtl'][contains(text(),'"+tabName+"')]"));
		Thread.sleep(2000);
		LogScreenshot("Pass", "Navigated to "+ tabName + " tab");
	}

	public String enterPODetails_old() throws Exception{
		String generatedPO = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		By purchaseTypeXpath = By.xpath("//*[@id='selPurchaseType']/option[text()='" + purchaseType + "']");
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
			WebElement PONum = driver.findElement(By.id("txtPurchaseOrderNumber"));
			//PONum.click();
			PONum.clear();
			String PO = "AutoPO_" + generateNo();
			PONum.sendKeys(PO);

			if (supplier==null){
				try {
					String state = driver.findElement(By.id("orgUnit_location")).getText();
					findElement(By.xpath("//a[text()='Add Supplier']")).click();
					// Code for switching to iSupplier tab
					String parent = driver.getWindowHandle();
					switchWindowHandles(parent, "Zycus SIM : Create Supplier");
					CreateSupplier objSupplier = new CreateSupplier(driver, logger, state);
					//if (objSupplier.createNewSupplier())
					supplier = objSupplier.createNewSupplier("Operational");
				} catch (Exception e) {
					LogScreenshot("Info", "SIM Supplier not created");
				}
			}else
				enterText_AutoComplete(By.id("txtSupplierName"), supplier);
			eProc_eIvoice_CommonFunctions objCommon = new eProc_eIvoice_CommonFunctions(driver, logger);
			objCommon.selectAddress();

			//Delivery Terms
			findElement(By.id("slctDeliveryTerm")).click();
			findElement(By.xpath("//select[@id='slctDeliveryTerm']/option[@title='"+deliveryTerms+"']")).click();
			try {
				// findElement(By.id("slctPurchaseType")).click();
				js.executeScript("arguments[0].click();", driver.findElement(purchaseTypeXpath));
				findElement(purchaseTypeXpath).click();
			} catch (Exception e) {
				e.printStackTrace();
			}
			driver.findElement(By.id("txtOrderDescription")).sendKeys(oderDesc);
			enterText_AutoComplete_eProc(By.id("txtBuyer"), buyer);
			addItem(itemAdditionProcess);
			generatedPO = PO;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return generatedPO;
	}

	public String enterPODetails() throws Exception{
		String generatedPO = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//WebEdit obj = new WebEdit();
		
		waitUntilInvisibilityOfElement(By.id("processing_cntPO"));
		waitUntilVisibilityOfElement(By.id("frmPurchaseOrder"));
		By purchaseTypeXpath = By.xpath("//*[@id='selPurchaseType']/option[text()='" + purchaseType + "']");
		eProc_eIvoice_CommonFunctions objCommon = new eProc_eIvoice_CommonFunctions(driver, logger);
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
			String PO = "AutoPO_" + generateNo();
			//obj.setWebEditValue(By.id("txtPurchaseOrderNumber"), PO);
			By txtPurchaseOrderNumber = By.id("txtPurchaseOrderNumber");
			clickElement(txtPurchaseOrderNumber);
			setInput(txtPurchaseOrderNumber, PO);
//			driver.findElement(By.id("txtPurchaseOrderNumber")).clear();
//			driver.findElement(By.id("txtPurchaseOrderNumber")).sendKeys(PO);

			/* driver.findElement(By.id("txtOrderDescription")).clear();
      driver.findElement(By.id("txtOrderDescription")).sendKeys(oderDesc);*/

			//Flexi fields if exist
			eInvoice_CommonFunctions objFunc = new eInvoice_CommonFunctions(driver, logger);
			objFunc.flexiFormDetails(false);

			Thread.sleep(3000);
			if (supplier==null){
				try {
					String state = driver.findElement(By.id("orgUnit_location")).getText();
					findElement(By.xpath("//a[text()='Add Supplier']")).click();
					// Code for switching to iSupplier tab
					String parent = driver.getWindowHandle();
					switchWindowHandles(parent, "Zycus SIM : Create Supplier");
					CreateSupplier objSupplier = new CreateSupplier(driver, logger, state);
					//if (objSupplier.createNewSupplier("Operational"))
					supplier = objSupplier.createNewSupplier("Operational");
				} catch (Exception e) {
					LogScreenshot("Info", "SIM Supplier not created");
				}
			}else
				//obj.setAutoCompleteTxt(driver, By.id("txtSupplierName"), supplier);
				enterText_AutoComplete_eProc(By.id("txtSupplierName"), supplier);
			
			objCommon.selectAddress();


			//Temperory code for Required By Selection

			selectTodayDate("deliveryOn_header");


			//Currency - Exchange Rate
			Random rnd = new Random();
			if (driver.findElements(By.xpath("//input[@id='txtBaseExchangeRate' and not(contains(@style,'none'))]")).size() > 0)
				driver.findElement(By.id("txtBaseExchangeRate")).sendKeys(String.valueOf(1+rnd.nextInt(10)));


			//Delivery Terms
			WebElement objDeliveryTerm = driver.findElement(By.id("slctDeliveryTerm"));
			/*((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", objDeliveryTerm);
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-200);");*/
			scroll_into_view_element(objDeliveryTerm);
			objDeliveryTerm.click();
			findElement(By.xpath("//select[@id='slctDeliveryTerm']/option[@title='"+deliveryTerms+"']")).click();
			try {
				// findElement(By.id("slctPurchaseType")).click();
				js.executeScript("arguments[0].click();", driver.findElement(purchaseTypeXpath));
				findElement(purchaseTypeXpath).click();
			} catch (Exception e) {
				e.printStackTrace();
			}
			//obj.setWebEditValue(driver, By.id("txtOrderDescription"), oderDesc);
			driver.findElement(By.id("txtOrderDescription")).sendKeys(oderDesc);
			Thread.sleep(3000);
			WebElement objBuyer = driver.findElement(By.id("txtBuyer"));
			scroll_into_view_element(objBuyer, "Buyer text field");
			Thread.sleep(2000);
			buyer = getUserName();
			LogScreenshot("Info", "Entering "+buyer+" in Buyer text field");
			enterText_AutoComplete_eProc(By.id("txtBuyer"), buyer);
			scroll_into_view_element(objBuyer, "Buyer text field");
			LogScreenshot("Info", "Buyer value entered as "+buyer);
			//obj.setAutoCompleteTxt(driver, By.id("txtBuyer"), buyer);
			//Remove all taxes
			WebElement objRemoveTaxes = driver.findElement(By.xpath("//div[@id='taxDetailCompleteBlock']//a[contains(@class,'scLnk dev_removeAllTaxes')]"));
			scroll_into_view_element(objRemoveTaxes);
			objRemoveTaxes.click();
			Thread.sleep(3000);
			addItem(itemAdditionProcess);
			generatedPO = PO;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return generatedPO;
	}

	private boolean addItem(String itemAdditionProcess) {
		boolean result = false;
		Actions action = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			WebElement objAddItem = driver.findElement(By.id("addItemBttn"));
			/*js.executeScript("arguments[0].scrollIntoView(true);", objAddItem);
      js.executeScript("window.scrollBy(0,-100)");*/
			scroll_into_view_element(objAddItem);
			Thread.sleep(500);
			action.moveToElement(objAddItem).build().perform();
			WebElement objItemAdditionProcess = driver.findElement(
					By.xpath("//div[@id='addItemBttn']/div//a[span[text()='" + itemAdditionProcess + "']]"));
			action.moveToElement(objItemAdditionProcess).click().build().perform();
			Thread.sleep(3000);
			switch (itemAdditionProcess) {
			case "Search Item":
				waitUntilVisibilityOfElement(By.id("searchTerm_addCollpsBxPad"));
				driver.findElement(By.id("searchTerm_addCollpsBxPad")).sendKeys("Freight"+Keys.ENTER);
				waitUntilInvisibilityOfElement(processingLoader,4);
				waitUntilVisibilityOfElement(By.id("itemList_addCollpsBxPad"));
				//Search Item Name

				break;
			case "Create a free-text Item":
				int existingItems = driver
				.findElements(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[contains(@id,'item') and contains(@style,'table-row')]"))
				.size();
				ItemDetails objItem = new ItemDetails(driver, logger);
				objItem.add_item();  
				int noOfItems = driver
						.findElements(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[contains(@id,'item') and contains(@style,'table-row')]"))
						.size();

				if (noOfItems == existingItems + 1) {
					LogScreenshot("Pass", "Free text item added to PO");
					result = true;
				}
				break;
			case "Add Items via file":
				break;
			case "Punchouts":
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean amendPOByItemQty(String qtyCategory, int allowedPercent) throws Exception{
		boolean result= false;
		int newQty = 0;
		Random rnd = new Random();
		ItemDetails objItem = new ItemDetails(driver, logger);
		//As Exchange Rate becomes 0 everytime PO is amended 
		//waitUntilVisibilityOfElement(By.id("txtBaseExchangeRate"));
		Thread.sleep(4000);
		try{
			if (driver.findElements(By.id("txtBaseExchangeRate")).size() > 0)
				driver.findElement(By.id("txtBaseExchangeRate")).sendKeys(String.valueOf(rnd.nextInt(10)));
		}catch(Exception e){
			e.printStackTrace();
		}
		WebElement objFirstItemEdit = driver.findElement(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[2]/td[last()]/a[@title='Edit']"));
		scroll_into_view_element(objFirstItemEdit);
		objFirstItemEdit.click();
		Thread.sleep(3000);
		LogScreenshot("Info", "Edit button clicked");

		int currItemQty = 0;
		if(driver.findElements(By.id("changeItemSummary")).size()>0) {
			currItemQty = objItem.getItemQty();
		}else {
			clickElement(objFirstItemEdit);
			Thread.sleep(3000);
			currItemQty = objItem.getItemQty();
		}
		/*  int currItemQty = objItem.getItemQty();*/
		int allowedQty = (int)currItemQty+(currItemQty*allowedPercent)/100;
		if (qtyCategory.equals("greater than allowed"))
			newQty  = allowedQty+1;
		else
			newQty  = allowedQty-1;
		try {
			objItem.editItemQty(newQty);
			Thread.sleep(3000);
			findElement(By.id("txtPOStatusComments")).sendKeys("Amending PO");
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
			Thread.sleep(2000);
			findElement(By.xpath("//a[span[text()='Submit PO for processing']]")).click();
			Thread.sleep(10000);
			LogScreenshot("Info", "Submit PO for Processing button clicked");
			scroll_into_view_element(driver.findElement(By.id("collapsibleGrid")));
			Thread.sleep(2000);
			if (newQty>allowedQty){
				if (driver.findElements(By.xpath("//td[@class='col-qty error']")).size() > 0)
					LogScreenshot("Pass","Error displayed on amending PO for more than allowed quantity "+allowedQty);
				else{
					LogScreenshot("Fail","Error not displayed on amending PO for more than allowed quantity "+allowedQty);
					Thread.sleep(2000);
					findElement(By.xpath("//a[span[text()='Submit PO for processing']]")).click();
					Thread.sleep(10000);
					LogScreenshot("Info", "Submit PO for Processing button clicked");
				}
			} else {
				Thread.sleep(2000);
				findElement(By.xpath("//a[span[text()='Submit PO for processing']]")).click();
				Thread.sleep(10000);
				LogScreenshot("Info", "Submit PO for Processing button clicked");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	public void selectTodayDate(String id) throws Exception {

		clickElement(By.id(id));
		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String s = formatter.format(date);
		/*JavascriptExecutor js = (JavascriptExecutor) driver; 
		js.executeScript("document.getElementById('"+id+"').value='"+s+"';");*/
		selectDate_v1(s);

	} 

	public boolean amendPOByItemprice(String amtCategory, int allowedPercent) throws Exception{
		boolean result= false;
		double newPrice = 0;
		Random rnd = new Random();
		ItemDetails objItem = new ItemDetails(driver, logger);
		//As Exchange Rate becomes 0 everytime PO is amended 
		List<WebElement> exchangeRates = driver.findElements(By.xpath("//input[@id='txtBaseExchangeRate' and not(contains(@style,'none'))]"));
		if (exchangeRates.size() > 0)
			//waitUntilVisibilityOfElement(By.id("txtBaseExchangeRate"));
			driver.findElement(By.id("txtBaseExchangeRate")).sendKeys(String.valueOf(rnd.nextInt(10)));
		WebElement objFirstItemEdit = driver.findElement(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[2]/td[last()]/a[@title='Edit']"));
		scroll_into_view_element(objFirstItemEdit);
		objFirstItemEdit.click();
		Thread.sleep(3000);
		LogScreenshot("Info", "Edit button clicked");

		double currItemPrice = 0.00;
		if(driver.findElements(By.id("changeItemSummary")).size()>0) {
			currItemPrice = objItem.getItemPrice();
		}else {
			clickElement(objFirstItemEdit);
			Thread.sleep(3000);
			currItemPrice = objItem.getItemPrice();
		}
		double allowedPrice = currItemPrice+(currItemPrice*allowedPercent)/100;
		if (amtCategory.equals("greater than allowed"))
			newPrice  = allowedPrice+1;
		else
			newPrice  = allowedPrice-1;
		try {
			objItem.editMktPrice(newPrice);
			Thread.sleep(3000);
			driver.findElement(By.id("txtPOStatusComments")).sendKeys("Amending PO");
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"),4);
			Thread.sleep(2000);
			findElement(By.xpath("//a[span[text()='Submit PO for processing']]")).click();
			Thread.sleep(10000);
			LogScreenshot("Info", "Submit PO for Processing button clicked");
			scroll_into_view_element(driver.findElement(By.id("collapsibleGrid")));
			Thread.sleep(2000);
			if (newPrice>allowedPrice){
				if (driver.findElements(By.xpath("//td[@class='col-unitprice iNum error']")).size() > 0)
					LogScreenshot("Pass","Error displayed on amending PO for more than allowed price "+allowedPrice);
				else {
					LogScreenshot("Fail","Error not displayed on amending PO for more than allowed price "+allowedPrice);
					scroll_to_TopofPage();
					LogScreenshot("info","Issue with purchase order submission");
				}
				
			} else {
				Thread.sleep(2000);
				findElement(By.xpath("//a[span[text()='Submit PO for processing']]")).click();
				Thread.sleep(10000);
				LogScreenshot("Info", "Submit PO for Processing button clicked");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void editItemQty(){
		findElement(By.xpath("//table[@id='collapsibleGrid']/tbody/tr[contains(@id,'item') and contains(@style,'table-row')]/td[last()]/a[@title='Edit']")).click();
	}

	/**
	 * @return the pgHeader
	 */
	public By getPgHeader() {
		return pgHeader;
	}

	/**
	 * @param pgHeader
	 *            the pgHeader to set
	 */
	public void setPgHeader(By pgHeader) {
		this.pgHeader = pgHeader;
	}

}
