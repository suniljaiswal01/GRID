package com.zycus.eProc.Requisition;

import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zycus.eProc.CheckoutPg;
import com.zycus.eProc.PO.CreateReceipt_page;

import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;
import net.bytebuddy.dynamic.scaffold.TypeInitializer.None;

/**
 * <p>
 * <b> Title: </b> RequisitionDetails.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.addRequisition: 
 * <br>
 * 2.filterByStatus: 
 * <br>
 * 3.filterBySubmittedOn: 
 * <br>
 * 4.filterByAmount: 
 * <br>
 * 5.verifyDisplayedAction: 
 * <br>
 * 6.takeAction: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class RequisitionDetails extends eProc_CommonFunctions {
  
  private static By processingLoader         = By.id("reqList_processing");
  private static By OnlineCatalogPgXpath       = By.id("searchCatalogHomeId");
  private static By recallApprovalCmmntId     = By.id("txtComment");
  private static By recallBtnId           = By.id("recallBtn");
  private static By recallReqActionMsgId       = By.id("status_overlay_savingComment");
  private static By closeCmmntId           = By.id("closeCommentTextArea");
  private static By closeBtnId           = By.id("closeAction");
  private static By requsitionLoadedPromptXpath   = By.xpath("//div[//td[contains(text(),'requisition is already loaded')] and contains(@class,'promptCnt')]/parent::div");
  private static By continueAddtoReqXpath     = By.xpath("//span[text()='No, continue adding to existing requisition']");
  private static By statusTxtXpath         = By.xpath("(//table[contains(@class,'dataTable')]//td[1]/div)[1]");
  private static By actionsLinkXpath         = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='Actions']");
  private static By requisitionNumTxtXpath     = By.xpath("(//table[contains(@class,'dataTable')]//td[2]/a)[1]");
  private static By requisitionNameTxtXpath     = By.xpath("//table[contains(@class,'dataTable')]//td[3]");
  private static By deletePopUpXpath         = By.xpath("//div[div//td[text()='Are you sure want to delete this requisition?']]");
  private static By deletePopUpYesLink       = By.xpath("//div[div//td[text()='Are you sure want to delete this requisition?']]//button/span[text()='Yes']");
  private static By reminderMsgSentXpath       = By.xpath("//*[@id='status_overlay_sendingReminder']/div");
  private static By recallApprovalReqPopUp     = By.xpath("//*[@id='saveCommentDOM']/parent::div");
  private static By closeReqPopUp         = By.xpath("//*[@id='closeBox']/parent::div");

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public RequisitionDetails(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }
  
  eInvoice_CommonFunctions objFunctions = new eInvoice_CommonFunctions(driver, logger);

  /**
   * <b>Function:</b> addRequisition -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param requisitionFlow
   * @return result - True/False
   */

  public boolean addRequisition(String requisitionFlow) {
    boolean result = false;
    try {
      findElement(By.id("lnkAddRequisition")).click();
      try {
        WebElement requsitionLoadedPrompt = findElement(requsitionLoadedPromptXpath);
        if (requsitionLoadedPrompt.getAttribute("style").contains("block"))
          findElement(continueAddtoReqXpath).click();
      } catch (Exception e) {
      }
      if (findElement(OnlineCatalogPgXpath)  !=  null)
        if (requisitionFlow == "Online Catalog") {
          OnlineStore objOSReq = new OnlineStore(driver, logger); 
          objOSReq.searchItemFromCatalog("laptop");
          OnlineStore_SearchResults objResults = new OnlineStore_SearchResults(driver, logger);
          objResults.addItemToCart(5);
        } else if (requisitionFlow == "Guided Procurement") {

        } else if (requisitionFlow == "Punchout") {

        } else
          LogScreenshot("Info", "Online Store page not displayed");
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }


  /**
   * <b>Function:</b> filterByStatus - To filter by Status
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param checkBoxLbl
   *            - Label of the checkbox which is to be selected
   * @return result - True/False
   */

  public boolean filterByStatus(String checkBoxLbl) {
    boolean result = false;
    try {
      String colName = "Status";
      // findElement(By.xpath("//th[contains(@class,'reqStatusFltrHdr')]//b"));
      int colNo = getColNum(colName);
      findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
      filterByChkbox(checkBoxLbl);
      result = verifyFilteredStatus(colName, colNo, checkBoxLbl) ? true : false;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> filterBySubmittedOn - To filter by Submitted On
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param fromDt
   *            - From Date , ToDt - To Date
   * @throws None
   * @return result - True/False
   */

  public boolean filterBySubmittedOn(Date fromDt, Date ToDt) {
    boolean result = false;
    try {
      String colName = "Received On";
      // findElement(By.xpath("//th[contains(@class,'reqDateFltrHdr')]//b"));
      int colNo = getColNum(colName);
      findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
      filterByDateRange(fromDt, ToDt);
      result = verifyFilteredDates(colNo, fromDt, ToDt) ? true : false;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> filterByAmount
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param fromAmt
   *            - From Amount , ToAmt - To Amount
   * @return result - True/False
   */

  public boolean filterByAmount(float fromAmt, float ToAmt) {
    boolean result = false;
    try {
      String colName = "Amount to be approved";
      int colNo = getColNum(colName);
      findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
      // findElement(By.xpath("//th[contains(@class,'reqAmountFltrHdr')]//b"));
      filterByAmtRange(fromAmt, ToAmt);
      result = verifyFilteredAmount(colNo, fromAmt, ToAmt) ? true : false;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> filterByAmount
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param fromAmt
   *            - From Amount , ToAmt - To Amount, currType - Type of currency
   * @return result - True/False
   */

  public boolean filterByAmount(float fromAmt, float ToAmt, String currType) {
    boolean result = false;
    String colName = "Amount to be approved";
    try {
      int colNo = getColNum(colName);
      findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
      // findElement(By.xpath("//th[contains(@class,'reqAmountFltrHdr')]//b"));
      filterByAmtRange(fromAmt, ToAmt, currType);
      result = verifyFilteredAmount(colNo, fromAmt, ToAmt, currType) ? true : false;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean filterByRequisitionNumber(String RequisitionNum) {
    boolean result = false;
    try {
      //result = objFunctions.filterByText_AutoComplete("Requisition Number", RequisitionNum) ? true : false;
      result = objFunctions.filterByText("Requisition Number", RequisitionNum);
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean filterByRequisitionName(String RequisitionName) {
    boolean result = false;
    try {
      result = objFunctions.filterByText("Name", RequisitionName);
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean filterByRequester(String requester) {
    boolean result = false;
    try {
      result = objFunctions.filterByText_AutoComplete("Requester", requester);
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * ---------------------------------------------------------------------------------
   * Function : filterByTextField
   * 
   * @param fieldName
   * @param fieldValue
   * @return result
   *         ---------------------------------------------------------------------------------
   *//*
     * 
     * public boolean filterByTextField1(String fieldName, String
     * fieldValue){ boolean result = false;
     * 
     * String fieldID = null; String elemClassSubstring = null;
     * switch(fieldName){ case "Requisition Number": fieldID =
     * "txtFltrReqNum"; elemClassSubstring = "requisitionNo"; break; case
     * "Name": fieldID = "txtFltrName"; elemClassSubstring = "name"; break;
     * case "Requester": fieldID = "txtFltrRequesterName";
     * elemClassSubstring = "behalfUserId"; break; }
     * sendKeys(By.id(fieldID), fieldValue);
     * if (findElement(processingLoader).getAttribute("style").contains(
     * "block")){ List<WebElement> objfilteredTxtList =
     * driver.findElements(By.xpath(
     * "//table[@id='reqList']//td[contains(@class,'"+elemClassSubstring+
     * "')]")); for(WebElement obj:objfilteredTxtList){
     * if (obj.getText().equals(fieldValue)) result = true; else{ result =
     * false; break; } } } return result; }
     */

  /**
   * <b>Function:</b> verifyDisplayedAction
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param action
   * @return result - True/False
   */

  protected boolean verifyDisplayedAction(String action) {
    boolean result = false;
    try {
      String status = driver.findElement(statusTxtXpath).getText();
      switch (action.toLowerCase()) {
      case "edit":
      case "delete":
        if (status.equals("Draft"))
          result = true;
        break;
      case "copy":
        if (status.equals("In Process(With Buyer)") || status.equals("In Process(Ready for approval)")
            || status.equals("Released") || status.equals("Ordering"))
          result = true;
        break;
      case "review and submit":
        if (status.equals("In Process(Ready for approval)"))
          result = true;
        break;
      case "close":
        if (status.equals("Released") || status.equals("In Process(Ordering)"))
          result = true;
        break;
      case "create receipt":
        if (status.equals("Released"))
          result = true;
        break;
      case "recall approval request":
      case "remind approver":
        if (status.equals("In Process(In Approval)"))
          result = true;
        break;
      default :
        break;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }

  /**
   * <b>Function:</b> takeAction
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param action
   * @return result - True/False
   */

  public boolean takeAction(String action) {
    boolean result = false;
    try {
      if (verifyDisplayedAction(action)) {
        
        WebElement objRequisitionNum = driver.findElement(requisitionNumTxtXpath);
        String requisitionNum = objRequisitionNum.getText();

        WebElement objRequisitionName = driver.findElement(requisitionNameTxtXpath);
        String requisitionName = objRequisitionName.getAttribute("title").replaceAll("\\s{2,}", " ").trim();
        
        findElement(actionsLinkXpath).click();
        findElement(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='" + action
            + "']")).click();

        switch (action.toLowerCase()) {
        case "delete":
          if (driver.findElement(deletePopUpXpath).getAttribute("style").contains("block"))
            findElement(deletePopUpYesLink).click();
          if (driver.findElement(processingLoader).getAttribute("style").contains("block")) {
            WebElement objDeletedReqNum = findElement(
                By.xpath("//table[contains(@class,'dataTable')]//td[2]/a[text()='" + requisitionNum + "']"));
            if (objDeletedReqNum == null)
              result = true;
            else
              LogScreenshot("Info", "Deleted Requisition still exists");
          } else
            LogScreenshot("Info", "Are you sure want to delete this requisition - message not displayed");
          break;
        case "edit":
          CheckoutPg objReqCheckout = new CheckoutPg(driver, logger);
          if (driver.findElement(objReqCheckout.getRequisitionNm()).getAttribute("value") == requisitionName){
            result = true;
          }else
            LogScreenshot("Info", "Requested Requisition not opened for editing");
          break;
        case "review and submit":
          RequisitionSubmitPg objReqSubmit = new RequisitionSubmitPg(driver, logger);
          if (driver.findElement(objReqSubmit.getRequisitionName()).getText() == requisitionName)
            result = true;
          else
            LogScreenshot("Info", "Requested Requisition not opened for review & submit");
          break;
        case "create receipt":
          CreateReceipt_page objCreateReceipt = new CreateReceipt_page(driver, logger);
          if (driver.findElement(objCreateReceipt.getHeaderReqNum()).getText().equals(requisitionNum)
              && driver.findElement(objCreateReceipt.getHeaderReqName()).getText().equals(requisitionName))
            result = true;
          else
            logger.fail("Requested Requisition not opened for Create Receipt");
          break;
        case "remind approver":
          if (driver.findElement(reminderMsgSentXpath)  !=  null)
            result = true;
          else
            LogScreenshot("Info", "Reminder message has been sent not displayed");
          break;
        case "copy":
          if (driver.findElement(By.xpath("//div[div//td[contains(text(),'Items from" + objRequisitionNum
              + "will be added to the shopping cart')]]")).getAttribute("style").contains("block")) {

            /*
             * Add code for clicking 'Proceed only with Req items'
             */

            findElement(By.xpath("//div[div//td[contains(text(),'Items from" + objRequisitionNum
                + "will be added to the shopping cart')]]//button/span[text()='"+getLanguageProperty("Proceed with Req & existing cart items")+"']")).click();
            CheckoutPg objReqCheckout1 = new CheckoutPg(driver, logger);
            if (findElement(objReqCheckout1.getRequisitionNm()).getAttribute("value") == requisitionName)
              result = true;
            else
              LogScreenshot("Info", "Requested Requisition not opened for editing");
          } else {
            LogScreenshot("Info", "Requested Requisition not opened for editing");
            result = false;
          }
          break;
        default :
          break;
        }
      } else
        LogScreenshot("Info", "Requisition is not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }

  /**
   * <b>Function:</b> takeAction
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param action
   * @param actionBasedReq_Comment
   * @return result - True/False
   */

  public boolean takeAction(String action, String actionBasedReq_Comment) {
    boolean result = false;
    try {
      findElement(actionsLinkXpath).click();
      findElement(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='" + action
          + "']")).click();

      if (verifyDisplayedAction(action)) {

        WebElement objRequisitionNum = findElement(requisitionNumTxtXpath);
        String requisitionNum = objRequisitionNum.getText();

        switch (action.toLowerCase()) {
        case "recall approval request":
          if (findElement(recallApprovalReqPopUp)  !=  null) {
            sendKeys(recallApprovalCmmntId, actionBasedReq_Comment);
            findElement(recallBtnId).click();
            if (findElement(recallReqActionMsgId)  !=  null) {
              WebElement objRecalledReqNum = findElement(
                  By.xpath("//table[contains(@class,'dataTable')]//td[2]/a[text()='" + requisitionNum + "']"));
              if (objRecalledReqNum == null)
                result = true;
            }
          } else
            LogScreenshot("Info", "Recall Approval Request pop up not displayed");
          break;
        case "close":
          if (findElement(closeReqPopUp)  !=  null) {
            sendKeys(closeCmmntId, actionBasedReq_Comment);
            findElement(closeBtnId).click();
            Thread.sleep(3000);
            
            if (driver.findElements(By.xpath("//tr[td[2]/a[text()='"+requisitionNum+"']]//td[1]/a[@class='icon po-closed']")).size()==1){
              LogScreenshot("Pass", "Requisition Number : "+requisitionNum+" closed");
              result = true;
            }else
              LogScreenshot("Fail", "Requisition Number : "+requisitionNum+" not closed");

          } else
            LogScreenshot("Info", "Recall Approval Request pop up not displayed");
          break;
        default :
          break;  
        }
      } else
        LogScreenshot("Info", "Requisition is not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean createReceiptAgainstRequisition(String RequisitionNum){
    boolean result = false;
    try {
      filterByRequisitionNumber(RequisitionNum);
      if (takeAction("Create Receipt")){
        CreateReceipt_page objReceipt = new CreateReceipt_page(driver, logger);
        objReceipt.createNewReceipt("submit");
        //Verify if receipt created
        
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  
  //This function edits the Requisition and add Supplier Comments only (doesn't edit anything else)
  public boolean editRequisition(String RequisitionName){
    boolean result = false;
    String suppComments = "Adding supplier comments";
    try {
      filterByStatus("Draft");
      filterByRequisitionName(RequisitionName);
      takeAction("Edit");
      //Add supplier Comments
      waitUntilVisibilityOfElement(By.xpath("//span[@class='chkoutlbl'][contains(text(),'Edit Requisition')]"));
      WebElement objSupplierComments = driver.findElement(By.id("txtSupplierComment"));
      objSupplierComments.sendKeys(suppComments);
      findElement(By.id("draftRequisition")).click();
      waitUntilInvisibilityOfElement(By.id("status_overlay_updateRequisition"),4);
      waitUntilInvisibilityOfElement(processingLoader,4);
      if (driver.findElement(MyRequisitions.getPgHead()).isDisplayed()){
        filterByStatus("Draft");
        filterByRequisitionName(RequisitionName);
        takeAction("Edit");
        String supplierCmmnt = objSupplierComments.getText();
        if (supplierCmmnt.equals(suppComments))
          result = true;
      }else
        logger.log(Status.FAIL, "Not navigated to My Requisitions page after editing the requisition");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public boolean deleteDraftedRequisition(String RequisitionName){
    boolean result = false;
    try {
      filterByStatus("Draft");
      filterByRequisitionName(RequisitionName);
      takeAction("Delete");
      //Add supplier Comments
      waitUntilInvisibilityOfElement(processingLoader,4);
      if (driver.findElement(MyRequisitions.getPgHead()).isDisplayed()){
        filterByStatus("Draft");
        filterByRequisitionName(RequisitionName);
        if (driver.findElement(By.xpath("//table[@id='reqList']/tbody/tr/td[text()='"+getLanguageProperty("No results found")+"']")).isDisplayed())
          result = true;
      }else
        logger.fail("Unable to delete Requisition in draft status : "+RequisitionName);
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
}
