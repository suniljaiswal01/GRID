package com.zycus.eProc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
//import com.aventstack.extentreports.Status;

import common.Functions.eProc_CommonFunctions;

public class CheckoutPg extends eProc_CommonFunctions{
  
  private By RequisitionNm = By.id("txtRequisitionName");
  
  public CheckoutPg(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the requisitionNm
   */
  public By getRequisitionNm() {
    return RequisitionNm;
  }

  /**
   * @param requisitionNm the requisitionNm to set
   */
  public void setRequisitionNm(By requisitionNm) {
    this.RequisitionNm = requisitionNm;
  }

}
