package com.zycus.eProc.Requisition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eProc.PO.CreateReceipt_page;

/**
 * <p>
 * <b> Title: </b> Requisition_ViewOrders.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.takeAction: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class ViewOrders extends RequisitionDetails {

  private static By actionsLinkXpath = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='Actions']");
  
  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public ViewOrders(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * <b>Function:</b> takeAction -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param action
   * @return result - True/False
   */

  public boolean takeAction(String action) {
    boolean result = false;
    try {
      findElement(actionsLinkXpath).click();
      findElement(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='" + action
          + "']")).click();

      if (verifyDisplayedAction(action)) {

        WebElement objRequisitionNum = findElement(By.xpath("(//table[@id='reqList']//td[2]/a)[1]"));
        String requisitionNum = objRequisitionNum.getText();

        WebElement objRequisitionName = findElement(By.xpath("(//table[@id='reqList']//td[3])[1]"));
        String requisitionName = objRequisitionName.getText();

        switch (action) {
        case "Create Receipt":
          CreateReceipt_page objCreateReceipt = new CreateReceipt_page(driver, logger);
          if (findElement(objCreateReceipt.getHeaderReqNum()).getText() == requisitionNum
              && findElement(objCreateReceipt.getHeaderReqName()).getText() == requisitionName)
            result = true;
          else {
            LogScreenshot("Info", "Requested Requisition not opened for Create Receipt");
            result = false;
          }
          break;
        case "View":
          break;
        case "Download":
          break;
        }
      } else
        LogScreenshot("Info", "Requisition is not in required status for the requested action");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;

  }
}
