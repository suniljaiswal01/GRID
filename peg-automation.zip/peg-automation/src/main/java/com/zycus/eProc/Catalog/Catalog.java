package com.zycus.eProc.Catalog;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Catalog.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.addCatalog: 
 * <br>
 * 2.filterByStatus: 
 * <br>
 * 3.filterByCatalogName: 
 * <br>
 * 4.filterBySupplier: 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class Catalog extends eProc_CommonFunctions {

	private static By pgHead = By.xpath("//h2[@class='pgHead' and text()='Catalogs']");
	private static By statusXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
	private static By filterBtnXpath = By.xpath(
			"//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='Filter']");
	private static By actionsLinkXpath = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='Actions']");

	eInvoice_CommonFunctions objFunctions = new eInvoice_CommonFunctions(driver, logger);

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 */

	public Catalog(WebDriver driver, ExtentTest logger) { 
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> addCatalog
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param None
	 * @return result - true/false
	 */

	public String addCatalog(String contractNo, boolean addItemFromFile) throws Exception{
		String newCatalog = null;
		String catalogName = null;
		findElement(By.id("addNewCatalogBtn"),"+ Add button").click();
		LogScreenshot("Info", "+ Add button clicked");
		NewCatalog objCatalog = new NewCatalog(driver, logger);
		if (driver.findElement(NewCatalog.getNewCatalogLbl()) != null){
			LogScreenshot("Info", "Navigated to Catalog Details page");
			catalogName = objCatalog.enterCatalogDetails(contractNo, addItemFromFile);
			waitUntilVisibilityOfElement(By.xpath("//h2[@class='pgHead' and text()='"+getLanguageProperty("Catalogs")+"']"));
			clrAllFilters();
			waitUntilInvisibilityOfElement(processingLoader,4);
			filterByCatalogName(catalogName);
			waitUntilInvisibilityOfElement(processingLoader,4);
			String catalogStatus = driver.findElement(By.xpath("//table[@id='catalogListing']/tbody/tr[td[contains(@class,'catalogName')]/a[text()='"+catalogName+"']]/td[2]/div")).getText().trim(); 
			if (catalogStatus.equals("In Approval")||catalogStatus.equals("Published")){
				LogScreenshot("Pass", "Created Catalog : "+catalogName+" in '"+catalogStatus+"' status");
				newCatalog = catalogName;
			}else
				LogScreenshot("Fail", "Created Catalog : "+catalogName+" is in '"+catalogStatus+"' status, Expected : In Approval or Published");
		}
		return newCatalog;
	}

	public String addCatalog(boolean addItemFromFile) throws Exception{
		return addCatalog("", addItemFromFile);
	}


	/**
	 * <b>Function:</b> filterByStatus - To filter by Status
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param checkBoxLbl
	 *            - Label of the checkbox which is to be selected
	 * @return result - True/False
	 * @throws Exception 
	 */

	/*public boolean filterByStatus(String checkBoxLbl) {
    boolean result = false;
    try {
      String colName = "Status";
      // click(By.xpath("//th[contains(@class,'budgetStatusFltrHdr')]//b"));
      int colNo = getColNum(colName);
      findElement(By.xpath("//tr[2]/th[" + colNo + "]//b")).click();
      filterByChkbox(checkBoxLbl);
      result = verifyFilteredStatus(colName, colNo, checkBoxLbl) ? true : false;
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByStatus(String checkBoxLbl) throws Exception {
		findElement(By.xpath("//th[contains(@class,'budgetStatusFltrHdr')]//b")).click();
		return objFunctions.filterByChkbox(checkBoxLbl, statusXpath);
	}

	/**
	 * <b>Function:</b> filterByCatalogName -
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param searchVal
	 *            -
	 * @return result - True/False
	 * @throws Exception 
	 */

	public boolean filterByCatalogName(String searchVal) {
		return filterByText1("Catalog Name", searchVal);
	}

	/**
	 * <b>Function:</b> filterBySupplier -
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param supplierType
	 * @param supplierName
	 *            -
	 * @return result - True/False
	 */

	public boolean filterBySupplier(String supplierType, String supplierName) {
		boolean result = false;
		try {
			findElement(By.xpath("(//div[contains(@id,'qtip')]//input[following-sibling::text()[contains(.,'" + supplierType
					+ "')]])[1]")).click();
			if (supplierType == "Single Supplier")
				sendKeys(By.id("txtSupplierName"), supplierName);
			findElement(filterBtnXpath).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void recallApprovalRequest(String catalogName) throws Exception{
		takeAction("Recall approval request", catalogName);
		driver.findElement(By.xpath("//form[@id='frmSaveComment']//textarea")).sendKeys("recalling request");
		LogScreenshot("Info","Recall action description added");
		findElement(By.id("recallBtn")).click();
		waitUntilInvisibilityOfElement(processingLoader,4);
		Thread.sleep(3000);
		LogScreenshot("Info","Recall button clicked");
		if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]/tbody/tr[1]/td[2]/div")).getText().equals(getLanguageProperty("Draft")))
			LogScreenshot("Pass","Catalog : "+catalogName+" status changed to Draft");
		else
			LogScreenshot("warning","Catalog : "+catalogName+" error while recalling");
	} 

	public void submitDraftedCatalog(String catalogName) throws Exception{
		Thread.sleep(6000);
		takeAction("Edit", catalogName);
		clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Item Details")+"']"));
		findElement(By.xpath("//a[@id='lnkScopeValidity']"),"Next button").click();
		waitUntilVisibilityOfElement(
				By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Scope & Validity")+"']"));
		findElement(By.id("lnkSubmit")).click();
		LogScreenshot("Pass", "Submitting Button clicked");
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process' and text()='"+getLanguageProperty("Catalog is ready for processing")+"']"),4);
		Thread.sleep(2000);
		if (driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Submit for approval")+"']]")).isDisplayed()){
			findElement(By.id("approvalSubmitBtn")).click();
			LogScreenshot("Pass", "Submitting Catalog in Draft State");
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='"+getLanguageProperty("Submiting Catalog for approval")+"']"),4);
			Thread.sleep(3000);
			LogScreenshot("Pass", "Catalog in Draft State submitted");
		}
	} 

	public void updateCatalog(String catalogName) throws Exception{
		takeAction("Update Catalog", catalogName);
		waitUntilVisibilityOfElement(By.id("txtDescription"));
		driver.findElement(By.id("txtDescription")).sendKeys("updating catalog");
		LogScreenshot("Pass", "Catalog Updated");
		clickAndWaitUntilElementAppears(By.xpath("//form[@id='frmCreateCatalog']//a[@id='btnLnkNext']"), By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Item Details")+"']"));
		Thread.sleep(4000);
		findElement(By.xpath("//a[@id='lnkScopeValidity']"),"Next button").click();
		waitUntilVisibilityOfElement(
				By.xpath("//ul[@class='stepsMenu']/li[@class='active']/p[text()='"+getLanguageProperty("Scope & Validity")+"']"));
		LogScreenshot("Pass", "Next button clicked");
		waitUntilInvisibilityOfElement(processingLoader);
		Thread.sleep(4000);
		waitUntilVisibilityOfElement(By.id("refresh"));
		Thread.sleep(2000);
		findElement(By.id("lnkSubmit")).click();
		LogScreenshot("Pass", "Submit button clicked");
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process' and text()='"+getLanguageProperty("Catalog is ready for processing")+"']"),4);
		waitUntilVisibilityOfElement(By.xpath("//div[contains(@class,'po-workflowDialog')]"));
		if (driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Submit for approval")+"']]")).isDisplayed()){
			findElement(By.id("approvalSubmitBtn")).click();
			LogScreenshot("Pass", "Submit button clicked");
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='status tickActive icon' and text()='"+getLanguageProperty("Submiting Catalog for approval")+"']"),4);
		}
	} 

	public void deactivateCatalog(String catalogName) throws Exception{
		takeAction("Deactivate", catalogName);
		findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']]/div[table//td[contains(text(),'"+getLanguageProperty("Are you sure you want to deactivate")+"')]]/following-sibling::div//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
		Thread.sleep(2000);
		waitUntilInvisibilityOfElement(processingLoader,4);
		filterByCatalogName(catalogName);
		Thread.sleep(3000);
		//Verify if Catalog is deactivated
		if (getCatalogStatus(catalogName).equals(getLanguageProperty("Deactivated")))
			LogScreenshot("Pass", "Catalog : " +catalogName + " deactivated");
		else
			LogScreenshot("Fail", "Catalog : " +catalogName + " not deactivated");
	} 

	public void deleteCatalog(String catalogName) throws Exception{
		takeAction("Delete", catalogName);
		findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']]/div[table//td[contains(text(),'"+getLanguageProperty("Are you sure you want to delete")+"')]]/following-sibling::div//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
		Thread.sleep(2000);
		waitUntilInvisibilityOfElement(processingLoader,4);
		Thread.sleep(3000);
		filterByCatalogName(catalogName);
		//Verify if Catalog is deleted
		waitUntilVisibilityOfElement(By.xpath("//table[@id='catalogListing']"));
		Thread.sleep(7000);
		//if (driver.findElements(By.xpath("//table[@id='catalogListing']/tbody/tr/td[text()='"+getLanguageProperty("No results found")+"']")).size() > 0)
		if (!(driver.findElements(By.xpath("//table[@id='catalogListing']/tbody/tr[td[contains(@class,'catalogName')]/a[text()='"+catalogName+"']]")).size() > 0))
			LogScreenshot("Pass", "Catalog : " +catalogName + " deleted");
		else
			LogScreenshot("Fail", "Catalog : " +catalogName + " not deleted");
	} 

	private void takeAction(String action, String entityName) throws Exception{
		//findElement(actionsLinkXpath).click();
		WebElement actionsLink =  findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[td[contains(@class,'catalogName')]/a[contains(text(),'"+entityName+"')]]/td[last()]//a[text()='Actions']"));
		actionsLink.click();
		LogScreenshot("Pass","Actions button clicked");
		Thread.sleep(3000);
		actionsLink.findElement(By.xpath("./following-sibling::ul//a[text()='"+getLanguageProperty(action)+"']")).click();
		waitUntilInvisibilityOfElement(processingLoader,4);
		Thread.sleep(2000);
		LogScreenshot("Pass",action + " button clicked");
	}

	public String getCatalogStatus(String catalogName) throws Exception{
		String status = null;
		try{
			status = driver.findElement(By.xpath("//table[@id='catalogListing']/tbody/tr[td[a[text()='"+catalogName+"']]]/td[2]/div")).getText().trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}

	public void editCatalogReceivedFromZSN(String catalogName) throws Exception{
		NewCatalog objNewCatalog= new NewCatalog(driver, logger);
		filterByCatalogName(catalogName);
		takeAction("Edit", catalogName);
		objNewCatalog.updateCatalogDetailsReceivedFromZSN(catalogName);
	}


	/**
	 * @return the pgHead
	 */
	public static By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead the pgHead to set
	 */
	public static void setPgHead(By pgHead) {
		Catalog.pgHead = pgHead;
	}
}
