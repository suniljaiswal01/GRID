package com.zycus.eProc.Requisition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Requisition_OnlineStore_SearchResults.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.filterByStatus: user shall be able to filter by Status 
 * <br>
 * 2.filterByReceivedOn: user shall be able to filter by Received On 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class OnlineStore_SearchResults extends eProc_CommonFunctions {
  private static By actionsList = By.id("cntToolbox");
  private static By addToCartAction = By.id("lnkAddMultipleToCart");
  private static By addToFavAction = By.id("lnkAddMultipleToFavorite");
  private static By addToBasketAction = By.id("lnkAddMultipleToBasket");
  private static By addToCompItemsAction = By.id("lnkCompareItems");
  private static By itemsFound = By.id("totalItemsFound");
  private static By processingLoader = By.id("tblSearchItemList_processing");
  private static By no_catalog_items_found = By.xpath("//*[@id='tblSearchItemList']//tr[contains(@id,'item_list_row')]");
  private static By search_results = By.xpath("//*[@id='tblSearchItemList']//tr[contains(@class,'dragToCart')]");
  private static By selectedItemsLblXpath = By.xpath("//div[@id='cart']/div[1]/span/span");
  private static By itemPriceLblXpath = By.xpath("//div[@id='cart']/div[1]/span[3]");
  private static By disabledCheckoutBtn = By.xpath("//*[@id='cart']/div[1]/a");

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public OnlineStore_SearchResults(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the search_results
   */
  public By getSearch_results() {
    return search_results;
  }

  /**
   * @param search_results
   *            the search_results to set
   */
  public void setSearch_results(By search_results) {
    this.search_results = search_results;
  }

  /**
   * @return the no_catalog_items_found
   */
  public By getNo_catalog_items_found() {
    return no_catalog_items_found;
  }

  /**
   * @param no_catalog_items_found
   *            the no_catalog_items_found to set
   */
  public void setNo_catalog_items_found(By no_catalog_items_found) {
    this.no_catalog_items_found = no_catalog_items_found;
  }

  /**
   * <b>Function:</b> addItemToCart_ByActions -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param quantity
   * @return result - True/False
   */

  public boolean addItemToCart_ByActions(int quantity) {
    boolean result = false;
    try {
      WebElement selectedItemsLbl = findElement(selectedItemsLblXpath);
      int numOfItems = Integer.parseInt(selectedItemsLbl.getText());

      WebElement itemPriceLbl = findElement(itemPriceLblXpath);
      float price = Float.parseFloat((itemPriceLbl.getText().split(" ", 2))[1]);

      // Select items in sequence - as per quantity
      for (int i = 1; i <= quantity; i++)
        findElement(By.xpath("(//input[contains(@id,'chk_item_list')])[i]")).click();
      if (findElement(actionsList)  !=  null)
        findElement(addToCartAction).click();

      if (findElement(By.xpath("//div[text()='" + quantity + " item(s) were added to cart']"))  !=  null) {
        LogScreenshot("Pass", quantity + " item(s) added to the cart message displayed");
        if (findElement(By
            .xpath("(//div[@class='item-incart itemInCart']/span/following-sibling::text())[1]"))  !=  null) {
          logger.pass("..already in the cart message displayed under Add to Cart button");
          if (numOfItems <= Integer.parseInt(selectedItemsLbl.getText())) {
            logger.pass("selected item count increased");
            if (price < Float.parseFloat((itemPriceLbl.getText().split(" ", 2))[1])) {
              logger.pass("Cart price increased on adding the item");
              if (findElement(disabledCheckoutBtn) == null) {
                logger.pass("Checkout button gets enabled");
                result = true;
              }
            }
          }
        }
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> addItemToFav_ByActions -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param quantity
   * @return result - True/False
   */

  public boolean addItemToFav_ByActions(int quantity) {
    boolean result = false;
    try {
      // Select items in sequence - as per quantity
      for (int i = 1; i <= quantity; i++)
        findElement(By.xpath("(//input[contains(@id,'chk_item_list')])[i]")).click();
      if (findElement(actionsList)  !=  null)
        findElement(addToFavAction).click();

      if (findElement(By.xpath("//div[text()='" + quantity + " item(s) were added to My Favorites']"))  !=  null) {
        logger.pass(quantity + " item(s) added to My Favorites message displayed");
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> addItemToBasket_ByActions -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param quantity
   * @return result - True/False
   */

  public boolean addItemToBasket_ByActions(int quantity) {
    boolean result = false;
    try {
      // Select items in sequence - as per quantity
      for (int i = 1; i <= quantity; i++)
        findElement(By.xpath("(//input[contains(@id,'chk_item_list')])[i]")).click();
      if (findElement(actionsList)  !=  null)
        findElement(addToBasketAction).click();

      OnlineStore_AddToBasket objAddToBasket = new OnlineStore_AddToBasket(driver, logger);
      if (findElement(objAddToBasket.getAddToBasketPg())  !=  null){
        logger.pass("Add to Basket page displayed");
        result = true;
      }else
        logger.fail("Add to Basket page not displayed");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> compareItems_ByActions -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param quantity
   * @return result - True/False
   */

  public boolean compareItems_ByActions(int quantity) {
    boolean result = false;
    try {
      // Select items in sequence - as per quantity
      for (int i = 1; i <= quantity; i++)
        findElement(By.xpath("(//input[contains(@id,'chk_item_list')])[i]")).click();
      if (!(driver.findElements(actionsList).size() > 0))
        findElement(addToCompItemsAction).click();
      if (quantity <= 1) {
        if (findElement(By.xpath("//div//td[text()='Please select at least 2 items for comparison']"))  !=  null)
          logger.pass("Alert message to select at least 2 items displayed");
        else
          logger.fail("Alert message to select at least 2 items not displayed");
      } else if (quantity > 4) {
        if (findElement(By.xpath("//div//td[text()='You can select upto 4 items for Comparison']"))  !=  null)
          logger.pass("Alert message to select upto 4 items displayed");
        else
          logger.fail("Alert message to select upto 4 items displayed");
      } else if (quantity > 1 && quantity <= 4) {
        OnlineStore_ProductComparison objProdComp = new OnlineStore_ProductComparison(
            driver, logger);
        if (!(driver.findElements(objProdComp.getCompareItemsPg()).size() > 0))
          logger.pass("Product Comparison page displayed");
        else
          logger.fail("Product Comparison page not displayed");
      }

      if (!(driver.findElements(By.xpath("//div[text()='" + quantity + " item(s) were added to My Favorites']")).size() > 0)) {
        logger.pass(quantity + " item(s) added to My Favorites message displayed");
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> addItemToCart -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param quantity
   * @return result - True/False
   */

  public boolean addItemToCart(int quantity) {
    boolean result = false;
    try {
      WebElement selectedItemsLbl = driver.findElement(selectedItemsLblXpath);
      int numOfItems = Integer.parseInt(selectedItemsLbl.getText());

      WebElement itemPriceLbl = driver.findElement(itemPriceLblXpath);
      //float price = Float.parseFloat((itemPriceLbl.getText().split(" ", 2))[1]);
      String price = String.valueOf(itemPriceLbl.getText().split(" ", 2)[1]);

      Thread.sleep(10000);
      if (quantity > 0)
        //Select search item not in Warehouse
        driver.findElement(By.xpath("(//tr[td[3]//span[text()='"+getLanguageProperty("Warehouse")+"']/following-sibling::span[text()='"+getLanguageProperty("N/A")+"']]//*[contains(@id,'quantity_list')])[1]")).sendKeys(String.valueOf(quantity));
      findElement(By.xpath("(//tr[td[3]//span[text()='"+getLanguageProperty("Warehouse")+"']/following-sibling::span[text()='"+getLanguageProperty("N/A")+"']]//*[contains(@id,'addToCart_list') and @title='"+getLanguageProperty("Add to Cart")+"'])[1]")).click();
      Thread.sleep(3000);
      if (driver.findElements(By.xpath("//div[div//td[contains(text(),'Do you wish to order')]]")).size() > 0)
        findElement(By.xpath("//div[div//td[contains(text(),'Do you wish to order')]]//button[span[text()='Yes']]")).click();
      if (driver.findElements(By.xpath("//div[@role='dialog'][div/span[text()='Add item to cart']]")).size() > 0)
        driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='Add item to cart']]//button[span[text()='Empty the Existing Cart and Add the Newly Selected Items']]")).click();
      
      if (waitFluent(By.xpath("//tr[td[3]//span[text()='Warehouse']/following-sibling::span[text()='N/A']]//div[@class='item-incart itemInCart']/span"))  !=  null)
        LogScreenshot("Pass", "..already in the cart message displayed under Add to Cart button");
      if (numOfItems + 1 <= Integer.parseInt(selectedItemsLbl.getText()))
        logger.pass("selected item count increased if different item chosen");
      /*if (price < Float.parseFloat((itemPriceLbl.getText().split(" ", 2))[1]))
        logger.pass("Cart price increased on adding the item");*/
      if (!waitFluent(disabledCheckoutBtn).getAttribute("class").contains("disableMe")) {
        logger.pass("Checkout button gets enabled");
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  
  /**
   * <b>Function:</b> addItemToCart -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param quantity
   * @return result - True/False
   */


  public boolean addItemToCart(int quantity,String item) {
    boolean result = false;
    try {
      WebElement selectedItemsLbl = driver.findElement(selectedItemsLblXpath);
      int numOfItems = Integer.parseInt(selectedItemsLbl.getText());

      WebElement itemPriceLbl = driver.findElement(itemPriceLblXpath);
      //float price = Float.parseFloat((itemPriceLbl.getText().split(" ", 2))[1]);
      String price = String.valueOf(itemPriceLbl.getText().split(" ", 2)[1]);

      Thread.sleep(10000);
      if (quantity > 0)
        //Select search item not in Warehouse
        //driver.findElement(By.xpath("//tr[1]//*[contains(@id,'quantity_list')]")).sendKeys(String.valueOf(quantity));
      	driver.findElement(By.xpath("(//*[contains(@id,'quantity_list')])[1]")).sendKeys(String.valueOf(quantity));
      //findElement(By.xpath("//tr[1]//*[contains(@id,'addToCart_list') and @title='Add to Cart']")).click();
      findElement(By.xpath("(//*[contains(@id,'addToCart_list') and @title='Add to Cart'])[1]")).click();
      Thread.sleep(3000);
      if (driver.findElements(By.xpath("//div[div//td[contains(text(),'Do you wish to order')]]")).size() > 0)
        findElement(By.xpath("//div[div//td[contains(text(),'Do you wish to order')]]//button[span[text()='Yes']]")).click();
      if (driver.findElements(By.xpath("//div[@role='dialog'][div/span[text()='Add item to cart']]")).size() > 0)
        driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='Add item to cart']]//button[span[text()='Empty the Existing Cart and Add the Newly Selected Items']]")).click();
      
      if (waitFluent(By.xpath("//tr[1]//div[@class='item-incart itemInCart']/span"))  !=  null)
        LogScreenshot("Pass", "..already in the cart message displayed under Add to Cart button");
      if (numOfItems + 1 <= Integer.parseInt(selectedItemsLbl.getText()))
        logger.pass("selected item count increased if different item chosen");
      /*if (price < Float.parseFloat((itemPriceLbl.getText().split(" ", 2))[1]))
        logger.pass("Cart price increased on adding the item");*/
      if (!waitFluent(disabledCheckoutBtn).getAttribute("class").contains("disableMe")) {
        logger.pass("Checkout button gets enabled");
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }


  /**
   * <b>Function:</b> addItemToFavorites -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param None
   * @return result - True/False
   * @throws Exception 
   */

  public void addItemToFavorites() throws Exception {
    // Select first search result to add to favorites
    WebElement addToFav = driver.findElement(By.xpath("(//label[contains(@id,'favorite_list') and not(@style)])[1]"));
    addToFav.click();
    if (driver.findElement(By.xpath("//em[text()='"+getLanguageProperty("Item added to favorites successfully")+"']"))  !=  null)
      if (addToFav.getAttribute("title") == getLanguageProperty("Remove from Favorites"))
        logger.pass("Item added to favorites");
      else{
        logger.fail("Item not added to favorites");
        throw new Exception();
      }
  }

  /**
   * <b>Function:</b> removeItemFromFavorites -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param None
   * @return result - True/False
   * @throws Exception 
   */

  public void removeItemFromFavorites() throws Exception {
    // Select first search result to remove from favorites
    WebElement removeFrmFav = driver.findElement(By.xpath("(//label[contains(@id,'favorite_list') and not(@style)])[1]"));
    removeFrmFav.click();
    findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
    if (driver.findElement(By.xpath("//em[text()='"+getLanguageProperty("Item removed from favorites successfully")+"']"))  !=  null)
      if (removeFrmFav.getAttribute("title") == getLanguageProperty("Remove from Favorites"))
        logger.pass("Item removed from favorites");
      else{
        logger.fail("Item not removed from favorites");
        throw new Exception();
      }
  }

  /**
   * <b>Function:</b> dragItemToCart -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param None
   * @return result - True/False
   */

  public boolean dragItemToCart() {
    boolean result = false;
    try {
      WebElement draggable = findElement(By.xpath("//*[@id='tblSearchItemList']/tbody/tr[1]"));
      WebElement droppable = findElement(By.xpath("//*[@id='cartHover']//span[@class='bld']"));
      new Actions(driver).dragAndDrop(draggable, droppable).build().perform();
      if (findElement(By.xpath(
          "//*[@id='cartHover']//span[@class='cartHoverTxt']/text()[contains(.,'"+getLanguageProperty("added to cart")+"')]"))  !=  null)
        logger.pass("1 EA added to cart message displayed");
      else
        logger.fail("1 EA added to cart message not displayed");
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> filterByChkboxType -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param chkBoxType
   * @param typeValue
   * @return result - True/False
   */

  public boolean filterByChkboxType(String chkBoxType, String typeValue) {
    boolean result = false;
    try {
      WebElement objItemsDisplayed = findElement(itemsFound);
      int itemsDisplayed = Integer.parseInt(objItemsDisplayed.getText());

      if ((chkBoxType == "All") | (chkBoxType == "None"))
        findElement(By.xpath("//div[@class='inptBx inptBxMltChk'][label[text()='" + chkBoxType
            + "']]/div/div[1]/a[text()='" + typeValue + "']")).click();
      else
        findElement(By.xpath("//div[@class='inptBx inptBxMltChk'][label[text()='" + chkBoxType
            + "']]/div/div[2]/label[@title='" + typeValue + "']")).click();
      if (findElement(processingLoader).getAttribute("style").contains("block")) {
        if (Integer.parseInt(objItemsDisplayed.getText()) <= itemsDisplayed)
          result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }

  /**
   * ---------------------------------------------------------------------------------
   * Function : filterByTextField
   * 
   * @param fieldName
   * @param fieldValue
   * @return result
   *         ---------------------------------------------------------------------------------
   *//*
     * 
     * public boolean filterByTextField1(String fieldName, String
     * fieldValue){ boolean result = false;
     * 
     * WebElement objItemsDisplayed = findElement(itemsFound); int
     * itemsDisplayed = Integer.parseInt(objItemsDisplayed.getText());
     * 
     * sendKeys(By.xpath("//div[@class='inptBx'][label[text()='"+fieldName+
     * "']]/div/input"), fieldValue);
     * if (findElement(processingLoader).getAttribute("style").contains(
     * "block")){
     * if (Integer.parseInt(objItemsDisplayed.getText())<=itemsDisplayed)
     * result = true; } return result; }
     */

  /**
   * <b>Function:</b> filterByRange -
   * 
   * @author Varun Khurana
   * @since April 2018
   * @param rangeName
   * @param minVal
   * @return result - True/False
   */

  public boolean filterByRange(String rangeName, String minVal) {
    boolean result = false;
    try {
      WebElement objItemsDisplayed = findElement(itemsFound);
      int itemsDisplayed = Integer.parseInt(objItemsDisplayed.getText());

      sendKeys(By.xpath("//div[@class='inptBx itmBxSlider'][label[text()='" + rangeName
          + "']]//input[@class='inptTxt minVal']"), minVal);
      if (findElement(processingLoader).getAttribute("style").contains("block")) {
        if (Integer.parseInt(objItemsDisplayed.getText()) <= itemsDisplayed)
          result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  public String checkOut() throws Exception{
	Thread.sleep(3000);
    findElement(By.xpath("//div[@id='cart']//a[span[text()='"+getLanguageProperty("Checkout")+"']]")).click();
    Checkout objChkOut  = new Checkout(driver, logger);
    waitUntilVisibilityOfElement(objChkOut.getPgHead());
    String requisition = objChkOut.createRequisition("");
    Thread.sleep(8000);
    if (driver.findElements(By.xpath("//table[@id='reqList']//td[contains(@class,'name')][contains(text(),'"+requisition+"')]")).size() > 0)
      LogScreenshot("Pass", "Requisition Name : "+ requisition + " created");
    else
      LogScreenshot("Fail", "Requisition Name : "+ requisition + " not created");
    return requisition;
  }

}
