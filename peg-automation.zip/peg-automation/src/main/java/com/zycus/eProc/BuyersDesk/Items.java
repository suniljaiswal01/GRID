package com.zycus.eProc.BuyersDesk;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eProc_CommonFunctions;

public class Items extends eProc_CommonFunctions{
  
  private String currency;
  
  public Items(WebDriver driver, ExtentTest logger) throws Exception { 
    super(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
        String[][] abc = (String[][]) objFunctions.dataProvider("QuickSourceEvent", Datasheet_eProc);
        this.currency = abc[0][0];
  }
  
  public void createQuickScEvent() throws Exception{
    String quickSrcName = "QuickSource_"+generateNo();
    selectItem();
    findElement(By.id("addQuickSourceEvent"),"+ Create Quick Source Event button").click();
    waitUntilVisibilityOfElement(By.id("dev_createQuickSourceDialog"));
    driver.findElement(By.id("txtEventName")).sendKeys(quickSrcName);
    enterText_AutoComplete(By.id("txtCurrency"), currency);
    
  }
  
  public void selectItem() throws Exception{
    Thread.sleep(20000);
    waitUntilInvisibilityOfElement(processingLoader,4);
    findElement(By.xpath("(//table[@id='buyerDeskItemListing']/tbody/tr/td/input[not(@disabled)])[1]")).click();
  }
  
  
  
  
}
