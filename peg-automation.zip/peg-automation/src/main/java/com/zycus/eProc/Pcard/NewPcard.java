package com.zycus.eProc.Pcard;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.eProc_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> NewPcard.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.filterByStatus: user shall be able to filter by Status 
 * <br>
 * 2.filterByReceivedOn: user shall be able to filter by Received On 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class NewPcard extends eProc_CommonFunctions {

	private String issuedTo;
	private String cardNo;
	private Date lastBilledOn;
	private String issuingBank;
	private String stmtFreq;
	private String  creditDays;
	private String issuedUserType;

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param issuedTo
	 * @param cardNo
	 * @param lastBilledOn
	 * @param issuingBank
	 * @param stmtFreq
	 * @param creditDays
	 */

	/*public NewPcard(WebDriver driver, ExtentTest logger, String issuedTo, String cardNo, Date lastBilledOn, String issuingBank, 
			String stmtFreq, int creditDays) {
		super(driver, logger);
		
		
		this.issuedTo = issuedTo;
		this.cardNo = cardNo;
		this.lastBilledOn = lastBilledOn;
		this.issuingBank = issuingBank;
		this.stmtFreq = stmtFreq;
		this.creditDays = creditDays;
	}*/


	public NewPcard(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eProc = configurationProperties.getProperty("Datasheet_eProc");
		String[][] abc = (String[][]) objFunctions.dataProvider("PCard", Datasheet_eProc);
		
		this.issuedUserType = abc[0][0];
		this.issuingBank = abc[0][1];
		this.stmtFreq = abc[0][2];
		this.creditDays = abc[0][3];
		
		
	}

	/**
	 * <b>Function:</b> addNewPcard -
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param type
	 * @param mm
	 * @param yy
	 * @param issuedUserType
	 * @param nameOnCard
	 * @param allowedOrgUnits
	 * @param spendPerTransaction
	 * @param transactionsPerDay
	 * @param spendPerDay
	 * @param transactionsPerCycle
	 * @param spendPerCyc
	 * @return result - True/False
	 */

	/*public boolean addNewPcard(String type, int mm, int yy, String issuedUserType, String nameOnCard,
			String allowedOrgUnits, int spendPerTransaction, int transactionsPerDay, int spendPerDay,
			int transactionsPerCycle, int spendPerCycle) {
		boolean result = true;
		try {
			findElement(By.xpath("//select[@id='txtType']/option[text()='" + type + "']")).click();
			findElement(By.xpath("//select[@id='txtExpiryMonth']/option[@value='" + mm + "']")).click();
			findElement(By.xpath("//select[@id='txtExpiryYear']/option[@value='" + yy + "']")).click();
			findElement(By.xpath("//select[@id='txtExpiryYear']/option[@value='" + yy + "']")).click();
			findElement(By.xpath("//label[input[contains(@id,'issuedTo')]]/text()[contains(.,'" + issuedUserType + "')]")).click();
			sendKeys(By.id("txtIssuedTo"), issuedTo);
			sendKeys(By.id("txtCardNo"), cardNo);
			findElement(By.xpath("//input[@id='txtStatementDate']/following-sibling::img")).click();
			selectDate(lastBilledOn);
			sendKeys(By.id("txtBankName"), issuingBank);
			findElement(By.xpath("//select[@id='txtBillingCycle']/option[@value='" + stmtFreq + "']")).click();
			sendKeys(By.id("txtCreditDays"), String.valueOf(creditDays));
			sendKeys(By.id("txtNameOnCard"), nameOnCard);
			findElement(By.xpath("//select[@id='txtOrganizationUnits']/option[@value='" + allowedOrgUnits + "']")).click();
			sendKeys(By.id("txtSpendPerTransaction"), String.valueOf(spendPerTransaction));
			sendKeys(By.id("txtTransactionsPerDay"), String.valueOf(transactionsPerDay));
			sendKeys(By.id("txtSpendPerDay"), String.valueOf(spendPerDay));
			sendKeys(By.id("txtTransactionsPerCycle"), String.valueOf(transactionsPerCycle));
			sendKeys(By.id("txtSpendPerCycle"), String.valueOf(spendPerCycle));
			findElement(By.id("btnSubmitPCard")).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}*/


	public void addNewPcard(String type) throws Exception {

		waitUntilVisibilityOfElement(By.id("pCardList"));
		
		WebElement addBtn = driver.findElement(By.xpath("//a[contains(@title,'Add')]"));
		clickElement(addBtn);
		
		waitUntilVisibilityOfElement(By.id("pCardDetails"));
		
		LogScreenshot("info","Adding "+type+" P Card");
		WebElement cardType = driver.findElement(By.xpath("//select[@id='txtType']/option[contains(text(),'"+type+"')]"));
		clickElement(cardType);
		
		WebElement expiryMonth = driver.findElement(By.xpath("//select[@id='txtExpiryMonth']/option[@value][1]"));
		clickElement(expiryMonth);
		
		WebElement expiryYear = driver.findElement(By.xpath("//select[@id='txtExpiryYear']/option[@value][2]"));
		clickElement(expiryYear);
		
		WebElement issuedType = driver.findElement(By.xpath("//label[input[contains(@id,'issuedTo')]]/input[@value='"+issuedUserType+"']"));
		clickElement(issuedType);
		Thread.sleep(3000);
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String issuedTo = supplierDetails.getCompanyName();
		enterSupplierDetails(issuedTo);
		
		if(!(driver.findElement(By.id("txtIssuedToSupplier")).getAttribute("value").equals(issuedTo))) {
			LogScreenshot("info","Supplier Details not added, Retrying.");
			enterSupplierDetails(issuedTo);
		}
		
		String cardNumber = generateCardNumber(type);
		setInput(By.id("txtCardNo"),cardNumber+ Keys.TAB);
		
		WebElement billedOn = driver.findElement(By.xpath("//input[@id='txtStatementDate']/following-sibling::img"));
		clickElement(billedOn);
		
		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String s = formatter.format(date);
		selectDate_v1(s);
		
		enterText_AutoCompleteIssuingBank(By.id("txtBankName"), issuingBank);	
		
		WebElement statementFrequency = driver.findElement(By.xpath("//select[@id='txtBillingCycle']/option[text()='" + stmtFreq + "']"));
		clickElement(statementFrequency);
		
		setInput(By.id("txtCreditDays"), String.valueOf(creditDays));
		setInput(By.id("txtNameOnCard"), "AutoCard_"+generateNo());
		
		
		WebElement orgUnit = driver.findElement(By.id("lnkComp"));
		clickElement(orgUnit);
		
		waitUntilVisibilityOfElement(By.id("companyTree"));
		
		int totalCompany = driver.findElements(By.xpath("//div[@id='slctComapany']//input")).size();
		
		Random rnd = new Random();
		int selectCompany = rnd.nextInt(totalCompany);
		
		WebElement companyName = driver.findElement(By.xpath("(//div[@id='slctComapany']//input)["+String.valueOf(1 + selectCompany) +"]"));
		clickElement(companyName);
		LogScreenshot("info","Company Selected");
		WebElement saveBtn = driver.findElement(By.id("selectCompanys"));
		clickElement(saveBtn);
		Thread.sleep(2000);
	
		findElement(By.id("btnSubmitPCard")).click();
		LogScreenshot("info","Submit Button Clicked");
		scroll_to_TopofPage();
		waitUntilVisibilityOfElement(By.id("pCardList"));
		clrAllFilters();
		driver.findElement(By.id("txtFltrCardNo")).sendKeys(cardNumber+ Keys.ENTER);
		waitUntilInvisibilityOfElement(processingLoader);
	
		if(driver.findElements(By.xpath("//table[@id='pCardList']//tr[td[contains(@class,'cardNo') and text()='"+cardNumber+"']]")).size()>0) {
			LogScreenshot("pass",type + " P card Added. Card Number:"+cardNumber);
			LogScreenshot("info","Deactivating Card");
			
			WebElement actionBtn = driver.findElement(By.xpath("//table[@id='pCardList']//tr[td[contains(@class,'cardNo') and text()='"+cardNumber+"']]//td[contains(@class,'actions')]"));
			actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Actions")+"']")).click();
			LogScreenshot("info", "Action Button clicked");
			actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Deactivate")+"']")).click();
			waitUntilVisibilityOfElement(By.id("frmDeactivatePcard"));
			setInput(By.id("deactivateComments"), "Deactivating Pcard");
			driver.findElement(By.xpath("//select[@id='deactivateReasons']/option[text()='"+getLanguageProperty("Expired")+"']")).click();
			LogScreenshot("info","Deactivating Details added");
			driver.findElement(By.id("deactivatePcard")).click();
			Thread.sleep(3000);
			LogScreenshot("info","Deactivate Button Clicked");
			if(driver.findElements(By.xpath("//div[contains(@class,'iConfirmBox')]")).size()>0) {
				LogScreenshot("info","Clicking yes button");
				driver.findElement(By.xpath("//div[contains(@class,'iConfirmBox')]//span[text()='Yes']")).click();
			}
					
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilVisibilityOfElement(By.id("pCardList"));
			waitUntilInvisibilityOfElement(processingLoader);
			
			if(driver.findElements(By.xpath("//table[@id='pCardList']//tr[td[contains(@class,'cardNo') and text()='"+cardNumber+"']]")).size()>0) {
				
				String status = driver.findElement(By.xpath("//td[contains(@class,'status')]//div")).getText();
				
				if(status.contains("Deactivated")) {
					LogScreenshot("pass",type +" P Card Deactivated Successfully");
				}else {
					LogScreenshot("fail",type +" P Card not  Deactivated");
				}
			}
		}
		
	}

	private void enterSupplierDetails(String supplierName) throws Exception {
		
		WebElement supplierInput = driver.findElement(By.id("txtIssuedToSupplier"));
		try{
			supplierInput.sendKeys(supplierName);
			//waitUntilVisibilityOfElement(By.xpath("//li[contains(@class,'ui-menu-item')]"));
			//By supplierList = By.xpath("//li[contains(@class,'ui-menu-item')]//span[text()='"+supplierName+"']");
			//clickElement(supplierList);	
			//Thread.sleep(2000);
	        waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
	        Thread.sleep(1500);
			findElement(By.xpath("//span[@aria-relevant='additions'][last()]/preceding-sibling::ul[li][1]/li/a[.|@span][contains(.,'"+supplierName+"')]")).click();
			LogScreenshot("pass",supplierName+ " Supplier Selected");
		}catch(Exception e){
			try{
				enterText_AutoComplete_eProc(By.id("txtIssuedToSupplier"), supplierName);
				LogScreenshot("pass",supplierName+ " Supplier Selected");
			}catch(Exception ex){
				LogScreenshot("fail",supplierName+ " Supplier not selected");
			}
		}
		
		
	}

}
