package com.zycus.eProc.PO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.eProc_CommonFunctions;

public class CreateReceipt_page extends eProc_CommonFunctions{
  
  private String receiptDt;
  
  private static By selectItemsChkbox     = By.id("chkAllItems");
  private static By consignNoId         = By.id("txt_consign");
  private static By shippedViaId       = By.id("txt_shipped_via");
  private static By airwayBillId       = By.id("txt_air_bill");
  private static By commentsId         = By.id("comment");
  private static By submitBtnId         = By.id("submitForm");
  private static By HeaderReqNum       = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName       = By.xpath("//h1[@class='pgHead']/span[3]");
  private static By addAttachmentsLink     = By.xpath("//a[@title='Add Attachments']");
  private static By attachFilePopUp       = By.xpath("//*[@id='addAttachment']/parent::div");
  private static By backBtn           = By.xpath("//div[@class='catFltr catFltr-tabbed']/a[@title='Back to Purchase Order listing']");
  
  private String consignmentNo;
  private String shippedVia;
  private String AirwayBillNo;
  private String Comments;
  
  public CreateReceipt_page(WebDriver driver, ExtentTest logger) throws Exception { 
    super(driver, logger);
    this.consignmentNo = "consignmentNo_"+generateNo();
    this.shippedVia = "shippedVia_"+generateNo();
    this.AirwayBillNo = "airwayBill_"+generateNo();
    this.Comments = "receiptComments";
  }
  

  public CreateReceipt_page(WebDriver driver, ExtentTest logger, String receiptDt) { 
    super(driver, logger);
    this.receiptDt = receiptDt;
    this.consignmentNo = "consignmentNo_"+generateNo();
    this.shippedVia = "shippedVia_"+generateNo();
    this.AirwayBillNo = "airwayBill_"+generateNo();
    this.Comments = "receiptComments";
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    this.HeaderReqNum = headerReqNum;
  }

  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    this.HeaderReqName = headerReqName;
  }
  
  
  /**
   * ---------------------------------------------------------------------------------
   * Function : enterDeliveryInfo
   * @param consignmentNo
   * @param shippedVia
   * @param AirwayBillNo
   * @param Comments
   * @param fileUploadPath
   * @return result
   * @throws Exception 
   */
  
  public String createNewReceipt(String saveOrSubmit) throws Exception{
    String receiptName = null;
    ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
    String fileUploadPath = configurationProperties.getProperty("upload_path");
  
    findElement(selectItemsChkbox).click();
      /*if (receiptDt != ""||receiptDt != null){
        findElement(By.xpath("//input[@id='txt_rcv_date']/following-sibling::img")).click();
        selectDate_v1(receiptDt);
      }*/
    /*driver.findElement(consignNoId).sendKeys(consignmentNo);
    driver.findElement(shippedViaId).sendKeys(shippedVia);
    driver.findElement(airwayBillId).sendKeys(AirwayBillNo);
    driver.findElement(commentsId).sendKeys(Comments);*/
    
    //Add Attachments
    WebElement objAttachmentLink = driver.findElement(addAttachmentsLink);
    String attachmentLinkTxt = objAttachmentLink.getText();
    objAttachmentLink.click();
    waitUntilVisibilityOfElement(attachFilePopUp);
    //if (driver.findElement(attachFilePopUp) != null)
    
    LogScreenshot("info","Uploading Attachment");
    ConfigurationProperties config = ConfigurationProperties.getInstance();
    driver.findElement(By.xpath("//input[contains(@id,'attachmentInput_receiptAttachment') and contains(@style,'block')]")).sendKeys(config.getProperty("upload_path"));

    //uploadFile(fileUploadPath);
    waitUntilVisibilityOfElement(By.xpath("//table[@class='attachmentsContainer zytbl']//td[2][text()='"+getLanguageProperty("Uploaded")+"']"));
    findElement(By.xpath("//*[contains(@id,'closeAttachmentDialog')]")).click();      
    //Verify if file is uploaded
    if (attachmentLinkTxt == objAttachmentLink.getText())
      LogScreenshot("Info", "Attachment file not uploaded");
    
    
    if (saveOrSubmit.equals("submit")){
    LogScreenshot("info","Clicking Submit Button");
      findElement(submitBtnId).click();
      waitUntilInvisibilityOfElement(processingLoader,4);
      if (driver.findElements(By.xpath("//td[contains(text(),'The selected items will be marked received')]/ancestor::div[contains(@class,'promptbx')]")).size() > 0){
        findElement(By.xpath("//div[contains(@class,'promptbx')]/div[3]//span[text()='Yes']")).click();
        //waitUntilVisibilityOfElement(By.xpath("//div[@id='hedaerSuccessBox']//li[text()='Receipt submitted successfully']"));
        Thread.sleep(2000);
        if (driver.findElements(By.xpath("//td[contains(text(),'Receipt details entered are not valid')]/ancestor::div[contains(@class,'promptbx')]")).size() > 0){
          findElement(By.xpath("//div[contains(@class,'promptbx')]/div[3]//span[text()='Continue']")).click();
          //waitUntilVisibilityOfElement(By.xpath("//div[@id='hedaerSuccessBox']//li[text()='Receipt submitted successfully']"));
        }
      }
      waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]"));
      Thread.sleep(6000);
      if(driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']")).size()>0) {
    	  //Thread.sleep(16000);
    	  waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn' and not(contains(@class,'disableMe'))]"));
    	  LogScreenshot("Info", "Receipt approval list displayed");
          //int approvalsReqCount = getApproversCount();
          findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']")).click();
          waitUntilInvisibilityOfElement(processingLoader,4);
          waitUntilInvisibilityOfElement(By.id("receiptItems"));
          waitUntilVisibilityOfElement(backBtn);
          Thread.sleep(4000);
          LogScreenshot("Pass", "Receipt submitted successfully");
      }      
    }else if (saveOrSubmit.equals("saveAsDraft")){
      findElement(By.id("saveAsDraft")).click();
      waitUntilInvisibilityOfElement(processingLoader,4);
      if (driver.findElements(By.xpath("//td[contains(text(),'The selected items will be marked received')]/ancestor::div[contains(@class,'promptbx')]")).size() > 0){
        findElement(By.xpath("//div[contains(@class,'promptbx')]/div[3]//span[text()='Yes']")).click();
        //waitUntilVisibilityOfElement(By.xpath("//div[@id='hedaerSuccessBox']//li[text()='Receipt submitted successfully']"));
        Thread.sleep(2000);
        if (driver.findElements(By.xpath("//td[contains(text(),'Receipt details entered are not valid')]/ancestor::div[contains(@class,'promptbx')]")).size() > 0){
          findElement(By.xpath("//div[contains(@class,'promptbx')]/div[3]//span[text()='Continue']")).click();
          //waitUntilVisibilityOfElement(By.xpath("//div[@id='hedaerSuccessBox']//li[text()='Receipt submitted successfully']"));
        }
      }
    }
    waitUntilInvisibilityOfElement(processingLoader,4);
    waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'overlay')]"),4);
    Thread.sleep(20000);
    receiptName = driver.findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[2][text()='"+getLanguageProperty("Receipt")+"']]/td[1]/a")).getAttribute("title");
    return receiptName;
  }
  
  public String createNewReturnNote(String saveOrSubmit, int returnQty) throws Exception{
    String returnNoteName = null;
    ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
    String fileUploadPath = configurationProperties.getProperty("upload_path");
  
    findElement(selectItemsChkbox).click();
    
    driver.findElement(By.xpath("//input[@class='frmEle returnQty']")).sendKeys(String.valueOf(returnQty));
    findElement(By.xpath("//select[@class='frmEle reasonForReturn']/option[@title='Damaged Item']")).click();
    findElement(By.xpath("//select[@class='frmEle returnMethod']/option[@title='Credit Memo']")).click();
    
    //Add Attachments
    /*WebElement objAttachmentLink = driver.findElement(addAttachmentsLink);
    String attachmentLinkTxt = objAttachmentLink.getText();
    objAttachmentLink.click();
    if (findElement(attachFilePopUp) != null)
      uploadFile(fileUploadPath);
    waitUntilVisibilityOfElement(By.xpath("//table[@class='attachmentsContainer zytbl']//td[2][text()='Uploaded']"));
    findElement(By.xpath("//*[contains(@id,'closeAttachmentDialog')]")).click();      
    //Verify if file is uploaded
    if (attachmentLinkTxt == objAttachmentLink.getText())
      LogScreenshot("Info", "Attachment file not uploaded");*/
    
    if (saveOrSubmit.equals("submit")){
      findElement(By.id("submitReturnNote")).click();
      findElement(By.xpath("//div[@role='dialog'][div//td[text()='System will finalize the Return Note. Do you want to continue?']]//button[span[text()='"+getLanguageProperty("Continue")+"']]")).click();
      waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]"));
      Thread.sleep(8000);
      try{
	      waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']"));
	      LogScreenshot("Info", "Return Note approval list displayed");
	      //int approvalsReqCount = getApproversCount();
	      findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//input[@id='approvalSubmitBtn']")).click();
      }catch(Exception e){
    	  e.printStackTrace();
      }
      waitUntilInvisibilityOfElement(processingLoader,4);
      waitUntilVisibilityOfElement(backBtn);
      Thread.sleep(4000);
      LogScreenshot("Pass", "Return Note submitted successfully");
    }else if (saveOrSubmit.equals("saveAsDraft"))
      findElement(By.id("saveAsDraft")).click();
    /*if (driver.findElement(By.xpath("//td[contains(text(),'The selected items will be marked received')]/ancestor::div[contains(@class,'promptbx')]")) != null){
      findElement(By.xpath("//div[contains(@class,'promptbx')]/div[3]//span[text()='Yes']")).click();
      //waitUntilVisibilityOfElement(By.xpath("//div[@id='hedaerSuccessBox']//li[text()='Receipt submitted successfully']"));
      Thread.sleep(2000);
      if (driver.findElement(By.xpath("//td[contains(text(),'Receipt details entered are not valid')]/ancestor::div[contains(@class,'promptbx')]")) != null){
        findElement(By.xpath("//div[contains(@class,'promptbx')]/div[3]//span[text()='Continue']")).click();
        //waitUntilVisibilityOfElement(By.xpath("//div[@id='hedaerSuccessBox']//li[text()='Receipt submitted successfully']"));
      }
    }*/
    waitUntilVisibilityOfElement(ReceiptsList.receiptsListTable);
    Thread.sleep(3000);
    /*ReceiptsList objList = new ReceiptsList(driver, logger);
    if (saveOrSubmit.equals("submit"))
      objList.filterByStatus("Confirmed");
    else if (saveOrSubmit.equals("saveAsDraft"))
      objList.filterByStatus("Draft");*/
    returnNoteName = driver.findElement(By.xpath("//table[@id='tblReceiptListing']/tbody/tr[td[2][text()='"+getLanguageProperty("Return Note")+"']]/td[1]/a")).getAttribute("title");
    return returnNoteName;
  }
}
