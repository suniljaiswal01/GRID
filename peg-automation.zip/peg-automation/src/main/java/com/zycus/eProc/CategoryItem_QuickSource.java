package com.zycus.eProc;

import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;

import common.Functions.iSource_CommonFunctions;

public class CategoryItem_QuickSource extends iSource_CommonFunctions {

  String itemname = "AutoPen" + generateNo();
  private String eventid;

  public Actions action = null;

  public CategoryItem_QuickSource(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    action = new Actions(driver);
  }

  public String createQSEvent(String SupplierContactName,String SupplierCompanyName) throws Exception {
    waitUntilVisibilityOfElement(By.xpath("//button[@title='Create Inquiry']"));
    LogScreenshot("pass", "Create Quick Source Page Displayed");

    try {
      fillEventDetails(SupplierContactName,SupplierCompanyName);
    } catch (Exception e) {
      LogScreenshot("fail", "Unable to Create QuickSource");
    }

    Thread.sleep(3000);
    driver.findElement(By.xpath("//button[text()='Send']")).click();
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Got it!']")));
    Thread.sleep(2000);
    LogScreenshot("pass", "Event Sent For Response from Supplier");
    driver.findElement(By.xpath("//button[text()='Got it!']")).click();
    waitUntilVisibilityOfElement(By.xpath("//button[@title='Create Inquiry']"));
    eventid = driver.findElement(By.xpath("//p[@title='" + itemname + "'] //span[@class='md-caption']")).getText();
    return eventid;
  }

  private void fillEventDetails(String SupplierContactName,String SupplierCompanyName) throws Exception {
    String eventName = "AutoQSEvent_"+generateNo();
    String currency = null;
    
    driver.findElement(By.id("txtEventName")).sendKeys(eventName);
    enterText_AutoComplete_eProc(By.id("txtCurrency"), currency);
    
    enterClosingDate();
    enterItemDetails();
    enterSupplierQuestion();
    enterSupplierOpeningMsg();
    inviteSuppliersToBid(SupplierContactName,SupplierCompanyName);
    
    findElement(By.id("createQuickSource"),"Create button").click();
    waitUntilInvisibilityOfElement(processingLoader,4);
    
    LogScreenshot("pass", "Quick Source Event created");
    
    
  }

  private void enterItemDetails() throws Exception {

    WebElement itemNameElement = driver.findElement(By.xpath("//input[@placeholder='Item Name']"));
    moveToElementAndEnterData(itemNameElement, itemname);

    WebElement itemQtyElement = driver.findElement(By.xpath("//input[@placeholder='Quantity']"));
    moveToElementAndEnterData(itemQtyElement, "10");

    WebElement itemUom = driver.findElement(By.xpath("//input[@placeholder='UOM']"));
    moveToElementAndEnterData(itemUom, "number");

    LogScreenshot("pass", "Item Details Added");
  }

  private void moveToElementAndEnterData(WebElement element, String data) throws Exception {

    try {
      element.clear();
      element.click();
      element.sendKeys(data);
      Thread.sleep(2000);
    } catch (ElementClickInterceptedException e) {
      scroll_into_view_element(element);
      element.click();
      element.sendKeys(data);
      Thread.sleep(2000);
    }

  }

  private void enterSupplierQuestion() throws Exception {

    WebElement supplierQuestion = driver.findElement(By.xpath("//input[@placeholder='Write a question here']"));
    moveToElementAndEnterData(supplierQuestion, "Auto entered question");
    
    LogScreenshot("pass", "Supplier Question Details Added");
  }

  private void enterSupplierOpeningMsg() throws Exception {

    // scroll_down(200);
    Thread.sleep(2000);
    WebElement supplierOpeneingMsg = driver.findElement(By.xpath("//textarea[@id='openingMessage']"));
    moveToElementAndEnterData(supplierOpeneingMsg, "Hi This is Auto QS Event");

    LogScreenshot("pass", "SupplierOpening Details Added");
    Thread.sleep(2000);
  }

  private void inviteSuppliersToBid(String SupplierContactName,String supplierCompanyName) throws Exception {
    
    WebElement supplierToBid = driver.findElement(By.xpath("//input[contains(@name,'companyName')]"));
    scroll_into_view_element(supplierToBid);
    enterText_AutoComplete_eProc(By.xpath("//input[contains(@name,'companyName')]"), supplierCompanyName);
    Thread.sleep(2000);
    enterText_AutoComplete_eProc(By.xpath("//input[contains(@name,'suppContact')]"), SupplierContactName);
    
  }

  private void enterClosingDate() throws Exception {
    String domain;
    String currhour = getcurrhour();
    String currDay = getDay();
    int k = Integer.parseInt(currDay) + 1;
    currDay = k + "";

    if (Integer.parseInt(currhour) > 12) {
      domain = "PM";
      int newcurrhour = Integer.parseInt(currhour) - 12;
      currhour = newcurrhour + "";
    } else
      domain = "AM";
    
    findElement(By.xpath("//input[@id='closeDate']/following-sibling::img")).click();
    Thread.sleep(1500);
    selectDate_v1(LocalDate.now().plusDays(1).toString());
    
    driver.findElement(By.id("txtHours")).sendKeys(currhour);
    driver.findElement(By.id("txtMin")).sendKeys(String.valueOf(0));
    findElement(By.xpath("//select[@id='meridiem']/option[@value='"+domain+"']")).click();
    LogScreenshot("pass", "Closing Time Added");
  }

  public void quickSourceAward(String supplierName, String eventid) throws Exception {

    if (driver.findElements(By.xpath("//label[@class='cns_CancelNotification']")).size() > 0) {
      JavascriptExecutor js = (JavascriptExecutor) driver;
      js.executeScript("arguments[0].click()",
          driver.findElement(By.xpath("//label[@class='cns_CancelNotification']")));

    }

    Thread.sleep(3000);
    findElement(By.xpath("//input[@id='searchInput']")).click();
    findElement(By.xpath("//input[@id='searchInput']")).sendKeys(eventid);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='in inquiry ID']")));
    Thread.sleep(1000);
    findElement(By.xpath("//span[text()='in inquiry ID']")).click();

    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='" + eventid + "'] ")));
    findElement(By.xpath("//span[text()='" + eventid + "'] ")).click();

    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@name='vm.frmSplitField']")));

    if (driver.findElements(By.xpath("//p[text()='SUBMITTED  ']")).size() > 0) {
      LogScreenshot("pass", "Event Award Started");
      findElement(By.xpath("//span[contains(text(),'" + supplierName + "')]")).click();
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Savings as per your selection : ')]")));
      findElement(By.xpath("//button[@title='AWARD']")).click();
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='mx-tabs']")));
      clickElement(By.xpath("//span[text()='Award Reason ']"));
//      driver.findElement(By.xpath("//span[text()='Award Reason ']")).click();
      Thread.sleep(5000);
      driver.findElement(By.xpath("//div[contains(@ng-show,'internal')]//textarea[@name='message']")).clear();
      driver.findElement(By.xpath("//div[contains(@ng-show,'internal')]//textarea[@name='message']"))  .sendKeys("Auto Award Reason");

      findElement(By.xpath("//span[text()='Award note to Suppliers ']")).click();
      Thread.sleep(5000);
      driver.findElement(By.xpath("//div[contains(@ng-show,'external')]//textarea[@name='message']")).clear();
      driver.findElement(By.xpath("//div[contains(@ng-show,'external')]//textarea[@name='message']")).sendKeys("Auto Award Note to Supplier");

      findElement(By.xpath("//button[text()='AWARD']")).click();

      waitUntilVisibilityOfElement(By.xpath("//span[text()='Inquiry has been awarded']"));
      LogScreenshot("pass", "Event Awarded Successfully");

    }

  }

  public void responseToEvent(String supplierName, String eventId) throws Exception {

    ViewSourcingEvents objEvents = new ViewSourcingEvents(driver, logger);
    objEvents.selectSupplierCompany();
    objEvents.filterByEventID(eventId);
    objEvents.enterInquiryQuickSource("QuickSource", eventId, "10", "10");

  }

}
