package com.zycus.eProc.eForms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Framework.ConfigurationProperties;
import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> AllForms.java
 * <br>
 * <b> Description: </b> To perform select New eForm 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewForm: user shall be able to filter by Status 
 * <br>
 * 2.addSection: user shall be able to filter by Received On 
 * <br>
 * 3.addfield 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class Import_Eforms_via_File extends eInvoice_CommonFunctions {

  private static By pgHead = By.xpath("//h1[@class='pgHead'][span[contains(text(),'Import eForms Via File')]]");
  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public Import_Eforms_via_File(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }
  
  public boolean createFileUpload() throws Exception {
    boolean result = false;
    int Iteration = 1;
    try {
      importEformFile();
      selectEFormScope_new(Iteration);
      clickAndWaitUntilLoaderDisappears(By.xpath("//input[@value='Save and Continue']"), By.id("status_overlay_saveForm"));
      while (findElement(By.xpath("//*[@id='scopesExistsMessageContainer']/div/div[2]"))  !=  null) {
        Iteration++;
        selectEFormScope_new(Iteration);
        clickAndWaitUntilLoaderDisappears(By.id("btnImportEform"), By.id("status_overlay_saveForm"));
      }
      if (driver.findElement(By.xpath("//b[@class='gblMsgHdr' and contains(text(),'following eForms have been uploaded')]")).isDisplayed()){
        findElement(By.id("cancelImportEform")).click();
        //Code remaining to verify if eForm created
        result = true;
      }
    } catch (Exception e) {
    e.printStackTrace();
    }
    return result;
  }
  
  
  private void importEformFile() throws Exception {
    //boolean result = false;
    ConfigurationProperties objConfig = ConfigurationProperties.getInstance();
    String filePath = objConfig.getProperty("Auto_Sample_eForm");
    try {
      uploadFile(filePath);
      waitUntilVisibilityOfElement(By.xpath("//div[@id='uploader_attachment']//div[@class='uploadifyProgress' and not(contains(@style,'none'))]"));
      logger.log(Status.PASS, "eForm uploaded successfully");
    } catch (Exception e) {
    e.printStackTrace();
      logger.log(Status.PASS, "eForm not uploaded");
    }
    //return result;
  }
  
  private void selectEFormScope_new(int iterationNo) throws Exception {
    try {
      findElement(By.id("lnkBUs")).click();
      Thread.sleep(10000);
      if (iterationNo > 1)
        changeScope_new(iterationNo);
      selectOrgUnit_and_Bank(iterationNo);
    } catch (Exception e) {
    e.printStackTrace();
    }
  }
  
  private void changeScope_new(int IteratioNo) throws Exception {
    try {
      String businessUnitList_xpath = "//div[@class='treeContainer treeview']/ul";
      // findElement(By.id("lnkBUs")).click();
      wait_untilVisible(findElement(By.xpath(businessUnitList_xpath)));
      findElement(By.xpath("//div[@class='treeContainer treeview']//input[@checked]")).click();
      // selectOrgUnit_and_Bank(IteratioNo);
    } catch (Exception e) {
    e.printStackTrace();
      throw new Exception();
    }
  }

  /**
   * <b>Function:</b> selectOrgUnit_and_Bank
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param IterationNo
   * @return None
   * @throws Exception
   */

  private void selectOrgUnit_and_Bank(int IterationNo) throws Exception {
    try {
      String businessUnitList_xpath = "//div[@class='treeContainer treeview']/ul";
      if (findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Select Companies & Business Units")+"']]")).isDisplayed()) {
        wait_untilVisible(findElement(By.xpath(businessUnitList_xpath)));
        if (findElement(By.xpath(businessUnitList_xpath))  !=  null) {
          // Selecting first Company & Business unit from the
          // displayed list tree
          findElement(By.xpath(
              "//div[@class='treeContainer treeview']//li[" + String.valueOf(IterationNo) + "]//input"))
                  .click();
          try {
            findElement(By.xpath("//div[contains(@style,'block')]//input[@value='"+getLanguageProperty("Save")+"']")).click();
          } catch (Exception e) {
            if (findElement(By
                .xpath("//div[contains(@class,'promptbx')][//td[contains(text(),'"+getLanguageProperty("Please select atleast one scope")+"')]]"))
                    .isDisplayed())
              findElement(By.xpath("//button/span[text()='"+getLanguageProperty("OK")+"']")).click();
            LogScreenshot("Info", "Please select atleast one scope - message displayed");
          }
        } else
          LogScreenshot("Info", "No results found - message displayed");

      }
    } catch (Exception e) {
    e.printStackTrace();
      throw new Exception();
    }
  }
  


  /**
   * @return the pgHead
   */
  public By getPgHead() {
    return pgHead;
  }

  /**
   * @param pgHead the pgHead to set
   */
  public void setPgHead(By pgHead) {
    this.pgHead = pgHead;
  }

}
