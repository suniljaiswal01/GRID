package com.zycus.crms.reportGeneration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.ExtentTest;
import com.pages.iRequest.English.crms.CreateReportsPage;
import com.pages.iRequest.English.crms.ReportTablePage;
import com.pages.iRequest.English.crms.Report_homePage;

import Framework.CommonUtility;

public class CreateNewReport extends CommonUtility {

	public CreateNewReport(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	public boolean selectProduct(String product) throws Exception {
		CreateReportsPage createReportPage = new CreateReportsPage(driver);
		String locator_product = createReportPage.productTab_link.replace("<<ProductName>>", product);
		boolean flag = false;
		boolean productPresent = false;
		do {
			try {
				driver.findElement(By.xpath(locator_product)).click();
				LogScreenshot("Pass", "product is selected for the parameter selection");
				productPresent = true;
				flag = false;
			} catch (Exception e) {
				flag = true;
				try {
					boolean moreProduct = createReportPage.swipeNext_button.getAttribute("class").contains("disabled");
					if(!moreProduct)
						createReportPage.swipeNext_button.click();
					else {
						flag = false;
						LogScreenshot("fail", product+ " product not present in CRMS");
						createReportPage.closePopUpBtn.click();
					}

				}catch (Exception e1) {
					flag = false;
					LogScreenshot("fail", product+ " product not present in CRMS");
				}	
			}
		} while (flag);
		return productPresent;
	}

	public void navigateTocreateNewReport() throws Exception {
		Report_homePage reportHome = new Report_homePage(driver);
		scroll_to_TopofPage();
		clickElement(reportHome.createReport_button);
		CreateReportsPage createReportsPage = new CreateReportsPage(driver);
		waitUntilVisibilityOfElement(createReportsPage.addFields_popup);
		verifyElementExist(createReportsPage.addFields_popup, "Navigated to reports add fields page");
	}

	public void selectParams(String category, String... data) throws Exception {
		CreateReportsPage createReportPage = new CreateReportsPage(driver);
		/*	
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet = System.getProperty("user.dir") + configurationProperties.getProperty(dataSheetName);

		String[][] paramList = (String[][]) objFunctions.dataProvider("crms_reportGeneration",Datasheet);*/

		//		for (String[] strings : paramList) {
		//			category = strings[0];
		String locator_param ;
		String locator_paramCheckbox;
		String locator_category = createReportPage.categoryTab.replace("<<CategoryName>>", category);
		clickElement(By.xpath(locator_category));
		//			driver.findElement(By.xpath(locator_category)).click();
		int param_Selected = 0;
		for (int i = 0; i < data.length; i++) {
			// strings[i] write the value and select the check box
			setInput(createReportPage.parameterSearch_input, data[i]);
			if(driver.findElements(By.xpath("//div[@class='empty-message']")).size()>0) {
				clickElement(By.xpath("//a[contains(@class,'clear-icon') and contains(@style,'flex')]"));
				setInput(createReportPage.parameterSearch_input, data[i]);
			}
			//				waitUntilInvisibilityOfElement(createReportPage.loaderInProgress);
			//				waitUntilInvisibilityOfElement(createReportPage.loader);
			Thread.sleep(2000);
			locator_param = createReportPage.parameterLabel_checkbox.replace("<<ParamValue>>", data[i]);
			locator_paramCheckbox = createReportPage.parameter_checkbox.replace("<<ParamValue>>", data[i]);
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(locator_param))));
			log4jLogger.info("Selecting   "+ data[i]);
			driver.findElement(By.xpath(locator_param)).click();
			verifyTrue(checkIfSelected(driver.findElement(By.xpath(locator_paramCheckbox))), "Parameter is selected  "+ data[i]);
			waitUntilInvisibilityOfElement(createReportPage.loaderInProgress);
			clickElement(createReportPage.clearSearchBox_button);
		}
		//		}
		// click on apply and generate report
		clickElement(createReportPage.applySearch_button);
		//add loader wait until invisible
		waitUntilInvisibilityOfElement(By.id("status_overlay_undefined"));
		waitUntilInvisibilityOfElement(createReportPage.loaderInProgress);
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		verifyElementExist(reportTablePage.reportGrid, "Report created for "+ category+" details search");
	}

}
