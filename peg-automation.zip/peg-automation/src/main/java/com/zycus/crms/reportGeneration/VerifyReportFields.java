package com.zycus.crms.reportGeneration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.main.eProcFlows.PurchaseOrderCreation_WithInvoice;
import com.main.eProcFlows.Requisition_Receipt;
import com.main.iContractFlows.CreateClauseTest;
import com.main.iContractFlows.CreateContractTest;
import com.main.iContractFlows.CreateTemplateTest;
import com.main.iPerformFlows.CloneEventTest;
import com.main.iPerformFlows.CreateEvent;
import com.main.iPerformFlows.CreateProgram;
import com.main.iPerformFlows.CreateSCAR;
import com.main.iPerformFlows.KPI;
import com.main.iPerformFlows.ScoreCard;
import com.main.iRequestFlows.ContractRequest;
import com.main.iRequestFlows.NoneRequest;
import com.main.iRequestFlows.SourcingRequest;
import com.main.iRequestFlows.iManageRequest;
import com.main.iSaveFlows.QuickProject;
import com.main.iSaveFlows.StrategicProjectFlow;
import com.main.iSourceFlows.DutchAuctionReverse;
import com.main.iSourceFlows.EngAuctionReverse;
import com.main.iSourceFlows.QuickSourceTest;
import com.main.iSourceFlows.RFIEvent;
import com.main.iSourceFlows.RFPEventThreeSixtyAnalysis;
import com.main.iSourceFlows.RFQEventBidOptimization;
import com.main.iSourceFlows.TwoBiddingEnvelope;
import com.pages.iRequest.English.crms.ReportTablePage;
import com.pages.iRequest.English.crms.Report_homePage;

import common.Functions.CRMS_CommonFunction;

public class VerifyReportFields extends CRMS_CommonFunction  {

	WebDriver driver;
	ExtentTest logger;
	String projectName = null;

	public VerifyReportFields(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		this.driver = driver;
		this.logger = logger;

	}

	public void iRequestFieldCheck(String category, String endpoint) throws Exception{
		String searchData = null;
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		switch(endpoint) {
		case "None":
			switch(category) {
			case "RequestDefinition":
				searchData = NoneRequest.newNoneReqDef;
				//				searchData="AG TEST";
				break;
			case "Request":
				searchData = NoneRequest.newNoneReqType;
				//				searchData = "AutoRequest_241525";
				break;
			case "RequestType":
				searchData = NoneRequest.newRequest;
				//				searchData = " AutoReqType_140086";
				break;
			}
			break;
		case "Contract":
			switch(category) {
			case "RequestDefinition":
								searchData = ContractRequest.newContractReqDef;
//				searchData="RequestDef_586678";
				break;
			case "Request":
								searchData = ContractRequest.newRequest;
//				searchData = "AutoRequest_241525";
				break;
			case "RequestType":
								searchData = ContractRequest.newContractReqType;
//				searchData = " AutoReqType_140086";
				break;
			}
			break;
		case "Sourcing":
			switch(category) {
			case "RequestDefinition":
								searchData = SourcingRequest.newSrcReqDef;
//				searchData="RequestDef_586678";
				break;
			case "Request":
								searchData = SourcingRequest.newRequest;
//				searchData = "AutoRequest_241525";
				break;
			case "RequestType":
								searchData = SourcingRequest.newSrcReqType;
//				searchData = " AutoReqType_140086";
				break;
			}
			break;
		case "iManage":
			switch(category) {
			case "RequestDefinition":
								searchData = iManageRequest.newManageReqDef;
//				searchData="RequestDef_586678";
				break;
			case "Request":
								searchData = iManageRequest.newRequest;
//				searchData = "AutoRequest_241525";
				break;
			case "RequestType":
								searchData = iManageRequest.newManageReqType;
//				searchData = " AutoReqType_140086";
				break;
			}
			break;
		}
		if(searchData!=null) {
			verifyElementExist(reportTablePage.iRequest_createdOnSorting_button, "report page is displayed");
			filterColumns("Created On", "customizeDate selected", searchData);
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", searchData);
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "created Request are displayed in the report");
			}catch (Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}
			
		}
		else {
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");
		}		
	}


	public void iSupplierFieldCheck(String supplierName) throws Exception{
		if(supplierName!=null) {
			System.out.println(supplierName);
			ReportTablePage reportTablePage = new ReportTablePage(driver);
			verifyElementExist(reportTablePage.iSupplier_createdOnSorting_button, "report page is displayed");
			Thread.sleep(5000);	
	
			filterColumns("Supplier Name", "CONTAINS", supplierName);	
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", supplierName);				
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "created Supplier is displayed in the report");
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}

		}
		else
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");
	}

	public void backToReportListing() throws Exception {
		ReportTablePage reportTablePage= new ReportTablePage(driver);
		clickElement(reportTablePage.backToListing_button);
		clickElement(reportTablePage.doNotSaveReport_button);
		Report_homePage reportsHome = new Report_homePage(driver);
		verifyElementExist(reportsHome.createReport_button, "Navigated back to reports home page");

	}



	public void iPerformFieldCheck(String category) throws Exception{
		String searchData = null;
		String colName = null;
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		switch(category) {
		case "Event":
			searchData= CreateEvent.NewEvent;
			colName = "Event Name";
			break;
		case "KPI":
			searchData = KPI.KPI;
			colName = "KPI Name";
			break;
		case "Program":
			searchData = CreateProgram.newProgFromScratch;
			colName = "Program Name";
			break;
		case "SCAR":
			searchData = CreateSCAR.newSCAR;
			colName = "SCAR Number";
			break;
		case "Scorecard":
			searchData = ScoreCard.Scorecard;
			colName = "Scorecard Name";
			break;
		}
		if(searchData!=null) {

			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");
			filterColumns(colName, "CONTAINS", searchData);
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", searchData);
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "created values are displayed in the report");
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}

		}
		else {
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");
		}		
	}


	public void iSaveFieldCheck(String category) throws Exception{
		String searchData = null;
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		switch(category) {
		case "Quick Project":
//						searchData ="AutoProj_155293";
			searchData=QuickProject.quickProjName;
			break;
		case "Strategic Project":
			//			searchData = NoneRequest.newSrcReqDef;
			searchData=StrategicProjectFlow.strategicProjName;
			break;
		}
		if(searchData!=null) {

			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");
			filterColumns("Project Title", "CONTAINS", searchData);
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", searchData);
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), category+ ":created values are displayed in the report");
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}
			clickElement(reportTablePage.clearFilter);
			waitUntilInvisibilityOfElement(By.id("status_overlay_undefined"));
		}
		else {
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");
		}		
	}
	
	
	public void iSourceFieldCheck(String type) throws Exception{
		String searchData = null;
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		switch(type) {
		case "RFI":
			searchData = RFIEvent.eventID;
//			searchData="1000073731";
			break;
		case "RFQ":
			searchData = RFQEventBidOptimization.eventID;
//			searchData="1000073729";
			break;
		case "RFP":
			searchData = RFPEventThreeSixtyAnalysis.eventID;
//			searchData="1000073726";
			break;
		case "Dutch":
			searchData = DutchAuctionReverse.eventID;
//			searchData="1000073728";
			break;
		case "English":
			searchData = EngAuctionReverse.eventID;
//			searchData="1000073727";
			break;
		case "TEB":
			searchData = TwoBiddingEnvelope.eventID;
//			searchData="1000073730";
			break;
		case "QuickSource":
			searchData = QuickSourceTest.eventID;
//			searchData="1000073732";
			break;
		}
		if(searchData!=null) {

			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");
			filterColumns("Event ID", "EQUALS", searchData);
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", searchData);
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "created values are displayed in the report for:"+type);
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}
		}
		else {
			LogScreenshot("Warning", "Data is not created by the dependent testcase "+type+" for verification");
		}		
	}


	public void iManageFieldCheckForProject(String projectName) throws Exception{							
		if(projectName!=null) {						
			ReportTablePage reportTablePage = new ReportTablePage(driver);					
			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");					
			Thread.sleep(5000);					
			filterColumns("Project Title", "CONTAINS", projectName);					
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", projectName);					
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "Created project is displayed in the report");
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}			
		}						
		else {						
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");					
		}						
	}							
								
	public void eInvoiceFieldCheck(String creditNonPO) throws Exception{							
		if(creditNonPO!=null) {						
			ReportTablePage reportTablePage = new ReportTablePage(driver);					
			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");					
			Thread.sleep(5000);					
			filterColumns("Invoice No.", "CONTAINS", creditNonPO);					
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", creditNonPO);					
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "Created Invoice is displayed in the report");
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}					
		}						
		else {						
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");					
		}						
								
	}		
	
	
	public void eProcFieldCheck(String category) throws Exception{
		String searchData = null;
		String colName = null;
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		switch(category) {
		case "PO":
			searchData= PurchaseOrderCreation_WithInvoice.standardPO;
			colName = "PO Number";
			break;
		case "PR":
			searchData = Requisition_Receipt.requisitionNum;
			colName = "Requisition Number";
			break;
		
		}
		if(searchData!=null) {

			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");
			filterColumns(colName, "CONTAINS", searchData);
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", searchData);
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "created values are displayed in the report");
				clickElement(reportTablePage.clearFilter);
				waitUntilInvisibilityOfElement(By.id("status_overlay_undefined"));
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
				clickElement(reportTablePage.clearFilter);
				waitUntilInvisibilityOfElement(By.id("status_overlay_undefined"));
			}

		}
		else {
			LogScreenshot("Warning", "Data is not created by the dependent testcase for verification");
			clickElement(reportTablePage.clearFilter);
			waitUntilInvisibilityOfElement(By.id("status_overlay_undefined"));
		}		
	}
	
	public void iContractFieldCheck(String type) throws Exception{							
		String searchData = null;
		String colName= null;
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		switch(type) {
		case "Contract":
			searchData = CreateContractTest.contractNumber;
			colName = "Contract Number";
			break;
		case "Template":
			searchData = CreateTemplateTest.templateName;
			colName = "Template Number";
			break;
		case "Clause":
			searchData = CreateClauseTest.clauseName;
			colName = "Clause Title";
			break;	
		}
		if(searchData!=null) {
			verifyElementExist(reportTablePage.reportGrid, "report page is displayed");
			filterColumns(colName, "EQUALS", searchData);
			String fieldLocator = reportTablePage.valueLocator.replace("<<value>>", searchData);
			try {
				verifyElementExist(driver.findElement(By.xpath(fieldLocator)), "created values are displayed in the report for:"+type);
			}catch(Exception e) {
				LogScreenshot("Warning", "Integration Failure");
			}
		}
		else {
			LogScreenshot("Warning", "Data is not created by the dependent testcase "+type+" for verification");
		}															
	}							


	public void saveReport() throws Exception {
		ReportTablePage reportTablePage = new ReportTablePage(driver);
		clickElement(reportTablePage.saveAs_button);
		waitUntilVisibilityOfElement(reportTablePage.saveAsPopUp_dialog);
		verifyElementExist(reportTablePage.reportName_input, "Save report pop up is displayed");
		setInput(reportTablePage.reportName_input, "AutoReport_"+generateNo());
		clickElement(reportTablePage.createNewFolder_button);
		setInput(reportTablePage.folderName_input, "AutoFolder"+generateNo());
		clickElement(reportTablePage.saveFolder_button);

	}

	public void exportReport() throws Exception{
		
		exportReport("Excel");
		exportReport("CSV");
		exportReport("PDF");
	}

}

