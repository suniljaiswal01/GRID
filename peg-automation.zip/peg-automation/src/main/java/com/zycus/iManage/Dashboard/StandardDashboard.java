package com.zycus.iManage.Dashboard;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iManage_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> BlanketPurchaseOrder.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class StandardDashboard extends iManage_CommonFunctions {

  private String standardDashboardName;
  private static By HeaderReqNum = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName = By.xpath("//h1[@class='pgHead']/span[3]");

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public StandardDashboard(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  public String searchStandardDashboard(String dashboardLayout, String... prePackagedReports) throws AWTException {
    String dashboardName = null;
    boolean result = false;
    boolean allWidgetsAdded = true;
    Random rnd = new Random();
    this.standardDashboardName = "StandardDash_"+generateNo();
    try {
      // Click on 'Add New' button
      findElement(By.xpath("//a[@name='addNewDashBoard']")).click();
      if (driver.findElement(By.id("AddNewDashPop")).isDisplayed()) {
        //logger.log(Status.INFO, "Add New Dashboard' pop-up displayed");
        LogScreenshot("INFO","Add New Dashboard' pop-up displayed");
        findElement(By.xpath("//a[@class='getStartedCustom']")).click();
        if (driver.findElement(By.id("customDashboardPopUp")).isDisplayed()) {
          driver.findElement(By.id("customDashboardName")).sendKeys(standardDashboardName);
          findElement(By.xpath("//div[@class='boxLayoutsDv']//a[text()='" + dashboardLayout + "']")).click();
          LogScreenshot("PASS","Create Custom Dashboard' pop-up displayed");
          JavascriptExecutor js = (JavascriptExecutor)driver;
          js.executeScript("arguments[0].click();", driver.findElement(By.id("customDash")));
          waitUntilInvisibilityOfElement(By.id("processLoader"));
          waitUntilVisibilityOfElement(By.id("noReportWidgetPresentEdit"));
          for (String reportToDrag : prePackagedReports) {
            if (!dragWidgetToDashboard(reportToDrag, 1 + rnd.nextInt(countLayoutDivisions(dashboardLayout))))
              allWidgetsAdded = false;
          }
          if (allWidgetsAdded)
            dashboardName = standardDashboardName;          
        } else          
          LogScreenshot("FAIL", "Create Custom Dashboard' pop-up not displayed");
      } else
        LogScreenshot("FAIL", "Add New Dashboard' pop-up not displayed");
    } catch (Exception e) {
    e.printStackTrace();
      Robot robot = new Robot();
      robot.keyPress(KeyEvent.VK_ESCAPE);
      robot.keyRelease(KeyEvent.VK_ESCAPE);
    }
    return standardDashboardName;
  }

  private boolean dragWidgetToDashboard(String reportToDrag, int i) {
    // TODO Auto-generated method stub
    return false;
  }


  private int countLayoutDivisions(String dashboardLayout) {
    // TODO Auto-generated method stub
    return 0;
  }


  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName
   *            the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    HeaderReqName = headerReqName;
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum
   *            the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    HeaderReqNum = headerReqNum;
  }

}
