package com.zycus.iManage.Dashboard;

import java.awt.AWTException;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.iManage_CommonFunctions;


public class CommonDashboard extends iManage_CommonFunctions {

	private String customDashboardName;

	private static By HeaderReqNum = By.xpath("//h1[@class='pgHead']/span[1]");
	private static By HeaderReqName = By.xpath("//h1[@class='pgHead']/span[3]");
	Actions builder = new Actions(driver);
	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 */

	public CommonDashboard(WebDriver driver, ExtentTest logger) { 
		super(driver, logger);
	}

	private boolean dragWidgetToDashboard(String widgetName, int position) {
		boolean result = false;
		try {
			WebElement draggable = driver
					.findElement(By.xpath("//div[@class='reportContainerParent']//a[@title='" + widgetName + "']"));
			WebElement droppable = findElement(By.xpath("//div[@class='dashboardRightPart']/div[" + position + "]"));
			new Actions(driver).dragAndDrop(draggable, droppable).build().perform();
			waitUntilInvisibilityOfElement(By.id("pleaseWaitLay"));
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private int countLayoutDivisions(String dashboardLayout){
		char[] chars = dashboardLayout.toCharArray();
		int divCtr = 0;
		for(char a : chars){
			if (a==':')
				divCtr++;
		}
		return divCtr;
	}


	public String addNewDashboard(String dashboardLayout, String... prePackagedReports) throws Exception {
		String dashboardName = null;
		boolean result = false;
		boolean allWidgetsAdded = true;
		Random rnd = new Random();
		this.customDashboardName = "CustomDash_"+generateNo();
		waitUntilInvisibilityOfElement(By.id("processLoader"));
		Thread.sleep(10000);
		try {
			// Click on 'Add New' button    
			if (driver.findElements(By.xpath("//a[@name='addNewDashBoard']")).size() > 0){
				findElement(By.xpath("//a[@name='addNewDashBoard']")).click();
				LogScreenshot("INFO", "Clicked on New Dashboard button");
				if (driver.findElement(By.id("AddNewDashPop")).isDisplayed()) {
					LogScreenshot("INFO","Add New Dashboard' pop-up displayed");
					findElement(By.xpath("//a[@class='getStartedCustom']")).click();
					if (driver.findElement(By.id("customDashboardPopUp")).isDisplayed()) {
						driver.findElement(By.id("customDashboardName")).sendKeys(customDashboardName);
						findElement(By.xpath("//div[@class='boxLayoutsDv']//a[text()='" + dashboardLayout + "']")).click();
						LogScreenshot("PASS","Create Custom Dashboard' pop-up displayed");
						JavascriptExecutor js = (JavascriptExecutor)driver;
						js.executeScript("arguments[0].click();", driver.findElement(By.id("customDash")));
						waitUntilInvisibilityOfElement(By.id("processLoader"));
						Thread.sleep(10000);
						waitUntilVisibilityOfElement(By.id("noReportWidgetPresentEdit"));
						for (String reportToDrag : prePackagedReports) {
							if (!dragWidgetToDashboard(reportToDrag, 1 + rnd.nextInt(countLayoutDivisions(dashboardLayout))))
								allWidgetsAdded = false;
						}
						if (allWidgetsAdded)
							dashboardName = customDashboardName;          
					} else          
						LogScreenshot("FAIL", "Create Custom Dashboard' pop-up not displayed");
				} else
					LogScreenshot("FAIL", "Add New Dashboard' pop-up not displayed");
			}else
				LogScreenshot("FAIL", "Add New Dashboard' is button not visible");

		} catch (Exception e) {
			e.printStackTrace();
			/*Robot robot = new Robot();
      robot.keyPress(KeyEvent.VK_ESCAPE);
      robot.keyRelease(KeyEvent.VK_ESCAPE);*/
		}
		return customDashboardName;
	}

	public void saveNewDashboardToMyDashboard(String dashboardLayout, String... prePackagedReports) throws Exception{
		/*  addNewDashboard(dashboardLayout, prePackagedReports);*/
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();    
			String setup = configurationProperties.getProperty("Setup");
		/*	if (setup.equals(getLanguageProperty("AWS UK"))) {
				waitUntilVisibilityOfElement(By.id("saveAch"));
				js.executeScript("arguments[0].click();", driver.findElement(By.id("saveAch")));
				LogScreenshot("INFO", "Clicked on New Save button");
			}else {*/
				waitUntilVisibilityOfElement(By.id("savePrivateAch"));
				js.executeScript("arguments[0].click();", driver.findElement(By.id("savePrivateAch")));
				LogScreenshot("INFO", "Clicked on New Save button");
			
			/*findElement(By.id("savePrivateAch")).click();*/
			waitUntilInvisibilityOfElement(By.id("editLoadingPopUp"));
			waitUntilInvisibilityOfElement(By.id("processLoader"));
			Thread.sleep(10000);
			if (verifyReportsAdded(prePackagedReports)){
				String allReports = "";
				for(String report : prePackagedReports)
					allReports = report + " , ";
				LogScreenshot("PASS",allReports + "added to custom Dashboard : "+customDashboardName);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void saveNewDashboardToPrecanned(String dashboardLayout, String... prePackagedReports) throws Exception{
		addNewDashboard(dashboardLayout, prePackagedReports);
		findElement(By.id("savePublicAch")).click();
		waitUntilInvisibilityOfElement(By.id("editLoadingPopUp"));
		waitUntilInvisibilityOfElement(By.id("processLoader"));
		Thread.sleep(10000);
		if (verifyReportsAdded(prePackagedReports)){
			String allReports = "";
			for(String report : prePackagedReports)
				allReports = report + " , ";
			LogScreenshot("PASS",allReports + "added to custom Dashboard : "+customDashboardName);
		}
	}

	private boolean verifyReportsAdded(String... prePackagedReports){
		boolean result = false;
		boolean reportNotFound = false;
		String portletTitle = null;
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dashboardWidgetLoader']"));
			waitUntilVisibilityOfElement(By.xpath("//div[@class='portlet']"));
			int portletsCount = driver.findElements(By.xpath("//div[@class='portlet']")).size();
			int reportCtr = 0;
			for(String report : prePackagedReports){
				reportCtr++;
				for(int i = 1; i<=portletsCount; i++){
					waitUntilVisibilityOfElement(By.xpath("(//div[@class='portlet'])["+i+"]//div[@class='dashName']//span"));
					Thread.sleep(30000);
					portletTitle = driver.findElement(By.xpath("(//div[@class='portlet'])["+i+"]//div[@class='dashName']//span")).getText();
					if (!report.equals(portletTitle)){
						if (reportCtr == i){
							reportNotFound = true;
							LogScreenshot("Fail", report +" not added to the My Dashboard/Precanned in Custom Dashboard : "+ customDashboardName);
							break;
						}
						else
							break;
					}
				}
			}
			if (!reportNotFound)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean exportDashboard(String exportFormat) throws Exception{
		boolean status=false;
		waitUntilInvisibilityOfElement(By.id("processLoader"));
		Thread.sleep(30);
		String name = System.getProperty("user.name");
		String filePath = "C:\\Users\\"+name+"\\Downloads\\"; 
		try {
			String fileExtension = null;
			String dashboardName= driver.findElement(By.id("viewInputTxtbx")).getAttribute("value");
			findElement(By.xpath("//a[@name='exportClick']")).click();
			if (driver.findElement(By.id("exportDashPop")).isDisplayed()) {      
				driver.findElement(By.xpath("//div[@title='"+exportFormat+"']")).click();
				LogScreenshot("INFO",exportFormat+ " Export in Progress");
				waitUntilInvisibilityOfElement(By.id("dashletProcessingKey"));
				switch(exportFormat){
				case "Excel":
					fileExtension = "xlsx";
					break;
				case "Word":
					fileExtension = "doc";
					break;
				case "PowerPoint":
					fileExtension = "pdf";
					break;
				case "PDF":
					fileExtension = "ppt";
					break;
				default:
					break;
				}
				Thread.sleep(8000);
				if (checkFileExists(filePath, dashboardName, fileExtension)) {
					LogScreenshot("PASS",exportFormat+ " Export successful");
					status=true;
				}else
					LogScreenshot("FAIL",exportFormat+ " Export failed");  
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public boolean performActionOnDashboard(String action) throws Exception {

		//    waitUntilVisibilityOfElement(objCommon.moreOptionsDrpDwn);

		driver.findElement(By.xpath("//strong[text()='"+getLanguageProperty("More Options")+"']")).click();
		builder.moveToElement(driver.findElement(By.xpath("//strong[text()='"+getLanguageProperty("More Options")+"']"))).build().perform();

		switch (action) {
		case "Add to Favorite":
			driver.findElement(By.xpath("//span[text()='"+action+"']")).click();
			Thread.sleep(5000);
			if (driver.findElements(By.id("popup_title")).size() > 0) {
				driver.findElement(By.xpath("popup_ok")).click();
				Thread.sleep(2000);
				LogScreenshot("PASS","Added to favorites");
			}

			break;
		case "Mark as Default":
			driver.findElement(By.xpath("//span[text()='"+action+"']")).click();
			Thread.sleep(5000);
			/*if (driver.findElements(By.id("popup_title")).size() > 0) {
        driver.findElement(By.xpath("popup_ok")).click();*/
			if (driver.findElements(By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Added Successfully")+"']]")).size() > 0) {
				findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
				Thread.sleep(2000);
				LogScreenshot("PASS","Marked as Default");
			}

			break;
		case "Delete":
			driver.findElement(By.xpath("//span[text()='"+action+"']")).click();
			Thread.sleep(5000);
			if (driver.findElements(By.id("popup_title")).size() > 0)
				driver.findElement(By.xpath("popup_ok")).click();
			Thread.sleep(2000);
			if (driver.findElements(By.xpath("//h1[text()='"+getLanguageProperty("Dashboard deleted")+"']")).size() > 0) {
				driver.findElement(By.xpath("popup_ok")).click();
				Thread.sleep(2000);
				LogScreenshot("PASS","Deletion successful");
			}
			break;
		case "Edit":
			break;
		default:
			break;
		}
		return false;




	}

	/**
	 * @return the headerReqName
	 */
	public By getHeaderReqName() {
		return HeaderReqName;
	}

	/**
	 * @param headerReqName
	 *            the headerReqName to set
	 */
	public void setHeaderReqName(By headerReqName) {
		HeaderReqName = headerReqName;
	}

	/**
	 * @return the headerReqNum
	 */
	public By getHeaderReqNum() {
		return HeaderReqNum;
	}

	/**
	 * @param headerReqNum
	 *            the headerReqNum to set
	 */
	public void setHeaderReqNum(By headerReqNum) {
		HeaderReqNum = headerReqNum;
	}

}
