package com.zycus.iManage.MyConfiguration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iManage_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> BlanketPurchaseOrder.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class MassUpdate extends iManage_CommonFunctions {


  private static By HeaderReqNum = By.xpath("//h1[@class='pgHead']/span[1]");
  private static By HeaderReqName = By.xpath("//h1[@class='pgHead']/span[3]");
  //private String uploadfileConfigProp;

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param uploadfileConfigProp 
   */
  
  public MassUpdate(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
  }

  /**
   * @return the headerReqName
   */
  public By getHeaderReqName() {
    return HeaderReqName;
  }

  /**
   * @param headerReqName
   *            the headerReqName to set
   */
  public void setHeaderReqName(By headerReqName) {
    HeaderReqName = headerReqName;
  }

  /**
   * @return the headerReqNum
   */
  public By getHeaderReqNum() {
    return HeaderReqNum;
  }

  /**
   * @param headerReqNum
   *            the headerReqNum to set
   */
  public void setHeaderReqNum(By headerReqNum) {
    HeaderReqNum = headerReqNum;
  }
  
  public boolean massUpdate(String uploadfileConfigProp) throws Exception
  {
    boolean result = false;
    Thread.sleep(4000);
    findElement(By.xpath("//table[@id='dataGrid']//tr[1]/td[@class='filterGridTblTd']/input")).click();
    By uploadBtn = By.xpath("//input[@id='fileUploader']");
    JavascriptExecutor js = (JavascriptExecutor)driver;
    js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(uploadBtn));
    Thread.sleep(3000);
    //  String uploadfileConfigProp = null;
    if (addAttachment(uploadBtn, uploadfileConfigProp)){
      LogScreenshot("PASS", "Attachment added");
      //Submit button
      //findElement(By.xpath("//div[@id='submitSheet']/input"),"Submit button").click();
      result = true;
    }else {
      LogScreenshot("FAIL", "Attachment not added");
    }
    return result;
  }

}
