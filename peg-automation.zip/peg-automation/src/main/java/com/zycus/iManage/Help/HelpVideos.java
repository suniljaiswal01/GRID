package com.zycus.iManage.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class HelpVideos extends ProductVideos {

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public HelpVideos(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> verifyLatestHelpVideo
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param displayName
   * @return result - True/False
   * @throws Exception
   */

  public boolean verifyLatestHelpVideo() throws Exception {
    boolean result = false;
    try {
      if (driver.findElement(By.xpath("//table[@class='selfTraining']//li[contains(@class,'VideoTab') and contains(@class,'active')]")).getText().equals(getLanguageProperty("Product Videos"))){
        if (verifyLatestProductVideo()){
          driver.close();
          result = true;
        }
      }else
        logger.log(Status.FAIL, "Product Videos tab not opened");
    } catch (Exception e) {
    e.printStackTrace();
      logger.log(Status.FAIL, "latest help video not opened");
    }
    return result;
  }

}
