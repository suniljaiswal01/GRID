package com.zycus.iManage.MyConfiguration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iManage_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> BlanketPurchaseOrder.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class MassUpload extends iManage_CommonFunctions {

	private static By HeaderReqNum = By.xpath("//h1[@class='pgHead']/span[1]");
	private static By HeaderReqName = By.xpath("//h1[@class='pgHead']/span[3]");
	private String uploadfileConfigProp;

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param uploadfileConfigProp 
	 */

	public MassUpload(WebDriver driver, ExtentTest logger) { 
		super(driver, logger);
	}

	public MassUpload(WebDriver driver, ExtentTest logger, String uploadfileConfigProp) { 
		super(driver, logger);
		this.uploadfileConfigProp=uploadfileConfigProp;
	}

	/**
	 * @return the headerReqName
	 */
	public By getHeaderReqName() {
		return HeaderReqName;
	}

	/**
	 * @param headerReqName
	 *            the headerReqName to set
	 */
	public void setHeaderReqName(By headerReqName) {
		HeaderReqName = headerReqName;
	}

	/**
	 * @return the headerReqNum
	 */
	public By getHeaderReqNum() {
		return HeaderReqNum;
	}

	/**
	 * @param headerReqNum
	 *            the headerReqNum to set
	 */
	public void setHeaderReqNum(By headerReqNum) {
		HeaderReqNum = headerReqNum;
	}

	public boolean uploadDocument(String uploadfileConfigProp) throws Exception{
		boolean result = false;
		Thread.sleep(3000);
		/*By uploadBtn = By.xpath("//*[@id='file"
        + "Uploader']/following-sibling::label");*/

		By uploadBtn = By.xpath("//*[@id='fileUploader']");
		Thread.sleep(8000);
		/*uploadfileConfigProp = null;*/
		if (addAttachment(uploadBtn, uploadfileConfigProp))
			result = true;
		if (findElement(By.xpath("//input[@value='"+getLanguageProperty("Submit")+"']")).isDisplayed())
		{  
			driver.findElement(By.xpath("//input[@value='"+getLanguageProperty("Submit")+"']")).click();
			Thread.sleep(5000);
			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'processOverlay')]"));
			driver.findElement(By.xpath("//input[@id='popup_ok'][@value='"+getLanguageProperty("OK")+"']")).click();
			LogScreenshot("PASS","Doc uploaded");
			result = true;
		}
		return result;

	}
}
