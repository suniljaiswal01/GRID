package com.zycus.iManage.Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfirmationDialog;
import common.Functions.iManage_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> NewCompany.java
 * <br>
 * <b> Description: </b> To perform iManage- Admin- New Company page 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since Oct 2018
 */

public class NewCompany extends iManage_CommonFunctions {


  private static By categoryUploadDocBtn = By.id("categoryFileUploader");
  private static By BusinessTreeUploadDocBtn = By.id("divisionFileUploader");

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public NewCompany(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  public void saveCategoryTree() throws Exception {
    importCategoryTree();
    findElement(By.id("saveCategoryTreeBtn")).click();
    if (driver.findElement(ConfirmationDialog.getDialogTitle()).isDisplayed()) {
      if (driver.findElement(ConfirmationDialog.getPopupMsg()).getText()
          .contains("delete the earlier records")) {
        driver.findElement(ConfirmationDialog.getDialogYesBtn()).click();
        LogScreenshot("Pass","Confirmation Dialog displayed");
      } else
        LogScreenshot("Fail", "Incorrect Confirmation Dialog displayed");
    } else
      LogScreenshot("Fail", "Confirmation Dialog not displayed");
  }


  public void appendCategoryTree() throws Exception {
    importCategoryTree();
    findElement(By.id("appendCategoryTreeBtn")).click();
    if (driver.findElement(ConfirmationDialog.getDialogTitle()).isDisplayed()) {
      if (driver.findElement(ConfirmationDialog.getPopupMsg()).getText()
          .contains("merge the earlier and new records")) {
        driver.findElement(ConfirmationDialog.getDialogYesBtn()).click();
        LogScreenshot("Pass","Confirmation Dialog displayed");
      } else
        LogScreenshot("Fail", "Incorrect Confirmation Dialog displayed");
    } else
      LogScreenshot("Fail", "Confirmation Dialog not displayed");

  }

  public boolean importCategoryTree() throws Exception {
    boolean result = false;
    boolean saveBtnEnabled = false;
    boolean appendBtnEnabled = false;
    try {
      addAttachment(categoryUploadDocBtn, "iManage_uploadCategoryfile_path");
      waitUntilVisibilityOfElement(
          By.xpath("//label[@id='categoryUploadedFileName']"));
      /*waitUntilVisibilityOfElement(
          By.xpath("//label[@id='categoryUploadedFileName' and contains(@style,'inline')]"));*/
    } catch (Exception e) {
    e.printStackTrace();
      //LogScreenshot("Fail", "Category tree not uploaded");
    }
    // input[@id='categoryFileUploader']/../../../following-sibling::div/label[contains(@style,'inline')]
    if (driver.findElement(By.xpath("//input[@id='saveCategoryTreeBtn']")).isEnabled()) {
      saveBtnEnabled = true;
    //LogScreenshot("PASS"," Save button enabled and Category Tree uploaded");
    }
    else
      LogScreenshot("Fail", "Save button not enabled or Category Tree not uploaded");
    if (driver.findElement(By.xpath("//input[@id='appendCategoryTreeBtn']")).isEnabled()) {
      appendBtnEnabled = true;
    //LogScreenshot("PASS"," Append button enabled and Category Tree  uploaded");
    }
    else
      //LogScreenshot("Fail", "Append button not enabled or Category Tree not uploaded");
    if (saveBtnEnabled && appendBtnEnabled){
      //LogScreenshot("INFO"," Save button, Append button enabled");
      result = true;
    }
    else
      LogScreenshot("Fail", "Append button and Save button not enabled");
    return result;
    

  }


  public void saveBusinessTree() throws Exception {
    importBusinessTree();
    findElement(By.id("saveDivisionTreeBtn")).click();
    if (driver.findElement(ConfirmationDialog.getDialogTitle()).isDisplayed()) {
      if (driver.findElement(ConfirmationDialog.getPopupMsg()).getText()
          .contains("delete the earlier records")) {
        driver.findElement(ConfirmationDialog.getDialogYesBtn()).click();
        //LogScreenshot("Pass","Confirmation Dialog displayed");
      } else
        LogScreenshot("Fail", "Incorrect Confirmation Dialog displayed");
    } else
      LogScreenshot("Fail", "Confirmation Dialog not displayed");
  }

  public void appendBusinessTree() throws Exception {
    importBusinessTree();
    findElement(By.id("appendDivisionTreeBtn")).click();
    if (driver.findElement(ConfirmationDialog.getDialogTitle()).isDisplayed()) {
      if (driver.findElement(ConfirmationDialog.getPopupMsg()).getText()
          .contains("delete the earlier records")) {
        driver.findElement(ConfirmationDialog.getDialogYesBtn()).click();
        //LogScreenshot("Pass","Confirmation Dialog displayed");
      } else
        LogScreenshot("Fail", "Incorrect Confirmation Dialog displayed");
    } else
      LogScreenshot("Fail", "Confirmation Dialog not displayed");
  }

  public boolean importBusinessTree() throws Exception {
    boolean result = false;
    try {
      addAttachment(BusinessTreeUploadDocBtn, "iManage_BusinessTreefile_path");
      waitUntilVisibilityOfElement(
          By.xpath("//label[@id='divisionUploadedFileName' and contains(@style,'inline')]"));
      if (driver.findElement(By.xpath("//label[@id='divisionUploadedFileName' and contains(@style,'inline')]"))
          .isDisplayed())
        LogScreenshot("PASS", "Business tree uploaded sucessfully");
      result = true;
    } catch (Exception e) {
    e.printStackTrace();
      LogScreenshot("FAIL", "Business tree not uploaded");
      throw new Exception();
    }
    return result;

  }
  public void activateCurrency() throws Exception {
    findElement(By.id("activateCMDCurrency")).click();
    if (driver.findElement(By.xpath("//label[@id='currencyResponseLabel']")).getText()
        .contains("Activated Successfully"))
      LogScreenshot("Pass", "Currency Activated Successfully");
  }

}
