package com.zycus.iManage.Admin;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iManage_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> BlanketPurchaseOrder.java
 * <br>
 * <b> Description: </b> To perform operations on pages Approval & All Requests
 * 
 * <br>
 * <b> Functions: 
 * </b> None <br>
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class PerformStatusTasks extends iManage_CommonFunctions {

  /**
   * Constructor for the class
   * 
   * @param driver
   */

  public PerformStatusTasks(WebDriver driver, ExtentTest logger) { 
    super(driver, logger);
    
  }

  public boolean validateStatus() throws Exception {
    String status;
    boolean result = false;
    if (findElement(By.xpath("//div[@class='marginTB10']/table")).isDisplayed()) {
      List<WebElement> rows = driver.findElements(By.xpath("//div[@class='marginTB10']/table//tr"));
      int count = rows.size();
      // taking i=4 as first 3 rows are headers 
      // count-2 as no status for last 2 rows
      for (int i = 4; i <= count - 2; i++) {
        status = findElement(By.xpath("//div[@class='marginTB10']/table//tr[" + i + "]/td[3]")).getText();
        System.out.println("status for row "+ i +"is "+status);
        assertEquals(status, "true");
      }
      result = true;
    }
    return result;

  }


}
