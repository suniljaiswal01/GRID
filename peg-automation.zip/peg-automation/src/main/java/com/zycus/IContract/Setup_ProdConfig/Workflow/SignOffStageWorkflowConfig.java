package com.zycus.IContract.Setup_ProdConfig.Workflow;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class SignOffStageWorkflowConfig extends eInvoice_CommonFunctions {

	private String contractType;
	private String workflowName;
	private String workflowDesc;
	
	public SignOffStageWorkflowConfig(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public SignOffStageWorkflowConfig(WebDriver driver, ExtentTest logger, String contractType, String workflowName, String workflowDesc) {
		super(driver, logger);
		this.contractType = contractType;
		this.workflowName = workflowName;
		this.workflowDesc = workflowDesc; 
	}

	public boolean createWorkflow() {
		boolean result = false;
		try {
			clickAndWaitUntilLoaderDisappears(By.xpath("//input[@value='"+getLanguageProperty("Create")+"']  "));
			if(driver.findElements(By.id("ruleForm")).size()>0){
			//if(driver.findElement(By.id("ruleForm")).isDisplayed()){
				findElement(By.xpath("//select[@id='workflowHierarchyId']/option[text()='"+contractType+"']")).click();
				findElement(By.id("ruleName")).sendKeys(workflowName);
				findElement(By.id("ruleDescription")).sendKeys(workflowDesc);
				
				//Add conditions and validate Formula
				clickAndWaitUntilLoaderDisappears(By.xpath("//*[@id='footerBar']//input[@value='"+getLanguageProperty("Save")+"']  "));
				//Flash error is received
				result= true;
			}else
				logger.fail("Create Workflow pop up not displayed");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public boolean verifyIfWorkflowActive(String contractType, String contractSubType) throws InterruptedException{
		boolean WorkflowActive = false;
		try{
			String searchValue = contractType + " - " + contractSubType;
			driver.findElement(By.xpath("//input[@name='TYPE_SUBTYPE_NAME']")).sendKeys(searchValue+Keys.ENTER);
			Thread.sleep(4000);
			List<WebElement> workflowRows = driver.findElements(By.xpath("//table[@id='workflow-listing-grid']/tbody/tr"));
			for(WebElement row : workflowRows){
				if(!(row.getAttribute("class").contains("deletedRow"))){
					WorkflowActive = true;
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return WorkflowActive;
	}

}
