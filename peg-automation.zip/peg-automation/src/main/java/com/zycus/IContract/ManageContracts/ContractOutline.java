package com.zycus.IContract.ManageContracts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ContractOutline extends eInvoice_CommonFunctions {

	private static By pgHead = By.xpath("//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Contract Outline")+"']");
	
	/*@FindBy(how = How.XPATH, using="//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Contract Outline")+"']")
	private static WebElement pgHeader;
	*/
	private static By pgHeader = By.xpath("//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Contract Outline")+"']");
			
			
/*	@FindBy(how = How.XPATH, using="//input[@title='"+getLanguageProperty("Create Version")+"']")
	private static WebElement createVersionBtn;*/
	private static By createVersionBtn = By.xpath("//input[@title='"+getLanguageProperty("Create Version")+"']");
	
	@FindBy(how = How.XPATH, using="//div[@role='dialog'][div[@id='revisionCommentPopup']]")
	private static WebElement revisionCommentPopup;
	
	@FindBy(how = How.ID, using="revisionComment")
	private static WebElement revisionCommentTextArea;
	
	/*@FindBy(how = How.XPATH, using="//div[@role='dialog'][div[@id='revisionCommentPopup']]//button[span[text()='"+getLanguageProperty("OK")+"']]")
	private static WebElement revisionCommentPopupOkBtn;*/
	private static By revisionCommentPopupOkBtn = By.xpath("//div[@role='dialog'][div[@id='revisionCommentPopup']]//button[span[text()='"+getLanguageProperty("OK")+"']]");

	public ContractOutline(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		PageFactory.initElements(driver, this);
	}

	public boolean createVersion() throws Exception {
		boolean result = false;
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String revisionCmmnt = "version comment";
		try {
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Create Version")+"']")).click();
			//createVersionBtn.click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div[@id='revisionCommentPopup']]"));
			//if(driver.findElements(By.xpath("//div[@role='dialog'][div[@id='revisionCommentPopup']]")).size()>0){
			//revisionCommentTextArea.sendKeys(revisionCmmnt);
			driver.findElement(By.id("revisionComment")).sendKeys(revisionCmmnt);
			LogScreenshot("Pass", "Version comment entered");
			WebElement popUpOkBtn = driver.findElement(By.xpath("//div[@role='dialog'][div[@id='revisionCommentPopup']]//button[span[text()='"+getLanguageProperty("Ok")+"']]"));
			Thread.sleep(2000);
			//js.executeScript("arguments[0].click();", revisionCommentPopupOkBtn);
			js.executeScript("arguments[0].click();", popUpOkBtn);
			//revisionCommentPopupOkBtn.click();
			
			LogScreenshot("Pass", "Ok button clicked to create new version");
			Thread.sleep(2000);
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(2000);
			waitUntilVisibilityOfElement(pgHeader);
			//if(pgHeader.isDisplayed())
			//}
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(6000);
			System.out.println("Now clicking on Line items");
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * @return the pgHead
	 */
	public static By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead the pgHead to set
	 */
	public static void setPgHead(By pgHead) {
		ContractOutline.pgHead = pgHead;
	}


}
