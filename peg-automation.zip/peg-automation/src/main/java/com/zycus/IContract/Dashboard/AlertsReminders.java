package com.zycus.IContract.Dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class AlertsReminders extends eInvoice_CommonFunctions {

	public AlertsReminders(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public void checkIfReminderIsVisible() throws Exception {
		
		By reminderWindow =By.id("loadingWindowReminder");
		if(isElementPresent(reminderWindow, 10)) {
			LogScreenshot("pass","Reminder Window Present");
		}else {
			LogScreenshot("fail","Reminder Window not Present");
		}	
	}
	
	
	
	public void checkIfAlertIsVisible() throws Exception {
		
		By reminderWindow =By.id("loadingWindowAlert");
		if(isElementPresent(reminderWindow, 10)) {
			LogScreenshot("pass","Alert Window Present");
		}else {
			LogScreenshot("warning","Alert Window not Present");
		}	
	}

}
