package com.zycus.IContract.Setup.ProductConfig;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.pages.iRequest.English.flexiform.FlexiformPage;

import common.Functions.Common_ConfigureFlexiForm;
import common.Functions.eInvoice_CommonFunctions;

public class FormWizard extends eInvoice_CommonFunctions {
	public static String sectionName;
	FlexiformPage flexiformPage = null;

	public FormWizard(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		flexiformPage = new FlexiformPage(driver);
	}

	public boolean createNewFlexiForm(String sectionDesc, String sectionLayout, String fieldDefaulVal, int fieldMaxChar, boolean isFieldMandatory, String sectionName) throws Exception{
		boolean result= false;
	/*	sectionName ="AutoSection_"+generateNo();*/
		String fieldType = "Numeric";
		String fieldName = "AutoField";	
		try{
			Common_ConfigureFlexiForm objForm = new Common_ConfigureFlexiForm(driver, logger, sectionName, fieldType, fieldName);
			objForm.addConfigureFlexiformHeaderFields(sectionDesc);
			/*objForm.addSection_flexiForm(sectionDesc, sectionLayout);	*/	
		/*	objForm.addfield_FlexiForm(fieldDefaulVal,fieldMaxChar,isFieldMandatory);*/
			addRandomFields();
			objForm.saveFlexiForm();
			LogScreenshot("Info","Saving created flexiForm");
			result = true;
		}catch(Exception e){
			LogScreenshot("fail","FlexiForm Creation Failed");
			e.printStackTrace();
			throw e;
		}
		return result;
	}
	
	
		public void addRandomFields() throws Exception{	
		String sectionName = "AutoSection_"+generateNo();
		String sectionDesc = sectionName+"_description";
		String sectionLayout = flexiformPage.column;
		Thread.sleep(5000);
		LogScreenshot("info", "FlexiForm Page");
		Common_ConfigureFlexiForm objForm = new Common_ConfigureFlexiForm(driver, logger, sectionName);
		objForm.addSection_flexiForm(sectionDesc, sectionLayout);
		
			String dynamicCustomFiled = flexiformPage.customField;		
			if(driver.findElements(By.xpath(dynamicCustomFiled)).size()==0){
				clickElement(flexiformPage.customField_menuClosed);
				waitUntilVisibilityOfElement(flexiformPage.customField_menuOpen);
			}
			
			WebElement customField = driver.findElement(By.xpath(dynamicCustomFiled));
			List<WebElement> customFieldsEle = flexiformPage.customFields_list;
			Random rnd = new Random();
			int randomCount = rnd.nextInt(customFieldsEle.size());
			int i, limit;
			if (randomCount==1 || randomCount == 0) {
				limit = 2;
			}
			else {
				limit = randomCount;
			}
			for( i = 1; i<limit; i++) {
				Thread.sleep(5000);
				String fieldName = customField.findElement(By.xpath("//div[contains(@class,'customFieldOuter')]//following-sibling::div//li["+i+"]/a")).getText().trim();
				if(!(fieldName.equals(getLanguageProperty("null")))) {
					WebElement fieldToDrag = driver.findElement(By.xpath("//div[contains(@class,'customFieldOuter')]//following-sibling::div//li["+i+"]/a"));
					WebElement dstElement = driver.findElement(By.xpath("//li/div[span[text()='"+sectionName+"']]/following-sibling::ul"));
					drag_drop(fieldToDrag, dstElement);
					objForm.addfield_FlexiForm(fieldName);
				}
			}
			
			
		}
	
}
