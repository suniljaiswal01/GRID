package com.zycus.IContract.ManageContracts;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.main.CommonTests1;
import com.main.ZycusCoreDriver;
import com.zycus.ZSN.MyContracts.ViewContracts;

import Framework.CommonUtility;
import Framework.ConfigurationProperties;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iContract_CommonFunctions;

public class ContractSummary extends iContract_CommonFunctions {

	private String assignAfter;
	private String assignTo;
	private String adHocComments;
	private String externalSupplier;
	private String externalPass;
	ConfigurationProperties configurationProperties= null;

	private List<String> externalSupplierList = new ArrayList<String>();
	private List<String> externalPassList = new ArrayList<String>();
	@FindBy(how = How.XPATH, using = "(//div[@id='summarypage']//h2)[1]")
	private static WebElement objContractNum;

	@FindBy(how = How.XPATH, using = "//div[h2[@class='conDetails pointer']]//tr[1]//span[@title]")
	private static WebElement objContractTitle;

	@FindBy(how = How.ID, using = "sendForSigningBtn")
	private static WebElement objSendForSigningBtn;

	@FindBy(how = How.ID, using = "closeAuthContract")
	private static WebElement objCloseOpenedContractBtn;

	@FindBy(how = How.ID, using = "sendToContractingParty")
	private static WebElement objSendToContractingPartyBtn;

	@FindBys(@FindBy(how = How.ID, using = "confirmationPopup"))
	private static List<WebElement> objRedlinesCommentsPopup;

	/*@FindBy(how = How.XPATH, using = "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]")
	private static WebElement objRedlinesCommentsPopup_ProceedBtn;*/

	@FindBys(@FindBy(how = How.ID, using = "emailPopup"))
	private static List<WebElement> objEmailPopup;

	/*@FindBy(how = How.XPATH, using = "//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]")
	private static WebElement objEmailPopup_SendBtn;*/

	@FindBy(how = How.XPATH, using = "//div[@id='confirmationPopup']")
	private static WebElement objConfirmationPopup;

	/*@FindBy(how = How.XPATH, using = "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]")
	private static WebElement objConfirmationPopup_ProceedBtn;*/

	@FindBy(how = How.XPATH, using = "//span[@class='yellowbutton']")
	private static WebElement objTopYellowBtn;

	@FindBy(how = How.ID, using = "proceedToSignOffBtn")
	private static WebElement objProceedToSignoffBtn;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'blockOverlay')]")
	private static WebElement objOverlayLoader;

	@FindBys(@FindBy(how = How.XPATH, using = "//div[contains(@class,'blockOverlay')]"))
	private static List<WebElement> objOverlayLoaders;

	@FindBys(@FindBy(how = How.XPATH, using = "//div[contains(@class,'jqifade')]"))
	private static List<WebElement> objAnotherOverlayLoaders;

	@FindBys(@FindBy(how = How.XPATH, using = "//div[@id='jqi']"))
	private static List<WebElement> objAlerts;

	/*@FindBy(how = How.XPATH, using = "//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")
	private static WebElement objAlert_OkBtn;*/

	@FindBy(how = How.XPATH, using = "//span[@class='zys-loader-icon']")
	private static WebElement objProcessingLoader;

	private static By processingLoader = By.xpath("//span[@class='zys-loader-icon']");
	private static By pgHead = By.xpath("//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Contract Summary")+"']");

	public ContractSummary(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		PageFactory.initElements(driver, this);



		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		this.externalSupplier = supplierDetails.getSupplierEmail();
		this.externalPass = supplierDetails.getSupplierPassword();
		configurationProperties = ConfigurationProperties.getInstance();
		
		/*CommonFunctions1 objFunctions = new CommonFunctions1();
		configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_SuppContacts = configurationProperties.getProperty("Datasheet_SupplierContacts");
		String[][] abc1 = (String[][]) objFunctions.dataProvider(configurationProperties.getProperty("Environment"), Datasheet_SuppContacts);
		for(int i=0; i<abc1.length ; i++){
			this.externalSupplierList.add(abc1[i][2]);
			this.externalPassList.add(abc1[i][3]);
		}
		this.externalSupplier = externalSupplierList.get(0);
		this.externalPass = externalPassList.get(0);*/
		/*
		configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");

		String[][] supplierDetails = (String[][]) dataProvider("SupplierDetails", Datasheet_iContract);
	    this.externalSupplier = supplierDetails[0][0];
		this.externalPass = supplierDetails[0][1];*/
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	public String getContractNum() {
		String contractNum = null;
		try {
			// contractNum =
			// driver.findElement(By.xpath("(//div[@id='summarypage']//h2)[1]")).getText();
			contractNum = getObjContractNum().getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return contractNum;
	}

	public String getContractTitle() {
		String contractTitle = null;
		try {
			// contractTitle =
			// driver.findElement(By.xpath("//div[h2[@class='conDetails
			// pointer']]//tr[1]//span[@title]")).getText();
			contractTitle = getObjContractTitle().getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return contractTitle;
	}

	/*
	 * public boolean sendForNegotiation(String negotiationComment) { boolean
	 * result = false; try { findElement(By.id("sendToNegotiate")).click();
	 * waitUntilInvisibilityOfElement(processingLoader);
	 * findElement(By.id("revisionComment")).sendKeys(negotiationComment);
	 * findElement(By.xpath(
	 * "//div[@id='revisionCommentPopup']/ancestor::div//button[span[text()='"+getLanguageProperty("OK")+"']]"
	 * )).click(); waitUntilVisibilityOfElement(processingLoader);
	 * waitUntilVisibilityOfElement(pgHead); if
	 * (findElement(By.xpath("//span[@class='yellowbutton']")).getText().
	 * equals("Pending External Review")){ LogScreenshot("INFO",
	 * "contract sent for negotiation"); result = true; }else
	 * LogScreenshot("INFO", "contract not sent for negotiation"); } catch
	 * (Exception e) { e.printStackTrace(); } return result; }
	 */

	public boolean sendForNegotiation(String negotiationComment) {
		boolean result = false;
		try {
			clickAndWaitUntilLoaderDisappears(By.id("sendToNegotiate"), processingLoader);
			findElement(By.id("revisionComment")).sendKeys(negotiationComment);
			findElement(By.xpath("//div[@id='revisionCommentPopup']/ancestor::div//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
			waitUntilVisibilityOfElement(processingLoader);
			waitUntilVisibilityOfElement(pgHead);
			if (findElement(By.xpath("//span[@class='yellowbutton']")).getText().equals(getLanguageProperty("Pending External Review"))) {
				LogScreenshot("INFO", "contract sent for negotiation");
				result = true;
			} else
				LogScreenshot("INFO", "contract not sent for negotiation");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * public boolean closeContract() { boolean result = false; try {
	 * findElement(By.id("closeAuthContract")).click();
	 * waitUntilInvisibilityOfElement(processingLoader); AuthorContract objAuth
	 * = new AuthorContract(driver, logger); if (objAuth.getPgHead() != null)
	 * result = true; } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * return result; }
	 */
	public boolean closeContract(AuthorContract objAuth) {
		boolean result = false;
		try {
			clickAndWaitUntilLoaderDisappears(objCloseOpenedContractBtn, processingLoader);
			if (objAuth.getPgHead() != null)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	public void sendToSign(String displayStyle, String Product, String contractNumber,boolean isTouchFreeEnabled, boolean isByPassAuthEnabled, boolean isNegotiating) throws Exception{
		if(!isTouchFreeEnabled|isNegotiating){
			if(isByPassAuthEnabled|!doesContractNeedApproval()){
				sendToNegotiate();
				sendToContractingParty_new();
				markContractAsReview(contractNumber);
			}else{
				sendForApproval_new();
				approveContract(displayStyle, Product, contractNumber);
				Thread.sleep(2000);
				driver.navigate().refresh();
				waitUntilVisibilityOfElement(objSendToContractingPartyBtn);
				Thread.sleep(2000);
				sendToContractingParty_new();
				markContractAsReview(contractNumber);
			}
		}else{
			proceedToSigning();
		}
	}

	private void markContractAsReview(String contractNumber) throws Exception {
		try {

			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			Login objLogin = new Login(driver1, logger, externalSupplier, externalPass);
			callAndLog(driver1,logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Contracts", "View Contracts", configurationProperties.getProperty("Tenant"));
			ViewContracts objViewContracts = new ViewContracts(driver1, logger);
			objViewContracts.performAction(contractNumber,"Mark as Reviewed");
			objLogin.logout();
		}catch (Exception e) {
			LogScreenshot("fail", "Failed to Review contract");
		}
		driver1.close();

	}
	private void sendToNegotiate() throws Exception{
		//Send to Negotiate
		findElement(By.id("sendToNegotiate")).click();
		waitUntilInvisibilityOfElement(processingLoader);
		driver.findElement(By.id("revisionComment")).sendKeys("revision comment");
		findElement(By.xpath("//div[@role='dialog']//button[span[text()='"+getLanguageProperty("Ok")+"']]")).click();
		waitUntilInvisibilityOfElement(processingLoader);
	}

	public void sendToContractingParty_new() throws Exception{
		clickAndWaitUntilLoaderDisappears(objSendToContractingPartyBtn, processingLoader);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='processLoadingDiv']"));	
		if (objRedlinesCommentsPopup.size() > 0){
			WebElement objProceedBtn = driver.findElement(By.xpath("//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"));
			clickAndWaitUntilLoaderDisappears(objProceedBtn, processingLoader);
		}
		if (objEmailPopup.size() > 0) {
			LogScreenshot("INFO", "sending contract to contracting party");
			WebElement emailSendBtn = driver.findElement(By.xpath("//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]"));
			clickAndWaitUntilLoaderDisappears(emailSendBtn, processingLoader);
			if (objTopYellowBtn.getText().equals(getLanguageProperty("Under External Review")))
				LogScreenshot("Pass", "Contract Under External Review");
		}
	}

	private boolean doesContractNeedApproval(){
		boolean result = false;
		//if(!(driver.findElements(By.xpath("//div[@id='conAuthorRev']/div/span[text()='"+getLanguageProperty("This contract does not need approval")+"']")).size()>0))
		if (objTopYellowBtn.getText().equals(getLanguageProperty("Pending Authoring Review")))
			result = true;
		return result;
	}

	public String getPendingForApprovalWith(){
		return driver.findElement(By.xpath("//div[@id='conAuthorRev']//table//td[span[contains(text(),'"+getLanguageProperty("Pending")+"')]]")).getText().trim().split(":")[1].trim();
	}

	public void sendForApproval_new() throws Exception{
		findElement(By.id("sendToNegotiate"), "Send for Approval button").click();
		waitUntilInvisibilityOfElement(processingLoader);
		findElement(By.xpath("//div[@id='initiateWorkflowPopup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Initiate Workflow")+"']]")).click();
		waitUntilVisibilityOfElement(By.id("revisionComment"));
		driver.findElement(By.id("revisionComment")).sendKeys("revision comment");
		LogScreenshot("pass","Sending for approval");
		findElement(By.xpath("//div[@role='dialog']//button[span[text()='"+getLanguageProperty("Ok")+"']]")).click();
		waitUntilInvisibilityOfElement(processingLoader);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
	}

	public void approveContract(String displayStyle, String Product,String contractNumber) throws Exception{

		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='processLoadingDiv']"));	
		String pendingWith = getPendingForApprovalWith();
		String authoringUser = getUserEmail(getClassName());
		if(!authoringUser.equals(pendingWith)){
			ZycusCoreDriver objDriver = new ZycusCoreDriver();
			WebDriver driver1 = objDriver.startSession(pendingWith,"Approve Contract with "+pendingWith);
			displayStyle = getDisplayStyle(driver1, logger,CommonTests1.loginCredentials, pendingWith);
			CommonUtility objUtility = new CommonUtility(driver1, logger);
			if(displayStyle.equals(getLanguageProperty("Classic")))
				objUtility.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contracts Pending Review");
			else
				objUtility.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
			ContractsPendingReview objReview = new ContractsPendingReview(driver1, logger);
			objReview.approveContract("Authoring Stage", contractNumber, "Approve");
			driver1.close();
		}else{
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.closeContract();
			Thread.sleep(2500);
			if(displayStyle.equals(getLanguageProperty("Classic")))
				navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contracts Pending Review");
			else
				navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Authoring Stage", contractNumber, "Approve");
			navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
			navigateToStage(contractNumber, getLanguageProperty("Negotiate"));
		}
	}

	public void proceedToSigning(){

	}




	/*
	 * public boolean sendToContractingParty() { boolean result = false; try {
	 * clickAndWaitUntilLoaderDisappears(By.id("sendToContractingParty"));
	 * findElement(By.id("sendToContractingParty")).click();
	 * waitUntilInvisibilityOfElement(processingLoader); if (driver
	 * .findElements(By
	 * .xpath("//div[@aria-describedby='confirmationPopup'][div/span[text()='"+getLanguageProperty("Redlines and Comments")+"']]"
	 * )) .size() > 0) findElement(By .xpath(
	 * "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"
	 * )) .click(); waitUntilInvisibilityOfElement(processingLoader);
	 * clickAndWaitUntilLoaderDisappears(By .xpath(
	 * "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"
	 * )); if (driver.findElements(By.id("emailPopup")).size() > 0) {
	 * LogScreenshot("INFO", "sending contract to contracting party");
	 * findElement(By.xpath(
	 * "//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]"
	 * )) .click(); waitUntilInvisibilityOfElement(processingLoader);
	 * clickAndWaitUntilLoaderDisappears(By.xpath(
	 * "//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]"
	 * )); if (findElement(By.xpath("//span[@class='yellowbutton']")).getText().
	 * equals("Under External Review")) result = true; } } catch (Exception e) {
	 * e.printStackTrace(); } return result; }
	 */

	public boolean sendToContractingParty() throws Exception{
		boolean result = false;
		System.out.println("Entered into send to Contracting Party");
		try {
			clickAndWaitUntilLoaderDisappears(objSendToContractingPartyBtn, processingLoader);
			if (objRedlinesCommentsPopup.size() > 0){
				WebElement objProceedBtn = driver.findElement(By.xpath("//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"));
				clickAndWaitUntilLoaderDisappears(objProceedBtn, processingLoader);
			}
			if (objEmailPopup.size() > 0) {
				LogScreenshot("INFO", "sending contract to contracting party");
				WebElement objSendBtn = driver.findElement(By.xpath("//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]"));
				clickAndWaitUntilLoaderDisappears(objSendBtn, processingLoader);
				if (objTopYellowBtn.getText().equals(getLanguageProperty("Under External Review")))
					result = true;
			}

			/*
			 * if (driver .findElements(By
			 * .xpath("//div[@aria-describedby='confirmationPopup'][div/span[text()='"+getLanguageProperty("Redlines and Comments")+"']]"
			 * )) .size() > 0) clickAndWaitUntilLoaderDisappears(By .xpath(
			 * "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"
			 * ), processingLoader);
			 * 
			 * if (driver.findElements(By.id("emailPopup")).size() > 0) {
			 * LogScreenshot("INFO", "sending contract to contracting party");
			 * clickAndWaitUntilLoaderDisappears(By.xpath(
			 * "//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]"
			 * ), processingLoader); if
			 * (findElement(By.xpath("//span[@class='yellowbutton']")).getText()
			 * .equals(getLanguageProperty("Under External Review"))) result = true; }
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * public boolean proceedToSignOff(String signingOption) { boolean result =
	 * false; try { if
	 * (findElement(By.xpath("//span[@class='yellowbutton']")).getText().
	 * equals("Ready for Signoff")) {
	 * findElement(By.id("proceedToSignOffBtn")).click();
	 * waitUntilInvisibilityOfElement(processingLoader); Thread.sleep(3000); if
	 * (driver .findElements(By
	 * .xpath("//div[@aria-describedby='confirmationPopup'][div/span[text()='"+getLanguageProperty("Redlines and Comments")+"']]"
	 * )) .size() > 0) findElement(By.xpath(
	 * "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"
	 * )) .click();
	 * 
	 * do{ Thread.sleep(200); }while(driver.findElements(By.xpath(
	 * "//div[contains(@class,'blockOverlay')]")).size()>0||driver.findElements(
	 * By.xpath("//div[contains(@class,'jqifade')]")).size()>0);
	 * 
	 * waitUntilInvisibilityOfElement(processingLoader);
	 * waitUntilInvisibilityOfElement(By.xpath(
	 * "//div[contains(@class,'blockOverlay')]")); Thread.sleep(3000); try{
	 * WebElement signingBtn = findElement(By.id("sendForSigningBtn"));
	 * ((JavascriptExecutor) driver).executeScript("arguments[0].click()",
	 * signingBtn); System.out.println("signing btn clicked"); }catch(Exception
	 * e){ System.out.println("signing button not clicked"); } try{ String
	 * popUpFinderXpath =
	 * "//div[contains(@class,'zys-popup-container')][div/h1[text()='"+getLanguageProperty("Confirm")+"']]";
	 * findElement(By.xpath(popUpFinderXpath +
	 * "//button[text()='"+getLanguageProperty("Yes")+"']")).click(); }catch(Exception e){}
	 * waitUntilInvisibilityOfElement(processingLoader); Signers objSigners =
	 * new Signers(driver, logger); if
	 * (objSigners.sendForSigning(signingOption)) result = true; } } catch
	 * (Exception e) { e.printStackTrace(); } return result; }
	 * 
	 * public boolean proceedToSignOff(String signingOption) { boolean result =
	 * false; try { //if
	 * (findElement(By.xpath("//span[@class='yellowbutton']")).getText().
	 * equals("Ready for Signoff")) { Thread.sleep(3000);
	 * clickAndWaitUntilLoaderDisappears(By.id("proceedToSignOffBtn"));
	 * waitUntilVisibilityOfElement(By.xpath(
	 * "//div[@role='dialog'][div[@id='confirmationPopup']]"));
	 * findElement(By.xpath(
	 * "//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"
	 * )) .click(); do{ Thread.sleep(200); }while(driver.findElements(By.xpath(
	 * "//div[contains(@class,'blockOverlay')]")).size()>0||driver.findElements(
	 * By.xpath("//div[contains(@class,'jqifade')]")).size()>0);
	 * 
	 * waitUntilInvisibilityOfElement(processingLoader);
	 * waitUntilInvisibilityOfElement(By.xpath(
	 * "//div[contains(@class,'blockOverlay')]")); Thread.sleep(5000); try{
	 * WebElement signingBtn = findElement(By.id("sendForSigningBtn"));
	 * ((JavascriptExecutor) driver).executeScript("arguments[0].click()",
	 * signingBtn); //findElement(By.id("sendForSigningBtn")).click();
	 * objSendForSigningBtn.click(); System.out.println("signing btn clicked");
	 * }catch(Exception e){ e.printStackTrace();
	 * System.out.println("signing button not clicked"); } try{ String
	 * confirmESig = null; String popUpFinderXpath =
	 * "//div[contains(@class,'zys-popup-container')][div/h1[text()='"+getLanguageProperty("Confirm")+"']]";
	 * if(signingOption.equals("e-Signature")) confirmESig = "No"; else
	 * if(signingOption.equals(getLanguageProperty("Offline Signing"))) confirmESig = "Yes";
	 * findElement(By.xpath(popUpFinderXpath +
	 * "//button[text()='"+confirmESig+"']")).click();
	 * if(signingOption.equals("e-Signature")){
	 * if(driver.findElements(By.xpath("//div[@id='jqi']")).size()>0)
	 * driver.findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")).
	 * click(); } }catch(Exception e){}
	 * waitUntilInvisibilityOfElement(processingLoader); Signers objSigners =
	 * new Signers(driver, logger); if
	 * (objSigners.sendForSigning(signingOption)) result = true; //} } catch
	 * (Exception e) { e.printStackTrace(); } return result; }
	 */
	public boolean sendForApproval() throws Exception{
		boolean result = false;
		try{
			//Click 'Send For Approval' button
			if(driver.findElements(By.id("sendToApproval")).size()>0){
				findElement(By.id("sendToNegotiate")).click();
				waitUntilInvisibilityOfElement(processingLoader);
				//Initiate Workflow
				try{
					if(driver.findElements(By.xpath("//div[@id='initiateWorkflowPopup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Initiate Workflow")+"']]")).size()>0)
						findElement(By.xpath("//div[@id='initiateWorkflowPopup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Initiate Workflow")+"']]")).click();
				}catch(Exception e){
				}
				driver.findElement(By.id("revisionComment")).sendKeys("revision comment");
				findElement(By.xpath("//div[@role='dialog']//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
				waitUntilInvisibilityOfElement(processingLoader);
			}
			//verify Yellow button as 'Pending Authoring Review'

			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}


	public boolean authorReview(){
		boolean result = false;
		try{
			String assignAfter = "Bruce sanity6";
			String assignAfterUserEmail = "bruce.sanity6@zycus.com";
			String assignTo = "John sanity6";
			String assignToUserEmail = "john.sanity6@zycus.com";
			String adHocComments = "Adding Internal user to approve";
			addAdHocUser(assignAfter, assignTo, adHocComments);
			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	public boolean negotiateReview(String reviewType, String reviewerEmail){
		boolean result = false;
		try{
			reviewerEmail = "admin.zcs@zycus.com";
			findElement(By.id("parallelReview")).click();
			findElement(By.id("addparallelReviewButton")).click();
			driver.findElement(By.id("searchTextparallel")).sendKeys(reviewerEmail+Keys.ENTER);
			Thread.sleep(2000);
			driver.findElement(By.id(reviewerEmail)).click();
			findElement(By.xpath("//div[@id='addparallelReviewBox']//input[@value='"+getLanguageProperty("Done")+"']  ")).click();
			waitUntilVisibilityOfElement(By.xpath("//div[@class='reviewerTile']"));
			findElement(By.xpath("//div[@class='reviewerTile']//input[@name='parallelSectChkBox']")).click();
			findElement(By.id("sendForNegotiateParallelReview")).click();
			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	public boolean proceedToSignOff(boolean isWorkflowActive) throws Exception{
		isWorkflowActive = false;
		boolean result = false;
		try{
			driver.navigate().refresh();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(4000);
			findElement(By.id("proceedToSignOffBtn")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(3000);
			//clickAndWaitUntilLoaderDisappears(objProceedToSignoffBtn);
			waitUntilVisibilityOfElement(objConfirmationPopup);
			WebElement objProceedBtn = driver.findElement(By.xpath("//div[@id='confirmationPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"));
			LogScreenshot("info", "Starting Signoff Stage");
			objProceedBtn.click();
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'Processing')]"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'processOverlay')]"));
			Thread.sleep(3000);
			//Oracle PO Number
			try{
				if(driver.findElements(By.id("nineDigitIntegerForm")).size()>0){
					LogScreenshot("info","Oracle PO Number Pop-up");
					driver.findElement(By.id("fieldValue")).clear();
					driver.findElement(By.id("fieldValue")).sendKeys(String.valueOf(999999999));
					findElement(By.xpath("//span[text()='"+getLanguageProperty("Save and Continue")+"']")).click();
					waitUntilVisibilityOfElement(objSendForSigningBtn);
				}
			}catch(Exception e){
				e.printStackTrace();

			}
		}catch(Exception e){
			throw new Exception();
		}

		do {
			Thread.sleep(200);
		} while (objOverlayLoaders.size() > 0 || objAnotherOverlayLoaders.size() > 0);

		//waitUntilInvisibilityOfElement(objProcessingLoader, objOverlayLoader);
		//waitUntilInvisibilityOfElement(objOverlayLoader);
		//Code for Initiate Workflow to be added
		/*if(driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')][div[@id='initiateWorkflowPopup']]")).size()>0)
			driver.findElement(By.xpath("//div[@id='initiateWorkflowPopup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Initiate Workflow")+"']]")).click();
		 */
		Thread.sleep(6000);

		//If signoff workflow is activated
		waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'processOverlay')]"));
		isWorkflowActive = driver.findElement(By.id("initiateWorkflowPopup")).isDisplayed();
		if(isWorkflowActive){
			try{
				//Initiate Workflow
				LogScreenshot("info","Initiating Workflow");
				findElement(By.xpath("//div[@id='initiateWorkflowPopup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Initiate Workflow")+"']]")).click();
				waitUntilInvisibilityOfElement(processingLoader);
				CreateContract objContract = new CreateContract(driver, logger);
				objContract.navigate_ContractSubTabs("Sign Off Approval");
				//Add Ad-Hoc user
				String assignAfter = driver.findElement(By.xpath("//div[@class='authorDiv']/span[1]")).getText();
				String assignTo = configurationProperties.getProperty("UserAccount");
				String adHocComments = "Adding Internal user to approve";
				String assignToName = configurationProperties.getProperty("UserName");
				if(!(assignAfter.equalsIgnoreCase(assignToName))) {
					if(addAdHocUser(assignAfter, assignTo, adHocComments)) {
						clickElement(By.xpath("//div[@class='authorApproval']//span[@title='"+getLanguageProperty("Withdraw")+"']"));
						LogScreenshot("info","Withdrawing Ad hoc user");
						driver.findElement(By.xpath("//div[@id='wfCommentsDiv']//textarea")).sendKeys("Withdraw comments");
						waitUntilInvisibilityOfElement(processingLoader);
						findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Add")+"']]")).click();
						waitUntilInvisibilityOfElement(By.xpath("//div[@class='authorApproval']//span[contains(text(),'"+getLanguageProperty("Withdrawn")+"')]"));
					}
				}

				//Withdraw from existing approver
				LogScreenshot("info","Sent for Sign-off Stage");
				waitUntilInvisibilityOfElement(processingLoader);
				//driver.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}else{
			LogScreenshot("info","Workflow Not Present");
		}
		return isWorkflowActive;	
	}

	public void skipSigning() throws Exception{
		findElement(By.id("skipSigning"),"Skip Signing").click();
		waitUntilInvisibilityOfElement(processingLoader);
		waitUntilVisibilityOfElement(By.id("zydev-popup"));
		findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Proceed")+"']]"),"Proceed button").click();
		waitUntilInvisibilityOfElement(processingLoader);
		waitUntilVisibilityOfElement(By.xpath("//span[@class='yellowbutton' and text()='"+getLanguageProperty("Signed")+"']"));
		//Verify if Contract Status changed to 'Signed'
		if(driver.findElements(By.xpath("//span[@class='yellowbutton' and text()='"+getLanguageProperty("Signed")+"']")).size()>0)
			logger.pass("Contract Status changed to 'Signed'");
		else
			logger.fail("Contract Status not changed to 'Signed'");
	}

	public boolean sendForSigning(boolean isSignoffWorkflowActive, String signingOption) throws Exception {
		boolean result = false;

		LogScreenshot("info","Starting Sign-in");
		clickElement(objSendForSigningBtn);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		Thread.sleep(5000);



		try {
			if(driver.findElement(By.id("zydev-popup")).isDisplayed()) {

				String popTitle = driver.findElement(By.xpath("//span[@class='ui-dialog-title']")).getText();
				if(popTitle.equals("Contract Document List")) {
					LogScreenshot("info", "Contract Document List");
					By ProceedBtn = By.xpath("//div[@aria-describedby='zydev-popup']//button/span[text()='"+getLanguageProperty("Proceed")+"']");
					clickElement(ProceedBtn);
					waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'blockUI')]"));
				}
			}
		}catch (Exception e) {}

		try {
			Thread.sleep(5000);
			String confirmESig = null;
			String popUpFinderXpath = "//div[contains(@class,'zys-popup-container')][div/h1[text()='"+getLanguageProperty("Confirm")+"']]";
			if (signingOption.equals("e-Signature"))
				confirmESig = "No";
			else if (signingOption.equals(getLanguageProperty("Offline Signing")))
				confirmESig = "Yes";
			System.out.println(driver.findElements(By.xpath(popUpFinderXpath)).size());
			// if(driver.findElements(By.xpath(popUpFinderXpath)).size()>0){
			Thread.sleep(2000);
			System.out.println(popUpFinderXpath + "//button[text()='" + confirmESig + "']");
			LogScreenshot("info","Confirm Pop-up");
			clickElement(By.xpath(popUpFinderXpath + "//button[text()='" + confirmESig + "']"));
			if (signingOption.equals("e-Signature")) {
				if (objAlerts.size() > 0)
					findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")).click();
			}

			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'blockUI')]"));
			Thread.sleep(5000);
			if(driver.findElements(By.id("sendMailBodyIdEmail")).size()>0) {
				LogScreenshot("info", "Sending Mail for Signing");
				clickElement(By.id("sendMailBtn"));
				waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'blockUI')]"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			if(driver.findElements(By.id("zys-popup-content")).size()>0) {

				String msg = driver.findElement(By.id("zys-popup-msg")).getText();
				if(msg.contains("internal signers")) {
					LogScreenshot("info", msg);
					driver.findElement(By.id("jqi_state0_buttonOK")).click();
				}
			}
		}catch (Exception e) {}

		if(!(objTopYellowBtn.getText().contains("Signing In Progress"))) {
			Signers objSigners = new Signers(driver, logger);
			navigate_ContractSubTabs("Signers");
			if (objSigners.sendForSigning(isSignoffWorkflowActive,signingOption))
				result = true;
		}	// }

		return result;
	}

	public boolean addAdHocUser(String assignAfter, String assignTo, String adHocComments){
		boolean result = false;
		try{
			findElement(By.xpath("//input[@value='"+getLanguageProperty("Add Adhoc User")+"']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilVisibilityOfElement(By.xpath("//div[@aria-describedby='adhocUserListingDiv']"));

			String tempAssignAfter = splitString(assignAfter);
			driver.findElement(By.xpath("//input[contains(@class,'adhocUserFrom') and @type='text']")).sendKeys(tempAssignAfter);
			findElement(By.xpath("//div[contains(@class,'adhocUserListFrom')]/span[strong[contains(text(),'"+tempAssignAfter+"')]]")).click();

			String tempAssignTo = splitString(assignTo);
			driver.findElement(By.xpath("//input[contains(@class,'adhocUserTo') and @type='text']")).sendKeys(tempAssignTo);
			findElement(By.xpath("//div[contains(@class,'adhocUserListTo')]/span[contains(text(),'"+tempAssignTo+"')]")).click();

			driver.findElement(By.id("adhocComments")).sendKeys(adHocComments);
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Add")+"']]")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'Processing')]"));
			waitUntilVisibilityOfElement(By.xpath("//div[@class='authorApproval']"));
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'Processing')]"));
			if(driver.findElements(By.xpath("//div[@class='authorApproval']")).size()==2){
				LogScreenshot("pass","Ad Hoc User Added");
				result = true;
			}else {
				LogScreenshot("fail","Unable to add Ad Hoc User");
			}
			waitUntilVisibilityOfElement(By.xpath("//div[@class='authorApproval']//span[@title='"+getLanguageProperty("Withdraw")+"']"));
			waitUntilInvisibilityOfElement(processingLoader);

		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	public boolean uploadNegotiatedContract(String contractTitle) throws Exception {
		boolean result = false;
		//String fileDownloadedPath = "C:\\Users\\"+System.getProperty("user.name")+"\\Downloads";\
		String fileDownloadedPath = getDownloadFilePath(); 
		ConfigurationProperties config = ConfigurationProperties.getInstance();
		try {
			findElement(By.id("uploadSupplierCopy"),"Upload Supplier Copy button").click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]"));
			System.out.println(fileDownloadedPath +"\\" +contractTitle.replace("/", "_").replace(":", "_").replace("+", " ")+".docx");
			driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]//input[@type='file']"))
			.sendKeys(fileDownloadedPath +"\\" +contractTitle.replace("/", "_").replace(":", "_").replace("+", " ")+".docx");
			Thread.sleep(6000);
			findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]//button[span[text()='"+getLanguageProperty("Upload")+"']]"))
			.click();
			Thread.sleep(4000);
			try{
				if(driver.findElements(By.id("jqi")).size()>0){
					findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Proceed")+"']"),"Proceed button").click();
				}
			}catch(Exception e){}
			waitUntilInvisibilityOfElement(processingLoader);
			LogScreenshot("Pass","Negotiated Contract Uploaded");
			findElement(By.xpath("//div[@id='jqi'][div/h1[text()='"+getLanguageProperty("Success")+"']]//button[text()='"+getLanguageProperty("OK")+"']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
		} catch (Exception e) {
			e.printStackTrace();
			findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]//button[span[text()='"+getLanguageProperty("Cancel")+"']]"));
		}
		return result;
	}



	public boolean uploadContract(String contractTitle) throws FileNotFoundException, IOException {
		boolean result = false;
		ConfigurationProperties config = ConfigurationProperties.getInstance();
		try {
			LogScreenshot("info","Upload Contract Starting");
			findElement(By.id("signOffUpload")).click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]"));
			String contractFilePath = config.getProperty("contractUpload");
			driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]//input[@type='file']")).sendKeys(contractFilePath);
			Thread.sleep(6000);
			findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]//button[span[text()='"+getLanguageProperty("Upload")+"']]")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilVisibilityOfElement(By.id("publishToRepoBtn"));
			LogScreenshot("Pass","Contract Uploaded");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * @return the objContractNum
	 */
	public static WebElement getObjContractNum() {
		return objContractNum;
	}

	/**
	 * @param objContractNum the objContractNum to set
	 */
	public static void setObjContractNum(WebElement objContractNum) {
		ContractSummary.objContractNum = objContractNum;
	}

	/**
	 * @return the objContractTitle
	 */
	public static WebElement getObjContractTitle() {
		return objContractTitle;
	}

	/**
	 * @param objContractTitle the objContractTitle to set
	 */
	public static void setObjContractTitle(WebElement objContractTitle) {
		ContractSummary.objContractTitle = objContractTitle;
	}
	public void addToRepository(String contractNumber) throws Exception {

		waitUntilVisibilityOfElement(By.id("publishToRepoBtn"));
		clickElement(By.id("publishToRepoBtn"));
		waitUntilVisibilityOfElement(By.id("listFolderNamesPopup"));
		setInput(driver.findElement(By.id("txtAreaComment")), "Adding To Repository");
		LogScreenshot("pass","Adding contract to repository");
		WebElement proceedBtn = driver.findElement(By.xpath("//button[@type='button']/span[text()='"+getLanguageProperty("Proceed")+"']"));
		clickElement(proceedBtn);


		//Email Popup

		waitUntilVisibilityOfElement(By.id("submitForm"));
		String msg = driver.findElement(By.xpath("//div[contains(@style,'block')]//span[@class='ui-dialog-title']")).getText();
		LogScreenshot("pass", msg);

		WebElement toMail = driver.findElement(By.id("toListId"));
		String mailId = configurationProperties.getProperty("UserAccount");
		setInput(toMail, mailId);
		//		LogScreenshot("pass", msg);
		WebElement sendMailBtn=  driver.findElement(By.id("sendMail"));
		clickElement(sendMailBtn);
		waitUntilVisibilityOfElement(By.id("authorContractListing-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		clearAllFilters();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		filterByContractNum(contractNumber);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		String status = "Added to Repository";

		if(driver.findElements(By.xpath("//table[@id='authorContractListing-grid']//tbody/tr[td[span[text()='"+contractNumber+"']]]/td[span[text()='"+status+"']]")).size()>0)
			LogScreenshot("pass",contractNumber+" Added To Repository");
		else
			LogScreenshot("fail",contractNumber+" not Added To Repository" +" \n Status is:"+status);


	}

}
