package com.zycus.IContract.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class HelpVideos extends ProductVideos {
	
	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public HelpVideos(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> verifyLatestHelpVideo
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param displayName
	 * @return result - True/False
	 * @throws Exception
	 */
	
	public void checkReleaseVideos() throws Exception{
		verifyReleaseVideos("Release Videos","Product Videos","WordConnect Videos");
	}
	
	public void verifyReleaseVideos(String...videosType) throws Exception {
		String parent = driver.getWindowHandle();
		/*switchWindowHandles(parent, "Self Training Videos");*/
		waitForTabToLoad("Help Videos", "Self Training Videos");
		Thread.sleep(2000);
		String tableId = null;
		for(String videoTypeName : videosType){
			switch(videoTypeName){
				case "Release Videos":
					tableId = "releaseVideoTab";
					break;
				case "Product Videos":
					tableId = "productVideoTab";
					break;
				case "WordConnect Videos":
					tableId = "wordConnectVideoTab";
					break;
				}
			findElement(By.xpath("//li[contains(@class,'"+tableId+"')]")).click();
			if(verifyFirstHelpVideo(tableId))
				logger.pass("Latest "+videoTypeName+" displayed");
			else
				logger.fail("Latest "+videoTypeName+" not displayed");
		}
		driver.close();
		driver.switchTo().window(parent);
		Thread.sleep(2000);
	}
	
	private boolean verifyFirstHelpVideo(String tableId) throws Exception {
		boolean result = false;
		findElement(By.xpath("(//table[@id='"+tableId+"']/tbody/tr[1]/td[1]//a)[1]"),"Help Video").click();
		waitUntilVisibilityOfElement(By.xpath("//div[div/div[@id='modal_body'] and not(contains(@style,'none'))]"));
		Thread.sleep(3000);
		result = true;
		findElement(By.id("close")).click();
		Thread.sleep(2000);
		return result;
	}
	
}
