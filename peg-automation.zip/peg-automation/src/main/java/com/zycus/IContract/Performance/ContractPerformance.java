package com.zycus.IContract.Performance;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ContractPerformance extends eInvoice_CommonFunctions {

	protected String searchBy;
	protected String searchValue;
	private static By contractNumber = By.xpath("//label[contains(text(),'"+getLanguageProperty("Contract Number")+"')]/following-sibling::label");
	private static By contractTitle = By.xpath("//label[contains(text(),'"+getLanguageProperty("Contract Title")+"')]/following-sibling::label");
	private static By totalValue = By.xpath("//label[contains(text(),'"+getLanguageProperty("Total Value")+"')]/following-sibling::label");
	private static By contractExpDate = By.xpath("//label[contains(text(),'"+getLanguageProperty("Contract Expiration Date")+"')]/following-sibling::label");
	private static By contractingPartyName = By.xpath("//label[contains(text(),'"+getLanguageProperty("Contracting Party Name")+"')]/following-sibling::label");
	
	
	public ContractPerformance(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
	}


	/**
	 * @return the contractNumber
	 */
	public static By getContractNumber() {
		return contractNumber;
	}


	/**
	 * @param contractNumber the contractNumber to set
	 */
	public static void setContractNumber(By contractNumber) {
		ContractPerformance.contractNumber = contractNumber;
	}


	/**
	 * @return the contractTitle
	 */
	public static By getContractTitle() {
		return contractTitle;
	}


	/**
	 * @param contractTitle the contractTitle to set
	 */
	public static void setContractTitle(By contractTitle) {
		ContractPerformance.contractTitle = contractTitle;
	}


	/**
	 * @return the totalValue
	 */
	public static By getTotalValue() {
		return totalValue;
	}


	/**
	 * @param totalValue the totalValue to set
	 */
	public static void setTotalValue(By totalValue) {
		ContractPerformance.totalValue = totalValue;
	}


	/**
	 * @return the contractExpDate
	 */
	public static By getContractExpDate() {
		return contractExpDate;
	}


	/**
	 * @param contractExpDate the contractExpDate to set
	 */
	public static void setContractExpDate(By contractExpDate) {
		ContractPerformance.contractExpDate = contractExpDate;
	}


	/**
	 * @return the contractingPartyName
	 */
	public static By getContractingPartyName() {
		return contractingPartyName;
	}


	/**
	 * @param contractingPartyName the contractingPartyName to set
	 */
	public static void setContractingPartyName(By contractingPartyName) {
		ContractPerformance.contractingPartyName = contractingPartyName;
	}
}
