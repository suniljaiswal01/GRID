package com.zycus.IContract.Setup.ProductConfig;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class ProdConfig extends eInvoice_CommonFunctions {

	public static By pgHead = By.xpath("//div[@id='porductConfigurationDiv']//h2[text()='"+getLanguageProperty("Product Configuration")+"']");
	public By clearFilters = By.xpath("//span[@class='clearSearch']");

	private String contractType;
	private String contractSubType;
	
	public ProdConfig(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
		String[][] abc1 = (String[][]) objFunctions.dataProvider("TypeSubType", Datasheet_iContract);
		this.contractType = abc1[0][0];
		this.contractSubType = abc1[0][1];
	}

	public boolean selectWorkflow(String category, String subCategory) {
		boolean result = false;
		try {
			result = clickAndWaitUntilElementAppears(
					By.xpath("//h2[@class='hd' and text()='" + category + "']/following-sibling::div/a[text()='"
							+ subCategory + "']"),
					By.xpath("//h3[contains(@class,'mainhead')]/label[text()='" + subCategory + "']")) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void selectWorkflow(String subCategory) throws Exception{
		Thread.sleep(3000);
		try{
			if(driver.findElements(By.xpath("//div[@class='cns_NotificationBox' and contains(@style,'block')]")).size()>0){
				findElement(By.xpath("//label[@class='cns_CancelNotification']")).click();
				Thread.sleep(2500);
			}
		}catch(Exception e){
		}

		waitUntilVisibilityOfElement(By.xpath("//div[@class='pad']"));
		Thread.sleep(3000);
		//		JavascriptExecutor js = (JavascriptExecutor)driver;
		//		js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//div[@id='porductConfigurationDiv']//a[text()='"+subCategory+"']")));
		findElement(By.xpath("//div[@id='porductConfigurationDiv']//a[text()='"+subCategory+"']")).click();
		waitUntilVisibilityOfElement(By.xpath("//h3[contains(@class,'mainhead')]/label[text()='" + subCategory + "']"));
	}

	public boolean verifyIfTouchFree(String contractType, String contractSubType) throws Exception{
		boolean result = false;
		if(driver.findElements(By.xpath("//select[@id='touchfree']/following-sibling::span[@title='Select Type Sub-type' and @class='blueText']")).size()>0){
			WebElement objSelectContract = driver.findElement(By.xpath("//select[@id='touchfree']/following-sibling::span[@title='"+getLanguageProperty("Select Type Sub-type")+"' and @class='blueText']"));
			scroll_into_view_element(objSelectContract);
			objSelectContract.click();			
			waitUntilVisibilityOfElement(By.id("zydev-popup"));
			WebElement objCheckBox = driver.findElement(By.xpath("(//table[@id='ConfigFieldTable']/tbody/tr[@class='blueRow'][td/div[text()='"+contractType+"']]/following-sibling::tr[td/div[@title='"+contractSubType+"']])[1]//input[@type='checkbox']"));
			if(objCheckBox.isSelected()){
				LogScreenshot("Info", "Contract Type : "+contractType +", Contract Sub Type : "+contractSubType+" configured as touch free");
				result = true;
			}
			try{
				if(driver.findElement(By.id("zydev-popup")).isDisplayed()){
					findElement(By.xpath("//button/span[text()='"+getLanguageProperty("Done")+"']"),"Done button").click();
					waitUntilInvisibilityOfElement(By.id("zydev-popup"));
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if(result==false)
			LogScreenshot("Info", "Contract Type : "+contractType +", Contract Sub Type : "+contractSubType+" configured as not touch free");
		return result;
	}

	public boolean verifyByPassAuthWorkflow() throws Exception{
		boolean result = false;
		if(driver.findElements(By.id("skipSystemWorkflow")).size()>0){
			WebElement objByPassAuthCheckbox = driver.findElement(By.id("skipSystemWorkflow"));
			scroll_into_view_element(objByPassAuthCheckbox, "Bypass Auth Workflow");
			if(objByPassAuthCheckbox.isSelected()){
				LogScreenshot("Info", "By Pass Auth Workflow selected");
				result = true;
			}else
				LogScreenshot("Info", "By Pass Auth Workflow not selected");
		}
		return result;
	}

	public void navigateToApplicationSettings() throws Exception{
		findElement(By.id("applicationSettingsDiv"),"Application Settings").click();
		waitUntilInvisibilityOfElement(processingLoader);
		Thread.sleep(2000);
		LogScreenshot("Pass", "Navigated to Application Setting page");
	}

	public void exitFromAppSettingsPage() throws Exception{
		Thread.sleep(2000);
		if(driver.findElements(By.id("jqi")).size()>0)
			findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")).click();
	}

	public void navigateToIntegrationSettings() throws Exception{
		findElement(By.id("integrationSetting"),"Integration Settings").click();
		waitUntilInvisibilityOfElement(processingLoader);
		Thread.sleep(2000);
		LogScreenshot("Pass", "Navigated to Integration Settings page");
	}

	public void flexiformMapping() throws Exception{
		findElement(By.xpath("//tr[@class='filterGridTblTd']//td/label[contains(text(),'"+getLanguageProperty("FLEXI CONTRACT TYPE MAPPING")+"')]//..//..//td/label[@id='configuration']"),"FLEXI CONTRACT TYPE MAPPING").click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		Thread.sleep(2000);
		LogScreenshot("Pass", "Navigated to Flexiform Mapping page");
	}

	public String editFlexiForm() throws Exception{
		String sectionName= "Section"+ String.valueOf(generateNo());
		String generatedSection = null;
		findElement(By.xpath("//tr[@class='dataRow filterGridTblTd']//span[contains(text(),'"+contractType+"/"+contractSubType+"')]//..//..//..//td//span[@title='"+getLanguageProperty("View")+"']")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		Thread.sleep(3000);	
		if(driver.findElements(By.xpath("//div[@class='ContractTitle']/div/span[text()='Associate Form with Type Subtype']")).size()>0){
			LogScreenshot("Pass","Navigated to 'Associate Form with Type Subtype' page");
			driver.findElement(By.id("eFormsectionData")).clear();
			driver.findElement(By.id("eFormsectionData")).sendKeys(sectionName);
			findElement(By.xpath("//div[@id='editDeleteBlock']//i[@class='icon edit']")).click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(4000);
			LogScreenshot("Info","Navigated to flexiform Edit page");
			List<WebElement> sections= driver.findElements(By.xpath("//ul[@id='zydf-devElemetsContainer']/li"));
			Thread.sleep(2000);
			for(int i=1;i<= sections.size();i++) {
				Thread.sleep(2000);
				WebElement deleteSection= findElement(By.xpath("//ul[@id='zydf-devElemetsContainer']/li//div[contains(@class,'section-head')]/a[contains(@title,'delete')][1]"));
				scroll_into_view_element(deleteSection);
				deleteSection.click();
				if(driver.findElements(By.xpath("//td[contains(text(),'"+getLanguageProperty("remove section")+"')]")).size()>0) {
					clickElement(findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Yes")+"']")));
					LogScreenshot("INFO","Section is deleted");
					generatedSection = sectionName;
				}
			}
		}else
			LogScreenshot("Fail","Unable to view associated form with "+contractType+"/"+contractSubType);
		return generatedSection;	
	}

	public String addFlexiForm(String sectionDesc, String sectionLayout, String fieldDefaulVal, int fieldMaxChar, boolean isFieldMandatory) throws Exception{
		String generatedSectionName = null;
		FormWizard objFormWiz= new FormWizard(driver, logger);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		navigateToIntegrationSettings();
		flexiformMapping();
		String sectionName= editFlexiForm();
		if(sectionName!=null){
			objFormWiz.createNewFlexiForm(sectionDesc, sectionLayout, fieldDefaulVal, fieldMaxChar, isFieldMandatory,sectionName);
			try{
				WebElement sectionNameField =  driver.findElement(By.id("eFormsectionData"));
				if(sectionName.equals(js.executeScript("return arguments[0].value", sectionNameField))){
					LogScreenshot("Pass", "Flexiform saved successfully");
					generatedSectionName = sectionName;
				}
			}catch(Exception e){
				LogScreenshot("Fail", "Unable to save flexiform");
			}
		}else
			LogScreenshot("fail", "Unable to edit flexiform for "+contractType+"/"+contractSubType);
		return generatedSectionName;
	}	

	public boolean verifyFlexiFormInContract(String sectionName) throws Exception{
		int count=0;
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		clickElement(By.id("addnew"));
		driver.findElement(By.xpath("//div[@class='selectList']//li//a[contains(text(),'"+getLanguageProperty("Procurement")+"')]")).click();
		driver.findElement(By.xpath("//label[contains(text(),'"+contractSubType+"')]//preceding-sibling::input[@type='radio']")).click();
		LogScreenshot("INFO","Contract type/subtype selected");
		clickElement(By.xpath("//input[@type='button'][@value='"+getLanguageProperty("Continue")+"']  "));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		LogScreenshot("INFO","Contract creation page is displayed");
		List <WebElement> contractTabs = driver.findElements(By.xpath("//div[@class='zys-default-tab']//li"));
		for(int i=1;i<=contractTabs.size();i++) {
			if(driver.findElement(By.xpath("//div[@class='zys-default-tab']//li["+i+"]")).getText().equals(sectionName)) {
				count++;
				driver.findElement(By.xpath("//div[@class='zys-default-tab']//li["+i+"]")).click();
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				LogScreenshot("PASS","Flexiform displayed");
				break;
			}	
		}
		if(count==1) {
			LogScreenshot("PASS","Flexiform Integration successful");
		}else
			LogScreenshot("PASS","Flexiform is not present. Flexiform Integration failed");

		return false;


	}	


}




