package com.zycus.IContract.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ReleaseNotes extends eInvoice_CommonFunctions {

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public ReleaseNotes(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> verifyLatestReleaseNote
	 * 
	 * @author Varun Khurana
	 * @since Oct 2018
	 * @param latestRelease
	 * @return result - True/False
	 * @throws Exception
	 */
		
	public void verifyLatestReleaseNote(String latestRelease) throws Exception {
		String filePath = "C:\\Users\\"+System.getProperty("user.name")+"\\Downloads";
		String filePartName = "Release_Notes";
		String fileExtension = "pdf";
		//Switch to tab 'Release Notes'
			String parent = driver.getWindowHandle();
			switchWindowHandles(parent, "Release Notes");
			Thread.sleep(2000);
			WebElement objLatestRelNote = driver.findElement(By.xpath("//table[@id='releaseNoteTab']//a[1]"));
			String latestRelNote = objLatestRelNote.getText();
			if(latestRelNote.contains(latestRelease)){
				try{
					deleteFiles(filePath, filePartName, fileExtension);
				}catch(Exception e){}
				objLatestRelNote.click();
				//Files.lines(Paths.get("C:\\Users\\varun.khurana\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Preferences"), StandardCharsets.UTF_8).forEach(System.out::println);
				//Waiting time for the file to get downloaded
				Thread.sleep(8000);
				if(checkFileExists(filePath, filePartName, fileExtension)){
					driver.close();
					logger.pass("Release notes verified");
				}
			}
	}

}
