package com.zycus.IContract.ManageContracts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.main.CommonTests1;
import com.main.ZycusCoreDriver;
import com.zycus.ZSN.MyContracts.ViewContracts;

import Framework.CommonUtility;
//import Flash.FlashObjectWebDriver;
import Framework.ConfigurationProperties;
import Framework.FrameworkUtility;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iContract_CommonFunctions;

public class CreateContract extends iContract_CommonFunctions {

	private static By processingLoader = By.xpath("//span[@class='zys-loader-icon']");
	public static By pgHead = By.xpath("//div[@class='formTitle']/span[text()='"+getLanguageProperty("Create Contract")+"']");
	static By initialDetailsSection = By.xpath("//div[@class='contractBasicDetail']");
	private String contractType;
	private String contractSubType;
	private boolean isNegotationAllowed;
	private boolean isExternalTemplate;
	private boolean sendForInternalReview;
	private boolean byPassAuthoringWorkflow;
	private String contractTitle;
	private String contractNumber;
	private String displayStyle;
	private String Product = "iContract";
	private boolean isSignoffWorkflowActive;
	private String externalSupplier;
	private String externalPass;
	private String authoringUserEmail;
	
	
	public CreateContract(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
        String[][] abc = (String[][]) objFunctions.dataProvider("AuthorContract", Datasheet_iContract);
        this.isNegotationAllowed = Boolean.parseBoolean(abc[0][0]);
        this.isExternalTemplate = Boolean.parseBoolean(abc[0][1]);
        this.sendForInternalReview = Boolean.parseBoolean(abc[0][2]);
        this.isSignoffWorkflowActive = Boolean.parseBoolean(abc[0][3]);
        this.authoringUserEmail = abc[0][4];
        
        String[][] abc1 = (String[][]) objFunctions.dataProvider("TypeSubType", Datasheet_iContract);
        this.contractType = abc1[0][0];
		this.contractSubType = abc1[0][1];
		
		/*String[][] supplierDetails = (String[][]) objFunctions.dataProvider("SupplierDetails", Datasheet_iContract);
	    this.externalSupplier = supplierDetails[0][0];
		this.externalPass = supplierDetails[0][1];*/
		
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		this.externalSupplier = supplierDetails.getSupplierEmail();
		this.externalPass = supplierDetails.getSupplierPassword();
	}
	
	
	public CreateContract(WebDriver driver, ExtentTest logger,String contractNumber,String contractTitle) throws Exception {
		super(driver, logger);
		this.contractNumber = contractNumber;
		this.contractTitle = contractTitle;
		CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
        String[][] abc = (String[][]) objFunctions.dataProvider("AuthorContract", Datasheet_iContract);
        this.isNegotationAllowed = Boolean.parseBoolean(abc[0][0]);
        this.isExternalTemplate = Boolean.parseBoolean(abc[0][1]);
        this.sendForInternalReview = Boolean.parseBoolean(abc[0][2]);
        this.isSignoffWorkflowActive = Boolean.parseBoolean(abc[0][3]);
        this.authoringUserEmail = abc[0][4];
        
        String[][] abc1 = (String[][]) objFunctions.dataProvider("TypeSubType", Datasheet_iContract);
        this.contractType = abc1[0][0];
		this.contractSubType = abc1[0][1];
		
		/*String[][] supplierDetails = (String[][]) objFunctions.dataProvider("SupplierDetails", Datasheet_iContract);
	    this.externalSupplier = supplierDetails[0][0];
		this.externalPass = supplierDetails[0][1];*/
		

		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		this.externalSupplier = supplierDetails.getSupplierEmail();
		this.externalPass = supplierDetails.getSupplierPassword();
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}
	
	/*public boolean startAuthoring(){
		boolean result = false;
		try{
			if(templateName!="")
				if(startAuthoring(contractType, contractSubType, isNegotationAllowed, templateName))
					result = true;
			else if(isExternalTemplate)
				if(startAuthoring(contractType, contractSubType, isNegotationAllowed, isExternalTemplate))
					result = true;
			else 
				if(startAuthoring(contractType, contractSubType, isNegotationAllowed))
					result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}*/
	
	
	
	/*public void startAuthoring() throws Exception{
		try{
			if(templateName!="")
				startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, templateName);
			else if(isExternalTemplate)
				startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, isExternalTemplate);
			else 
				startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview);
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/
	
	public void startAuthoring(String templateName) throws Exception{
		if(templateName!="")
			startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, templateName);
		else if(isExternalTemplate)
			startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, isExternalTemplate);
		else 
			startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview);
	}
	
	public void startAuthoring(String templateName, boolean isNegotationAllowed, boolean isExternalTemplate) throws Exception{
		sendForInternalReview = isNegotationAllowed;
		if(templateName!="")
			startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, templateName);
		else if(isExternalTemplate)
			startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, isExternalTemplate);
		else 
			startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview);
	}

	private boolean startAuthoring(String contractType, String contractSubType, boolean isNegotationAllowed, boolean byPassAuthoringWorkflow, 
			boolean sendForInternalReview, String templateName) throws Exception {
		boolean result = false;
		try {
			if (selectIntialDetails(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview)) {
				boolean templateSelected = false;
				if (templateName == "")
					templateSelected = selectTemplate();
				else
					templateSelected = selectTemplate(templateName);
				if (templateSelected) {
					waitUntilInvisibilityOfElement(By.id("jqifade"));
					Thread.sleep(1000);
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[@name='startAuthoring']"), processingLoader);
					Thread.sleep(3000);
					try {
						findElement(By.xpath("//div[@id='zys-popup-content']/following-sibling::div/button")).click();
					} catch (Exception e) {
					}
					waitUntilInvisibilityOfElement(processingLoader);
					ContractDetails objDetails = new ContractDetails(driver, logger);
					if (objDetails.getPgHead() != null) {
						LogScreenshot("INFO","navigated to Contract details page on clicking Start Authoring button");
						objDetails.enterContractDetails();
						result = true;
					}
				} else {
					LogScreenshot("INFO", "template not selected");
					throw new Exception();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO", "not navigated to Contract details page");
			throw new Exception();
		}
		return result;
	}

	private boolean startAuthoring(String contractType, String contractSubType, boolean isNegotationAllowed, boolean byPassAuthoringWorkflow, boolean sendForInternalReview) throws Exception {
		boolean result = false;
		try {
			if (selectIntialDetails(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview)) {
				ContractDetails objDetails = new ContractDetails(driver, logger);
				if (uploadExternaltemplate(objDetails)){
					objDetails.enterContractDetails();
					result = true;
				}else {
					LogScreenshot("INFO", "template not selected");
					throw new Exception();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO", "not navigated to Contract details page");
		}
		return result;
	}
	
	

	/*public boolean uploadExternaltemplate() throws Exception {
		boolean result = false;
		try {
			findElement(By.id("externalButton")).click();
			ConfigurationProperties config = ConfigurationProperties.getInstance();
			driver.findElement(By.xpath("//input[@type='button' and @value='Browse']/following-sibling::input"))
					.sendKeys(System.getProperty("user.dir") + config.getProperty("upload_docxfile_path"));
			waitUntilInvisibilityOfElement(By.xpath("//input[@id='extractClauses' and @disabled]"));
			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'blockOverlay')]"));
			try {
				WebElement continueBtn = findElement(By.xpath("//input[@id='extractClauses']"));
				LogScreenshot("INFO", "file uploaded successfully");
				continueBtn.click();
			} catch (Exception e) {
				LogScreenshot("INFO", "file not uploaded successfully");
			}
			ContractDetails objDetails = new ContractDetails(driver, logger);
			if (objDetails.getPgHead() != null) {
				result = true;
				LogScreenshot("INFO", "navigated to Contract details page on cliking Continue button");
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO", "not navigated to Contract details page");
		}
		return result;

	}*/
	
	public boolean uploadExternaltemplate(ContractDetails objDetails) throws Exception {
		boolean result = false;
		try {
			findElement(By.id("externalButton")).click();
			ConfigurationProperties config = ConfigurationProperties.getInstance();
			driver.findElement(By.xpath("//input[@type='button' and @value='"+getLanguageProperty("Browse")+"']/following-sibling::input"))
					.sendKeys(config.getProperty("upload_docxfile_path"));
			waitUntilInvisibilityOfElement(By.xpath("//input[@id='extractClauses' and @disabled]"));
			waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'blockOverlay')]"));
			try {
				WebElement continueBtn = findElement(By.xpath("//input[@id='extractClauses']"));
				LogScreenshot("INFO", "file uploaded successfully");
				continueBtn.click();
			} catch (Exception e) {
				LogScreenshot("INFO", "file not uploaded successfully");
			}
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//div[@id='jqi']")).size()>0)
				driver.findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			//ContractDetails objDetails = new ContractDetails(driver, logger);
			if (objDetails.getPgHead() != null) {
				result = true;
				LogScreenshot("INFO", "navigated to Contract details page on cliking Continue button");
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO", "not navigated to Contract details page");
		}
		return result;

	}

	private boolean startAuthoring(String contractType, String contractSubType, boolean isNegotationAllowed,boolean byPassAuthoringWorkflow, 
			boolean sendForInternalReview, boolean isExternalTemplate) throws Exception {
		boolean result = false;
		try {
			if (isExternalTemplate)
				startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview);
			else
				startAuthoring(contractType, contractSubType, isNegotationAllowed, byPassAuthoringWorkflow, sendForInternalReview, "");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
		return result;
	}

	private boolean selectIntialDetails(String contractType, String contractSubType, boolean isNegotiationAllowed, boolean byPassAuthoringWorkflow, boolean sendForInternalReview)
			throws Exception {
		boolean result = false;
		try {
			driver.findElement(By.xpath("//select[@name='contractType']/option[text()='" + contractType + "']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			driver.findElement(By.xpath("//select[@name='subTypeName']/option[text()='" + contractSubType + "']")).click();
			//if(driver.findElement(By.xpath("//div[@id='bypassNegotiationWorkflowSelect']")).isDisplayed()){
			if(driver.findElements(By.xpath("//div[@id='bypassNegotiationWorkflowSelect']")).size()>0){
				if (isNegotiationAllowed){
					try {
						findElement(By.xpath("//div[@id='bypassNegotiationWorkflowSelect']/span[@value='"+getLanguageProperty("false")+"']  ")).click();
					} catch (Exception e) {
						LogScreenshot("INFO", "Options to select Negotiation round for contract - not displayed");
					}
				}else 
					findElement(By.xpath("//div[@id='bypassNegotiationWorkflowSelect']/span[@value='"+getLanguageProperty("true")+"']  ")).click();
				
			}	
			
			//Uncomment later for Bypassing Authoring Workflow
			/*if(!byPassAuthoringWorkflow){
				//if(driver.findElement(By.xpath("//div[@id='bypassAuthoringWorkflowSelect']")).isDisplayed()){
				if(driver.findElements(By.xpath("//div[@id='bypassAuthoringWorkflowSelect']")).size()>0){
					if (sendForInternalReview){
						try {
							findElement(By.xpath("//div[@id='bypassAuthoringWorkflowSelect']/span[@value='0']")).click();
						} catch (Exception e) {
							LogScreenshot("INFO", "Options to select Negotiation round for contract - not displayed");
						}
					}else 
						findElement(By.xpath("//div[@id='bypassAuthoringWorkflowSelect']/span[@value='1']")).click();				
				}
			}*/
			waitUntilVisibilityOfElement(By.xpath("//div[@id='suggestedTemplateDiv']/div[1]"));			
			LogScreenshot("INFO",	"Contract Type : " + contractType + "& Contract Sub Type : " + contractSubType + " selected");
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO",
					"Contract Type : " + contractType + "& Contract Sub Type : " + contractSubType + " not selected");
			throw new Exception();
		}
		return result;
	}

	private boolean selectTemplate(String templateName) throws Exception {
		boolean result = false;
		searchTemplate(templateName);
		try {
			Thread.sleep(3000);
			findElement(By.xpath("(//div[@class='tileTitle ellipsisBx' and contains(text(),'" + templateName + "')])[1]")).click();
			try {
				findElement(By.xpath("//div[@id='zys-popup-content']/parent::div//button[text()='"+getLanguageProperty("OK")+"']")).click();
			} catch (Exception e) {
			}
			if (driver.findElements(By.xpath("//div[contains(@class,'selected')]")).size() > 0) {
				LogScreenshot("INFO", "Template : " + templateName + " selected");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO", "Template : " + templateName + " not selected");
		}
		return result;
	}

	private boolean selectTemplate() throws Exception {
		boolean result = false;
		try {
			WebElement firstTemplate = findElement(By.xpath("(//div[@class='tileTitle ellipsisBx'])[1]"));
			firstTemplate.click();
			try {
				findElement(By.xpath("//div[@id='zys-popup-content']/parent::div//button[text()='"+getLanguageProperty("OK")+"']")).click();
			} catch (Exception e) {
			}
			if (driver.findElements(By.xpath("//div[contains(@class,'selected')]")).size() > 0) {
				LogScreenshot("INFO", "Template : " + firstTemplate.getText() + " selected");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("INFO", "No template selected");
		}
		return result;
	}
	
	public void searchTemplate(String templateName) throws Exception{
		//Searching for template no as full Template name search shows no result
		String templateNo = (templateName.split("-"))[0].trim();
		driver.findElement(By.id("searchBox")).sendKeys(templateNo+Keys.ENTER);
		waitUntilVisibilityOfElement(By.xpath("//div[@id='suggestedTemplateDiv']/div[1]/div[1]/div[1][contains(text(),'"+templateName+"')]"));
	}

	
	public void enterContractDetails(String contractNumber,String displayStyle, boolean isTouchFreeContract, boolean byPassAuthorStage, boolean isNegotiating) throws Exception {
		
//		contractSummaryDetails();
		verifyContractStatusinGrid(contractNumber);
		navigateToStage(contractNumber, "Author");
		if(addContractingParty()) {
			addContractOutLine();
			addLineItem();
			addDocument();
			addMileStone();
			addTimeline();
			sendToSigning(contractNumber,displayStyle,isTouchFreeContract,byPassAuthorStage,isNegotiating);
			isSignoffWorkflowActive =proceedToSignOff();
			if(isSignoffWorkflowActive) {
				internalReviewer(contractNumber);
//				authorReviewer();
			}
			sendForSigning();
			if(downloadContract()) {
				uploadContract();
			}
			addToRepository();
		}	
	}

	private void addToRepository() throws Exception {
		
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Contract Summary");
		objSummary.addToRepository(contractNumber);
		
	}

	private void sendToSigning(String contractNumber,String displayStyle, boolean isTouchFreeContract, boolean byPassAuthorStage, boolean isNegotiating) throws Exception {
		
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Contract Summary");
		objSummary.sendToSign(displayStyle, Product, contractNumber, isTouchFreeContract, byPassAuthorStage, isNegotiating);
		
	}

	private void uploadContract() throws Exception {
		try{
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.uploadContract(contractTitle);
		}catch(Exception e){
			Documents objDoc1 = new Documents(driver, logger);
			objDoc1.addDocument_ForEnd(contractTitle);
		}
		
	}

	private void sendForSigning() throws Exception {
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Contract Summary");
		objSummary.sendForSigning(isSignoffWorkflowActive, "Offline Signing");
		
	}

	public void authorReviewer() throws Exception {
		
		WebDriver driver1 = startSession(this.getClass().getName());
		displayStyle =getDisplayStyle(driver1, logger, CommonTests1.loginCredentials,authoringUserEmail);
		iContract_CommonFunctions objFunctions = new iContract_CommonFunctions(driver1, logger);
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		clrAllFilters();
		Thread.sleep(2000);
		filterByContractNum(contractNumber);
		navigateToStage(contractNumber, "Sign off");
		
	}

	private void internalReviewer(String contractNumber) throws Exception {
		
		String pendingWith = ConfigurationProperties.getInstance().getProperty("UserAccount");
		ZycusCoreDriver objDriver = new ZycusCoreDriver();
		WebDriver driver1 = objDriver.startSession(pendingWith,"Approve Contract with "+pendingWith);
		displayStyle = getDisplayStyle(driver1, logger, CommonTests1.loginCredentials,pendingWith);
		CommonUtility objUtility = new CommonUtility(driver1, logger);
		if(displayStyle.equals(getLanguageProperty("Classic")))
				objUtility.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contracts Pending Review");
		else
			objUtility.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
		
		ContractsPendingReview objReview = new ContractsPendingReview(driver1, logger);
		objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
	
		driver1.close();
	}

	private boolean proceedToSignOff() throws Exception {
		
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Contract Summary");
		return objSummary.proceedToSignOff(isSignoffWorkflowActive);
		
	}

	private boolean downloadContract() throws Exception {
				
		
		FrameworkUtility frameWorkUtility = new FrameworkUtility();
		CommonTests1 commontests = new CommonTests1();
		ConfigurationProperties configurationProperties =ConfigurationProperties.getInstance();
		WebDriver driver1 = frameWorkUtility.getWebDriverInstance1(this.getClass().getName());
		Login objLogin = new Login(driver1, logger, externalSupplier, externalPass);
		commontests.callAndLog(driver1,logger,objLogin.login(ConfigurationProperties.getInstance()), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", configurationProperties.getProperty("Tenant"));
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		boolean isFileDownloaded = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
		objLogin.logout();
		driver1.quit();
		return isFileDownloaded;
		
	}

	public void approveContract() throws Exception{
		
		WebDriver driver1 = startSession(this.getClass().getName());
		displayStyle =getDisplayStyle(driver1, logger, CommonTests1.loginCredentials,ConfigurationProperties.getInstance().getProperty("UserAccount"));
		iContract_CommonFunctions objFunctions = new iContract_CommonFunctions(driver1, logger);
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
		ContractsPendingReview objReview = new ContractsPendingReview(driver1, logger);
		objReview.approveContract("Authoring Stage", contractNumber, "Approve");
		driver1.quit();
		
	}

	public void authorReview() throws Exception {
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Author Review");
		objSummary.authorReview();
		
	}

	public boolean sendForApproval() throws Exception {
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Contract Summary");
		return objSummary.sendForApproval();
		
	}

	private void addTimeline() throws Exception {
		
		navigate_ContractSubTabs("Timeline");
		Timeline objTimeline = new Timeline(driver, logger, contractTitle);
		if(objTimeline.verifyVersionCreated())
			LogScreenshot("Pass","Version created and Downloaded");
		else
			LogScreenshot("info", "Version not created or Downloaded");
		
		if(objTimeline.verifyDocumentCreated())
			LogScreenshot("Pass", "Document visible in timeline and Downloaded");
		else
			LogScreenshot("info", "Document not visible or Downloaded in timeline");
		
	}

	private void addDocument() throws Exception {
		
		Documents objDoc = new Documents(driver, logger);
		navigate_ContractSubTabs("Documents");
		objDoc.selectDocuments(2);
		
	}

	private void addMileStone() throws Exception {
		
		Milestone objMilestone = new Milestone(driver, logger);
		navigate_ContractSubTabs("Milestones");
		objMilestone.addMilestone();
		
	}

	private boolean addContractingParty() throws Exception {
		
		ContractingParty objContParty = new ContractingParty(driver, logger);
		navigate_ContractSubTabs("Contracting Party");
		return objContParty.addContractingParties();
	}

	private void addLineItem() throws Exception {
		
		LineItems objItems = new LineItems(driver, logger);
		navigate_ContractSubTabs("Line Items");
		objItems.createLineItem();
		
	}

	private void addContractOutLine() throws Exception {
		
		
		ContractOutline objOutline = new ContractOutline(driver, logger);
		navigate_ContractSubTabs("Contract Outline");
		objOutline.createVersion();
		
	}

	public String contractSummaryDetails() throws Exception {
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		navigate_ContractSubTabs("Contract Summary");
		contractNumber = objSummary.getContractNum();
		LogScreenshot("info","Contract Number created here is :"+ contractNumber);
		return contractNumber;
	}


	public String getContractTitle() throws Exception {
		
		ContractSummary objSummary = new ContractSummary(driver, logger);
		contractTitle = objSummary.getContractTitle();
		LogScreenshot("info","Contract Title created here is :"+ contractTitle);
		closeContract();
		return contractTitle;
	}
	
	/*public void testFlash() throws InterruptedException{
		try{
			findElement(By.xpath("//a[text()='"+getLanguageProperty("SignOff Stage Workflow Configuration")+"']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			findElement(By.xpath("(//span[@class='icon view'])[2]")).click();
			findElement(By.xpath("//div[@id='zydev-popup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Next")+"']]")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			//Thread.sleep(20000);
			Set<String> s1 = driver.getWindowHandles();
			Iterator<String> I1 = s1.iterator();
			while (I1.hasNext()) {
				String child_window = I1.next();
				//if (!parent.equals(child_window)) {
					Thread.sleep(4000);
					String title = driver.switchTo().window(child_window).getTitle();
					if (title.equals(getLanguageProperty("Workflow Editor"))) {
						break;
					}
				//}
			}
			
			
			
			//driver.switchTo().window("Workflow Editor");
			//Thread.sleep(10000);
			FlashObjectWebDriver flashApp = new FlashObjectWebDriver(driver, "WorkFlowEditor");
			JavascriptExecutor js = (JavascriptExecutor)driver;
			System.out.println(js.executeScript("return describeType()", flashApp));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}*/

}
