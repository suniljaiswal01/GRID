package com.zycus.IContract.ManageContracts;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iContract_CommonFunctions;

public class Repository extends iContract_CommonFunctions{

	private static By filterBtnXpath = By.xpath(
			"//div[contains(@class,'ui-tooltip') and contains(@style,'block')]//a[text()='"+getLanguageProperty("Filter")+"'][ancestor::div[@aria-hidden='false']]");
	private static By contractSrcXpath = By.xpath("//table[@id='repoContractListing-grid']/thead//th[contains(@id,'CONTRACT_SOURCE')]");
	private static By statusXpath = By.xpath("//table[@id='repoContractListing-grid']/tbody//td[4]/span");
	private static By stageXpath = By
			.xpath("//table[@id='authorContractListing-grid']/tbody//td[8]//li[@class='inprogress']/span");
	private static By pgHead = By.xpath("//div[@id='main-action-button']/h3[text()='"+getLanguageProperty("Author Contract")+"']");

	private List<String> contractingPartyList = new ArrayList<String>();
	private List<String> contactPersonList = new ArrayList<String>();
	private String contractingParty;
	private String contactPerson;


	public Repository(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		/*CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_SuppContacts = configurationProperties.getProperty("Datasheet_SupplierContacts");
		String[][] abc1 = (String[][]) objFunctions.dataProvider(configurationProperties.getProperty("Environment"), Datasheet_SuppContacts);
		for(int i=0; i<abc1.length ; i++){
			this.contractingPartyList.add(abc1[i][0]);
			this.contactPersonList.add(abc1[i][1]);
		}
		this.contractingParty = contractingPartyList.get(0);
		this.contactPerson = contactPersonList.get(0); */


		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		this.contractingParty = supplierDetails.getCompanyName();
		this.contactPerson = supplierDetails.getContactingPerson();

	}


	public String uploadContract() throws Exception {

		String contractID = null;
		try {
			//Click on '+ Upload Contract' button
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
			clickAndWaitUntilLoaderDisappears(By.id("addnew"));
			SelectContractType objSelectContract = new SelectContractType(driver, logger);
			if (objSelectContract.getPgHead() != null){
				LogScreenshot("pass","clicked on 'Upload Contract' button");
				objSelectContract.selectContractTypes();
				contractID = objSelectContract.addContractAndPublish();
				clickElement(By.id("closeContract"));
				waitUntilVisibilityOfElement(By.id("repoContractListing-grid"));
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));/*
				String contractStatus = driver.findElement(By.xpath("//span[contains(@class,'statusBg')]")).getText().trim();*/
				if(filterByContractNumber(contractID)) {

					int statusCol = getColNum_IContract("Status");
					String contractStatus = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td["+statusCol+"]/span")).getText().trim();
					if(contractStatus.contains("Active")) {
						LogScreenshot("pass","Contract:"+contractID+" Uploaded And Published");
					}else {
						LogScreenshot("info","Contract Status in "+contractStatus);
						LogScreenshot("info","Waiting for 3 min");
						Thread.sleep(180000);
						driver.navigate().refresh();
						waitUntilVisibilityOfElement(By.id("repoContractListing-grid"));
						waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
						if(filterByContractNumber(contractID)) {

							statusCol = getColNum_IContract("Status");
							contractStatus = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td["+statusCol+"]/span")).getText().trim();
							if(contractStatus.contains("Active")) {
								LogScreenshot("pass","Contract: "+contractID+" Uploaded And Published");
							}else {
								LogScreenshot("fail","Contract :"+contractID+" Status in :"+contractStatus+" status" );
							}

						}
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("fail"," Not navigated to 'Select Contract Type' page");
			throw new Exception();
		}
		return contractID;
	}




	public boolean linkMasterToContract(String masterContract, String contractToLink){
		boolean result = false;
		try{
			filterByStatus("Active");
			filterByContractNumber(masterContract);
			findElement(By.xpath("//table[@id='repoContractListing-grid']/tbody/tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")).click();
			findElement(By.xpath("//table[@id='repoContractListing-grid']/tbody/tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']/..//span[@id='edit']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			if(ContractSummary.getObjContractNum().getText().equals(masterContract)){
				findElement(By.xpath("//li[@id='contractHierarchy']/span")).click();
				waitUntilInvisibilityOfElement(processingLoader);
				Hierarchy objHierarchy = new Hierarchy(driver,logger);
				objHierarchy.linkContract(contractToLink);
				result = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}


	public void cloneInRepository(String contractNumber) throws Exception {

		clearAllFilters();
		filterByContractNumber(contractNumber);
		Thread.sleep(3000);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		WebElement actionBtn = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td//a[text()='"+getLanguageProperty("Actions")+"']"));
		clickElement(actionBtn);
		waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
		clickElement(actionBtn.findElement(By.xpath(".//..//ul/li/span[contains(text(),'"+getLanguageProperty("Clone in Repository")+"')]")));
		waitUntilVisibilityOfElement(By.id("Contract_Header"));

		waitUntilVisibilityOfElement(By.xpath("//ul[@id='headerTab']"));
		List<WebElement> headersList = driver.findElements(By.xpath("//ul[@id='headerTab']/li"));
		for(WebElement header: headersList) {
			clickElement(header);
			LogScreenshot("info", header.getText()+" Section Opened");
		}
		waitUntilVisibilityOfElement(By.id("flexiFormContainer"));
		//		enterFlexiFormDetails();
		Thread.sleep(5000);
		WebElement saveBtn = driver.findElement(By.id("saveBtn"));
		clickElement(saveBtn);
		if(driver.findElements(By.xpath("//label[text()='"+getLanguageProperty("Please enter a value")+"']")).size()>0) {
			enterFlexiFormDetails();
			Thread.sleep(5000);
			saveBtn = driver.findElement(By.id("saveBtn"));
			clickElement(saveBtn);
		}
		
		
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		
		String contractID = driver.findElement(By.xpath("//span[@class='topTitle']/span[1]")).getText().trim();
		
		publishContract();

		clickElement(By.id("closeContract"));
		waitUntilVisibilityOfElement(By.id("repoContractListing-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		clearAllFilters();
		waitUntilVisibilityOfElement(By.id("repoContractListing-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		/*
		String contractStatus = driver.findElement(By.xpath("//span[contains(@class,'statusBg')]")).getText().trim();*/
		if(filterByContractNumber(contractID)) {
			int statusCol = getColNum_IContract("Status");
			String contractStatus = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td["+statusCol+"]/span")).getText().trim();
			if(contractStatus.contains("Active")) {
				LogScreenshot("pass","Contract: "+contractID+" Uploaded And Published");
			}else {
				LogScreenshot("info","Contract Status in "+contractStatus);
				Thread.sleep(180000);
				driver.navigate().refresh();
				waitUntilVisibilityOfElement(By.id("repoContractListing-grid"));
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				LogScreenshot("info","Waited for 3 min and refresh");
				try{
					filterByContractNumber(contractNumber);
				}catch(Exception e){
				}
				clearAllFilters();
				waitUntilVisibilityOfElement(By.id("repoContractListing-grid"));
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				statusCol = getColNum_IContract("Status");
				contractStatus = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td["+statusCol+"]/span")).getText().trim();
				if(contractStatus.contains("Active")) {
					LogScreenshot("pass","Contract "+contractID+" Uploaded And Published. Status is in "+contractStatus +" state");
				}else {
					LogScreenshot("fail","Contract Status in :"+contractStatus+" status" );
				}
			}

		}

	}



	public void publishContract() throws Exception {

		waitUntilVisibilityOfElement(By.id("publishButtonDiv"));
		WebElement publishContractBtn = driver.findElement(By.id("publishContract"));
		clickElement(publishContractBtn);
		waitUntilVisibilityOfElement(By.xpath("//div[@class='jconfirm-content-pane']"));
		Thread.sleep(5000);
		By remarkInput = By.id("revisionComment");
		setInput(remarkInput, "Publishing Event");
		LogScreenshot("pass","Publishing Contract");
		WebElement publishBtn = driver.findElement(By.id("publishBtn"));
		clickElement(publishBtn);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.xpath("//div[@class='jconfirm-content-pane']"));
		LogScreenshot("pass","Contract Published Successfully");
		WebElement setAlertBtn = driver.findElement(By.xpath("//input[@value='"+getLanguageProperty("Set Alert")+"']  "));
		LogScreenshot("info","Setting Alert");
		clickElement(setAlertBtn);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));

	}

	public void cloneInAuthoring(String contractNumber) throws Exception {

		filterByContractNumber(contractNumber);

		WebElement actionBtn = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td[last()]"));
		clickElement(actionBtn);
		waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
		actionBtn.findElement(By.xpath(".//ul/li/span[text()='"+getLanguageProperty("Clone in Authoring")+"']")).click();

	}


	public boolean filterByContractNumber(String contractNum) {
		boolean result = false;
		try {
			result = filterByText("Contract Number", contractNum) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	public boolean filterByTitle(String title) {
		boolean result = false;
		try {
			result = filterByText("Contract Title", title) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByContractSource(String contractSrc) {
		boolean result = false;
		try {
			clickElement(contractSrcXpath);
			result = filterByChkbox(contractSrc, contractSrcXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByContractingParty(String contractingParty) {
		boolean result = false;
		try {
			result = filterByText("Contracting Party", contractingParty) ? true : false;
		} catch (Exception e) {



			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByStatus(String status) {
		boolean result = false;
		try {
			result = filterByChkbox(status, statusXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByCreatedBy(String createdBy) {
		boolean result = false;
		try {
			result = filterByText("Created By", createdBy) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByStage(String stage) {
		boolean result = false;
		try {
			result = filterByChkbox(stage, stageXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*public boolean logout() {
		boolean result = false;
		try {
			findElement(By.xpath("//label[@id='logout']")).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
*/

	public boolean viewContract(String contractNum, ContractSummary objSummary){
		boolean result = false;
		try{
			clickAndWaitUntilLoaderDisappears(By.xpath("//*[@id='authorContractListing-grid']/tbody//td[2]/span[@title='"+contractNum+"']"));
			if(objSummary.getPgHead()!=null)
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByText
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fieldName
	 * @param searchValue
	 * @return result - True/False
	 */

	public boolean filterByText(String fieldName, String searchValue) {
		boolean result = false;
		try {
			int intColNo = getColNum_IContract(fieldName);
			searchAndWaitUntilLoaderDisappears(By.xpath("//table[@id='repoContractListing-grid']/thead/tr[2]/th[" + intColNo + "]//input"), searchValue);
			Thread.sleep(3000);
			List<WebElement> objfilteredTxtList = driver.findElements(By.xpath("//table[@id='repoContractListing-grid']/tbody//td[" + intColNo + "]"));

			for (WebElement obj : objfilteredTxtList) {
				if (obj.getText().contains(searchValue))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * -------------------------------------------------------------------------
	 * -------- Function : filterByChkbox
	 * 
	 * @param checkBoxLbl
	 *            --------------------------------------------------------------
	 *            -------------------
	 * @throws Exception
	 */

	public boolean filterByChkbox(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			
			By deselectButton = By.xpath("//div[contains(@id,'ui-tooltip') and contains(@style,'block')]//label[@class='deselAllLbl']");
			clickElement(deselectButton);
			
			By labelPath = By.xpath("//label[text()='"+checkBoxLbl+"']//preceding-sibling::input");
			clickElement(labelPath);
			/*
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");*/
			clickAndWaitUntilLoaderDisappears(filterBtnXpath);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(checkBoxLbl))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}



	public boolean filterByContractingParty() {
		return filterByText("Contracting Party", contractingParty);
	}

	public List<String> getFilteredContractsListWithSingleContParty(){
		List<WebElement> contractsList = driver.findElements(By.xpath("//table[@id='repoContractListing-grid']/tbody/tr[td[1]]/td[2]//span[@title]"));
		List<String> contractsTitleList = new ArrayList<String>();
		for(WebElement objContract : contractsList){
			contractsTitleList.add(objContract.getAttribute("title"));
		}
		try {
			LogScreenshot("info","Contract Available for supplier : "+contractingParty);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contractsTitleList;
	}


	public void deleteContract(String contractId) throws Exception {

		clearAllFilters();
		filterByContractNumber(contractId);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		WebElement actionBtn = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr[td[span[span[text()='"+contractId+"']]]]/td[last()]"));
		clickElement(actionBtn.findElement(By.xpath(".//a")));
		LogScreenshot("info","Deleting Contract");
		clickElement(actionBtn.findElement(By.xpath(".//ul//span[@title='"+getLanguageProperty("Delete")+"']")));

		waitUntilVisibilityOfElement(By.id("zydev-popup-delete-contract-from-listing"));
		By commentArea = By.id("txtAreaCommentForDelete");
		setInput(commentArea, "Deleting Contract");
		LogScreenshot("pass","Delete Popup Displayed");

		By deleteBtn = By.xpath("//button[@type='button']/span[text()='"+getLanguageProperty("Delete")+"']");
		clickElement(deleteBtn);
		waitUntilVisibilityOfElement(By.id("zys-popup-content"));

		String msg = driver.findElement(By.id("zys-popup-msg")).getText().trim();
		if(msg.equals("Contract deleted successfully."))
			LogScreenshot("pass",msg);
		else
			LogScreenshot("fail",msg);


	}








}
