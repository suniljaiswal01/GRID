package com.zycus.IContract.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class AboutIContract extends eInvoice_CommonFunctions {

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public AboutIContract(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> clickCreateWorkflow
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param displayName
	 * @return result - True/False
	 * @throws Exception
	 */

	
	public void verifyVersion(String version) throws Exception {
		waitUntilVisibilityOfElement(By.xpath("//div[@class='rb-rainbowModal']/div"));
		Thread.sleep(3000);
		String displayedVersion = driver.findElement(By.xpath("//div[@class='rb-rainbowModal']/div/div[2]/p[1]")).getText();
		if(version.equals(displayedVersion))
			logger.pass("Version : "+version+" displayed, as expected");
		else
			logger.fail("Version : "+version+" not displayed, as expected");
		findElement(By.xpath("//span[@class='rb-button-close']")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='rb-rainbowModal']/div"));
		Thread.sleep(2000);
	}
	
	public void verifyVersion() throws Exception {
		waitUntilVisibilityOfElement(By.xpath("//div[@class='rb-rainbowModal']/div"));
		Thread.sleep(3000);
		String displayedVersion = driver.findElement(By.xpath("//div[@class='rb-rainbowModal']/div/div[2]/h2")).getText();
		if(displayedVersion.equals(getLanguageProperty("iContract Green Version")))
			LogScreenshot("PASS","Version : "+displayedVersion+" displayed, as expected");
		else
			LogScreenshot("FAIL","Version : "+displayedVersion+" not displayed, as expected");
		findElement(By.xpath("//span[@class='rb-button-close']")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='rb-rainbowModal']/div"));
		Thread.sleep(2000);
	}
}
