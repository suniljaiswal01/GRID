package com.zycus.IContract.ManageContracts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class Hierarchy extends eInvoice_CommonFunctions {

	public Hierarchy(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	public void linkContract(String contractToLink){
		try{
			findElement(By.id("linkbutton")).click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Link Contract")+"']]"));
			searchContractToLink("Contract Number", contractToLink);
			findElement(By.xpath("//table[@id='linkTable']/tbody/tr[2]/td[1]/input")).click();
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Done")+"']]")).click();
			Thread.sleep(3000);
			WebElement objSubAgreement = driver.findElement(By.xpath("//span[@title='"+getLanguageProperty("Sub Agreement")+"']/preceding-sibling::span/span"));
			if(objSubAgreement.getText().contains(contractToLink))
				logger.pass( contractToLink +" linked with Master Contract");
		}catch(Exception e){
			e.printStackTrace();
			logger.fail( "unable to link "+contractToLink);
		}
	}
	
	public void searchContractToLink(String searchBy, String searchValue){
		findElement(By.xpath("//select[@id='selectFilter']/option[text()='"+searchBy+"']")).click();
		driver.findElement(By.id("searchText")).sendKeys(searchValue);
		findElement(By.xpath("//input[@title='"+getLanguageProperty("Go")+"']")).click();	
	}

	

}
