package com.zycus.IContract.Performance;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class SpendByContractingParty extends PerformanceDetail {

	public SpendByContractingParty(WebDriver driver, ExtentTest logger,String searchBy,String searchValue) throws Exception {
		super(driver, logger);
        this.searchBy = searchBy;
        this.searchValue = searchValue;
	}
	
	public SpendByContractingParty(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		}
}
