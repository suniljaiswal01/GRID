package com.zycus.IContract.Setup_ProdConfig.Workflow;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class OOOAssignmentWorkflowConfig extends eInvoice_CommonFunctions {

	private String assignFrom;
	private String assignTo;
	private String fromDt;
	private String ToDt;
	private String comments;
	
	public OOOAssignmentWorkflowConfig(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public OOOAssignmentWorkflowConfig(WebDriver driver, ExtentTest logger, String assignFrom, String assignTo, String fromDt, String ToDt, String comments) {
		super(driver, logger);
		this.assignFrom = assignFrom;
		this.assignTo = assignTo;
		this.fromDt = fromDt;
		this.ToDt = ToDt; 
		this.comments = comments;
	}

	public boolean createWorkflow() {
		boolean result = false;
		try {
			clickAndWaitUntilLoaderDisappears(By.xpath("//input[@value='"+getLanguageProperty("Create")+"']  "));
			if(driver.findElements(By.xpath("//div[@aria-describedby='oooAssignmentPopup']")).size()>0){
			//if(driver.findElement(By.xpath("//div[@aria-describedby='oooAssignmentPopup']")).isDisplayed()){
				findElement(By.id("fromUserSearchBar")).sendKeys(assignFrom);
				if(driver.findElements(By.xpath("//div[@id='fromUserList' and contains(@style,'block')]")).size()>0)
				//if(findElement(By.xpath("//div[@id='fromUserList' and contains(@style,'block')]")).isDisplayed())
					findElement(By.xpath("//div[@id='fromUserList']/span[1]")).click();
				else
					logger.fail("Assign From user not found");
				findElement(By.id("toUserSearchBar")).sendKeys(assignTo);
				if(driver.findElements(By.xpath("//div[@id='toUserList' and contains(@style,'block')]")).size()>0)
				//if(driver.findElement(By.xpath("//div[@id='toUserList' and contains(@style,'block')]")).isDisplayed())
					findElement(By.xpath("//div[@id='toUserList']/span[1]")).click();
				else
					logger.fail("Assign To user not found");
				findElement(By.id("notifyFromDate")).click();
				selectDate_v1(fromDt);
				findElement(By.id("notifyToDate")).click();
				selectDate_v1(ToDt);
				findElement(By.xpath("//textarea[contains(@class,'commonComments')]")).sendKeys(comments);
				clickAndWaitUntilLoaderDisappears(By.xpath("//div[@id='oooAssignmentPopup']/following-sibling::div//span[text()='"+getLanguageProperty("Save")+"']"));
				//Flash error is received
				result= true;
			}else
				logger.fail("Create Workflow pop up not displayed");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
