package com.zycus.IContract.Performance;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class SpendByContracts extends PerformanceDetail {

	public SpendByContracts(WebDriver driver, ExtentTest logger,String searchBy,String searchValue) throws Exception {
		super(driver, logger);
        this.searchBy = searchBy;
        this.searchValue = searchValue;
	}
	

	public SpendByContracts(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
	}
}
