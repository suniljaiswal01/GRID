package com.zycus.IContract.Setup_ProdConfig.Workflow;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class AuthorStageWorkflowConfig extends eInvoice_CommonFunctions {

	private String contractType;
	private String workflowName;
	
	public AuthorStageWorkflowConfig(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public AuthorStageWorkflowConfig(WebDriver driver, ExtentTest logger, String contractType, String workflowName) {
		super(driver, logger);
		this.contractType = contractType;
		this.workflowName = workflowName;
	}

	public boolean createWorkflow() {
		boolean result = false;
		try {
			clickAndWaitUntilLoaderDisappears(By.xpath("//input[@value='"+getLanguageProperty("Create")+"']  "));
			if(driver.findElements(By.xpath("//div[@aria-describedby='createWorkflowPopupDiv']")).size()>0){
			//if(driver.findElement(By.xpath("//div[@aria-describedby='createWorkflowPopupDiv']")).isDisplayed()){
				findElement(By.xpath("//select[@id='createWorkflowHierarchyId']/option[text()='"+contractType+"']")).click();
				findElement(By.id("createPopupWorkflowName")).sendKeys(workflowName);
				clickAndWaitUntilLoaderDisappears(By.xpath("//div[@id='createWorkflowPopupDiv']/following-sibling::div//span[text()='"+getLanguageProperty("Save")+"']"));
				//Flash error is received
				result= true;
			}else
				logger.fail("Create Workflow pop up not displayed");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
