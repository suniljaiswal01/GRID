package com.zycus.IContract.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ReleaseVideos extends ProductVideos {

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public ReleaseVideos(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> verifyLatestRelVideo
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param displayName
	 * @return result - True/False
	 * @throws Exception
	 */

	public void verifyLatestRelVideo() throws Exception {
		try {
			if(driver.findElement(By.xpath("//table[@class='selfTraining']//li[contains(@class,'VideoTab') and contains(@class,'active')]")).getText().equals(getLanguageProperty("Release Videos"))){
				verifyLatestProductVideo();
				driver.close();
				logger.pass("Latest Release Video verified");
			}else
				logger.log(Status.FAIL, "Product Videos tab not opened");
		} catch (Exception e) {
			e.printStackTrace();
			logger.log(Status.FAIL, "latest Release video not opened");
		}
	}

}
