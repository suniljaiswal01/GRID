package com.zycus.IContract.ClauseLibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ClauseDetails extends eInvoice_CommonFunctions {

	static By clauseDetailsHeader = By.xpath("//h1[@class='zy-mainhead' and contains(text(),'"+getLanguageProperty("Clause Details")+"')]");
	static By backToClauseListing = By.xpath("//a[contains(text(),'"+getLanguageProperty("Back to Clause Listing")+"')]");

	public ClauseDetails(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
}
