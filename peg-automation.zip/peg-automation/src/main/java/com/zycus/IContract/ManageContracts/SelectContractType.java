package com.zycus.IContract.ManageContracts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.IContract.Templates.Templates;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.iContract_CommonFunctions;

public class SelectContractType extends iContract_CommonFunctions {

	private static By pgHead = By.xpath("//div[@id='main-action-button']/h3[text()='"+getLanguageProperty("Author Contract")+"']");
	private String contractType;
	private String contractSubType;

	public SelectContractType(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
        String[][] abc = (String[][]) objFunctions.dataProvider("SelectContract", Datasheet_iContract);
        this.contractType = abc[0][0];
        this.contractSubType = abc[0][1];
	}
	
	public SelectContractType(WebDriver driver, ExtentTest logger, String contractType, String contractSubType) {
		super(driver, logger);
		this.contractType = contractType;
		this.contractSubType = contractSubType;
	}
	
	public boolean selectContractTypes() throws Exception {
		boolean result = false;
		try {
			clickElement(By.xpath("//ul[@id='subTypeSelector']//a[contains(text(),'"+contractType+"')]"));
			try{
				waitUntilVisibilityOfElement(By.id(contractType.toUpperCase()));
			}catch(Exception e){
				e.printStackTrace();
				LogScreenshot("fail","No sub type displayed for Contract Type : "+contractType);
				throw new Exception();
			}
			//findElement(By.xpath("//div[@id='"+contractType.toUpperCase()+"' and contains(@style,'block')]//input[@type='radio'][following-sibling::label[contains(text(),'"+contractSubType+"')]]")).click();
			findElement(By.xpath("//div[@id='"+contractType.toUpperCase()+"']//li[label[contains(text(),'"+contractSubType+"')]]/input")).click();
			findElement(By.xpath("//input[@value='"+getLanguageProperty("Continue")+"']  ")).click();
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("fail","Not navigated to 'Contract Details' page");
			throw new Exception();
		}
		return result;
	}
	
	public String addContractAndPublish(){
		String ContractID = null;
		try{
			ContractDetails objDetails =  new ContractDetails(driver, logger);
			if (objDetails.getPgHead() != null){
				LogScreenshot("pass","navigated to 'Contract Details' page");
				ContractID = objDetails.enterContractDetails();
				ContractingParty objParty = new ContractingParty(driver, logger);
				objParty.addMultiContractingParty();
				objDetails.publishContract();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return ContractID;
	}
	
	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	public void selectTypeSubTypeForClone() throws Exception {
		
		waitUntilVisibilityOfElement(By.id("frmCreateContractExternalTemplate"));
		By negotiationRound = By.xpath("//div[@id='bypassNegotiationWorkflowSelect']/span[text()='"+getLanguageProperty("Yes")+"']");
		clickElement(negotiationRound);
		
		List<WebElement> optionsList = driver.findElements(By.xpath("//div[@class='buttonSet']/span[contains(@id,'useContract')]"));
		for(WebElement optionValue:optionsList)
			clickElement(optionValue);
		
		WebElement templateType = driver.findElement(By.id("originalTemplate"));
		clickElement(templateType);
		
		LogScreenshot("pass","Contract Basic Details Filled");
		WebElement startAuthoringBtn = driver.findElement(By.xpath("//input[@value='"+getLanguageProperty("Start Authoring")+"']"));
		clickElement(startAuthoringBtn);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
	}

	public void selectTypeSubTypeForAmendment() throws Exception {
		
		waitUntilVisibilityOfElement(By.id("frmCreateContractExternalTemplate"));
		WebElement negotiationRound = driver.findElement(By.xpath("//div[@id='bypassNegotiationWorkflowSelect']/span[text()='"+getLanguageProperty("Yes")+"']"));
		clickElement(negotiationRound);
		
		List<WebElement> optionsList = driver.findElements(By.xpath("//div[@class='buttonSet']/span[contains(@id,'useContract')]"));
		for(WebElement optionValue:optionsList)
			clickElement(optionValue);
		
		LogScreenshot("pass","Adding Basic Details");
		WebElement templateType = driver.findElement(By.id("NewTemplate"));
		clickElement(templateType);
		
		Templates template = new Templates(driver, logger);
		template.uploadTemplate();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
	}

}
