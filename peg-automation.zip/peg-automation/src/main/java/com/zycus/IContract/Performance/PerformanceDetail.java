package com.zycus.IContract.Performance;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iContract_CommonFunctions;

public class PerformanceDetail extends iContract_CommonFunctions {

	protected String searchBy;
	protected String searchValue;

	public PerformanceDetail(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
	}

	public boolean searchContracts(String searchBy, String searchValue) {
		boolean result = false;
		try {
			Thread.sleep(3000);
			if(driver.findElements(By.xpath("//table[@id='compliance-grid']/tbody/tr/td[contains(@class,'noRecordFound')]")).size()>0){
				LogScreenshot("info","'There are no records found' message displayed");
				result = true;
			}else{
				findElement(By.xpath("//select[@name='searchSelect']/option[text()='"+searchBy+"']")).click();
				driver.findElement(By.id("searchValue")).sendKeys(searchValue);
				result = clickAndWaitUntilElementAppears(By.xpath("//div[@id='search-bar']//input[@value='"+getLanguageProperty("Go")+"']  "), By.id("gridMessageDiv"))?true:false;
				if(verifyContractSearched()) {
					LogScreenshot("pass",searchValue+ " Searched Successfully");
					result = true;
				}
					
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private boolean verifyContractSearched() throws Exception{
		boolean result = true;
		List<WebElement> contractTitles;
		List<WebElement> contractingParties;
		List<WebElement> contractNumbers;
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		
		try{
			if(searchBy.equals(getLanguageProperty("Contract Title"))){
				contractTitles = driver.findElements(By.xpath("//table[@id='compliance-grid']/tbody//td[2]/span"));
				for(WebElement title : contractTitles){
					String displayedTitle = title.getText(); 
					if(!displayedTitle.equals(searchValue)){
						LogScreenshot("fail","Contract Title " +displayedTitle+" also displayed for searched Title : "+searchValue);
						result = false;
						break;
					}
				}
			}
			if(searchBy.equals(getLanguageProperty("Contract Number"))){
				contractNumbers = driver.findElements(By.xpath("//table[@id='compliance-grid']/tbody//td[1]/span"));
				for(WebElement contract : contractNumbers){
					String displayedContractNos = contract.getText(); 
					if(!displayedContractNos.equals(searchValue)){
						LogScreenshot("fail","Contract Number " +displayedContractNos+" also displayed for searched Contract Number : "+searchValue);
						result = false;
						break;
					}
				}
			}
			if(searchBy.equals(getLanguageProperty("Contracting Party"))){
				contractingParties = driver.findElements(By.xpath("//table[@id='compliance-grid']/tbody//td[3]/span"));
				for(WebElement party : contractingParties){
					String displayedParty = party.getAttribute("title"); 
					if(!displayedParty.equals(searchValue)){
						LogScreenshot("fail","Contracting Party " +displayedParty+" also displayed for searched Contracting Party : "+searchValue);
						result = false;
						break;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	public void checkContractPerformance() throws Exception{
		//searchContracts();
		String contractNumber = driver.findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[1]/span")).getAttribute("title");
		String contractTitle = driver.findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[2]/span")).getAttribute("title");
		String totalContractValue = driver.findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[5]/span")).getAttribute("title");
		String contractExpDate = driver.findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[4]/span")).getAttribute("title");
		String contractingPartyName = driver.findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[3]/span")).getAttribute("title");
		
		findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")).click();
		findElement(By.xpath("//table[@id='compliance-grid']/tbody/tr[1]/td[last()]//a/..//span[@title='"+getLanguageProperty("View Performance")+"']")).click();
		waitUntilInvisibilityOfElement(processingLoader);
		
		Assert.assertEquals(ContractPerformance.getContractNumber(), contractNumber);
		Assert.assertEquals(ContractPerformance.getContractTitle(), contractTitle);
		Assert.assertEquals(ContractPerformance.getTotalValue(), totalContractValue);
		Assert.assertEquals(ContractPerformance.getContractExpDate(), contractExpDate);
		Assert.assertEquals(ContractPerformance.getContractingPartyName(), contractingPartyName);
	}

}
