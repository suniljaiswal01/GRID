package com.zycus.IContract.ManageContracts;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class Timeline extends eInvoice_CommonFunctions {

	private String contractTitle;
	private static By processingLoader = By.xpath("//span[@class='zys-loader-icon']");
	
	@FindBy(how = How.ID, using="dataGrid")
	private static WebElement objVersionsGrid;
	
	@FindBy(how = How.ID, using="AttachmentsSubTab")
	private static WebElement objDocumentsSubTab;
	
	@FindBy(how = How.ID, using="attachmentsAuditList-grid")
	private static WebElement objDocumentsGrid;
		

	public Timeline(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		PageFactory.initElements(driver, this);
	}
	
	public Timeline(WebDriver driver, ExtentTest logger, String contractTitle) throws Exception {
		super(driver, logger);
		this.contractTitle = contractTitle;
		System.out.println("Contract Title reported to Timeline is "+contractTitle);
		PageFactory.initElements(driver, this);
	}
	
	public boolean switchToDocumentsTab(){
		boolean result = false;
		try{
			clickAndWaitUntilLoaderDisappears(objDocumentsSubTab);
			waitUntilVisibilityOfElement(objDocumentsGrid);
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	public boolean verifyVersionCreated() throws InterruptedException {
		boolean result = false;
		String fileDownloadedPath = getDownloadFilePath();
		String fileExtension = "docx";
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			waitUntilVisibilityOfElement(objVersionsGrid);
			LocalDate versionCreationDt = LocalDate.now();
			String versionDt = DateTimeFormatter.ofPattern("MM/dd/YYYY").format(versionCreationDt);
			String versionRowXpath = "//tr[td[span[text()='"+getLanguageProperty("version comment")+"'] and position()=4] and td[span[text()='"+versionDt+"'] and position()=5]]";
			if(objVersionsGrid.findElements(By.xpath(versionRowXpath)).size()>0)
				//Download Version
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				Thread.sleep(1000);
				findElement(By.xpath(versionRowXpath + "/td[last()]//a[1]")).click();
				//Waiting time for the file to get downloaded
				Thread.sleep(6000);
				if(checkFileExists(fileDownloadedPath, contractTitle, fileExtension))
					result = true;
//				deleteFiles(fileDownloadedPath, contractTitle, fileExtension);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean verifyDocumentCreated() {
		boolean result = false;
		String fileDownloadedPath = "C:\\Users\\"+System.getProperty("user.name")+"\\Downloads";
		String fileExtension = "docx";
		try {
			switchToDocumentsTab();
			waitUntilVisibilityOfElement(objDocumentsGrid);
			/*LocalDate versionCreationDt = LocalDate.now();
			String versionDt = DateTimeFormatter.ofPattern("dd/MM/YYYY").format(versionCreationDt);
			String versionRowXpath = "//tr[td[span[text()='"+getLanguageProperty("version comment")+"'] and position()=4] and td[span[text()='"+versionDt+"'] and position()=5]]";
			if(objVersionsGrid.findElements(By.xpath(versionRowXpath)).size()>0)
				//Download Version
				findElement(By.xpath(versionRowXpath + "/td[last()]//a[1]")).click();
				//Waiting time for the file to get downloaded
				Thread.sleep(6000);
				deleteFiles(fileDownloadedPath, contractTitle, fileExtension);
				if(checkFileExists(fileDownloadedPath, contractTitle, fileExtension))
					result = true;*/
			
			//Download Version
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(1000);
			findElement(By.xpath("//td[last()]//a[@class='icon download' and position()=1]")).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}



}
