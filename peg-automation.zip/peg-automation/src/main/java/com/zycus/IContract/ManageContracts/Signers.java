package com.zycus.IContract.ManageContracts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class Signers extends eInvoice_CommonFunctions {

	@FindBys(@FindBy(how = How.ID, using = "emailPopup"))
	private static List<WebElement> objEmailPopup;
	
	/*@FindBy(how = How.XPATH, using = "//div[@id='emailPopup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]")
	private static WebElement objEmailPopup_SendBtn;*/
	
	@FindBy(how = How.XPATH, using = "//span[@class='yellowbutton']")
	private static WebElement objTopYellowBtn;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'blockOverlay')]")
	private static WebElement objOverlayLoader;
	
	@FindBys(@FindBy(how = How.XPATH, using = "//div[contains(@class,'blockOverlay')]"))
	private static List<WebElement> objOverlayLoaders;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'jqifade')]")
	private static WebElement objAnotherOverlayLoader;
	
	@FindBys(@FindBy(how = How.XPATH, using = "//div[contains(@class,'jqifade')]"))
	private static List<WebElement> objAnotherOverlayLoaders;
	
	@FindBys(@FindBy(how = How.XPATH, using = "//div[@id='jqi']"))
	private static List<WebElement> objAlerts;
	
	/*@FindBy(how = How.XPATH, using = "//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")
	private static WebElement objAlert_OkBtn;*/
	
	@FindBy(how = How.XPATH, using = "//span[@class='zys-loader-icon']")
	private static WebElement objProcessingLoader;
	
	public Signers(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		PageFactory.initElements(driver, this);
	}
	
	//newSignerPartyFrom : Internal, External
	public boolean sendForSigning(boolean isSignoffWorkflowActive, String signingOption) {
		boolean result = false;
		try {
			//waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'Overlay')]"));
			//waitUntilInvisibilityOfElement(objOverlayLoader);
			Thread.sleep(8000);
			
			if(signingOption.equals("e-Signature")) {
				LogScreenshot("info","e-signature Signing");
				clickElement(By.xpath("//input[@name='esigningStatus' and @value='true']"));
			}
			else if(signingOption.equals(getLanguageProperty("Offline Signing"))){
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				LogScreenshot("info","Offline Signing");
				clickElement(By.xpath("//input[@name='esigningStatus' and @value='false']"));
			}
			String popUpFinderXpath = "//div[contains(@class,'zys-popup-container')][div/h1[text()='"+getLanguageProperty("Confirm")+"']]";
			
			try{
				if(driver.findElements(By.xpath(popUpFinderXpath)).size()>0){
					try{
						LogScreenshot("info","Confirmation Pop-up");
						findElement(By.xpath(popUpFinderXpath + "//button[text()='"+getLanguageProperty("Yes")+"']")).click();
					}catch(Exception e){}
					waitUntilInvisibilityOfElement(objProcessingLoader);
					//waitUntilInvisibilityOfElement(objAnotherOverlayLoader);
					waitUntilInvisibilityOfElement(objOverlayLoader);
					do{
						Thread.sleep(200);
					}while(objOverlayLoaders.size()>0||objAnotherOverlayLoaders.size()>0);
				}
			 }catch(Exception e){}
			
			//Add Internal Party
			addSignerParty(isSignoffWorkflowActive, "Internal");
			waitUntilInvisibilityOfElement(By.id("jqifade"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			/*do{
				Thread.sleep(200);
			}while(objOverlayLoaders.size()>0||objAnotherOverlayLoaders.size()>0);*/
			clickAndWaitUntilLoaderDisappears(By.id("sendForSigningBtn"));
			
			waitUntilInvisibilityOfElement(processingLoader);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(3000);
			findElement(By.xpath("//div[@id='zydev-popup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Proceed")+"']]"))	.click();
			waitUntilInvisibilityOfElement(processingLoader);
			/*do{
				Thread.sleep(200);
			}while(objOverlayLoaders.size()>0||objAnotherOverlayLoaders.size()>0);*/
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			try{
				if(signingOption.equals(getLanguageProperty("Offline Signing"))){
					findElement(By.xpath(popUpFinderXpath + "//button[text()='"+getLanguageProperty("Yes")+"']")).click();
					waitUntilInvisibilityOfElement(processingLoader);
					Thread.sleep(2000);
					waitUntilInvisibilityOfElement(processingLoader);
					/*do{
						Thread.sleep(200);
					}while(objOverlayLoaders.size()>0||objAnotherOverlayLoaders.size()>0);*/
					if (driver.findElements(By.id("emailPopup")).size() > 0) {
						clickAndWaitUntilLoaderDisappears(By.xpath("//div[@id='zydev-popup']/following-sibling::div//button[span[text()='"+getLanguageProperty("Send")+"']]"));
						Thread.sleep(2000);
					}
				}else if(signingOption.equals("e-Signature")){
					findElement(By.xpath(popUpFinderXpath + "//button[text()='"+getLanguageProperty("Proceed")+"']")).click();
					waitUntilInvisibilityOfElement(objProcessingLoader);
					Thread.sleep(2000);
					waitUntilInvisibilityOfElement(objProcessingLoader);
					do{
						Thread.sleep(200);
					}while(objOverlayLoaders.size()>0||objAnotherOverlayLoaders.size()>0);
				}
			}catch(Exception e){}
			//waitUntilInvisibilityOfElement(objProcessingLoader);
			/*do{
				Thread.sleep(200);
			}while(objOverlayLoaders.size()>0||objAnotherOverlayLoaders.size()>0);*/
			
			//waitUntilInvisibilityOfElement(objOverlayLoader);
			//waitUntilInvisibilityOfElement(objAnotherOverlayLoader);
			Thread.sleep(6000);
			if (driver.findElement(By.xpath("//span[@class='yellowbutton']")).getText().equals(getLanguageProperty("Signing In Progress"))){
				LogScreenshot("Pass","contract sent to contracting party for signing");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private boolean addSignerParty(boolean isSignoffWorkflowActive, String newSignerPartyFrom){
		boolean result = false;
		String partyType = getLanguageProperty(newSignerPartyFrom + " Party");
		try{
			waitUntilInvisibilityOfElement(By.id("jqifade"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			LogScreenshot("info","Adding Signer to Party Starting");
			findElement(By.xpath("//div[@id='signerBlockContainer']/ul[li[span[text()='"+partyType+"']]]//span[@class='addParty']")).click();
			//waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='Add "+newSignerPartyFrom+" Signer']]"));
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog']"));
			//if(driver.findElement(By.xpath("//div[@role='dialog'][div/span[text()='Add "+newSignerPartyFrom+" Signer']]")).isDisplayed()){
			if(isSignoffWorkflowActive)
				findElement(By.xpath("//select[@id='wfUserSelect']/option[text()='admin.zcs@zycus.com']"));
			else{
				driver.findElement(By.xpath("//input[@type='email']")).sendKeys("varun.khurana@zycus.com");
				driver.findElement(By.id("elementValue_4")).sendKeys("Varun Khurana");
			}
			LogScreenshot("info", "Signer Details Added");
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Add Signer")+"']]")).click();
			//waitUntilInvisibilityOfElement(objProcessingLoader);
			waitUntilVisibilityOfElement(By.xpath("//div[@id='signerBlockContainer']/ul[li[span[text()='"+getLanguageProperty("Internal Party")+"']]]//div[@class='addSignerDiv']"));
			LogScreenshot("Pass","Signer Added Successfully");
			//}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

}
