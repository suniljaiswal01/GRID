package com.zycus.IContract.ManageContracts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iContract_CommonFunctions;

public class AuthorContract extends iContract_CommonFunctions {

	private static By filterBtnXpath = By.xpath("//div[contains(@class,'typeFilterContent') and contains(@style,'block')]//a[text()='"+getLanguageProperty("Filter")+"'][ancestor::div[@aria-hidden='false']]");
	private static By contractSrcXpath = By.xpath("//table[@id='authorContractListing-grid']/tbody//td[4]/span");
	private static By statusXpath = By.xpath("//table[@id='authorContractListing-grid']/tbody//td[6]/span");
	private static By stageXpath = By.xpath("//table[@id='authorContractListing-grid']/tbody//td[8]//li[@class='inprogress']/span");
	private static By pgHead = By.xpath("//div[@id='main-action-button']/h3[text()='"+getLanguageProperty("Author Contract")+"']");

	public AuthorContract(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	public void createContract(String templateName) throws Exception {
		findElement(By.xpath("//input[@name='createContract']")," + Create Contract button").click();
		waitUntilInvisibilityOfElement(processingLoader);
		CreateContract objCreateContract = new CreateContract(driver, logger);
		if (objCreateContract.getPgHead() != null){
			LogScreenshot("Pass","clicked on ' + Create Contract' button");
			waitUntilVisibilityOfElement(CreateContract.initialDetailsSection);
			objCreateContract.startAuthoring(templateName);

		}else
			LogScreenshot("fail","Not navigated to 'Create Contract' page");
	}

	public void createContract(String templateName, boolean isNegotiationAllowed, boolean isExternalTemplateAvailable) throws Exception {
		findElement(By.xpath("//input[@name='createContract']")," + Create Contract button").click();
		waitUntilInvisibilityOfElement(processingLoader);
		CreateContract objCreateContract = new CreateContract(driver, logger);
		if (objCreateContract.getPgHead() != null){
			logger.pass("clicked on ' + Create Contract' button");
			waitUntilVisibilityOfElement(CreateContract.initialDetailsSection);
			objCreateContract.startAuthoring(templateName, isNegotiationAllowed, isExternalTemplateAvailable);
		}else
			LogScreenshot("fail","Not navigated to 'Create Contract' page");
	}

	public void createContract() throws Exception {
		createContract("");
	}


	/*public boolean createContract() throws Exception {
		boolean result = false;
		try {
			findElement(By.xpath("//input[@name='createContract']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			CreateContract objCreateContract = new CreateContract(driver, logger);
			if (objCreateContract.getPgHead() != null){
				logger.pass("clicked on 'Create Contract' button");
				waitUntilVisibilityOfElement(By.xpath("//div[@class='contractBasicDetail']"));
				objCreateContract.startAuthoring();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.fail("Not navigated to 'Create Contract' page");
			throw new Exception();
		}
		return result;
	}*/



	/*public boolean createContract(CreateContract objCreateContract) throws Exception {
		boolean result = false;
		try {
			clickAndWaitUntilLoaderDisappears(By.xpath("//input[@name='createContract']"));
			if (objCreateContract.getPgHead() != null){
				logger.log(Status.INFO, "clicked on 'Create Contract' button");
				//CreateContract objContract = new CreateContract(driver, logger);
				waitUntilVisibilityOfElement(By.xpath("//div[@class='contractBasicDetail']"));
				objCreateContract.startAuthoring();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.log(Status.INFO, "Not navigated to 'Create Contract' page");
			throw new Exception();
		}
		return result;
	}*/

	/*public void clrAllFilters() throws Exception{
		findElement(By.id("clearAllFilters")).click();
		waitUntilInvisibilityOfElement(processingLoader);
	}*/

	public boolean filterByContractNum(String contractNumber) throws Exception{
		return filterByText("Contract Number", contractNumber);
	}

	public boolean filterByTitle(String title) throws Exception{
		return filterByText("Title", title);
	}

	public boolean filterByContractSource(String contractSrc) throws Exception {
		return filterByChkbox(contractSrc, contractSrcXpath);
	}

	public boolean filterByContractingParty(String contractingParty) throws Exception{
		return filterByText("Contracting Party", contractingParty);
	}

	public boolean filterByStatus(String status) throws Exception {
		return filterByChkbox(status, statusXpath);
	}

	public boolean filterByCreatedBy(String createdBy) throws Exception{
		return filterByText("Created By", createdBy);
	}

	public boolean filterByStage(String stage) throws Exception {
		findElement(By.xpath("//div[contains(@id,'CONTRACT_STAGE')]//label[@class='deselAllLbl']")).click();
		return filterByChkbox(stage, stageXpath);
	}

	public void logout() throws Exception{
		findElement(By.xpath("//label[@id='logout']")).click();
	}

	public void viewIContractCreatedContract() throws Exception{
		String contractNum = driver.findElement(By.xpath("//table[@id='authorContractListing-grid']/tbody/tr[td[6][not(span[@class='redText'])]]/td[2]/span")).getAttribute("title");
		viewContract(contractNum);
	}

	public void viewContract() throws Exception{
		String contractNum = driver.findElement(By.xpath("//table[@id='authorContractListing-grid']/tbody/tr[1]/td[2]/span")).getAttribute("title");
		viewContract(contractNum);
	}

	public void viewContract(String contractNum) throws Exception{
		clickAndWaitUntilLoaderDisappears(By.xpath("//table[@id='authorContractListing-grid']/tbody//td[2]/span[@title='"+contractNum+"']"));
		ContractSummary objSummary = new ContractSummary(driver, logger);
		if(objSummary.getPgHead()!=null)
			LogScreenshot("Pass", "Contract Details viewed");
	}

	//verification pending- where the page will land after clicking on a particular page


	/*public boolean viewContract(String contractNum, ContractSummary objSummary){
		boolean result = false;
		try{
			clickAndWaitUntilLoaderDisappears(By.xpath("//*[@id='authorContractListing-grid']/tbody//td[2]/span[@title='"+contractNum+"']"));
			if(objSummary.getPgHead()!=null)
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}*/

	/**
	 * <b>Function:</b> filterByText
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fieldName
	 * @param searchValue
	 * @return result - True/False
	 */

	public boolean filterByText(String fieldName, String searchValue) {
		boolean result = false;
		try {
			int intColNo = getColNum_IContract(fieldName);
			if(intColNo!=0){
				searchAndWaitUntilLoaderDisappears(By.xpath("//table[@id='authorContractListing-grid']/thead/tr[2]/th[" + intColNo + "]//input"), searchValue);
				Thread.sleep(3000);
				List<WebElement> objfilteredTxtList = driver
						.findElements(By.xpath("//table[@id='authorContractListing-grid']/tbody//td[" + intColNo + "]"));
				for (WebElement obj : objfilteredTxtList) {
					if (obj.getText().contains(searchValue))
						result = true;
					else {
						result = false;
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * -------------------------------------------------------------------------
	 * -------- Function : filterByChkbox
	 * 
	 * @param checkBoxLbl
	 *            --------------------------------------------------------------
	 *            -------------------
	 * @throws Exception
	 */

	/*public boolean filterByChkbox(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			findElement(filterBtnXpath).click();
			waitUntilInvisibilityOfElement(processingLoader);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(checkBoxLbl))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}*/

	public boolean filterByChkbox(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			Thread.sleep(3000);
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			clickAndWaitUntilLoaderDisappears(filterBtnXpath);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(checkBoxLbl))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}


	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	public void selectContractingParty(String supplierName) throws Exception{
		waitUntilVisibilityOfElement(By.xpath("//span[@class='addParty']"));
		findElement(By.id("addVendor")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.id("vendor-grid-div"));
		driver.findElement(By.id("vendorSearchValue")).sendKeys(supplierName);
		findElement(By.id("goButton")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		findElement(By.xpath("//table[@id='vendor-grid']//tr[td[div[span[text()='"+supplierName+"']]]]/td/div/input[@type='radio']")).click();
		findElement(By.xpath("//div[@id='contractingPartyButtons']//input[@value='"+getLanguageProperty("Save")+"']  ")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.id("contractingPartyDiv"));
	}

	public boolean filterByContractNumber(String contractNum) {
		boolean result = false;
		try {
			result = filterByText("Contract Number", contractNum) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void cloneInAuthoring(String contractNumber) throws Exception {

		clearAllFilters();
		waitUntilVisibilityOfElement(By.id("authorContractListing-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		filterByContractNumber(contractNumber);
		Thread.sleep(8000);
		By actionBtn = By.xpath("//table[@id='authorContractListing-grid']//tbody/tr[td/span[text()='"+contractNumber.toUpperCase()+"']]/td[last()]");
		clickElement(actionBtn);
		waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
		LogScreenshot("pass","Clone In Authoring Starting");
		clickElement(driver.findElement(actionBtn).findElement(By.xpath(".//ul/li/span[contains(text(),'"+getLanguageProperty("Clone in Authoring")+"')]")));
		LogScreenshot("pass","Clone In Authoring Button Clicked");
		SelectContractType contractType = new SelectContractType(driver, logger);
		contractType.selectTypeSubTypeForClone();
			
		waitUntilVisibilityOfElement(By.id("Contract_Header"));

		waitUntilVisibilityOfElement(By.xpath("//ul[@id='headerTab']"));
		List<WebElement> headersList = driver.findElements(By.xpath("//ul[@id='headerTab']/li"));
		for(WebElement header: headersList) {
			clickElement(header);
			LogScreenshot("info", header.getText()+" Section Opened");
		}
		waitUntilVisibilityOfElement(By.id("flexiFormContainer"));
		Thread.sleep(5000);
		WebElement saveBtn = driver.findElement(By.id("saveAsDraftAuthBtn"));
		LogScreenshot("pass","Saving Contract as Draft");
		clickElement(saveBtn);
		if(driver.findElements(By.xpath("//label[text()='"+getLanguageProperty("Please enter a value")+"']")).size()>0) {
			enterFlexiFormDetails();
			Thread.sleep(5000);
			saveBtn = driver.findElement(By.id("saveAsDraftAuthBtn"));
			clickElement(saveBtn);
		}
		waitUntilInvisibilityOfElement(By.xpath("//div[contains(@class,'blockUI blockOverlay')]"));
		waitUntilInvisibilityOfElement(By.xpath("//span[contains(@class,'zys-loader-icon')]"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		waitUntilVisibilityOfElement(By.id("wordSummary"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		Thread.sleep(5000);
		String contractID = driver.findElement(By.xpath("//span[@class='topTitle']/span[1]")).getText().trim();
		
		clickElement(By.id("closeAuthContract"));
		waitUntilVisibilityOfElement(By.id("authorContractListing-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		clearAllFilters();
		waitUntilVisibilityOfElement(By.id("authorContractListing-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		/*
		String contractStatus = driver.findElement(By.xpath("//span[contains(@class,'statusBg')]")).getText().trim();*/
		if(filterByContractNumber(contractID)) {
			int statusCol = getColNum_IContract("Status");
			String contractStatus = driver.findElement(By.xpath("//table[@id='authorContractListing-grid']//tbody/tr/td["+statusCol+"]/span")).getText().trim();
			if(contractStatus.contains("Draft in Progress")) {
				LogScreenshot("pass","Clone In Authoring Completed");
			}else {
				LogScreenshot("fail","Clone In Authoring Failed Contract Status is :"+contractStatus );
			}

		}

	}


	public void publishContract() throws Exception {

		waitUntilVisibilityOfElement(By.id("publishContract"));
		WebElement publishContractBtn = driver.findElement(By.id("publishContract"));
		clickElement(publishContractBtn);
		waitUntilVisibilityOfElement(By.xpath("//div[@class='jconfirm-content-pane']"));
		WebElement remarkInput = driver.findElement(By.id("revisionComment"));
		setInput(remarkInput, "Publishing Event");
		LogScreenshot("pass","Publishing Contract");
		WebElement publishBtn = driver.findElement(By.id("publishBtn"));
		clickElement(publishBtn);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.xpath("//div[@class='jconfirm-content-pane']"));
		LogScreenshot("pass","Contract Published Successfully");
		WebElement setAlertBtn = driver.findElement(By.xpath("//input[@value='"+getLanguageProperty("Set Alert")+"']  "));
		LogScreenshot("info","Setting Alert");
		clickElement(setAlertBtn);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));

	}


}
