package com.zycus.IContract.Search;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ContractSearch extends eInvoice_CommonFunctions {

	public ContractSearch(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public void saveSearch() throws Exception{
		String nameOfSearch = "AutoSearch_"+generateNo();
		findElement(By.xpath("//span[text()='"+getLanguageProperty("Save Search")+"']"),"Save Search").click();
		waitUntilVisibilityOfElement(By.xpath("//div[contains(@class,'saveSearchContent')]"));
		driver.findElement(By.id("saveSearchName")).sendKeys(nameOfSearch);
		findElement(By.id("saveSearchButton"),"Save button").click();
		waitUntilVisibilityOfElement(By.id("jqi"));
		findElement(By.xpath("//button[text()='"+getLanguageProperty("OK")+"']"),"OK button").click();
		logger.pass("Search : "+nameOfSearch+" saved");
		//Click Back button
		findElement(By.id("back"),"Back link").click();
		waitUntilInvisibilityOfElement(processingLoader);
		if(driver.findElements(By.xpath("//ul[@id='savedSearchesLandingPageList']/li/span[@title='"+nameOfSearch+"']")).size()>0)
			logger.pass("Search : "+nameOfSearch + "saved in 'My Searches'");
	}
	
	public void savePreference(String preference) throws Exception{
		findElement(By.xpath("//span[text()='"+getLanguageProperty("My Preferences")+"']"),"My Preferences").click();
		waitUntilVisibilityOfElement(By.xpath("//div[contains(@class,'myPreferencesContent')]"));
		findElement(By.xpath("//select[contains(@class,'searchByPreference')]/option[text()='"+preference+"']")).click();
		findElement(By.id("savePreferencesBtn"),"Save button").click();
		waitUntilVisibilityOfElement(By.id("jqi"));
		findElement(By.xpath("//button[text()='"+getLanguageProperty("OK")+"']"),"OK button").click();
		logger.pass("My Preferences : "+preference+" saved");
		//Click Back button
		findElement(By.id("back"),"Back link").click();
		waitUntilInvisibilityOfElement(processingLoader);
		if(driver.findElement(By.xpath("//div[@class='metaDataSelect']//span")).getAttribute("title").equals(preference))
			logger.pass("Search : "+preference + "saved in 'My Searches'");
	}
	
	public void switchByTypeOrFolder(String switchTo){
		if(switchTo.equals(getLanguageProperty("Type"))){
			if(driver.findElement(By.xpath("//li[contains(@class,'typeBtn')]")).getAttribute("class").contains("active"))
				logger.info("Already switched to 'Type'");
			else
				switchBrowseByType();
		}else{
				if(driver.findElement(By.xpath("//li[contains(@class,'typeBtn')]")).getAttribute("class").contains("active"))
					logger.info("Already switched to 'Type'");			
				else
					switchBrowseByFolder();
		}
	}
	
	private void switchBrowseByType(){
		findElement(By.xpath("//li[@class='typeBtn']")).click();
	}
	
	private void switchBrowseByFolder(){
		findElement(By.xpath("//li[@class='folderBtn']")).click();
	}
	
	
	public boolean searchContract(String contractType, String contractCategory, String searchValue) {
		boolean result = false;
		boolean searchResult = true;
		try {
			//Select Contract Type
			findElement(By.xpath("//div[@class='contrType']/span[2]")).click();
			findElement(By.xpath("//div[@class='contrType']/ul/li[@title='"+contractType+"']")).click();
			
			//Select Contract Category
			findElement(By.xpath("//div[@class='metaDataSelect']/span[2]")).click();
			findElement(By.xpath("//div[@class='metaDataSelect']/ul/li[@title='"+contractCategory+"']")).click();
			
			driver.findElement(By.id("searchedContent")).sendKeys(searchValue);
			findElement(By.id("getSearchResults")).click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='processLoadingDiv']"));		
			if(!(driver.findElements(By.xpath("//div[@id='searchResultsTileView']/div/div/span/h3")).size()>0)){
				List<WebElement> contractTiles = driver.findElements(By.xpath("//div[@id='searchResultsTileView']/div/div/span"));
				for(WebElement contractTile : contractTiles){
					String contractTitle = contractTile.getAttribute("contracttitle").toLowerCase();
					if(!contractTitle.equals(searchValue.toLowerCase())){
						LogScreenshot("fail", contractTitle +" displayed for search Value : "+searchValue);
						searchResult = false;
						break;
					}
				}
				if(searchResult) {
					result = true;
					LogScreenshot("pass", searchValue+" found in search");
				}
					
			}
		clickElement(By.id("back"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//Searches only Contract Number
	public boolean advancedSearch(String contractType, String contractCategory, String searchValue){
		boolean result = false;
		try{
			findElement(By.xpath("//span[@class='advanceSearchBtn']")).click();
			findElement(By.xpath("//ul[@id='subTypeSelector']/a[contains(text(),'"+contractType+"')]")).click();
			findElement(By.xpath("//div[@class='childSelectorContent']//input[following-sibling::label[contains(text(),'"+contractCategory+"')]]")).click();
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Continue")+"']")).click();
			driver.findElement(By.id("Contract_ID")).sendKeys(searchValue);
			findElement(By.id("saveAndContinue")).click();
			
			//Need to verfiy if the results are correct - functionality not working in ZCS Production, shows blank page
			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	private boolean verifyTopFiveViewedContractsSectionDisplayed(){
		return driver.findElements(By.xpath("//div[@class='topTreandBx']//span[@title='Top 5 Viewed Contract']")).size()==1;
	}
	
	private boolean verifyTopFiveRecentSearchesSectionDisplayed(){
		return driver.findElements(By.xpath("//div[@class='topTreandBx']//span[@title='Top 5 Recent Searches']")).size()==1;
	}
	
	public void verifyTopFiveContractsDisplayed() throws Exception{
		if(verifyTopFiveViewedContractsSectionDisplayed()){
			if(driver.findElements(By.id("MostViewedContractList")).size()>0)
				LogScreenshot("pass","Top 5 Viewed Contracts displayed");
			else
				LogScreenshot("fail","Top 5 Viewed Contracts not displayed");
		}else
			LogScreenshot("fail","'Top 5 Viewed Contract' section not displayed");
	}
	
	public void verifyTopFiveRecentSearchesDisplayed() throws Exception{
		if(verifyTopFiveRecentSearchesSectionDisplayed()){
			if(driver.findElements(By.id("LandingPageRecentSearches")).size()>0)
				LogScreenshot("pass","Top 5 Recent Searches displayed");
			else
				LogScreenshot("fail","Top 5 Recent Searches not displayed");
		}else
			LogScreenshot("fail","'Top 5 Recent Searches' section not displayed");
	}

}
