package com.zycus.IContract.ManageContracts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ContractsPendingReview extends eInvoice_CommonFunctions {

	public ContractsPendingReview(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public boolean approveContract(String stage, String contractNo, String actionParam) throws Exception {
		boolean result = false;
		String action = getLanguageProperty(actionParam);
		try {
			switch(stage){
			case "Authoring Stage":
				LogScreenshot("info","Navigated to Authoring Stage Tab");
				waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
				WebElement actionBtn = findElement(By.xpath("//table[@id='author-approval-grid']/tbody/tr[td[1]/span[@title='"+contractNo+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
				clickElement(actionBtn);
				clickElement(actionBtn.findElement(By.xpath(".//following-sibling::ul/li/span[@title='"+action+"']")));
				if(action.equals(getLanguageProperty("Approve"))){
					waitUntilVisibilityOfElement(By.id("revisionCommentPopup"));
					driver.findElement(By.id("revisionComment")).sendKeys("approval comment");
					LogScreenshot("pass","Approving from Authoring Stage");
					findElement(By.xpath("//div[@id='revisionCommentPopup']/following-sibling::div/div/button[span[text()='"+getLanguageProperty("Ok")+"']]")).click();
					//waitUntilInvisibilityOfElement(processingLoader);
					waitUntilVisibilityOfElement(By.xpath("//div[@id='jqi']//div[contains(text(),'"+getLanguageProperty("The contract has been Approved")+"')]"));
					findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("OK")+"']")).click();
					waitUntilVisibilityOfElement(By.id("author-approval-grid"));
					if(driver.findElements(By.xpath("//table[@id='author-approval-grid']/tbody/tr[td[1]/span[@title='"+contractNo+"']]")).size()==0)
						LogScreenshot("Pass","The Contract Account : "+contractNo+" has beeen approved");
				}
				break;
			case "Negotiate Stage":
				break;
			case "Sign-off Stage":
				waitUntilInvisibilityOfElement(processingLoader);
				findElement(By.id("signoffHeader")).click();
				waitUntilInvisibilityOfElement(processingLoader);
				waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
				waitUntilVisibilityOfElement(By.xpath("//table[@id='author-approval-grid']"));
				LogScreenshot("info","Navigated to Sign-off Stage Tab");
				Thread.sleep(5000);
				WebElement actionLink = driver.findElement(By.xpath("//table[@id='author-approval-grid']//tr[td[1]/span[@title='"+contractNo+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
				clickElement(actionLink);
				clickElement(actionLink.findElement(By.xpath(".//following-sibling::ul//span[text()='"+getLanguageProperty("Approve")+"']")));
				driver.findElement(By.id("revisionComment")).sendKeys("Marking as approved");
				LogScreenshot("pass", "Approving from Sign-off stage");
				findElement(By.xpath("//div[contains(@style,'block')]//button[span[text()='"+getLanguageProperty("Ok")+"']]")).click();
				waitUntilInvisibilityOfElement(processingLoader);
				waitUntilVisibilityOfElement(By.xpath("//div[@id='jqi'][//div[contains(text(),'"+getLanguageProperty("The contract has been Approved")+"')]]"));
				WebElement successPopup = driver.findElement(By.xpath("//div[@id='jqi'][//div[contains(text(),'"+getLanguageProperty("The contract has been Approved")+"')]]"));
				waitUntilVisibilityOfElement(successPopup);
				successPopup.findElement(By.xpath("//button[text()='"+getLanguageProperty("OK")+"']")).click();
				if(!(driver.findElements(By.xpath("//table[@id='author-approval-grid']//tr[td[1]/span[@title='"+contractNo+"']]")).size()>0))
					LogScreenshot("pass",contractNo+" has been approved");
					result = true;
					break;
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("Fail","Not navigated to 'Contract Details' page");
			throw new Exception();
		}
		return result;
	}

}
