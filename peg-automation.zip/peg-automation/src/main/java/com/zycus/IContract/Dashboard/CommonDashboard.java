package com.zycus.IContract.Dashboard;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class CommonDashboard extends eInvoice_CommonFunctions {

	private String customDashboardName;

	public CommonDashboard(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	private boolean searchDashboard(String dashboardName) throws Exception{
		boolean result = false;
		returnElemWhenVisible(By.id("viewInputTxtbx")).clear();
		//driver.findElement(By.id("viewInputTxtbx")).clear();
		System.out.println("Search Dashboard Name :"+dashboardName);
		driver.findElement(By.id("viewInputTxtbx")).sendKeys(dashboardName);
		waitUntilVisibilityOfElement(By.xpath("//div[@id='DashboardListAutoComplete']/ul"));
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[@id='DashboardListAutoComplete']/ul/li/a[contains(@title,'No Matching Results Found')]")).size()>0){
			LogScreenshot("fail", "'No Matching Results Found' displayed for dashboard "+dashboardName);
			result = false;
		}else{
			//waitUntilInvisibilityOfElement(By.id("zys-popup-overlay"));
			findElement(By.xpath("//div[@id='DashboardListAutoComplete']/ul/li/a[@title='"+dashboardName+"']")).click();
			waitUntilInvisibilityOfElement(By.id("processLoader"));
			result = true;
		}
		return result;
	}
	
	public boolean verifyReportExistInDashboard(String dashboardName, String reportName) throws Exception{
		boolean result = false;
		try{
			searchDashboard(dashboardName);
			if(driver.findElements(By.xpath("//div[@class='portlet']//h2[contains(@id,'widgetName') and @title='"+reportName+"']")).size()>0)
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	private boolean dragWidgetToDashboard(String widgetName, int position) {
		boolean result = false;
		try{
			WebElement draggable = driver
					.findElement(By.xpath("//div[@class='reportContainerParent']//a[@title='" + widgetName + "']"));
			WebElement droppable = findElement(By.xpath("//div[@class='dashboardRightPart']/div[" + position + "]"));
			new Actions(driver).dragAndDrop(draggable, droppable).build().perform();
			waitUntilInvisibilityOfElement(By.id("pleaseWaitLay"));
			Thread.sleep(1000);
			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	private int countLayoutDivisions(String dashboardLayout){
		char[] chars = dashboardLayout.toCharArray();
		int divCtr = 0;
		for(char a : chars){
			if(a==':')
				divCtr++;
		}
		return divCtr;
	}
	

	public String addNewDashboard(String dashboardLayout, String... prePackagedReports) throws Exception {
		String dashboardName = null;
		boolean result = false;
		boolean allWidgetsAdded = true;
		Random rnd = new Random();
		this.customDashboardName = "CustomDash_"+generateNo();
		try {
			// Click on 'Add New' button
			WebDriverWait wait = new WebDriverWait(driver, 600);
			wait.until(ExpectedConditions.visibilityOf(findElement(By.xpath("//a[@name='addNewDashBoard']"))));
			Thread.sleep(2000);
			findElement(By.xpath("//a[@name='addNewDashBoard']")).click();
			//findElement(By.xpath("//a[@name='addNewDashBoard']"),"Add New button").click();
			if (driver.findElements(By.id("AddNewDashPop")).size()>0) {
			//if (driver.findElement(By.id("AddNewDashPop")).isDisplayed()) {
				LogScreenshot("pass","'Add New Dashboard' pop-up displayed");
				findElement(By.xpath("//a[@class='getStartedCustom']"), "Generate button").click();
				if (driver.findElements(By.id("customDashboardPopUp")).size()>0) {
				//if (driver.findElement(By.id("customDashboardPopUp")).isDisplayed()) {
					driver.findElement(By.id("customDashboardName")).sendKeys(customDashboardName);
					findElement(By.xpath("//div[@class='boxLayoutsDv']//a[text()='" + dashboardLayout + "']"), dashboardLayout +" Dashboard Layout").click();
					LogScreenshot("pass","'Create Custom Dashboard' pop-up displayed");
					// Click on 'Create Dashboard' button
					//findElement(By.id("customDash"), "Create Dashboard button").click();
					JavascriptExecutor js = (JavascriptExecutor)driver;
					js.executeScript("arguments[0].click();", driver.findElement(By.id("customDash")));
					waitUntilInvisibilityOfElement(By.id("processLoader"));
					waitUntilVisibilityOfElement(By.id("noReportWidgetPresentEdit"));
					for (String reportToDrag : prePackagedReports) {
						if(!dragWidgetToDashboard(reportToDrag, 1 + rnd.nextInt(countLayoutDivisions(dashboardLayout))))
							allWidgetsAdded = false;
					}
					if(allWidgetsAdded)
						dashboardName = customDashboardName;
				} else
					LogScreenshot("fail","'Create Custom Dashboard' pop-up not displayed");
			} else
				LogScreenshot("fail","'Add New Dashboard' pop-up not displayed");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(dashboardName);
		return dashboardName;
	}
	
	public String saveNewDashboardToMyDashboard(String dashboardLayout, String... prePackagedReports) throws Exception{
		String savedDashboardName = null;
		try{
			customDashboardName = addNewDashboard(dashboardLayout, prePackagedReports);
			Thread.sleep(6000);
			waitUntilVisibilityOfElement(By.id("savePrivateAch"));
			WebElement saveInDashboard = driver.findElement(By.id("savePrivateAch"));
			clickElement(saveInDashboard);
			waitUntilInvisibilityOfElement(By.id("editLoadingPopUp"));
			waitUntilInvisibilityOfElement(By.id("processLoader"));
			savedDashboardName = customDashboardName;
			if(verifyReportsAdded(prePackagedReports)){
				String allReports = "";
				for(String report : prePackagedReports)
					allReports = report + " , ";
				LogScreenshot("pass",allReports + "added to custom Dashboard : "+customDashboardName);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return savedDashboardName;
	}
	
	public String saveNewDashboardToPrecanned(String dashboardLayout, String... prePackagedReports){
		String savedDashboardName = null;
		try{
			//if(addNewDashboard(dashboardLayout, prePackagedReports)){
				customDashboardName = addNewDashboard(dashboardLayout, prePackagedReports);
				WebElement saveInPrecanned = driver.findElement(By.id("savePublicAch"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("window.scrollBy(0,-1000)", saveInPrecanned);
				saveInPrecanned.click();
				//findElement(By.id("savePublicAch"), "Save as Precanned button").click();
				waitUntilInvisibilityOfElement(By.id("editLoadingPopUp"));
				waitUntilInvisibilityOfElement(By.id("processLoader"));
				if(verifyReportsAdded(prePackagedReports)){
					String allReports = "";
					for(String report : prePackagedReports)
						allReports = report + " , ";
					LogScreenshot("pass", allReports + "added to custom Dashboard : "+customDashboardName);
					savedDashboardName = customDashboardName;
				}
			//}
		}catch(Exception e){
			e.printStackTrace();
		}
		return savedDashboardName;
	}
	
	private boolean verifyReportsAdded(String... prePackagedReports){
		boolean result = false;
		boolean reportNotFound = false;
		String portletTitle = null;
		try{
			int portletsCount = 0;
			int j =0;
			do{
				j++;
				Thread.sleep(3000);
				portletsCount = driver.findElements(By.xpath("//div[@class='portlet']")).size();
				if(j>20)
					break;
			}while(portletsCount>0);
			int reportCtr = 0;
			for(String report : prePackagedReports){
				reportCtr++;
				for(int i = 1; i<=portletsCount; i++){
					portletTitle = driver.findElement(By.xpath("(//div[@class='portlet'])["+i+"]//div[@class='dashName']/h2")).getAttribute("title");
					if(!report.equals(portletTitle)){
						if(reportCtr == i){
							reportNotFound = true;
							LogScreenshot("fail", report +" not added to the My Dashboard/Precanned in Custom Dashboard : "+ customDashboardName);
							break;
						}
					else
						break;
					}
				}
			}
			if(!reportNotFound)
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean deleteDashboard(String dashboardName) throws Exception{
		boolean result = false;
		try{
			searchDashboard(dashboardName);
			//Click on 'More Options' link
			findElement(By.id("activeOnMenu"), "More Options button").click();
			findElement(By.xpath("//a[@id='activeOnMenu']/following-sibling::div[@class='subDropMenu']//a[@title='"+getLanguageProperty("Delete")+"']"), "Delete link").click();
			Thread.sleep(3000);
			if(driver.findElements(By.id("deleteDefault")).size()>0){
				findElement(By.xpath("//select[@id='newDefaultDashList']/optgroup[1]/option[1]")).click();
				waitUntilVisibilityOfElement(By.xpath("//div[@id='deleteDefaultDashboard' and contains(@style,'block')]"));
				Thread.sleep(3000);
				//driver.findElement(By.id("btnPopUpDashSaveAsPopup")).click();
				driver.findElement(By.id("deleteDefaultDashboard")).click();
			}
			if(driver.findElements(By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Please confirm your action")+"']]")).size()>0)
				findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
			waitUntilInvisibilityOfElement(By.id("grayLayerDel"));
			if(driver.findElements(By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Dashboard deleted")+"']]")).size()>0){
				findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
				waitUntilInvisibilityOfElement(By.id("processLoader"));
				if(!searchDashboard(dashboardName))
					result = true;
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	
	public boolean removeFromFavorites(String dashboardName) throws Exception{
		boolean result = false;
		//Click on Favorites link to expand favorites list
		findElement(By.id("Quicktitle"), "Favorites link").click();
		try{
			driver.findElement(By.xpath("//div[@id='favouriteDBList']/ul/li/a[span[@title='"+dashboardName+"']]/following-sibling::span")).click();
			if(driver.findElements(By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Please confirm your action")+"']]")).size()>0){
				findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
				waitUntilInvisibilityOfElement(By.xpath("//span[@class='LoadingFav']"));
			}
		}catch(Exception e){
			e.printStackTrace();
			LogScreenshot("fail", dashboardName + "already not in the Favorites list");
		}
		if(driver.findElements(By.xpath("//div[@id='favouriteDBList']/ul/li/a/span[@title='"+dashboardName+"']")).size()>0)
			LogScreenshot("fail", dashboardName + " not removed from Favorites");
		else{
			LogScreenshot("pass", dashboardName + " added to Favorites");
			result = true;
		}
		return result;
	}
	
	public boolean addDashboardToFavorites(String dashboardName){
		boolean result = false;
		try{
			searchDashboard(dashboardName);
			//Click on 'More Options' link
			findElement(By.id("activeOnMenu"), "More Options button").click();
			findElement(By.xpath("//a[@id='activeOnMenu']/following-sibling::div[@class='subDropMenu']//a[@title='"+getLanguageProperty("Add to Favorite")+"']"), "Add to Favorite link").click();
			//Click on Favorites link to expand favorites list
			findElement(By.id("Quicktitle"), "Favorites link").click();
			if(driver.findElements(By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Added Successfully")+"']]")).size()>0)
				findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
			if(driver.findElements(By.xpath("//div[@id='favouriteDBList']/ul/li/a/span[@title='"+dashboardName+"']")).size()>0){
				LogScreenshot("pass", dashboardName + " added to Favorites");
				result = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean markDashboardAsDefault(String dashboardName) throws Exception{
		boolean result = false;
		try{
			searchDashboard(dashboardName);
			//Click on 'More Options' link
			findElement(By.id("activeOnMenu"), "More Options button").click();
			findElement(By.xpath("//a[@id='activeOnMenu']/following-sibling::div[@class='subDropMenu']//a[@title='"+getLanguageProperty("Mark as Default")+"']"), "Mark as Default link").click();
			waitUntilVisibilityOfElement(By.xpath("//div[@id='zys-popup-container']/div/h1[text()='"+getLanguageProperty("Successfully marked")+"']"));
			Thread.sleep(1500);
			//if(driver.findElements(By.xpath("//div[@id='zys-popup-container'][div/h1[text()='"+getLanguageProperty("Successfully marked")+"']]")).size()>0)
			findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
			findElement(By.xpath("//a[@class='viewClick']"),"Dropdown arrow after search Dashboard field").click();
			if(driver.findElement(By.xpath("//div[@class='defaultDashIcoActive']/preceding-sibling::a[@title]")).getAttribute("title").equals(dashboardName)){
				//waitUntilVisibilityOfElement(By.xpath("//div[@id='zys-popup-container']/div/h1[text()='"+getLanguageProperty("Successfully marked")+"']"));
				//findElement(By.xpath("//div[@id='zys-popup-container']//input[@id='popup_ok']")).click();
				result= true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	//exportFormats = .xlsx, .doc,.ppt,.pdf
	public boolean exportDashboard(String dashboardName, String exportFormat) throws Exception{
		boolean result = false;
		String filePath = getDownloadFilePath();
		try{
			if(searchDashboard(dashboardName)){
				findElement(By.name("exportClick"), "Export button").click();
				if(driver.findElements(By.xpath("//div[@id='exportDashPop'][//div[@title='"+dashboardName+"']]")).size()>0){
					findElement(By.xpath("//div[@id='exportDashPop']//div[@class='selectOptDv']//a[@title='"+exportFormat+"']"), exportFormat + " link under Export Dashboard : "+dashboardName+" popup").click();
					//Waiting time to download the file
					Thread.sleep(8000);
					if(checkFileExists(filePath, dashboardName, exportFormat)){
						LogScreenshot("fail", "Dashboard : "+dashboardName +" exported successfully");
							result = true;
					}
				}else
					LogScreenshot("fail", "'Export Dashboard : "+dashboardName +"' pop-up not displayed");
			}else
				LogScreenshot("fail", "Unable to search Dashboard");
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

}
