package com.zycus.IContract.ManageContracts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.SkipException;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iContract_CommonFunctions;

public class Amendment extends iContract_CommonFunctions{

	public String amendmentNumber = null;

	public Amendment(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
	}

	public String createAmendment(String contractId) throws Exception {

		clearAllFilters();
		filterByContractNumber(contractId);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));

		int statusCol = getColNum_IContract("Status");
		String contractStatus = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td["+statusCol+"]/span")).getText().trim();

		if(contractStatus.equals("Pending Publish")) {
			LogScreenshot("info","Contract Status in Pending Publish");
			throw new SkipException("Skipping Amendment creation because contract status is in "+contractStatus);
		}else {

			WebElement actionBtn = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr[td[span[span[text()='"+contractId+"']]]]//td[last()]"));
			LogScreenshot("info","Clicking Action Button");
			clickElement(actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Actions")+"']")));
			LogScreenshot("pass","Action Button Clicked");
			Thread.sleep(3000);
			if(driver.findElements(By.xpath("//div[contains(@class,'actBxWrapOpen')]")).size()==0) {
				LogScreenshot("info","Clicking Action Button second time");
				clickElement(actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Actions")+"']")));
				LogScreenshot("pass","Action Button Clicked");
			}
			waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
			LogScreenshot("pass","Create Amendment Starting");
			clickElement(actionBtn.findElement(By.xpath(".//ul/li/span[text()='"+getLanguageProperty("Create Amendment")+"']")));

			SelectContractType contractType = new SelectContractType(driver, logger);
			contractType.selectTypeSubTypeForAmendment();

			amendmentNumber = enterAmendmentDetails();

			List<WebElement> headerTab = driver.findElements(By.xpath("//ul[@id='headerTab']/li"));
			for(WebElement header : headerTab) {
				clickElement(header);
				LogScreenshot("info","Navigated To "+header.getText());
				if(header.getText().contains("Section")) {
					waitUntilVisibilityOfElement(By.id("zydf-dynamicForm"));
				}
			}

			WebElement saveBtn = driver.findElement(By.id("saveBtn"));
			clickElement(saveBtn);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
			LogScreenshot("info","Amendment saved as draft");
			waitUntilVisibilityOfElement(By.id("summarypage"));
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
			waitUntilVisibilityOfElement(By.id("closeAuthContract"));	
			clickElement(By.id("closeAuthContract"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			waitUntilVisibilityOfElement(By.id("authorContractListing-grid"));
			LogScreenshot("info","Authoring Page Displayed");

			clearAllFilters();
			filterByContractNumber(contractId);


			try {

				WebElement viewAmendment = driver.findElement(By.xpath("//table[@id='authorContractListing-grid']//tbody/tr[td[span[text()='"+contractId+"']]]//span[@title='"+getLanguageProperty("View Amendments")+"']"));
				clickElement(viewAmendment);
				waitUntilVisibilityOfElement(By.id("zydev-popup-authoringContractListing"));

				String amendMentValue = driver.findElement(By.xpath("//div[@id='zydev-popup-authoringContractListing']//td[1]")).getAttribute("title");
				if(amendMentValue.equals(amendmentNumber)) {
					LogScreenshot("pass","Amendment "+amendMentValue+" Added against Contract: "+contractId);
				}else {
					LogScreenshot("fail","Unable to add Amendment against Contract: "+contractId);
				}
				clickElement(By.xpath("//button[@title='"+getLanguageProperty("close")+"']"));
			}catch (Exception e) {
				LogScreenshot("fail","View Amendment Pop-up not displayed");
			}

			return amendmentNumber;
		}
	}



	private String enterAmendmentDetails() throws Exception {

		String amendmentNumber = "AutoAmendment_"+generateNo();

		waitUntilVisibilityOfElement(By.id("Contract_Header"));
		WebElement amendmentInput = driver.findElement(By.id("AMENDMENT_NUMBER"));
		setInput(amendmentInput, amendmentNumber);

		WebElement amendmentDate = driver.findElement(By.id("AMENDMENT_EFFECTIVE_DATE"));
		enterDate(amendmentDate);

		WebElement amendmentDesc = driver.findElement(By.id("AMENDMENT_DESCRIPTION"));
		setInput(amendmentDesc, amendmentNumber+"_Desc");

		LogScreenshot("pass","Amendment Details Added");

		return amendmentNumber;
	}

	public boolean filterByContractNumber(String contractNum) {
		boolean result = false;
		try {
			result = filterByText("Contract Number", contractNum) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	public boolean filterByText(String fieldName, String searchValue) {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
			int intColNo = getColNum_IContract(fieldName);
			searchAndWaitUntilLoaderDisappears(By.xpath("//table[@id='repoContractListing-grid']/thead/tr[2]/th[" + intColNo + "]//input"), searchValue);
			Thread.sleep(3000);
			List<WebElement> objfilteredTxtList = driver.findElements(By.xpath("//table[@id='repoContractListing-grid']/tbody//td[" + intColNo + "]"));
			for (WebElement obj : objfilteredTxtList) {
				if (obj.getText().contains(searchValue))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByTextAuthor(String fieldName, String searchValue) {
		boolean result = false;
		try {
			int intColNo = getColNum_IContract(fieldName);
			searchAndWaitUntilLoaderDisappears(By.xpath("//table[@id='authorContractListing-grid']/thead/tr[2]/th[" + intColNo + "]//input"), searchValue);
			Thread.sleep(3000);
			List<WebElement> objfilteredTxtList = driver.findElements(By.xpath("//table[@id='authorContractListing-grid']/tbody//td[" + intColNo + "]"));
			for (WebElement obj : objfilteredTxtList) {
				if (obj.getText().contains(searchValue))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByAuthorContractNumber(String contractNum) {
		boolean result = false;
		try {
			result = filterByTextAuthor("Contract Number", contractNum) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	public void delegateAmendment(String contractId) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		clearAllFilters();
		filterByContractNumber(contractId);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		WebElement actionBtn = driver.findElement(By.xpath("//table[@id='repoContractListing-grid']//tbody/tr/td[last()]"));
		clickElement(actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Actions")+"']")));
		LogScreenshot("pass","Action Button Clicked");
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[contains(@class,'actBxWrapOpen')]")).size()==0) {
			LogScreenshot("info","Clicking Action Button second time");
			clickElement(actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Actions")+"']")));
			LogScreenshot("pass","Action Button Clicked");
		}
		waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
		LogScreenshot("PASS","Delegate Amendment Started");
		actionBtn.findElement(By.xpath(".//ul/li/span[text()='"+getLanguageProperty("Delegate Amendment")+"']")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.id("zydev-popup-amendment-delegetion"));
		if(driver.findElements(By.xpath("//div[@id='userList']//input")).size()>0) {
			findElement(By.xpath("//div[@id='userList']//input[1]")).click();
			LogScreenshot("PASS","User selected");
			findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Delegate")+"']")).click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			if(driver.findElements(By.xpath("//div[@class='zys-popup-title jqicontainer']/h1[text()='"+getLanguageProperty("Success")+"']")).size()>0) {
				LogScreenshot("PASS","Confirmation popup is displayed");
				js.executeScript("arguments[0].click()", driver.findElement(By.id("jqi_state0_buttonOK")));
				LogScreenshot("PASS","User delegated successfully");
			}
		}else {
			LogScreenshot("warning","No users found. Unable to delegate amendment");
			clickElement(By.xpath("//button/span[text()='"+getLanguageProperty("Cancel")+"']"));
		}

	}

	public boolean deleteAmendment(String contractId) throws Exception {
	
		clearAllFilters();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		filterByAuthorContractNumber(contractId);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
		try {
			WebElement viewAmendment = driver.findElement(By.xpath("//table[@id='authorContractListing-grid']//tbody/tr[td[span[text()='"+contractId+"']]]//span[@title='"+getLanguageProperty("View Amendments")+"']"));
			clickElement(viewAmendment);
			waitUntilVisibilityOfElement(By.id("zydev-popup-authoringContractListing"));

			clickElement(By.xpath("//td[@class='iAct icon-only']//span[@class='icon delete'][@title='"+getLanguageProperty("Delete")+"']"));
			Thread.sleep(2000);
			if(driver.findElements(By.id("zydev-popup-delete-contract")).size()>0) {
				LogScreenshot("PASS","Popup displayed");
				findElement(By.id("txtAreaComment")).sendKeys("Deleting Amendment "+amendmentNumber);
				clickElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Delete")+"']"));	
				LogScreenshot("PASS","Amednment is deleted");
			}	else {
				LogScreenshot("FAIL","Amendment is not deleted");
			}
		}catch (Exception e) {
			LogScreenshot("FAIL","View Amendment Pop-up not displayed");
		}
		return false;
	}
}
