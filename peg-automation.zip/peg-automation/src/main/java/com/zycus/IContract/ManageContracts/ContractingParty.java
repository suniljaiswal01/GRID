package com.zycus.IContract.ManageContracts;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iContract_CommonFunctions;

public class ContractingParty extends iContract_CommonFunctions {

	private static By processingLoader = By.xpath("//span[@class='zys-loader-icon']");
	private static By pgHead = By.xpath("//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Contracting Party")+"']");
	//private static By addPartyBtn = By.xpath("//div[@id='contractingPartyDiv']//span[@class='addParty']/label");
	private static By addPartyBtn = By.xpath("//span[@class='addParty']/label");
	/*private String[] contractingPartyList1;
	private String[] contactPersonList1;*/
	private List<String> contractingPartyList = new ArrayList<String>();
	private List<String> contactPersonList = new ArrayList<String>();
	private String contractingParty;
	private String contactPerson;

	public ContractingParty(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		try{
			

			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			this.contractingParty = supplierDetails.getCompanyName();
			this.contactPerson = supplierDetails.getContactingPerson();
			this.contractingPartyList.add(contractingParty);
			this.contactPersonList.add(contactPerson);
			supplierDetails.setSupplierData(1);
			this.contractingPartyList.add(supplierDetails.getCompanyName());
			this.contactPersonList.add(supplierDetails.getContactingPerson());
			
			
		/*	CommonFunctions1 objFunctions = new CommonFunctions1();
			ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
			String Datasheet_SuppContacts = configurationProperties.getProperty("Datasheet_SupplierContacts");
			String[][] abc1 = (String[][]) objFunctions.dataProvider(configurationProperties.getProperty("Environment"), Datasheet_SuppContacts);
			for(int i=0; i<abc1.length ; i++){
				this.contractingPartyList.add(abc1[i][0]);
				this.contactPersonList.add(abc1[i][1]);
			}
			this.contractingParty = contractingPartyList.get(0);
			this.contactPerson = contactPersonList.get(0);*/
		}catch(Exception e){
			e.printStackTrace();
		}

		/* this.contractingParty = abc[0][0];
		this.contactPerson = abc[0][1];*/

	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	public boolean addContractingParties(){
		boolean result = false;
		try{	
			addContractingParty(contactPerson,contractingParty);
			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}


	public boolean addContractingParty(String contactPerson,String contractingParty) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			//clickAndWaitUntilElementAppears(By.id("addVendor"), By.id("vendor-grid"));
			clickAndWaitUntilElementAppears(addPartyBtn, By.id("vendor-grid"));
			Thread.sleep(2000);
			waitUntilInvisibilityOfElement(processingLoader);
			driver.findElement(By.id("vendorSearchValue")).sendKeys(contractingParty);
			clickAndWaitUntilLoaderDisappears(By.id("goButton"), processingLoader);
			Thread.sleep(4000);
			waitUntilVisibilityOfElement(By.xpath("//table[@id='vendor-grid']"));
			findElement(By.xpath("//table[@id='vendor-grid']/tbody//span[@title='"+contractingParty+"']/ancestor::tr/td[1]")).click();

			//****************************Site Info column missing in ZCS RM ****************************
			try{
				clickElement(By.xpath("//table[@id='vendor-grid']/tbody//span/ancestor::tr/td[5]//span[contains(text(),'"+ contactPerson + "')]/input"));
				LogScreenshot("pass","Supplier Found in Grid");
			}catch(Exception e){
				clickElement(By.xpath("//table[@id='vendor-grid']/tbody//span/ancestor::tr/td[4]//span[contains(text(),'"+ contactPerson + "')]/input"));
				LogScreenshot("pass","Supplier Found in Grid");
			}
			//********************************************************
			String contractPartyFullNm = findElement(By.xpath("//table[@id='vendor-grid']/tbody//span[contains(text(),'" + contractingParty + "')]")).getText();
			//clickAndWaitUntilLoaderDisappears(By.id("contractingPartySaveButton"), processingLoader);
			clickAndWaitUntilLoaderDisappears(By.xpath("//div[@id='contractingPartyButtons']//input[@value='"+getLanguageProperty("Save")+"']  "), processingLoader);
			LogScreenshot("pass", "Contracting Party: "+ contractPartyFullNm +" added");
			/*String contractingPartyTitle = findElement(By.xpath("//div[@id='contractingPartyDiv']/div/span")).getText();
			if (contractingPartyTitle.equals(contractPartyFullNm)){
				LogScreenshot("pass", "Contracting Party: "+ contractingPartyTitle +" added");
				result = true;
			}*/
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("fail","Contracting Party: "+ contractingParty +" not added");
		}
		return result;
	}

	public void markPartyAsPrimary(String contractingparty) throws Exception{
		WebElement objMakePrimary = driver.findElement(By.xpath("//div[contains(@class,'addParty')][div/span[@title='"+contractingparty+"']]//label[contains(@id,'makePrimary')]"));
		String divClass = objMakePrimary.getAttribute("class");
		if(divClass.contains("makePrimary"))
			logger.log(Status.INFO, contractingparty +" Contracting Party is already marked primary");
		else if(divClass.contains("notPrimary")){
			objMakePrimary.click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockMsg blockPage']"));
			waitUntilInvisibilityOfElement(processingLoader);

			//Verify
			if(driver.findElement(By.xpath("//div[contains(@class,'addParty')][div/span[@title='"+contractingparty+"']]//label[contains(@id,'makePrimary')]")).getAttribute("class").contains("makePrimary"))
				logger.pass( contractingparty +"Contracting Party marked primary");
			else
				logger.fail( contractingparty +"Contracting Party not marked primary");
		}
	}

	//Incomplete as no Vendor Contractor is displayed in ZCS production
	public boolean addContractor(String contractorName, String engStartDt, String engEndDt){
		boolean result = false;
		try{
			//Click on 'Add Contractor' button
			findElement(By.id("addContractorPopup")).click();
			findElement(By.xpath("//select[@id='contractorInfor']/option[text()='"+contractorName+"']")).click();
			driver.findElement(By.id("engagementStartDate")).click();
			selectDate_v1(engStartDt);
			driver.findElement(By.id("engagementEndDate")).click();
			selectDate_v1(engEndDt);
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Save")+"']]")).click();
			result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	public void addMultiContractingParty() throws Exception {

		try {
			for(int i=0;i<contractingPartyList.size();i++) {
				navigate_ContractSubTabs("Contracting Party");
				this.contractingParty = contractingPartyList.get(i);
				this.contactPerson = contactPersonList.get(i);
				addContractingParty(contactPerson, contractingParty);
			}
			LogScreenshot("pass","Multi Contracting party added");
		}catch (Exception e) {
			LogScreenshot("fail","Unable to add Multi Contracting party");
		}
	}


	/*public boolean addContractingParty() {
		boolean result = false;
		try {
			clickAndWaitUntilElementAppears(By.id("addVendor"), By.id("vendor-grid"));
			String contractPartyFullNm = findElement(By.xpath("(//table[@id='vendor-grid']/tbody//span)[1]")).getText();
			clickAndWaitUntilLoaderDisappears(By.xpath("//div[@id='contractingPartyButtons']/input"), processingLoader);
			String contractingPartyTitle = findElement(By.xpath("//div[@id='contractingPartyDiv']/div/span")).getText();
			if (contractingPartyTitle.equals(contractPartyFullNm)){
				LogScreenshot("INFO", "Contract Party added");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

}
