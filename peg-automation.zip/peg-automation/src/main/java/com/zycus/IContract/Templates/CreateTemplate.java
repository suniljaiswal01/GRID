package com.zycus.IContract.Templates;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.iContract_CommonFunctions;

public class CreateTemplate extends iContract_CommonFunctions {

	private static By pgHead = By.xpath("//div[@id='main-action-button']/h3[text()='"+getLanguageProperty("Create Template")+"']");
	private String templateNo = "Auto_"+generateNo();
	private String templateTitle = "Template_"+templateNo;
	private String assocBaseType;
	private String contractSubType;
	private String templateFor;
	//private String templateFor;
	private String language;
	private String templateSource;
	private List<String> regionList = new ArrayList<String>();
	private List<String> categoryList = new ArrayList<String>();
	private List<String> businessUnitList = new ArrayList<String>();
	
	public CreateTemplate(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
		String[][] abc = (String[][]) objFunctions.dataProvider("CreateTemplate", Datasheet_iContract);
		this.templateSource = abc[0][0];
		this.assocBaseType =  abc[0][1];
		this.contractSubType = abc[0][2];
		this.language =  abc[0][3];
		this.regionList.add(abc[0][4]);
		this.categoryList.add(abc[0][5]);
		this.businessUnitList.add(abc[0][6]);
		this.templateFor = abc[0][7];
	}

	/*public CreateTemplate(WebDriver driver, ExtentTest logger, String templateNo, String templateTitle,
			String assocBaseType, String contractSubType, String templateFor, String language) {
		super(driver, logger);
		this.driver = driver;
		this.logger = logger;
		this.templateNo = templateNo;
		this.templateTitle = templateTitle;
		this.assocBaseType = assocBaseType;
		this.contractSubType = contractSubType;
		this.templateFor = templateFor;
		this.language = language;
	}*/
	
	public CreateTemplate(WebDriver driver, ExtentTest logger,String templateSource, String assocBaseType, String contractSubType) {
		super(driver, logger);
		this.templateSource = templateSource;
		this.templateTitle = "TemplateTitle_"+generateNo();
		this.assocBaseType = assocBaseType;
		this.contractSubType = contractSubType;
		//this.templateFor = templateFor;
		this.language = "English";
	}

	/*public boolean enterTemplateDetails(String templateDesc, String[] regionList, String[] categoryList, String[] businessUnitList) {
		boolean result = false;
		String filePath = "";
		try {
			if(!templateType.equals(getLanguageProperty("Clause Library"))){
				findElement(By.xpath("//input[@type='radio' and @value='fromDocument']")).click();
				uploadFile(filePath);
			}
			driver.findElement(By.id("templateNo")).sendKeys(templateNo);
			driver.findElement(By.id("templateTitle")).sendKeys(templateTitle);
			driver.findElement(By.id("templateDescription")).sendKeys(templateDesc);
			findElement(By.xpath("//select[@id='baseTypeList']/option[text()='" + assocBaseType + "']")).click();
			findElement(By.xpath("//select[@id='contractTypeSubType']/option[text()='" + contractSubType + "']"))
					.click();
			
			selectDropdownChkBx("regionSearchBx", regionList);
			selectDropdownChkBx("categorySearchBx", categoryList);
			selectDropdownChkBx("busUnitSearchBx", businessUnitList);
			findElement(By.xpath("//select[@id='templateFor']/option[text()='" + templateFor + "']")).click();
			findElement(By.xpath("//select[@id='languageFor']/option[text()='" + language + "']")).click();
			// Click Continue button
			findElement(By.id("saveAndContinue")).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
*/
	
	public String enterTemplateDetails(String templateNo) throws Exception {
		String newTemplate = null;
		if(templateNo=="")
			templateNo = this.templateNo;
		String filePath = "";
		String templateDesc = templateNo+"_desc";
		if(!templateSource.equals(getLanguageProperty("Clause Library"))){
			findElement(By.xpath("//input[@type='radio' and @value='fromDocument']")).click();
			uploadFile(filePath);
		}
		driver.findElement(By.id("templateNo")).sendKeys(templateNo);
		driver.findElement(By.id("templateTitle")).sendKeys(templateTitle);
		driver.findElement(By.id("templateDescription")).sendKeys(templateDesc);
		findElement(By.xpath("//select[@id='baseTypeList']/option[text()='" + assocBaseType + "']"), "Associated Base Type : "+assocBaseType).click();
		findElement(By.xpath("//select[@id='contractTypeSubType']/option[text()='" + contractSubType + "']"),"Contract Type - Sub Type :"+contractSubType).click();
		
		if(regionList.size()>0)
			selectDropdownChkBx("regionSearchBx", regionList);
		if(categoryList.size()>0)
			selectDropdownChkBx("categorySearchBx", categoryList);
		if(businessUnitList.size()>0)
			selectDropdownChkBx("busUnitSearchBx", businessUnitList);
		findElement(By.xpath("//select[@id='templateFor']/option[text()='" + templateFor + "']")).click();
		try{
		findElement(By.xpath("//select[@id='languageFor']/option[text()='" + language + "']")).click();
		}catch(Exception e){}
		// Click Continue button
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		Thread.sleep(2000);
		findElement(By.id("saveAndContinue"), "Continue button").click();
		newTemplate = templateNo;
		return newTemplate;
	}
	
/*	public String enterTemplateDetails(String templateFor) throws Exception {
		return enterTemplateDetails("", templateFor);
	}
	*/
	public String enterTemplateDetails() throws Exception {
		return enterTemplateDetails("");
	}

	private void selectDropdownChkBx(String txtInputObjId, List<String> checkBxLabels) throws Exception{
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		clickElement(By.xpath("//input[@id='" + txtInputObjId + "']/following-sibling::span"));
		for(String checkbox : checkBxLabels){
			clickElement(By.xpath("//input[@id='" + txtInputObjId + "']/parent::div//li[contains(text(),'" + checkbox+ "')]/input[@type='checkbox']"));
		}
		clickElement(By.xpath("//input[@id='" + txtInputObjId + "']/following-sibling::span"));
	}

	public String addSection(String sectionName) throws Exception{
		findElement(By.xpath("//input[@title='"+getLanguageProperty("Add Section")+"']"),"+ Add Section button").click();
		int noOfSectionAdded = driver
				.findElements(By.xpath("//tbody[@id='sectionClauses']//div[contains(@class,'newSection')]")).size();
		if (noOfSectionAdded == 1)
			driver.findElement(By.xpath("//tbody[@id='sectionClauses']//div[contains(@class,'newSection')]")).sendKeys(sectionName);
		
		clickElement(By.xpath("//tbody[@id='sectionClauses']//input[@value='"+getLanguageProperty("Save")+"']"),"Save button to add section");
		if (driver.findElements(By.xpath("//tbody[@id='sectionClauses']//div/span")).size() > 0) {
			LogScreenshot("pass","Section added successfully");
		}else	
			LogScreenshot("fail","Section not added");
		return sectionName;
	}
	
	public String addSection() throws Exception{
		String sectionName = "Section_"+generateNo();
		addSection(sectionName);
		return sectionName;
	}

	/*public boolean addClause(String sectionName, String clauseTitle) throws Exception{
		boolean result = false;
		try {
			int existingClauses = driver
					.findElements(
							By.xpath("//tr[@class='MoveableRow']/td[div/span[contains(text(),'" + clauseTitle + "')]]"))
					.size();
			clickAndWaitUntilLoaderDisappears(By.xpath("//tbody[@id='sectionClauses']//tr[td/div/span[text()='" + sectionName
					+ "']]//span[@name='addClause']"));
			if (driver.findElements(By.xpath("//div[@aria-describedby='zydev-popup'][div/span[text()='"+getLanguageProperty("Clause List")+"']]"))
					.size()>0)
				findElement(By.xpath("(//table[@id='selective']/tbody[2]/tr[td[position()=3 and span[contains(text(),'"
						+ clauseTitle + "')]]])[1]//input")).click();
			findElement(By.xpath("//div[@aria-describedby='zydev-popup']//button[span[text()='"+getLanguageProperty("Done")+"']]")).click();
			int noOfClauses = driver
					.findElements(
							By.xpath("//tr[@class='MoveableRow']/td[div/span[contains(text(),'" + clauseTitle + "')]]"))
					.size();
			if (noOfClauses == existingClauses + 1) {
				logger.pass("Clause added successfully");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/
	
	public void addClause(String sectionName, String clauseTitle) throws Exception{
		
		int existingClauses;
		if(clauseTitle!=null) {
			existingClauses = driver.findElements(By.xpath("//tr[@class='MoveableRow']/td[div/span[contains(text(),'" + clauseTitle + "')]]")).size();
		}else
			existingClauses = 0;
		
		clickAndWaitUntilLoaderDisappears(By.xpath("//tbody[@id='sectionClauses']//tr[td/div/span[text()='" + sectionName+ "']]//span[@name='addClause']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		
		if(clauseTitle==null) {
			clauseTitle = driver.findElement(By.xpath("//table[@id='selective']/tbody[2]/tr[1]/td[3]/span")).getText();
		}
		log4jLogger.info("Clause Title to search here is "+clauseTitle);
		if (driver.findElements(By.xpath("//div[@aria-describedby='zydev-popup'][div/span[text()='"+getLanguageProperty("Clause List")+"']]"))
				.size()>0){
			searchClause(clauseTitle);
			log4jLogger.info("Clause Title to search here is "+clauseTitle);
			findElement(By.xpath("(//table[@id='selective']/tbody[2]/tr[td[position()=3 and span[contains(text(),'"	+ clauseTitle + "')]]])[1]//input")).click();
		}
		findElement(By.xpath("//div[@aria-describedby='zydev-popup']//button[span[text()='"+getLanguageProperty("Done")+"']]")).click();
		int noOfClauses = driver.findElements(By.xpath("//tr[@class='MoveableRow']/td[div/span[contains(text(),'" + clauseTitle + "')]]")).size();
		if (noOfClauses == existingClauses + 1) 
			LogScreenshot("Pass","Clause: "+clauseTitle+" added successfully");
		else
			LogScreenshot("Pass","Clause not added");
	}
	
	public void searchClause(String clauseTitle) throws Exception{
		driver.findElement(By.id("searchStringTxtBox")).sendKeys(clauseTitle);
		findElement(By.id("searchButton"),"Go button").click();
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

}
