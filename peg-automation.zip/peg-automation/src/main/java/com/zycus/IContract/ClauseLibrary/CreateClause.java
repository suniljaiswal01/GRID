package com.zycus.IContract.ClauseLibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iContract_CommonFunctions;

public class CreateClause extends iContract_CommonFunctions {

	private static By pgHead = By.xpath("//div[@id='dialog-confirm']//span[contains(text(),'"+getLanguageProperty("Create Clause")+"')]");
	//private String clauseTitle = "AutoClause_"+generateNo();
	private String clauseCategory = null;
	private String assocBaseType = null;
	private String language = null;
	//private String clauseDesc = clauseTitle+"_desc";
	private String clauseText = "Some string in the clause text";
	private String reviewerName=null;


	public CreateClause(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public CreateClause(WebDriver driver, ExtentTest logger, String clauseCategory, String reviewerName, String associatedBaseType, String language) {
		super(driver, logger);
		this.reviewerName = reviewerName;
		this.clauseCategory = clauseCategory;
		this.assocBaseType = associatedBaseType;
		this.language = language;
	}
	
	/*public CreateClause(WebDriver driver, ExtentTest logger, String clauseTitle, String clauseCategory,
			String assocBaseType, String language, String clauseText) {
		super(driver, logger);
		//this.driver = driver;
		//this.logger = logger;
		this.clauseTitle = clauseTitle;
		this.clauseCategory = clauseCategory;
		this.assocBaseType = assocBaseType;
		//this.language = language;
		this.clauseText = clauseText;
	}*/

	public String createClause() throws Exception {
		
		String newClauseTitle= null;
		String clauseTitle = "AutoClause_"+generateNo();
		waitUntilVisibilityOfElement(By.id("clause-grid"));
		
		WebElement addClause = driver.findElement(By.id("newClause"));
		clickElement(addClause);
		waitUntilVisibilityOfElement(By.id("addClauseFm"));
		String clauseDesc = clauseTitle+"_desc";
		setInput(By.id("clauseTitle_"), clauseTitle);
		clickElement(By.xpath("//select[@id='clauseCategory_']/option[@value='" + clauseCategory + "']"));
		selectDropdownChkBx("basetypeSearchBx", assocBaseType);
		try{
			findElement(By.xpath("//select[@id='language_']/option[@title='" + language + "']")).click();
		}catch(Exception e){}
		driver.findElement(By.id("description_")).sendKeys(clauseDesc);
		// Add code to enter Clause text
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1500);
		WebElement clauseTxtFrame = driver.findElement(By.xpath("//div[@id='cke_clauseText_']//iframe"));
		driver.switchTo().frame(clauseTxtFrame);
		driver.findElement(By.tagName("body")).sendKeys(clauseText);
		addReviewers(reviewerName);
		findElement(By.xpath("//input[@title='"+getLanguageProperty("Save and Activate")+"']")).click();
		waitUntilVisibilityOfElement(By.xpath("//div[@id='jqi'][div/h1[text()='"+getLanguageProperty("Success")+"']]"));
		LogScreenshot("pass","Clause Created");
		findElement(By.xpath("//button[text()='"+getLanguageProperty("OK")+"']"),"OK button").click();
		waitUntilVisibilityOfElement(By.id("clause-grid"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		filterByText("Clause Title", clauseTitle);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		if(driver.findElements(By.xpath("//table[@id='clause-grid']/tbody/tr[td[span[contains(text(),'"+clauseTitle+"')]]]/td[span[contains(text(),'"+getLanguageProperty("Active")+"')]]")).size()>0) {
			LogScreenshot("pass","Clause : "+clauseTitle+" Created and Activated" );
			newClauseTitle= clauseTitle;
		}else {
			LogScreenshot("pass","Clause : "+clauseTitle+" not Created");
		}
	
		return newClauseTitle;
		//waitUntilVisibilityOfElement(ClauseDetails.clauseDetailsHeader);
		//findElement(ClauseDetails.backToClauseListing).click();
	}
	
	private void selectDropdownChkBx(String txtInputObjId, String checkBxLabel) throws Exception{
		findElement(By.xpath("//input[@id='" + txtInputObjId + "']/following-sibling::span")).click();
		driver.findElement(By.id("selectAllBaseType")).click();
		
		/*findElement(By.xpath("//input[@id='" + txtInputObjId + "']/parent::div//li[contains(text(),'" + checkBxLabel+ "')]/input[@type='checkbox']")).click();
		findElement(By.xpath("//input[@id='" + txtInputObjId + "']/following-sibling::span")).click();*/
	}
	
	public void addReviewers(String reviewerName) throws Exception{
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(1500);
		driver.switchTo().defaultContent();
		String reviewerEmailId = getUserEmail(getClassName());
		driver.findElement(By.xpath("//table[@id='clause-reviewer-listing']//input[@type='text']")).click();
		driver.findElement(By.xpath("//table[@id='clause-reviewer-listing']//input[@type='text']")).sendKeys(reviewerEmailId);
		Thread.sleep(5000);
//		driver.findElement(By.xpath("//table[@id='clause-reviewer-listing']//input[@type='text']")).click();
		if(driver.findElements(By.xpath("//ul[@id='reviewerList' and not(contains(@class,'hidden'))]")).size()>0){
			WebElement objReviewer = driver.findElement(By.xpath("//ul[@id='reviewerList']/li[option[@email='"+reviewerEmailId+"']]"));
			//js.executeScript("arguments[0].click();", objReviewer);
			Thread.sleep(2500);
			objReviewer.click();
			String reviewerEmail = driver.findElement(By.xpath("//ul[@id='reviewerList']/li/option[@email='"+reviewerEmailId+"']")).getAttribute("email");
			if(driver.findElement(By.xpath("//table[@id='clause-reviewer-listing']//td[3]")).getText().trim().equals(reviewerEmail))
				LogScreenshot("pass", "Reviewer Added to the Cluase");
		}else{
			LogScreenshot("pass", "Reviewer "+ reviewerName + "not displayed to add to the clause");
			throw new Exception();
		}
	}
	
	
	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

}
