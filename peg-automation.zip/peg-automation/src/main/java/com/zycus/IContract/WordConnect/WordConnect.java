package com.zycus.IContract.WordConnect;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iContract_CommonFunctions;

public class WordConnect extends iContract_CommonFunctions {


	public WordConnect(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	public void setOOOAssignment() throws Exception{	
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.xpath("//div[@id='oooAssignmentPopup'][contains(@style,'block')]"));
		findElement(By.id("toUserSearchBar")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@id='toUserList'][contains(@style,'block')][1]"));
		String assignedToUser= findElement(By.xpath("//div[@id='toUserList'][contains(@style,'block')][1]/span")).getAttribute("title");
		findElement(By.xpath("//div[@id='toUserList'][contains(@style,'block')][1]/span")).click();
		selectRecentDate("notifyFromDate");
		selectFutureDate("notifyToDate");
		findElement(By.id("userOOOAssignmentComments")).sendKeys("OOO Comments");
		findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Save")+"']")).click();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h1[@class='jqititle'][text()='"+getLanguageProperty("Success")+"']")).size()>0) {
			clickElement(By.xpath("//button[@class='jqidefaultbutton'][text()='"+getLanguageProperty("OK")+"']"));
		}

	}

	public void verifyOOOAssignmentPage() throws Exception{	
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));	
		waitUntilVisibilityOfElement(By.xpath("//div[@id='oooAssignmentPopup'][contains(@style,'block')]"));
		if(driver.findElements(By.xpath("//span[@class='ui-dialog-title'][text()='"+getLanguageProperty("Out of Office Assignment")+"']")).size()>0) 
			LogScreenshot("PASS","OOO Assignment popup is displayed successfully");
		else
			LogScreenshot("FAIL","OOO Assignment popup is not displayed");			
		findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Cancel")+"']")).click();
	}


	public void verifySentMailsPage() throws Exception{	
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));	
		if(driver.findElements(By.xpath("//h3[text()='"+getLanguageProperty("Emails")+"']")).size()>0) {
			if(driver.findElements(By.id("ViewSentMailGridDiv")).size()>0) 
				LogScreenshot("PASS","View Sent Mails Grid is displayed successfully");
			else
				LogScreenshot("FAIL","View Sent Mails Grid is not displayed");			
		}
	}


	public boolean wordConnectConfig() throws Exception{	
		boolean flag=false;
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));	
		Thread.sleep(3000);
		if(driver.findElement(By.id("wordConnectConfigurationPopup")).isDisplayed()) {
			LogScreenshot("PASS","Wordconnect Configuration popup is displayed successfully");
			Thread.sleep(2000);
			findElement(By.xpath("//input[@value='"+getLanguageProperty("Download")+"']  ")).click();
			String filePath = getDownloadFilePath(); 
			Thread.sleep(5000);
			if(checkFileExists(filePath, "WordConnectSetup", "zip")){
				flag=true;	
			}

			findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Save")+"']")).click();
			if(driver.findElements(By.xpath("//h1[@class='jqititle'][text()='"+getLanguageProperty("Success")+"']")).size()>0) {
				LogScreenshot("PASS","Success confirmation popup displayed");
				clickElement(By.xpath("//button[@class='jqidefaultbutton'][text()='"+getLanguageProperty("OK")+"']"));
				LogScreenshot("PASS","Configuration is saved successfully");
			}
		}else
			LogScreenshot("fail","Wordconnect Configuration popup is not displayed");
	
		return flag;


	}


	public boolean masterDataPage() throws Exception{	
		boolean status=false;
		SoftAssert softassert= new SoftAssert();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));	
		if(driver.findElements(By.xpath("//h2[contains(text(),'"+getLanguageProperty("Master data")+"')]")).size()>0) {
			softassert.assertTrue(driver.findElements(By.xpath("//h2[text()='"+getLanguageProperty("Basic Masters")+"']")).size()>0);	
			softassert.assertTrue(driver.findElements(By.xpath("//h2[text()='"+getLanguageProperty("Custom Masters")+"']")).size()>0);	
			softassert.assertTrue(driver.findElements(By.xpath("//h2[text()='"+getLanguageProperty("Product Masters")+"']")).size()>0);	
			softassert.assertAll();
			LogScreenshot("PASS","All masters are displayed");
			status=true;
		}else {
			LogScreenshot("FAIL","All masters are not displayed");
		}
		return status;
	}


	public void manageContractingPartiesPage() throws Exception{	
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));	
		if(driver.findElements(By.xpath("//h2[text()='Access Denied!']")).size()>0) 
			LogScreenshot("WARNING","User has no access to Manage Contract parties");
	}
}



