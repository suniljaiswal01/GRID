package com.zycus.IContract.Reports;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

//import common.Functions.eInvoice_CommonFunctions;
import common.Reports.Common_ReportDetail;

public class ReportDetail extends Common_ReportDetail {

	//private By reportLabel = By.xpath("//*[@id='reportNameHeader_RMS']/label");

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public ReportDetail(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> shareMyReports
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param reportName
	 * @return result - True/False
	 * @throws Exception
	 */

	public boolean shareMyReports(String reportName, String sharedUserEmail) throws Exception {
		boolean result = false;
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More Option")+"') ]")).click();
			WebElement objShare = findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Share")+"']"));
			js.executeScript("arguments[0].click()", objShare);
			waitUntilVisibilityOfElement(By.id("shareDashList"));
			WebElement userChkBox = driver.findElement(By.xpath(
					"//table[@class='shareListTable_RMS']//div[text()='" + sharedUserEmail + "']/ancestor::tr//input"));
			if (userChkBox.getAttribute("disabled").equals(getLanguageProperty("true"))) {
				findElement(
						By.xpath("(//table[@class='shareListTable_RMS']//div/ancestor::tr//input[not(@disabled)])[1]"))
								.click();
				sharedUserEmail = findElement(By
						.xpath("(//table[@class='shareListTable_RMS']//div/ancestor::tr//input[not(@disabled)])[1]/ancestor::tr/td[3]/div"))
								.getText();
			} else
				userChkBox.click();

			if (driver.findElements(By.xpath("//ul[@id='ulUser']/li[@id='" + sharedUserEmail + "']")).size() > 0) {
				result = clickAndWaitUntilElementAppears(By.id("btnconfirm"), By.xpath("//div[@id='jqi'][div/div[text()='"+getLanguageProperty("Success")+"']]"))?true:false;
				/*
				findElement(By.id("btnconfirm")).click();
				result = findElement(By.xpath("//div[@id='jqi'][div/div[text()='"+getLanguageProperty("Success")+"']]")).isDisplayed() ? true
						: false;*/
				findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Go to report")+"']")).click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> closeReportDetails
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param reportName
	 * @return result - True/False
	 * @throws Exception
	 */

	/*public boolean closeReportDetails() throws Exception {
		boolean result = false;
		try {
			findElement(By.xpath("//div[@id='rightButton_RMS']//input[@title='"+getLanguageProperty("Close")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
*/
	

	public boolean exportReport(String reportName, String exportFormat){
		boolean result = false;
		String filepath=System.getProperty("user.name");
		String filePath = "C:/Users/"+filepath+"/Downloads";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try{
			findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("Export")+"') ]")).click();
			WebElement objExport = findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[@class='export_RMS']/img[contains(@title,'"+exportFormat+"')]"));
			js.executeScript("arguments[0].click()", objExport);
			Thread.sleep(5000);
			//Wait for the file to download
			Thread.sleep(8000);
			String fileExtension = null;
			switch(exportFormat){
			case "CSV":
				fileExtension = "csv";
				break;
			case "Excel":
				fileExtension = "xlsx";
				break;
			case "PDF":
				fileExtension = "pdf";
				break;
			}

			Thread.sleep(5000);
			if(checkFileExists(filePath, reportName, fileExtension))
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	

}
