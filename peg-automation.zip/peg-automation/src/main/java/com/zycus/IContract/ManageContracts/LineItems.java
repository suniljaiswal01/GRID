package com.zycus.IContract.ManageContracts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class LineItems extends eInvoice_CommonFunctions {

	private static By processingLoader = By.xpath("//span[@class='zys-loader-icon']");
	private static By pgHead = By.xpath("//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Line Items")+"']");
	private String itemNo;
	private String desc;
	private String measurementUnit;
	private int qty;
	private String priceType;
	private String currency;
	private float cost;
	private String category;
	private String pricingType;
	//private String copyPricingFrm;
	private float fixedPrice;
	
	@FindBy(how = How.XPATH, using="//div[@id='addLineItemDiv']//button")
	private static WebElement objAddNewLineItemBtn;
	
	/*@FindBy(how = How.XPATH, using="//div[@id='addLineItemDiv']//ul/li/a[text()='"+getLanguageProperty("Create Line Item")+"']")
	private static WebElement objCreateLineItemLink;*/
	private static By objCreateLineItemLink = By.xpath("//div[@id='addLineItemDiv']//ul/li/a[text()='"+getLanguageProperty("Create Line Item")+"']");
	
	@FindBy(how = How.XPATH, using="//div[div[@id='addLineItemPopup']]")
	private static WebElement objAddLineItemPopup;
	
	@FindBy(how = How.ID, using="lineItemNumber")
	private static WebElement objItemNum;
	
	@FindBy(how = How.ID, using="description")
	private static WebElement objDescription;
	
	@FindBy(how = How.ID, using="lineItemQuantity")
	private static WebElement objQuantity;
	
	@FindBy(how = How.ID, using="category")
	private static WebElement objCategory;
	
	@FindBy(how = How.ID, using="lineItemCost")
	private static WebElement objCost;
	
	/*@FindBy(how = How.XPATH, using="//button/span[text()='"+getLanguageProperty("Save")+"']")
	private static WebElement objSave;*/
	private static By objSave = By.xpath("//button/span[text()='"+getLanguageProperty("Save")+"']");
	
	@FindBy(how = How.ID, using="firmFixedPrice")
	private static WebElement objFixedPrice;
	
	@FindBy(how = How.XPATH, using="//div[@class='//span[@class='zys-loader-icon']']")
	private static WebElement objProcessingLoader;
	
	@FindBy(how = How.XPATH, using="//div[@class='blockUI blockOverlay']")
	private static WebElement objOverlayLoader;

	public LineItems(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		PageFactory.initElements(driver, this);
		CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
        String[][] abc = (String[][]) objFunctions.dataProvider("LineItem", Datasheet_iContract);
        this.itemNo = abc[0][0];
		this.desc = abc[0][1];
		this.measurementUnit = abc[0][2];
		this.qty = Integer.parseInt(abc[0][3]);
		this.category = abc[0][4];
		this.priceType = abc[0][5];
		this.currency = abc[0][6];
		this.cost = Float.parseFloat(abc[0][7]);
		this.pricingType = abc[0][8];
		this.fixedPrice = Float.parseFloat(abc[0][9]);
	}

	public LineItems(WebDriver driver, ExtentTest logger, String itemNo, String desc, String measuremenUnit, int qty,
			String priceType, String currency, float cost) throws Exception {
		super(driver, logger);
		PageFactory.initElements(driver, this);
		CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_iContract = System.getProperty("user.dir")
                     + configurationProperties.getProperty("Datasheet_iContract");
        String[][] abc = (String[][]) objFunctions.dataProvider("LineItem", Datasheet_iContract);
        this.itemNo = abc[0][0];
		this.desc = abc[0][1];
		this.measurementUnit = abc[0][2];
		this.qty = Integer.parseInt(abc[0][3]);
		this.category = abc[0][4];
		this.priceType = abc[0][5];
		this.currency = abc[0][6];
		this.cost = Float.parseFloat(abc[0][7]);
		this.pricingType = abc[0][8];
		this.fixedPrice = Float.parseFloat(abc[0][9]);
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	public boolean createLineItem() {
		boolean result = false;
		try {
			findElement(By.xpath("//div[@id='addLineItemDiv']//button")).click();
			//objAddNewLineItemBtn.click();
			//clickAndWaitUntilLoaderDisappears(objCreateLineItemLink, processingLoader);
			WebElement createLineItemLink = driver.findElement(By.xpath("//div[@id='addLineItemDiv']//ul/li/a[text()='"+getLanguageProperty("Create Line Item")+"']"));
			clickAndWaitUntilLoaderDisappears(createLineItemLink, processingLoader);
			waitUntilVisibilityOfElement(By.xpath("//div[div[@id='addLineItemPopup']]"));
			addLineItem();
			LogScreenshot("Pass","Line Item added");
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Reason for failure : "+e.getMessage());
		}
		return result;
	}


	private boolean addLineItem() {
		boolean result = false;
		try {
			int existingLineItems = driver
					.findElements(By.xpath("//table[@id='lineItems-grid']/tbody/tr[contains(@class,'dataRow')]"))
					.size();

			// Line Item Information
			objItemNum.sendKeys(itemNo);
			objDescription.sendKeys(desc);
			findElement(By.xpath("//select[@id='uomId']/option[text()='" + measurementUnit + "']")).click();;
			objQuantity.sendKeys(String.valueOf(qty));
			//objCategory.sendKeys(category);
			findElement(By.xpath("//select[@id='priceType']/option[text()='" + priceType + "']")).click();;
			findElement(By.xpath("//select[@id='currency']/option[@currencyname='" + currency + "']")).click();;
			objCost.sendKeys(String.valueOf(cost));

			// Line Item Pricing
			findElement(By.xpath("//select[@id='pricingTypeId']/option[text()='" + pricingType + "']")).click();;
			//findElement(By.xpath("//select[@id='lineItemCopyId']/option[text()='" + copyPricingFrm + "']")).click();;
			objFixedPrice.sendKeys(String.valueOf(fixedPrice));
			clickElement(objSave);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(3000);
			//clickAndWaitUntilLoaderDisappears(objSave, objOverlayLoader);
			int lineItems = driver
					.findElements(By.xpath("//table[@id='lineItems-grid']/tbody/tr[contains(@class,'dataRow')]"))
					.size();
			if (lineItems == existingLineItems + 1)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
