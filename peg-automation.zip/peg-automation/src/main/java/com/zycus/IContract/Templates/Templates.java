package com.zycus.IContract.Templates;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.iContract_CommonFunctions;

public class Templates extends iContract_CommonFunctions {

	private static By filterBtnXpath = By.xpath(
			"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]//a[text()='"+getLanguageProperty("Filter")+"'][ancestor::div[@aria-hidden='false']]");
	private static By sourceXpath = By.xpath("//table[@id='TemplateGridImpl-grid']/tbody//td[2]/span");
	private static By statusXpath = By.xpath("//table[@id='TemplateGridImpl-grid']/tbody//td[6]/span");

	public Templates(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/*
	 * public boolean createTemplate() { boolean result = false; try {
	 * findElement(By.xpath("//input[@name='createTemplate']")).click();
	 * CreateTemplate objCreateTemplate = new CreateTemplate(driver, logger);
	 * if(objCreateTemplate.getPgHead()!=null) result= true; } catch (Exception
	 * e) { e.printStackTrace(); } return result; }
	 */

	/*public boolean createTemplate(CreateTemplate objCreateTemplate) {
		boolean result = false;
		try {
			findElement(By.xpath("//input[@name='createTemplate']")).click();
			if (objCreateTemplate.getPgHead() != null)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	/*public boolean createTemplate() {
		boolean result = false;
		try {
			findElement(By.xpath("//input[@name='createTemplate']")).click();
			CreateTemplate objCreateTemplate = new CreateTemplate(driver, logger);
			if (objCreateTemplate.getPgHead() != null)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	/*public void createTemplate() throws Exception{
		findElement(By.xpath("//input[@name='createTemplate']"),"+ Create Template button").click();
		CreateTemplate objCreateTemplate = new CreateTemplate(driver, logger);
		if (objCreateTemplate.getPgHead() != null)
			logger.pass("Navigated to 'Create Template' page");
		else
			logger.fail("Unable to navigate to 'Create Template' page");
	}*/

	public String createTemplate(String clauseTitle) throws Exception{
		String templateName = null;
		String newTemplateName = null;
		findElement(By.xpath("//input[@name='createTemplate']"),"+ Create Template button").click();
		CreateTemplate objCreateTemplate = new CreateTemplate(driver, logger);
		if (objCreateTemplate.getPgHead() != null){
			LogScreenshot("pass","Navigated to 'Create Template' page");
			templateName = objCreateTemplate.enterTemplateDetails();
			String sectionName = objCreateTemplate.addSection();
			objCreateTemplate.addClause(sectionName, clauseTitle);
			//Save and Activate template
			clickElement(By.id("saveAndActivateTemplate"));

			waitUntilVisibilityOfElement(By.id("TemplateGridImpl-grid"));
			
			if(driver.findElements(By.id("TemplateGridImpl-grid")).size()>0) {
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				
				filterByText("Template No. - Name", templateName);
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
				if(driver.findElements(By.xpath("//table[@id='TemplateGridImpl-grid']/tbody/tr[td[span[contains(text(),'"+templateName+"')]]]/td[span[contains(text(),'"+getLanguageProperty("Active")+"')]]")).size()>0) {
					LogScreenshot("pass","Template : "+templateName+" Created and Activated" );
					newTemplateName= templateName;
				}else {
					LogScreenshot("fail","Template : "+templateName+" not Created");
				}
			}else {
				naivgateToTemplateGrid();
			}
			

		}else
			LogScreenshot("fail","Unable to navigate to 'Create Template' page");
		return templateName;
	}

	private void naivgateToTemplateGrid() throws Exception {
		
		LogScreenshot("warning","Page Should be navigated to Template Grid Page after clicking Save and Activate button .Incident already raised : 01275553");
		driver.findElement(By.xpath("//a[@title='"+getLanguageProperty("Back to Template Listing")+"']")).click();
		Thread.sleep(3000);
		clickElement(By.id("jqi_state0_buttonYes"));
		waitUntilVisibilityOfElement(By.id("TemplateGridImpl-grid"));
		
	}

	public String getFirstTemplateFromList(){
		return driver.findElement(By.xpath("//table[@id='TemplateGridImpl-grid']/tbody/tr[1]/td[1]/span")).getText();
	}

	/*public boolean filterByTemplateNum(String templateNumOrName) {
		boolean result = false;
		try {
			result = filterByText("Template No. - Name", templateNumOrName) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	public void filterByTemplateNum(String templateNumOrName) throws Exception{
		filterByText("Template No. - Name", templateNumOrName);
	}

	/*public boolean filterByContractType(String contractType) {
		boolean result = false;
		try {
			result = filterByText("Contract Type", contractType) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	public void filterByContractType(String contractType) throws Exception{
		filterByText("Contract Type", contractType);
	}

	/*public boolean filterBySubType(String subType) {
		boolean result = false;
		try {
			result = filterByText("Sub Type", subType) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	public void filterBySubType(String subType) throws Exception {
		filterByText("Sub Type", subType);
	}

	/*public boolean filterBySource(String source) {
		boolean result = false;
		try {
			result = filterByChkbox(source, sourceXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	public void filterBySource(String source) throws Exception {
		filterByChkbox(source, sourceXpath);
	}

	/*public boolean filterByStatus(String status) {
		boolean result = false;
		try {
			result = filterByChkbox(status, statusXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/

	public boolean filterByStatus(String status) throws Exception {
		return filterByChkbox(status, statusXpath);
	}

	/**
	 * <b>Function:</b> filterByText
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fieldName
	 * @param searchValue
	 * @return result - True/False
	 */


	public boolean filterByText(String fieldName, String searchValue) {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			driver.findElement(By.id("clearAllFilters")).click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(2000);
			int intColNo = getColNum_IContract(fieldName);
			searchAndWaitUntilLoaderDisappears(By.xpath("//table[@id='TemplateGridImpl-grid']/thead/tr[2]/th[" + intColNo + "]//input"), searchValue);
			Thread.sleep(3000);
			List<WebElement> objfilteredTxtList = driver
					.findElements(By.xpath("//table[@id='TemplateGridImpl-grid']/tbody//td[" + intColNo + "]"));
			for (WebElement obj : objfilteredTxtList) {
				if (obj.getText().contains(searchValue))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * -------------------------------------------------------------------------
	 * -------- Function : filterByChkbox
	 * 
	 * @param checkBoxLbl
	 *            --------------------------------------------------------------
	 *            -------------------
	 * @throws Exception
	 */

	public boolean filterByChkbox(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			clickAndWaitUntilLoaderDisappears(filterBtnXpath);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(checkBoxLbl))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}


	public void selectActionTemplate(String action) throws Exception {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement actionBtn= findElement(By.xpath("(//table[@id='TemplateGridImpl-grid']//tr[@class='dataRow filterGridTblTd']//div/a[text()='"+getLanguageProperty("Actions")+"'])[1]"));
			clickElement(actionBtn);
			LogScreenshot("INFO","Clicked on Actions");
			Thread.sleep(5000);
			waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
			if(actionBtn.findElements(By.xpath(".//..//ul/li/a[contains(@title,'" + action + "')]")).size()>0) {
				clickElement(actionBtn.findElement(By.xpath(".//..//ul/li/a[contains(@title,'"+action+"')]")));
				LogScreenshot("PASS","Clicked on "+action);
			}else {
				LogScreenshot("warning",action+" Action not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String viewEditTemplate() throws Exception {
		
		findElement(By.id("zys-sequential-tab-step1"),"Template Details tab").click();
		String templateNumber= driver.findElement(By.id("templateNo")).getAttribute("value");
		String templatetitle= driver.findElement(By.id("templateTitle")).getAttribute("value");
		findElement(By.id("templateNo"),"Template Number").clear();
		String templateEdited=templateNumber+"_edited";
		String templateNew= templateEdited+" - "+templatetitle;
		findElement(By.id("templateNo"),"Template Number").sendKeys(templateEdited);
		findElement(By.id("templateDescription"),"Template Description").clear();
		findElement(By.id("templateDescription"),"Template Description").sendKeys(templateNumber+" Description");
		LogScreenshot("INFO","Template Number updated, Template Description added");
		findElement(By.id("saveAndContinue"),"Continue Button").click();
		LogScreenshot("PASS","Clicked on Save and Continue");
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		findElement(By.id("saveTemplate"),"Save Button").click();
		
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilVisibilityOfElement(By.id("TemplateGridImpl-grid"));
		if(driver.findElements(By.id("TemplateGridImpl-grid")).size()>0) {
			LogScreenshot("PASS","Updated templated is saved");
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		}else {
			naivgateToTemplateGrid();
		}

		return templatetitle;
	}

	public void deactivateActivateTemplate(String templateEdited, String activationStatus) throws Exception {	
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		Thread.sleep(30000);
		if(driver.findElements(By.xpath("//table[@id='TemplateGridImpl-grid']//tr[td/span[contains(@title,'"+templateEdited+"')]]//td/span[text()='Inactive'] | span[text()='"+activationStatus+"']")).size()>0) {
			LogScreenshot("PASS","Template is "+activationStatus);
		}else {
			LogScreenshot("warning","Template is not "+activationStatus);
		}

	}

	public void deleteTemplate() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		if(driver.findElements(By.xpath("//div[@class='zys-popup-title jqicontainer']/h1[text()='"+getLanguageProperty("Confirm")+"']")).size()>0) {
			LogScreenshot("PASS","Confirmation popup is displayed");
			js.executeScript("arguments[0].click()", driver.findElement(By.id("jqi_state0_buttonYes")));
			LogScreenshot("PASS","Template is deleted successfully");
		}else {
			LogScreenshot("WARNING","Confirmation popup is not displayed");
		}

	}

	public boolean downloadTemplate(String templateEdited) throws Exception {
		boolean result=false;
		try {
			String filePath = getDownloadFilePath(); 
			Thread.sleep(5000);
			if(checkFileExists(filePath, templateEdited, "docx"))
				result = true;		
		}catch(Exception e){
			e.printStackTrace();
		}

		return result;
	}

	public void uploadTemplate() throws Exception {

		By externalTemplate = By.id("externalButton");
		clickElement(externalTemplate);

		waitUntilVisibilityOfElement(By.id("externalTemplateContainer"));

		WebElement uploadBtn = driver.findElement(By.xpath("//div[@id='attachFile']//input[@type='file']"));
		uploadBtn.sendKeys(ConfigurationProperties.getInstance().getProperty("upload_template"));

		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		LogScreenshot("pass","Template Uploaded");

		By continueBtn = By.id("extractClauses");
		clickElement(continueBtn);

		waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='processLoadingDiv']"));	

		By popUpContainer = By.xpath("//div[contains(@class,'zys-popup-container')]");	
		
		if(driver.findElements(popUpContainer).size()>0) {
			LogScreenshot("info","Pop-up Displayed");
			By yesBtn = By.id("jqi_state0_buttonYes");
			clickElement(yesBtn);
		}
	
	}

}
