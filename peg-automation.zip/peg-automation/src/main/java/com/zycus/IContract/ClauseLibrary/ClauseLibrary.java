package com.zycus.IContract.ClauseLibrary;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.iContract_CommonFunctions;

public class ClauseLibrary extends iContract_CommonFunctions {

	static By clauseLibraryPgHeader = By.xpath("//h3[text()='"+getLanguageProperty("Clause Library")+"']");
	private static By filterBtnXpath = By.xpath(
			"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]//a[text()='"+getLanguageProperty("Filter")+"'][ancestor::div[@aria-hidden='false']]");
	private static By sourceXpath = By.xpath("//table[@id='clause-grid']/tbody//td[2]/span");
	private static By statusXpath = By.xpath("//table[@id='clause-grid']/tbody//td[7]/span");
	private static By alternateXpath = By.xpath("//table[@id='clause-grid']/tbody//td[4]/span");
	private static By fallbackXpath = By.xpath("//table[@id='clause-grid']/tbody//td[5]/span");

	public ClauseLibrary(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}
	
	public boolean addAlternateClause(String clauseName){
		boolean result = false;
		try{
			clickElement(By.id("clearAllFilters"));
			waitUntilVisibilityOfElement(By.id("clause-grid"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
			filterByClauseTitle(clauseName);
			String alternateClauseTxt= "AlternateClause"+generateNo();
			findElement(By.xpath("//table[@id='clause-grid']/tbody/tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")).click();
			findElement(By.id("editReqn")).click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Add Alternate Clause")+"']]"));
			WebElement altClauseTxtFrame = driver.findElement(By.xpath("//div[@id='cke_clauseText_alt_']//iframe"));
			driver.switchTo().frame(altClauseTxtFrame);
			driver.findElement(By.tagName("body")).sendKeys(alternateClauseTxt);
			driver.switchTo().defaultContent();
			clickElement(By.xpath("//button[span[text()='"+getLanguageProperty("Save and Activate")+"']]"));
			if(driver.findElements(By.xpath("//div[@class='alternateClause']//div[@class='clauseText liveEditable']//span[@id='clauseHtml' and text()='"+alternateClauseTxt+"']")).size()>0) {
				LogScreenshot("pass","Alternate Clause: "+alternateClauseTxt +" Added in clause: "+clauseName);
				result = true;
			}else {
				LogScreenshot("pass","Alternate Clause: "+alternateClauseTxt +" not Added in clause: "+clauseName);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean addFallbackClause(String clauseName){
		boolean result = false;
		try{
			clickElement(By.id("clearAllFilters"));
			waitUntilVisibilityOfElement(By.id("clause-grid"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
			filterByClauseTitle(clauseName);
			String fallbackClauseTxt= "FallBackClause"+generateNo();
			clickElement(By.xpath("//table[@id='clause-grid']/tbody/tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
			clickElement(By.xpath("//a[@title='"+getLanguageProperty("Add Fallback Clause")+"']"));
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Add Fallback Clause")+"']]"));
			WebElement fallbckClauseTxtFrame = driver.findElement(By.xpath("//div[@id='cke_clauseText_alt_']//iframe"));
			driver.switchTo().frame(fallbckClauseTxtFrame);
			driver.findElement(By.tagName("body")).sendKeys(fallbackClauseTxt);
			driver.switchTo().defaultContent();
			clickElement(By.xpath("//button[span[text()='"+getLanguageProperty("Save and Activate")+"']]"));
			if(driver.findElements(By.xpath("//div[@class='alternateClause']//div[@class='clauseText liveEditable']//span[@id='clauseHtml' and text()='"+fallbackClauseTxt+"']")).size()>0) {
				LogScreenshot("pass","Fallback Clause: "+fallbackClauseTxt +" Added in clause: "+clauseName);
				result = true;
			}else
				LogScreenshot("pass","Fallback Clause: "+fallbackClauseTxt +" not Added in clause: "+clauseName);
				
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	
	/*public boolean addClause() {
		boolean result = false;
		try {
			findElement(By.xpath("//input[@id='newClause']")).click();
			CreateClause objCreateClause = new CreateClause(driver, logger);
			if (objCreateClause.getPgHead() != null)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/
	
	/*public boolean addClause(CreateClause objCreateClause) {
		boolean result = false;
		try {
			findElement(By.xpath("//input[@id='newClause']")).click();
			if (objCreateClause.getPgHead() != null){
				logger.pass("Navigated to 'Create Clause' page");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}*/
	
	public String addClause(String clauseCategory, String reviewerName, String associatedBaseType, String language) throws Exception{
		String newClause = null;
		CreateClause objCreateClause = new CreateClause(driver, logger, clauseCategory,  reviewerName, associatedBaseType, language);
		if (objCreateClause.getPgHead() != null){
			LogScreenshot("Pass","Navigated to 'Create Clause' page");
			newClause=objCreateClause.createClause();
			waitUntilVisibilityOfElement(clauseLibraryPgHeader);
		}
		return newClause;
	}
	
	public String getFirstClauseFromList() throws Exception{
		return driver.findElement(By.xpath("//table[@id='clause-grid']/tbody/tr[1]/td[1]/span")).getText();
	}

	public boolean filterByClauseTitle(String clauseTitle) {
		return filterByText("Clause Title", clauseTitle);
	}

	public boolean filterByClauseCategory(String category) {
		return filterByText("Clause Category", category);
	}

	public boolean filterBySource(String source) throws Exception {
		return filterByChkbox(source, sourceXpath);
	}

	public boolean filterByAlternate(String alternateCategory) throws Exception {
		return filterByChkbox1(alternateCategory, alternateXpath);
	}

	public boolean filterByFallback(String fallbackCategory) throws Exception {
		return filterByChkbox1(fallbackCategory, fallbackXpath);
	}

	public boolean filterByStatus(String status) throws Exception {
		return filterByChkbox(status, statusXpath);
	}

	/**
	 * <b>Function:</b> filterByText
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fieldName
	 * @param searchValue
	 * @return result - True/False
	 */

	public boolean filterByText(String fieldName, String searchValue) {
		boolean result = false;
		try {
			int intColNo = getColNum(fieldName);
			searchAndWaitUntilLoaderDisappears(By.xpath("//table[contains(@class,'newFilterTableGrid')]/thead/tr[2]/th[" + intColNo + "]//input"), searchValue);
			Thread.sleep(3000);
			List<WebElement> objfilteredTxtList = driver
					.findElements(By.xpath("//table[@id='TemplateGridImpl-grid']/tbody//td[" + intColNo + "]"));
			for (WebElement obj : objfilteredTxtList) {
				if (obj.getText().contains(searchValue))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	

	/**
	 * -------------------------------------------------------------------------
	 * -------- Function : filterByChkbox
	 * 
	 * @param checkBoxLbl
	 *            --------------------------------------------------------------
	 *            -------------------
	 * @throws Exception
	 */

	/*public boolean filterByChkbox(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			findElement(filterBtnXpath).click();
			waitUntilInvisibilityOfElement(processingLoader);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(checkBoxLbl))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}*/
	
	public boolean filterByChkbox(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			clickAndWaitUntilLoaderDisappears(filterBtnXpath);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(checkBoxLbl))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}

	/*public boolean filterByChkbox1(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			findElement(filterBtnXpath).click();
			waitUntilInvisibilityOfElement(processingLoader);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (checkBoxLbl.contains("without")) {
					if (obj.getText().equals(getLanguageProperty("Add")))
						result = true;
					else {
						result = false;
						break;
					}
				}else
					if (!obj.getText().equals(getLanguageProperty("Add")))
						result = true;
					else {
						result = false;
						break;
					}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}*/
	
	
	public boolean filterByChkbox1(String checkBoxLbl, By displayedLabel) throws Exception {
		boolean result = false;
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(
					"var objContainer = document.evaluate(\"//div[contains(@class,'typeFilterContent') and contains(@style,'block')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
							+ "document.evaluate(\"//input[following-sibling::label[contains(.,'" + checkBoxLbl
							+ "')]]\", objContainer, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
			clickAndWaitUntilLoaderDisappears(filterBtnXpath);
			List<WebElement> objfilteredList = driver.findElements(displayedLabel);
			for (WebElement obj : objfilteredList) {
				if (checkBoxLbl.contains("without")) {
					if (obj.getText().equals(getLanguageProperty("Add")))
						result = true;
					else {
						result = false;
						break;
					}
				}else
					if (!obj.getText().equals(getLanguageProperty("Add")))
						result = true;
					else {
						result = false;
						break;
					}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}
	
	public boolean workflowSettings() throws Exception{
		boolean result = false;
		WebElement objSkipWorkflow = driver.findElement(By.xpath("//input[@id='skippingEnable']/../div[contains(@class,'text-off-btn')]"));
		flipSwitch(objSkipWorkflow);
		return result;
	}
	
	private void flipSwitch(WebElement obj){
		Random rnd = new Random();
		int temp = 0;
		try {
			temp = rnd.nextInt(1);
			String objClass = obj.getAttribute("class");
			if((temp==0)&&(!objClass.contains(" on"))||(temp==1)&&(objClass.contains(" on")))
				obj.click();				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
