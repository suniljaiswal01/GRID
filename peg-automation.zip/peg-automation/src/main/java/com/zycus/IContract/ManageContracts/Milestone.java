package com.zycus.IContract.ManageContracts;


import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class Milestone extends eInvoice_CommonFunctions {

	private String milestoneDueDt;
	private String verifierIntOrExt;
	private String verifierName;
	private String verifierEmail;
	
	public Milestone(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		try{
			CommonFunctions1 objFunctions = new CommonFunctions1();
	        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
	        String Datasheet_iContract = configurationProperties.getProperty("Datasheet_iContract");
	        String[][] abc = (String[][]) objFunctions.dataProvider("MilestoneDetails", Datasheet_iContract);
	        this.milestoneDueDt = abc[0][0];
	        this.verifierIntOrExt = abc[0][1]; 
	        this.verifierName = abc[0][2];
	        this.verifierEmail = abc[0][3];
		}catch(Exception e){
			e.printStackTrace();
			logger.fail( "Issue while fetching data for Milestone page");
		}
	}


	public boolean addMilestone() throws Exception{
		boolean result = false;
		String milestoneTitle = "Milestone_"+generateNo();
		try{
			findElement(By.id("addNewAlert")).click();
			driver.findElement(By.id("milestoneTitle")).sendKeys(milestoneTitle);
			Thread.sleep(2000);
			//findElement(By.xpath("//input[@id='dueDate']/following-sibling::span")).click();
			WebElement objMilestoneDueDt = findElement(By.id("dateIcon"));
			//js.executeScript("arguments[0].click()", objMilestoneDueDt);
			//action.moveToElement(objMilestoneDueDt).click().build().perform();
			driver.findElement(By.id("dueDate")).click();
			Thread.sleep(1000);
			
			
			LocalDateTime a = LocalDateTime.now().plusMonths(3);
			String currDtTime =a.toString(); 
			String tempDt = (currDtTime.split("T"))[0].toString();
			
			String originalStringFormat = "yyyy-MM-dd";
		    String desiredStringFormat = "dd/MM/yyyy";

			SimpleDateFormat readingFormat = new SimpleDateFormat(originalStringFormat);
			SimpleDateFormat outputFormat = new SimpleDateFormat(desiredStringFormat);
   
		     try {
		        Date date1 = readingFormat.parse(tempDt);
		        milestoneDueDt = outputFormat.format(date1);
		        LogScreenshot("Info", "Entering milestone Due date as "+milestoneDueDt );
		     }catch (Exception e) {
		      e.printStackTrace();
		     }
			
			selectDate_v1(milestoneDueDt);
			Thread.sleep(3000);
			//***********************************Not getting added in ZCS RM, hence commenting it*********************
			addMilestoneVerifiers();
			//******************************************************
			LogScreenshot("Pass", "Milestone Details filled");
			WebElement saveBtn =  driver.findElement(By.xpath("//input[contains(@class,'milestoneSave')]"));
			scroll_into_view_element(saveBtn,"Save button");
			saveBtn.click();
			//findElement(By.xpath("//input[contains(@class,'milestoneSave')]"), "Save button").click();
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(10000);
			LogScreenshot("Pass", "Save button clicked");
			if(driver.findElements(By.xpath("//table[@id='milestone-grid']/tbody/tr[1]/td[1]/span[@title='"+milestoneTitle+"']")).size()>0){
				LogScreenshot("Pass", "Milestone Added");
				result = true;
			}else
				LogScreenshot("Fail", "Milestone not Added");
		}catch(Exception e){
			e.printStackTrace();
			LogScreenshot("Fail", "Milestone not Added");
			CreateContract objContract = new CreateContract(driver, logger);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			objContract.navigate_ContractSubTabs("Timeline");
			findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Yes")+"']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
		}
		return result;
	}

	private void addMilestoneVerifiers() throws Exception{
		driver.findElement(By.xpath("//li[span[text()='"+getLanguageProperty("Add Verifiers")+"']]")).click();
		if(verifierIntOrExt.equals(getLanguageProperty("Internal"))){
			findElement(By.id("internalVerifier")).click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Add Milestone Verifiers")+"']]"));
			driver.findElement(By.id("searchBasketGridTextBox")).sendKeys(verifierEmail);
			findElement(By.xpath("//div[@id='updateContractOwnerDiv']//input[@id='searchGoBtn']")).click();
			waitUntilInvisibilityOfElement(processingLoader);
			//String verifierName = driver.findElement(By.xpath("//table[@id='dataGrid']/tbody/tr[1]/td[2]/div/span")).getText();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
			Thread.sleep(2000);
			findElement(By.xpath("//table[@id='dataGrid']/tbody/tr[1]/td[1]/input")).click();
			LogScreenshot("info","Adding Milestone Verifiers");
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Save")+"']]")).click();
		}else{
			findElement(By.id("externalVerifier")).click();
			waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Add Milestone Verifiers")+"']]"));
			driver.findElement(By.id("externalUserName")).sendKeys(verifierName);
			driver.findElement(By.id("externalUserEmail")).sendKeys(verifierEmail);
			findElement(By.xpath("//button[span[text()='"+getLanguageProperty("Add")+"']]")).click();
		}
		Thread.sleep(2500);
		//*******************************Adding Verifiers again in ZCS RM****************************
		//addMilestoneVerifiers();
		//************************************************************************************
		if(driver.findElement(By.xpath("//div[@id='verifiersDiv']//span[@name='verifierName']")).getText().equals(verifierName))
			LogScreenshot("pass", verifierIntOrExt +" added to the Milestone");
		else
			LogScreenshot("info", verifierIntOrExt +" not added to the Milestone");
		
	}
	

}
