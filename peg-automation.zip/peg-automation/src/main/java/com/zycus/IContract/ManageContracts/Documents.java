package com.zycus.IContract.ManageContracts;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.eInvoice_CommonFunctions;

public class Documents extends eInvoice_CommonFunctions {

	private static By pgHead = By.xpath("//span[@id='headerLabel']/following-sibling::h2[text()='"+getLanguageProperty("Line Items")+"']");
	
	@FindBy(how = How.XPATH, using="//div[@id='btnAddDoc']//input")
	private static WebElement addDocumentBtn;
	
	@FindBy(how = How.XPATH, using="//div[div[contains(@id,'zyDevPopup')] and contains(@style,'block')]")
	private static WebElement addDocumentsPopup;
	
	@FindBy(how = How.XPATH, using="//div[@id='zyDevPopup1']//span[@class='newUploadBtn']")
	private static WebElement chooseFilesBtn;
	
	@FindBy(how = How.ID, using="addDocBtnDone")
	private static WebElement doneBtn;
	
	
	@FindBy(how = How.ID, using="addDocBtnDoneEdit")
	private static WebElement editDoneBtn;
	
	public Documents(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		PageFactory.initElements(driver, this);
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}
	
	public void DropFile(File filePath, WebElement target, int offsetX, int offsetY) {
	    if(!filePath.exists())
	        throw new WebDriverException("File not found: " + filePath.toString());

	    //WebDriver driver = ((RemoteWebElement)target).getWrappedDriver();
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    WebDriverWait wait = new WebDriverWait(driver, 30);

	    String JS_DROP_FILE =
	        "var target = arguments[0]," +
	        "    offsetX = arguments[1]," +
	        "    offsetY = arguments[2]," +
	        "    document = target.ownerDocument || document," +
	        "    window = document.defaultView || window;" +
	        "" +
	        "var input = document.createElement('INPUT');" +
	        "input.type = 'file';" +
	        "input.style.display = 'none';" +
	        "input.onchange = function () {" +
	        "  var rect = target.getBoundingClientRect()," +
	        "      x = rect.left + (offsetX || (rect.width >> 1))," +
	        "      y = rect.top + (offsetY || (rect.height >> 1))," +
	        "      dataTransfer = { files: this.files };" +
	        "" +
	        "  ['dragenter', 'dragover', 'drop'].forEach(function (name) {" +
	        "    var evt = document.createEvent('MouseEvent');" +
	        "    evt.initMouseEvent(name, !0, !0, window, 0, 0, 0, x, y, !1, !1, !1, !1, 0, null);" +
	        "    evt.dataTransfer = dataTransfer;" +
	        "    target.dispatchEvent(evt);" +
	        "  });" +
	        "" +
	        "  setTimeout(function () { document.body.removeChild(input); }, 25);" +
	        "};" +
	        "document.body.appendChild(input);" +
	        "return input;";

	    WebElement input =  (WebElement)jse.executeScript(JS_DROP_FILE, target, offsetX, offsetY);
	    input.sendKeys(filePath.getAbsoluteFile().toString());
	    //wait.until(ExpectedConditions.stalenessOf(input));
	}
	
	
	private boolean addDocument(String filePath) throws Exception {
		boolean result = false;
		File f = new File(filePath);
		String fileName = f.getName();
		try {
			addDocumentBtn.click();
			waitUntilVisibilityOfElement(addDocumentsPopup);
			Thread.sleep(5000);
			ConfigurationProperties config = ConfigurationProperties.getInstance();
			try{
				// locate the drop area
				WebElement droparea = driver.findElement(By.id("dropZoneArea"));
	
				// drop the file
				DropFile(new File(filePath), droparea, 0, 0);
				
				Thread.sleep(10000);
				driver.findElement(By.id("fileNameId")).clear();
				driver.findElement(By.id("fileNameId")).sendKeys(String.valueOf(generateNo()));
				LogScreenshot("info","Uploading Document");
				doneBtn.click();
				Thread.sleep(3000);
				clickElement(By.xpath("//div[@id='zys-popup-msg' and text()='Document added successfully']/../../..//button[text()='"+getLanguageProperty("OK")+"']"));
			}catch(Exception e){
				e.printStackTrace();
				LogScreenshot("Fail", "'Add Documents' popup not displayed");
				findElement(By.id("addDocBtnCancel")).click();
				waitUntilInvisibilityOfElement(addDocumentsPopup);
			}
			Thread.sleep(8000);
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'"+getLanguageProperty("Processing")+"')]"));
			//Verify Document uploaded
			if(driver.findElements(By.xpath("//table[@id='dataGrid']/tbody//td[5]/div/span[@title='"+fileName+"']")).size()>0){
				LogScreenshot("Pass", "Document "+ fileName +" upoaded successfully");
				result= true;
			}else
				LogScreenshot("Fail", "No row created in the Grid for the uploaded document "+fileName);
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("Fail", "'Add Documents' popup not displayed");
		}
		return result;
	}
	
	private boolean addDocumentWhileEdit(String filePath) throws Exception {
		boolean result = false;
		File f = new File(filePath);
		String fileName = f.getName();
		try {
			waitUntilVisibilityOfElement(addDocumentsPopup);
			Thread.sleep(5000);
			ConfigurationProperties config = ConfigurationProperties.getInstance();
			try{
				// locate the drop area
				WebElement droparea = driver.findElement(By.id("dropZoneAreaEdit"));
	
				// drop the file
				DropFile(new File(filePath), droparea, 0, 0);
				
				Thread.sleep(10000);
				driver.findElement(By.id("editFileNameId")).clear();
				driver.findElement(By.id("editFileNameId")).sendKeys(String.valueOf(generateNo()));
				LogScreenshot("info","Uploading Document");
				editDoneBtn.click();
				Thread.sleep(3000);
				clickElement(By.xpath("//div[@id='zys-popup-msg' and text()='Document updated Successfully']/../../..//button[text()='"+getLanguageProperty("OK")+"']"));
			}catch(Exception e){
				e.printStackTrace();
				LogScreenshot("Fail", "'Add Documents' popup not displayed");
				findElement(By.id("addDocBtnCancel")).click();
				waitUntilInvisibilityOfElement(addDocumentsPopup);
			}
			Thread.sleep(8000);
			waitUntilInvisibilityOfElement(By.xpath("//p[contains(text(),'Processing')]"));
			//Verify Document uploaded
			if(driver.findElements(By.xpath("//table[@id='dataGrid']/tbody//td[5]/div/span[@title='"+fileName+"']")).size()>0){
				LogScreenshot("Pass", "Document "+ fileName +" upoaded successfully");
				result= true;
			}else
				LogScreenshot("Fail", "No row created in the Grid for the uploaded document "+fileName);
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("Fail", "'Add Documents' popup not displayed");
		}
		return result;
	}
	
	
	public boolean addDocument_ForEnd(String contractTitle) throws Exception {
		boolean result = false;
		String fileDownloadedPath = getDownloadFilePath();
		ConfigurationProperties config = ConfigurationProperties.getInstance();
		try {
			//findElement(By.id("signOffUpload")).click();
			//waitUntilVisibilityOfElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]"));
			System.out.println(fileDownloadedPath +"\\" +contractTitle+".pdf");
			try{
				// locate the drop area
				WebElement droparea = driver.findElement(By.id("attachment"));
	
				// drop the file
				DropFile(new File(fileDownloadedPath +"\\" +contractTitle+".pdf"), droparea, 0, 0);
				
			
			Thread.sleep(6000);
			findElement(By.xpath("//div[@role='dialog'][div/span[text()='"+getLanguageProperty("Upload")+"']]//button[span[text()='"+getLanguageProperty("Upload")+"']]"))
					.click();
			
			}catch(Exception e){
				e.printStackTrace();
				logger.fail("'Add Documents' popup not displayed");
				findElement(By.id("addDocBtnCancel")).click();
				waitUntilInvisibilityOfElement(addDocumentsPopup);
			}
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
			logger.fail("'Add Documents' popup not displayed");
		}
		return result;
	}
	
	public boolean addDocument1(String filePath) throws Exception {
		boolean result = false;
		System.out.println(filePath);
		File f = new File(filePath);
		String fileName = f.getName();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Actions actions = new Actions(driver);
		try {
			clickAndWaitUntilElementAppears(addDocumentBtn, addDocumentsPopup);
			Thread.sleep(3000);
			actions.moveToElement(chooseFilesBtn).click().build().perform();
			//actions.moveToElement(chooseFilesBtn).sendKeys(System.getProperty("user.dir") + config.getProperty("upload_docxfile_path")).build().perform();
			//js.executeScript("arguments[0].focus();", chooseFilesBtn);
			//chooseFilesBtn.sendKeys(filePath);
			uploadFileWithRobot(filePath);
			//Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + Keys.ENTER);
			/*sendKeys(By.xpath("//div[@id='zyDevPopup1']//span[@class='newUploadBtn']"),
					System.getProperty("user.dir") + config.getProperty("upload_docxfile_path"));*/
			Thread.sleep(4000);
			doneBtn.click();
			
			//Verify Document uploaded
			if(driver.findElements(By.xpath("//table[@id='dataGrid']/tbody/tr[1]/td[5]/div/span[@title='"+fileName+"']")).size()>0){
				logger.pass( "Document "+ fileName +" upoaded successfully");
				result= true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.fail("'Add Documents' popup not displayed");
			//findElement(By.xpath("//div[@role='dialog' and div[@id='zyDevPopup1']]//button/span[text()='"+getLanguageProperty("Cancel")+"']")).click();
			findElement(By.id("addDocBtnCancel")).click();
			waitUntilInvisibilityOfElement(addDocumentsPopup);
		}
		return result;
	}

	public boolean selectDocuments(int noOfDocs) {
		boolean result = false;
		String filePath = null;
		boolean fileAdded = false;
		try {
			ConfigurationProperties config = ConfigurationProperties.getInstance();
			
			if(driver.findElements(By.xpath("//table[@id='dataGrid']//span[@id='mandatory']")).size()>0) {
				addDocumentForMandatory();
				
			}
			
			
			for(int i=1; i<=noOfDocs; i++){
				fileAdded = false;
				//String temp = "upload_docxfile"+ String.valueOf(i) +"_path";
				String temp = "DocFile"+ String.valueOf(i);
				filePath = System.getProperty("user.dir") + config.getProperty(temp);
			
				int existingDocs = driver.findElements(By.xpath("//table[@id='dataGrid']/tbody/tr[contains(@class,'dataRow')]")).size();
				
				if (addDocument(filePath)) {
					//Verify if Contractual Document added to the Grid
					int docs = driver.findElements(By.xpath("//table[@id='dataGrid']/tbody/tr[contains(@class,'dataRow')]")).size();
					if (docs == existingDocs + 1)
						fileAdded = true;
				}
			}
			if(fileAdded)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	private void addDocumentForMandatory() throws Exception
	{
		ConfigurationProperties config = ConfigurationProperties.getInstance();
		LogScreenshot("info","Adding Mandatory Document");
		WebElement actionBtn = driver.findElement(By.xpath("//table[@id='dataGrid']//tr[td[contains(text(),'"+getLanguageProperty("undefined")+"')]]/td[last()]"));
		clickElement(actionBtn.findElement(By.xpath(".//a[contains(@class,'actLnk')]")));
		waitUntilVisibilityOfElement(By.xpath("//ul[@class='actBxAll']"));
		LogScreenshot("info","Clicking on Edit Button to add mandatory doucment");
		clickElement(actionBtn.findElement(By.xpath(".//a[text()='"+getLanguageProperty("Edit")+"']")));
		String filepath = config.getProperty("upload_docxfile_path");
		addDocumentWhileEdit(filepath);		
		if(driver.findElements(By.xpath("//table[@id='dataGrid']//tr[td[contains(text(),'"+getLanguageProperty("undefined")+"')]]")).size()==0) {
			LogScreenshot("pass","Mandatory Document added ");
		}
		
	}

	public boolean deleteDocument(String documentName){
		boolean result = false;
		try{
			WebElement actionBtn = driver.findElement(By.xpath("//table[@id='dataGrid']/tbody/tr[td[2][div/span[@title='"+documentName+"']]]/td[last()]"));
			actionBtn.click();
			actionBtn.findElement(By.xpath("//a[text()='"+getLanguageProperty("Delete")+"']")).click();
			findElement(By.xpath("//div[@id='jqi'][div/h1[text()='"+getLanguageProperty("Confirm")+"']]//button[text()='"+getLanguageProperty("Yes")+"']")).click();
			Thread.sleep(1000);
			if(driver.findElements(By.xpath("//table[@id='dataGrid']/tbody/tr/td[2]/div[span[@title='"+documentName+"']]/following-sibling::span[contains(text(),'"+getLanguageProperty("Document Deleted")+"')]")).size()>0)
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	} 
	
	public boolean deleteDocument(){
		boolean result = false;
		try{
			String documentName = driver.findElement(By.xpath("//table[@id='dataGrid']/tbody/tr[1]/td[2]/div/span")).getAttribute("title");
			if(deleteDocument(documentName))
				result = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	} 

}
