package com.zycus.IContract.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import common.Functions.eInvoice_CommonFunctions;

public class ProductVideos extends eInvoice_CommonFunctions {
	
	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public ProductVideos(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> clickCreateWorkflow
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param displayName
	 * @return result - True/False
	 * @throws Exception
	 */

	protected void verifyLatestProductVideo() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor)driver; 
		//Switch to tab 'Self Training Videos'
		String parent = driver.getWindowHandle();
		switchWindowHandles(parent, "Self Training Videos");
		Thread.sleep(2000);
		driver.navigate().refresh();
		findElement(By.xpath("//table[@id='productVideoTab']/tbody/tr[1]//a[1]"), "Product Video link").click();
		waitUntilVisibilityOfElement(By.xpath("//div[@class='modal' and //video]"));
		Thread.sleep(2000);
		js.executeScript("document.getElementById(\"videoPlayer\").play()");
		Thread.sleep(4000);
		js.executeScript("document.getElementById(\"videoPlayer\").pause()");
		Double d  = new Double((double) js.executeScript("return document.getElementById(\"videoPlayer\").currentTime"));
		int timePlayedFor = d.intValue();
		if(timePlayedFor == 4)
			logger.log(Status.PASS, "video played for 4 seconds");
	}

}
