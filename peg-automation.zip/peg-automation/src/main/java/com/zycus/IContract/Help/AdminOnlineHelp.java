package com.zycus.IContract.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class AdminOnlineHelp extends eInvoice_CommonFunctions {

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public AdminOnlineHelp(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * <b>Function:</b> clickCreateWorkflow
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param displayName
	 * @return result - True/False
	 * @throws Exception 
	 * @throws Exception
	 */

	public void verifyOnlineHelpPage() throws Exception {
		//Switch to tab 'Purpose'
		String parent = driver.getWindowHandle();
		/*switchWindowHandles(parent, "Purpose");
		Thread.sleep(2000);*/
		waitForTabToLoad("Admin Online Help", "Purpose");
		WebElement objHelpManualHeader = driver.findElement(By.id("c1headerText"));
		if(objHelpManualHeader.getText().equals("iContract Blue User Guide - Customer Admin"))
			logger.pass("iContract Blue User Guide - Customer Admin header displayed");
		else
			logger.fail("iContract Blue User Guide - Customer Admin header not displayed");
		//Assert.assertEquals(objHelpManualHeader.getText(), "iContract Blue User Guide - Customer Admin");
		WebElement objTopicHeader = driver.findElement(By.xpath("//div[@id='c1topic']/h2/a"));
		//Assert.assertEquals(objTopicHeader.getText(), "Purpose");
		if(objTopicHeader.getText().equals(getLanguageProperty("Purpose")))
			logger.pass("Purpose section displayed");
		else
			logger.fail("Purpose section not displayed");
		driver.close();
		driver.switchTo().window(parent);
		Thread.sleep(2000);
	}

}
