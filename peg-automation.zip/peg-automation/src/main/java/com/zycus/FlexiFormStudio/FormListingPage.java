package com.zycus.FlexiFormStudio;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.Common_ConfigureFlexiForm;
import common.Functions.eInvoice_CommonFunctions;

public class FormListingPage extends eInvoice_CommonFunctions {
	public static String sectionName;

	public FormListingPage(WebDriver driver, ExtentTest logger) {
		super(driver, logger);		
	}

	public boolean createNewFlexiForm(String sectionDesc, String sectionLayout, String fieldDefaulVal, int fieldMaxChar, boolean isFieldMandatory) throws Exception{
		boolean result= false;
		 sectionName ="AutoSection_"+generateNo();
		String fieldType = "Numeric";
		String fieldName = "AutoField";	
		try{
			findElement(By.id("lnkAddForm"),"+ Create New Flexiform button").click();
			Common_ConfigureFlexiForm objForm = new Common_ConfigureFlexiForm(driver, logger, sectionName, fieldType, fieldName);
			objForm.addSection_flexiForm(sectionDesc, sectionLayout);		
			objForm.addfield_FlexiForm(fieldDefaulVal,fieldMaxChar,isFieldMandatory);
			objForm.addConfigureFlexiformHeaderFields(sectionDesc);
			objForm.saveFlexiForm();
			LogScreenshot("Pass","FlexiForm Creation Completed");
			result = true;
		}catch(Exception e){
			LogScreenshot("fail","FlexiForm Creation Failed");
			throw e;
		}
		return result;
	}
}
