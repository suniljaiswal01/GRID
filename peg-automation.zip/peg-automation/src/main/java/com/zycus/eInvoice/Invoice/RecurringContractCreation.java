
package com.zycus.eInvoice.Invoice;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eInvoice.RecurringContracts.ContractList;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class RecurringContractCreation extends eInvoice_CommonFunctions {

	private String searchValue;
	private String contractOwner;	
	private String frequencyNo;
	private String frequency;
	private Date fromDt;
	private String supplierName;
	private String paymentTerm;
	private String currency_value;
	private String purchaseType;
	private String company;
	private String businessUnit;
	private String location;
	private String costCenter;
	private String supplierSelectCategory;
	private String headerLevelTaxType;
	private String buyer;
	private String requester;
	private String notes;
	private String description;
	private String headLvlTaxRate;
	SoftAssert softAssert= new SoftAssert();

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public RecurringContractCreation(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = 
				configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("RecurringContractDetails", Datasheet_eInvoice);
		this.supplierSelectCategory = abc[0][0];
		this.supplierName = abc[0][1];
		this.paymentTerm = abc[0][2];
		this.currency_value = abc[0][3];
		this.contractOwner = abc[0][4];
		this.purchaseType = abc[0][5];
		this.company = abc[0][6];
		this.businessUnit = abc[0][7];
		this.location = abc[0][8];
		this.costCenter = abc[0][9];
		this.headerLevelTaxType = abc[0][10];
		this.buyer = abc[0][11];
		this.requester = abc[0][12];
		this.notes= abc[0][13];
		this.description= abc[0][14];
		this.headLvlTaxRate= abc[0][15];


	}

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * @param searchValue
	 * @param paymentTerms
	 * @param contractName
	 * @param contractOwner
	 * @param autoInvoiceNo
	 * @param purchaseType
	 * @param frequencyNo
	 * @param frequency
	 * @param fromDt
	 * @param weekDay
	 * 
	 */

	public RecurringContractCreation( WebDriver driver, ExtentTest logger,String supplierSelectCategory, String supplierName,String paymentTerm, 
			String currency_value,String contractOwner,String purchaseType,String company,String businessUnit, String location, String costCenter, String headerLevelTaxType, String buyer,String requester, String notes,String description,String frequencyNo,String frequency, String headLvlTaxRate) {
		super(driver, logger);
		this.supplierSelectCategory = supplierSelectCategory;
		this.supplierName = supplierName;
		this.paymentTerm = paymentTerm;
		this.currency_value = currency_value;
		this.contractOwner = contractOwner;
		this.purchaseType = purchaseType;
		this.company = company;
		this.businessUnit = businessUnit;
		this.location = location;
		this.costCenter = costCenter;
		this.headerLevelTaxType = headerLevelTaxType;
		this.buyer = buyer;
		this.requester = requester;
		this.notes = notes;
		this.description = description;
		this.frequencyNo= frequencyNo;
		this.frequency= frequency;
		this.headLvlTaxRate= headLvlTaxRate;
	}



	/**
	 * <b>Function:</b> enterSupplierInfo
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param searchType
	 * @return result - True/False
	 * @throws Exception
	 */

	public boolean enterSupplierInfo(String searchType) throws Exception {
		boolean result = false;
		try {
			WebElement paymentTerms = findElement(By.xpath("//select[@id='slctPaymentTerms'][@disabled]"));
			WebElement address = findElement(By.xpath("//select[@id='slctSupplierAddress'][@disabled]"));
			WebElement remitToAddr = findElement(By.xpath("//select[@id='slctSupplierAddressRemit'][@disabled]"));
			WebElement currency = findElement(By.xpath("//select[@id='txtSupplierCurrency'][@disabled]"));
			WebElement suppContact = findElement(By.xpath("//select[@id='txtSupplierContact'][@disabled]"));

			findElement(By.xpath("//*[@id='supplierNameDropdown']/div/a[span[text()='" + searchType + "']]")).click();
			findElement(By.id("txtSupplierName")).sendKeys(searchValue);
			if (findElement(By.xpath("//form[@id='frmInvoice']/ul[contains(@style,'block')]")) != null) {
				findElement(By.xpath("//form[@id='frmInvoice']/ul[contains(@style,'block')]/li[1]")).click();
				Assert.assertNull(paymentTerms);
				Assert.assertNull(address);
				Assert.assertNull(remitToAddr);
				Assert.assertNull(currency);
				Assert.assertNull(suppContact);
				findElement(By.xpath("//select[@id='slctPaymentTerms']/option[text()='" + paymentTerms + "']")).click();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> enterContractDetails
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param buyer
	 * @param requester
	 * @param notes
	 * @param description
	 * @return result - True/False
	 * @throws Exception
	 */

	public boolean enterContractDetails(String contractName,String buyer, String requester, String notes, String description)
			throws Exception {
		boolean result = false;
		try {


			String autoInvoiceNo = String.valueOf(generateNo());
			findElement(By.id("txtContractName")).sendKeys(contractName);
			//findElement(By.id("txtBuyer")).sendKeys(buyer);
			enterText_AutoComplete(By.id("txtBuyer"), buyer);
			/*findElement(By.id("txtContractOwner")).sendKeys(contractOwner);*/
			enterText_AutoComplete(By.id("txtContractOwner"), contractOwner);
			/*findElement(By.id("txtRequester")).sendKeys(requester);*/
			enterText_AutoComplete(By.id("txtRequester"), requester);
			findElement(By.id("txtAutoInvoiceNo")).sendKeys(autoInvoiceNo);
			findElement(By.xpath("//select[@id='slctPurchaseType']/option[text()='" + purchaseType + "']")).click();
			findElement(By.id("txtInvoiceComments")).sendKeys(notes);
			findElement(By.id("txtDescription")).sendKeys(description);
			LogScreenshot("INFO","Contract Details added");
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> enterReleaseSchedule
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @return result - True/False
	 * @throws Exception
	 */

	public boolean enterReleaseSchedule(String frequencyNo, String frequency) throws Exception {
		boolean result = false;
		try {
			findElement(By.id("txtFrequencyOccurance")).sendKeys(frequencyNo);
			findElement(By.xpath("//select[@id='txtFrequencyBy']/option[@value='" + frequency + "']")).click();
			//findElement(By.id("txtFromDate")).click();
			selectRecentDate("txtFromDate");
			LogScreenshot("INFO","From date selected");
			Thread.sleep(2000);
			selectFutureDate("txtToDate");
			LogScreenshot("INFO","To date selected");
			/*  findElement(By.id("txtNeverExpires")).click();*/
			findElement(By.xpath("//select[@id='txtDayOfWeek']/option[text()='"+getLanguageProperty("Monday")+"']")).click();
			LogScreenshot("INFO","Release schedule details added");
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean selectFromDate() throws InterruptedException {
		boolean result = false;
		Thread.sleep(2000);
		WebElement date = driver.findElement(By.id("txtFromDate"));
		date.click();
		Thread.sleep(2000);
		
		//Selecting Next day from today - as sometimes today's date is disabled
		findElement(By.xpath("//*[@id='ui-datepicker-div']/table//tr/td[contains(@class,'today')]/following-sibling::td")).click();
		Thread.sleep(2000);
		if (date.getText() != null)
			result = true;
		else{}
		//LogScreenshot("INFO", "date field is empty");
		return result;
	}

	public void selectNextDate(String id) {  
		Date date = new Date(System.currentTimeMillis());
		Calendar c = Calendar.getInstance();
		c.setTime(date); 
		c.add(Calendar.YEAR, 1);
		date = c.getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String s = formatter.format(date);

		JavascriptExecutor js = (JavascriptExecutor) driver; 
		js.executeScript("document.getElementById('"+id+"').value='"+s+"';");
	} 


	/**
	 * <b>Function:</b> enterReleaseSchedule
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param ToDt
	 * @return result - True/False
	 * @throws Exception
	 */

	public boolean enterReleaseSchedule(Date ToDt) throws Exception {
		boolean result = false;
		try {
			findElement(By.id("txtFrequencyOccurance")).sendKeys(frequencyNo);
			findElement(By.xpath("//select[@id='txtFrequencyBy']/option[text()='" + frequency + "']")).click();
			findElement(By.id("txtFromDate")).click();
			selectDate(fromDt);
			findElement(By.id("txtToDate")).click();
			selectDate(ToDt);
			findElement(By.xpath("//select[@id='txtDayOfWeek']/option[text()='"+getLanguageProperty("weekDay")+"']")).click();
			result = true;
			LogScreenshot("INFO","Release schedule details added");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> editBillingCostBookingInfo
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param billingCompany
	 * @param billingBusinessUnit
	 * @param billingLocation
	 * @param CBCostCenter
	 * @param CBProject
	 * @return result - True/False
	 * @throws Exception
	 */


	public String getContractStatus(String documentNo) throws Exception{
		String contractStatus=null;  
		if (filterByDocNo(documentNo)) {
			contractStatus= driver.findElement(By.xpath("//table[@id='contractlisting']//tr[td[contains(@class,'invoiceNumber')]/a[text()='"+documentNo+"']]/td[1]/div")).getText();
			if(contractStatus.equals("In Approval") || contractStatus.equals("Delegated") || contractStatus.equals("Activated")) {
				LogScreenshot("PASS",documentNo+ " :Contract is created with status "+contractStatus);
			}else
				LogScreenshot("FAIL", documentNo+ " :Contract is not displayed in Contract Listing");
		}
		return contractStatus;

	}


	public String createContract() throws Exception {    
		String contract = createContractRecurring(supplierSelectCategory, supplierName, paymentTerm, 
				currency_value, contractOwner, purchaseType, company,businessUnit,  location, costCenter, headerLevelTaxType, buyer, requester, notes, description, frequencyNo, frequency, headLvlTaxRate);

		return contract;

	}

	public String createDuplicateContract(String contractName) throws Exception {    
		String contract = createDuplicateContractRecurring(supplierSelectCategory, supplierName, paymentTerm, 
				currency_value, contractOwner, purchaseType, company,businessUnit,  location, costCenter, headerLevelTaxType, buyer, requester, notes, description, frequencyNo, frequency,contractName, headLvlTaxRate);

		return contract;

	}


	public boolean filterByDocNo(String DocumentNo) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(By.id("invoicelisting_processing"));
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='txtFltrInvoiceNum']")).sendKeys(DocumentNo);
			driver.findElement(By.xpath("//input[@id='txtFltrInvoiceNum']")).sendKeys(Keys.ENTER);
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(3000);
			List<WebElement> objfilteredList = driver.findElements(By.xpath("//table[@id='contractlisting']/tbody//td[2]/a"));
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(DocumentNo))
					result = true;
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void verifyContractAuditTrail(String DocumentNo) throws Exception {
		filterByDocNo(DocumentNo);
		ContractList objContractList = new ContractList(driver, logger);  
		objContractList.performActionOnContract("View","");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement objAuditTrailButton = getDriver().findElement(By.id("invoiceauditTrailHead"));
		js.executeScript("arguments[0].scrollIntoView();", objAuditTrailButton);
		findElement(By.id("invoiceauditTrailHead")).click();
		Thread.sleep(1500);
		softAssert.assertTrue(driver.findElements(By.id("auditTrailList_INVOICE_TEMPLATE")).size() > 0);
		softAssert.assertAll();              
	}

	public void verifyEFormInContract(String fieldName) throws Exception {
		String expectedFileName= driver.findElement(By.xpath("//label[text()='"+fieldName+"']")).getText();
		softAssert.assertEquals(fieldName, expectedFileName);
		softAssert.assertAll();

	}



}
