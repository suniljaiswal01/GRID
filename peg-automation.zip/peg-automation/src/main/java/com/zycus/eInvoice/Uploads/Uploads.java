package com.zycus.eInvoice.Uploads;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eInvoice.PO.PurchaseOrder;

import Framework.ConfigurationProperties;
import common.Functions.eInvoice_CommonFunctions;

public class Uploads extends eInvoice_CommonFunctions {

  private static By actionsLinkXpath = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
  private String filePath;
  SoftAssert softAssert= new SoftAssert();

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * @throws Exception 
   * 
   */

  public Uploads(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    ConfigurationProperties config = ConfigurationProperties.getInstance();
    this.filePath = config.getProperty("upload_Jpgfile_path");
  }

  /**
   * <b>Function:</b> searchDisplayName
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param displayName
   * @return result - True/False
   * @throws Exception
   */

  public boolean searchDisplayName(String displayName) throws Exception {
    boolean result = true;
    try {
      result = filterByText("Display Name", displayName) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> searchSupplierName
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param supplierName
   * @return result - True/False
   * @throws Exception
   */

  public boolean searchSupplierName(String supplierName) throws Exception {
    boolean result = true;
    try {
      result = filterByText("Supplier Name", supplierName) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> uploadNewFile
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param filePath
   * @return result - True/False
   * @throws Exception
   */

  public boolean uploadNewFile() throws Exception {
    boolean result = false;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    waitUntilInvisibilityOfElement(By.xpath("//div[@id='uploadsListing_processing'][contains(@style,'block')]"));
    try {
      findElement(By.id("lnkInvoiceAttachments")).click();
      sendKeys(By.xpath("//*[contains(@id,'attachmentInput')]"), filePath);
      Thread.sleep(30000);
      WebDriverWait wait = new WebDriverWait(driver, 60);
      wait.until(ExpectedConditions.presenceOfElementLocated(
          By.xpath("//tr[contains(@class,'attachmentRow')]//td[@class='status' and text()='Uploaded']")));  
      LogScreenshot("PASS","File selected successfully");
      js.executeScript("arguments[0].click()", driver.findElement(By.xpath("//*[@id='attachmentsDOM']//input[@value='"+getLanguageProperty("Done")+"']")));
      waitUntilInvisibilityOfElement(By.xpath("//div[@id='uploadsListing_processing'][contains(@style,'block')]"));  

      result = true;
      // WRITE CODE TO VERIFY THAT THE FILE IS UPLOADED AND A ROW IS
      // CREATED
    } catch (Exception e) {
      e.printStackTrace();
      LogScreenshot("FAIL","File not uploaded");
    }
    return result;
  }

  public boolean editUploadDetails(){
    boolean result = false;
    try {
      String uploadedDt = driver.findElement(By.xpath("//table[@id='uploadsListing']/tbody/tr[1]/td[5]")).getText().trim();
      String fileName = driver.findElement(By.xpath("//table[@id='uploadsListing']/tbody/tr[1]/td[2]/a")).getText().trim();
      int timer = 0;
      while(true) {
        timer++;
        driver.navigate().refresh();
        Thread.sleep(5000);
        if (driver.findElements(actionsLinkXpath).size() > 0 || timer>60)
          break;

      } 
      waitUntilInvisibilityOfElement(By.xpath("//div[@id='uploadsListing_processing'][contains(@style,'block')]"));
      findElement(actionsLinkXpath).click();
      findElement(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"+getLanguageProperty("Edit Upload Details")+"']")).click();
      driver.findElement(By.xpath("//tr[not(@class='attachmentRow')]//input[@id='txtdisplayName']")).clear();
      String editedFileName = "uploadedFile_"+generateNo();
      driver.findElement(By.xpath("//tr[not(@class='attachmentRow')]//input[@id='txtdisplayName']")).sendKeys(editedFileName);
      LogScreenshot("INFO","Edited file name");
      findElement(By.name("closeAttachments")).click();
      waitUntilInvisibilityOfElement(processingLoader);
      searchDisplayName(editedFileName);
      if (driver.findElement(By.xpath("//table[@id='uploadsListing']/tbody/tr[1]/td[5]")).getText().trim().equals(uploadedDt)) {
        LogScreenshot("INFO","Searched by edited file name");
        result = true;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }


  /**
   * <b>Function:</b> takeAction
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param action
   * @return result - True/False
   * @throws Exception
   */

  public boolean takeAction(String action) throws Exception {
    boolean result = false;
    try {
      Thread.sleep(3000);
      findElement(actionsLinkXpath).click();
      /*findElement(By.xpath("(//*[@id='uploadsListing']//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"
          + action + "']")).click();
      waitUntilInvisibilityOfElement(By.id("status_overlay_loading_msg"));*/
      clickAndWaitUntilLoaderDisappears(By.xpath("(//table[contains(@class,'dataTable')]//a[@class='icon actLnk'])[1]/following-sibling::ul//a[text()='"
          + action + "']"), By.id("status_overlay_loading_msg"));
      switch (action) {
      case "Create Non-PO Invoice":
        LogScreenshot("INFO","Create Non-PO Invoice - action selected");
        break;
      case "Create PO Invoice":
        LogScreenshot("INFO","Create PO Invoice - action selected");
        if (findElement(By
            .xpath("//div[contains(@class,'promptbx')][//td[contains(text(),'"+getLanguageProperty("You will be redirected to PO Listing")+"')]]"))
            .isDisplayed()) {
          findElement(By.xpath("//button/span[text()='"+getLanguageProperty("Continue")+"']")).click();
          PurchaseOrder objPurchaseOrder = new PurchaseOrder(driver, logger);
          waitUntilInvisibilityOfElement(objPurchaseOrder.getProcessingLoader());
          if (findElement(objPurchaseOrder.getAlertBoxmsg()).getText()
              .equals("To create an invoice against a PO, select the PO from the list below"))
            LogScreenshot("PASS", "navigated to Purchase Orders page");

          else
            LogScreenshot("FAIL",
                "not navigated to Purchase Orders page or alertBox message not displayed");
        } else
          LogScreenshot("INFO", "You will be directed to PO Listing - confirm promptBox not displayed");
        break;
      case "Create Credit Memo":
        LogScreenshot("INFO","Create Credit Memo - action selected");
        if (findElement(By
            .xpath("//div[contains(@class,'promptbx')][//td[contains(text(),'"+getLanguageProperty("You will be redirected to PO Listing")+"')]]"))
            .isDisplayed()) {
          findElement(By.xpath("//button/span[text()='"+getLanguageProperty("Continue")+"']")).click();
          PurchaseOrder objPurchaseOrder = new PurchaseOrder(driver, logger);
          waitUntilInvisibilityOfElement(objPurchaseOrder.getProcessingLoader());
          if (findElement(objPurchaseOrder.getAlertBoxmsg()).getText().equals(getLanguageProperty("Open a released PO from the list of POs to create a Credit Memo against it")))
            LogScreenshot("INFO", "navigated to Purchase Orders page");
          else
            LogScreenshot("INFO",
                "not navigated to Purchase Orders page or alertBox message not displayed");
        } else
          LogScreenshot("INFO", "You will be directed to PO Listing - confirm promptBox not displayed");
        break;
      case "Create Credit Memo w/o ref":
        LogScreenshot("INFO","Create Credit Memo w/o ref - action selected");
        break;
      }
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception();
    }
    return result;
  }

  public boolean filterByDocNo(String DocumentNo) throws Exception {
    boolean result = false;
    try {
      waitUntilInvisibilityOfElement(By.id("invoicelisting_processing"));
      Thread.sleep(3000);
      findElement(By.xpath("//th[contains(@class,'invNumFltrHdr')]//b")).click();
      findElement(By.xpath("//input[@type='radio'][@id='txtFltrWithInv']")).click();
      findElement(By.xpath("//input[@id='txtFltrInvoiceNum']")).sendKeys(DocumentNo);
      Thread.sleep(3000);
      findElement(By.xpath("//div[@class='b-box filterBtnBx typeFilterBtnbx']//a[@class='b-button b-primary b-small inpt fltrBtn'][text()='"+getLanguageProperty("Filter")+"']")).click();
      waitUntilInvisibilityOfElement(processingLoader);
      Thread.sleep(5000);
      List<WebElement> objfilteredList = driver.findElements(By.xpath("//td[@class=' invoiceNo']"));
      for (WebElement obj : objfilteredList) {
        if (obj.getText().equals(DocumentNo))
          result = true;
        else {
          result = false;
          break;
        }
      }
      return result;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  public boolean verifyInvoiceCreditMemoFields() throws Exception {
    boolean status=false;
    if (driver.findElements(By.xpath("//div[@id='createInvoiceCont']//span[text()='"+getLanguageProperty("Invoice")+"']")).size() > 0) {    
      softAssert.assertTrue(driver.findElement(By.xpath("//div[@id='createInvoiceCont']//h2[text()='"+getLanguageProperty("Supplier Info")+"']")).isDisplayed());
      softAssert.assertTrue(driver.findElement(By.xpath("//div[@id='createInvoiceCont']//h2[contains(text(),'"+getLanguageProperty("Invoice Details")+"')]")).isDisplayed());
      softAssert.assertTrue(driver.findElement(By.xpath("//div[@id='createInvoiceCont']//h2[contains(text(),'"+getLanguageProperty("Billing  & Cost Booking Info")+"')]")).isDisplayed());
      softAssert.assertTrue(driver.findElement(By.xpath("//a[@id='lnkInvoiceAttachments'][text()='1 attachment']")).isDisplayed());
      softAssert.assertAll();
      LogScreenshot("PASS","Invoice Details Verified");
      status=true;
    }else if (driver.findElements(By.xpath("//div[@id='createInvoiceCont']//span[text()='"+getLanguageProperty("Credit Memo")+"']")).size() > 0) {    
      softAssert.assertTrue(driver.findElement(By.xpath("//div[@id='createInvoiceCont']//h2[text()='"+getLanguageProperty("Supplier Info")+"']")).isDisplayed());
      softAssert.assertTrue(driver.findElement(By.xpath("//div[@id='createInvoiceCont']//h2[contains(text(),'"+getLanguageProperty("Credit Memo Details")+"')]")).isDisplayed());
      softAssert.assertTrue(driver.findElement(By.xpath("//div[@id='createInvoiceCont']//h2[contains(text(),'"+getLanguageProperty("Billing  & Cost Booking Info")+"')]")).isDisplayed());
      softAssert.assertTrue(driver.findElement(By.xpath("//a[@id='lnkInvoiceAttachments'][text()='1 attachment']")).isDisplayed());
      softAssert.assertAll();
      LogScreenshot("PASS","Credit Memo Details Verified");
      status=true;
    }
    else {
      LogScreenshot("FAIL","Invoice/Credit Memo Not displayed");
    }
    return status;

  }


}
