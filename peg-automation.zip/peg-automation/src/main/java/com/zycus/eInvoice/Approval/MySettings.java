package com.zycus.eInvoice.Approval;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import net.bytebuddy.dynamic.scaffold.TypeInitializer.None;

/**
 * <p>
 * <b> Title: </b> Approval.java
 * <br>
 * <b> Description: </b> Preform operations on a purchase order
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.configureOOO: user is able to configure OOO
 * <br>
 * 
 * @author Anisha
 * @since April 2018
 */
public class MySettings extends eInvoice_CommonFunctions {

  private static By btnRevokeID = By.id("btnRevoke");
  private static By delegateToID = By.id("delegateTo");
  private static By delegateFromID = By.id("delegateFrom");
  private static By btnSaveID = By.id("btnSave");
  private static By notificationMsgXpath = By
      .xpath("//*[@id='status_overlay_loading']/div[text()='"+getLanguageProperty("Approval Delegated successfully")+"']");
  private String delegateTo;

  public MySettings(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_eInvoice =configurationProperties.getProperty("Datasheet_eInvoice");
        String[][] abc = (String[][]) objFunctions.dataProvider("MySettings", Datasheet_eInvoice);
        this.delegateTo = abc[0][0];
  }

  /**
   * <b>Function:</b> configureOOO
   * 
   * @author Anisha
   * @since May 2018
   * @param
   * @throws None
   * @return result
   * @throws InterruptedException 
   * @throws Exception
   */
  public boolean configureOOO() throws InterruptedException {
    boolean status = false;
    Thread.sleep(3000);
    try {
      if (!driver.findElement(btnRevokeID).getAttribute("style").contains("none")) {
        findElement(btnRevokeID, "Revoke button").click();
        waitUntilInvisibilityOfElement(processingLoader);
        Thread.sleep(4000);
      }
      enterText_AutoComplete(delegateToID, delegateTo);
      //enterText_AutoComplete(delegateFromID, delegateTo);
      LogScreenshot("INFO","Delegate Approval To added");
      clickAndWaitUntilLoaderDisappears(btnSaveID, notificationMsgXpath);
      waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"));
      status = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return status;
  }
}
