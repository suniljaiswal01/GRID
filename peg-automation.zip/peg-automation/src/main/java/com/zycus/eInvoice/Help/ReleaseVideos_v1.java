package com.zycus.eInvoice.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class ReleaseVideos_v1 extends ProductVideos {

  private WebDriver driver;
  private ExtentTest logger;

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public ReleaseVideos_v1(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }

  /**
   * <b>Function:</b> verifyLatestRelVideo
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param displayName
   * @return result - True/False
   * @throws Exception
   */

  public boolean verifyLatestRelVideo() throws Exception {
    boolean result = false;
    try {
      if (driver.findElement(By.xpath("//table[@class='selfTraining']//li[contains(@class,'VideoTab') and contains(@class,'active')]")).getText().equals(getLanguageProperty("Release Videos"))){
        if (verifyLatestProductVideo()){
          driver.close();
          result = true;
        }
      }else
        LogScreenshot("FAIL", "Product Videos tab not opened");
    } catch (Exception e) {
      e.printStackTrace();
      LogScreenshot("FAIL", "latest help video not opened");
    }
    return result;
  }

}
