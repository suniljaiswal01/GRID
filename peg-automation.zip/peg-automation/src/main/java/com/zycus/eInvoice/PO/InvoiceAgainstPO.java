package com.zycus.eInvoice.PO;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eInvoice.Invoice.ItemDetails;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> InvoiceAgainstPO.java
 * <br>
 * <b> Description: </b> create new Invoice against PO
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewInvoice: user is able to create an Invoice against a PO 
 * <br>
 * 
 * @author Anisha
 * @since May 2018
 */

public class InvoiceAgainstPO extends eInvoice_CommonFunctions {

  private String invoiceDate;
  String invoiceStatus;
  String company;
  String businessUnit;
  String location;
  String costCenter;
  String project;
  //private String invoiceNo;

  public InvoiceAgainstPO(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
    ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
    String Datasheet_eInvoice =configurationProperties.getProperty("Datasheet_eInvoice");
    String[][] abc = (String[][]) objFunctions.dataProvider("InvoiceAgainstPO", Datasheet_eInvoice);

    String[][] abc1 = (String[][]) objFunctions.dataProvider("InvoiceNonPONew", Datasheet_eInvoice);

    this.invoiceDate = abc[0][0]; 
    this.company= abc1[0][6];
    this.businessUnit= abc1[0][7];
    this.location= abc1[0][8];
    this.costCenter= abc1[0][9];      
    String[][] abc2 = (String[][]) objFunctions.dataProvider("CreditMemoAgainstPO", Datasheet_eInvoice);
    this.project = abc2[0][0];  

  }

  // public InvoiceAgainstPO(WebDriver driver, ExtentTest logger, Date
  // invoiceDate) {
  public InvoiceAgainstPO(WebDriver driver, ExtentTest logger, String invoiceDate) {
    super(driver, logger);
    this.invoiceDate = invoiceDate;

  }

  /**
   * <b>Function:</b> createNewInvoice
   * 
   * @author Anisha
   * @param invoiceNo
   * @since May 2018
   * @throws Exception
   * @return status
   */

  public String createNewInvoice(String PO) throws Exception {

    //boolean result = false;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    String invoice = null;
    try {
      Thread.sleep(3000);
      String invoiceNo = String.valueOf(generateNo());
      driver.findElement(By.id("txtInvoiceNumber")).sendKeys(invoiceNo);
      findElement(By.xpath("//input[@id='txtInvoiceDate']/following-sibling::img")).click();
      //selectDate_v1(invoiceDate);
      selectTodayDate();
      LogScreenshot("Info", "Invoice Date selected as today's date");
      //if (addAttachment()){
      addAttachment();
        //LogScreenshot("INFO","Attachment added");
	    if(!(driver.findElement(By.id("previewCollapseBtn")).getAttribute("class").contains("openPreviewCollapse"))) {
	    	driver.findElement(By.xpath("//span[@id='previewCollapseBtn']/span")).click();
	    	Thread.sleep(4000);
	    	LogScreenshot("INFO","Attachment collapsed");
        }
      //}
      /*else
        LogScreenshot("INFO","Attachment is not added");*/
      
      try {
          flexiFormDetails(false);      
        }catch(Exception e) {e.printStackTrace();}
      
      try {
        if (driver.findElements(By.id("txtBaseExchangeRate")).size() > 0) {
        	driver.findElement(By.id("txtBaseExchangeRate")).clear();
        	driver.findElement(By.id("txtBaseExchangeRate")).sendKeys("50");
        	LogScreenshot("INFO","Exchange Rate entered");
        }
      }catch(Exception e) {}

      editBillingCostBookingforPOInvoice(company, businessUnit, location, costCenter, project);
      // TODO add remit to address
      scroll_into_view_element(findElement(By.id("einvoiceItemList")));
      ItemDetails objItem = new ItemDetails(driver, logger);  
      WebElement foo = driver.findElement(By.xpath(
          "//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)][1]"));
      if (foo.isDisplayed()) {
        Thread.sleep(2000);
        scroll_into_view_element(foo);
        Thread.sleep(2000);

        if (driver.findElements(By.xpath("//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)]")).size() > 0) {
          List<WebElement> itemLines= driver.findElements(By.xpath("//tbody/tr[contains(@id,'itemRow')]//input[@type='checkbox'][not(@disabled)]"));        
          for(int i=1;i<=itemLines.size();i++)  
          {  System.out.println(itemLines.size());
          driver.findElement(By.xpath("(//tbody/tr[contains(@id,'itemRow')]//input[@type='checkbox'][not(@disabled)])["+i+"]")).click();
          objItem.editAccountingDetailsOfLineItem(i);
          }
        }  
      }
      LogScreenshot("INFO","Item row selected");

      try {
        if (driver.findElement(By.xpath("(//input[contains(@class,'txtInvoicedQty')])[1]")).getAttribute("data-invoiced-quantity").equals("0")) {
          driver.findElement(By.xpath("(//input[contains(@class,'txtInvoicedQty')])[1]")).sendKeys("6");  
        }

      }catch(Exception e) {}
      Thread.sleep(2000);

      try {
        if (driver.findElement(By.xpath("(//input[contains(@class,'priceTxtbx txtMarketPrice')])[1]")).getAttribute("data-market-price").equals("0")) {
          driver.findElement(By.xpath("(//input[contains(@class,'priceTxtbx txtMarketPrice')])[1]")).sendKeys("2");
        }
        Thread.sleep(5000);
      }catch(Exception e) {}
      
      try {
          if (driver.findElements(By.id("txtBaseExchangeRate")).size() > 0) {
          	driver.findElement(By.id("txtBaseExchangeRate")).clear();
          	driver.findElement(By.id("txtBaseExchangeRate")).sendKeys("50");
          	LogScreenshot("INFO","Exchange Rate entered");
          }
        }catch(Exception e) {}
      Thread.sleep(5000);
      LogScreenshot("INFO","About to click Submit button");
      Thread.sleep(5000);
      clickAndWaitUntilLoaderDisappears(By.xpath("//a[@id='btnSubmit']"), By.xpath("//*[@id='status_overlay_updateInvoice']/div"));
      Thread.sleep(5000);
      LogScreenshot("INFO","Invoice submitted");
      if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Invoicing Error")+"']")).size() > 0)
        findElement(By.xpath("//span[text()='"+getLanguageProperty("Ignore & Submit")+"']")).click();
      Thread.sleep(5000);
      if (findElement(By.xpath("//span[text()='"+getLanguageProperty("Submit for approval")+"']")).isDisplayed()) {
        LogScreenshot("INFO","Sending for Confirmation");
        findElement(By.xpath("//div[@class='b-box']//input[@value='"+getLanguageProperty("Send for confirmation")+"']")).click();
      }
      waitUntilInvisibilityOfElement(By.xpath("//*[@id='status_overlay_updateInvoice']/div"));
      Thread.sleep(8000);
      LogScreenshot("INFO", "created invoice against PO : " + invoiceNo);

      // validate if invoice is created
      if (findElement(By.xpath("//*[@id='invoiceGrid']/tbody/tr[*]/td[1]/a[text()='" + invoiceNo + "']"))
          .isDisplayed()) {
        String status= driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[@class=' status']")).getText();
        if (status.equals(getLanguageProperty("In Approval"))) {
          invoiceStatus= "In-Approval";      
        }else
          if (status.equals("On-hold")){
            driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td//a[@class='scLnk icon actLnk']")).click();
            Thread.sleep(5000);
            driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[div//a[@class='scLnk icon actLnk']]//ul//a[@title='"+getLanguageProperty("Release Hold")+"']")).click();
            driver.findElement(By.id("txtInvoiceProcessComment")).sendKeys("Releasing Hold");
            Thread.sleep(5000);
            driver.findElement(By.xpath("//input[@value='"+getLanguageProperty("Release Hold")+"']")).click();
            Thread.sleep(5000);
            waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process']"));  
            Thread.sleep(10000);
            invoiceStatus= driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[@class=' status']")).getText();
            if (invoiceStatus.equals(getLanguageProperty("Submitted"))) {  
              Thread.sleep(5000);
              driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td//a[@class='scLnk icon actLnk']")).click();
              Thread.sleep(5000);
              driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[div//a[@class='scLnk icon actLnk']]//ul//a[@title='"+getLanguageProperty("Confirm and Match")+"']")).click();
              Thread.sleep(5000);
              waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process']"));  
              Thread.sleep(10000);
              invoiceStatus= driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[@class=' status']")).getText();
              Thread.sleep(5000);
            }                
          }else
            if (status.equals(getLanguageProperty("Submitted"))) {
              driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td//a[@class='scLnk icon actLnk']")).click();
              Thread.sleep(5000);
              driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[div//a[@class='scLnk icon actLnk']]//ul//a[@title='"+getLanguageProperty("Confirm and Match")+"']")).click();

              waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process']"));  
              Thread.sleep(5000);
              invoiceStatus= driver.findElement(By.xpath("//tr[td[@title='" + invoiceNo + "']]//td[@class=' status']")).getText();
              Thread.sleep(5000);
            }else
                if (status.equals(getLanguageProperty("Approved"))) {
                	invoiceStatus= "Approved"; 
                    Thread.sleep(5000);
                  }
        LogScreenshot("INFO","Invoice created wit status "+invoiceStatus);
        invoice = invoiceNo;      
      }
    } catch (Exception e) {
      e.printStackTrace();
      LogScreenshot("FAIL", "Unable to create Invoice");
      scroll_to_TopofPage();
      LogScreenshot("Info", "Scrolled to top of page for screenshot");
    }
    return invoice;

  }

}
