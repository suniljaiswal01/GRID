package com.zycus.eInvoice.Reports;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

//import common.Functions.eInvoice_CommonFunctions;
import common.Reports.Common_ReportDetail;

public class ReportDetail extends Common_ReportDetail {

  //private By reportLabel = By.xpath("//*[@id='reportNameHeader_RMS']/label");

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public ReportDetail(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> shareMyReports
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param reportName
   * @return result - True/False
   * @throws Exception
   */

  public boolean shareMyReports(String reportName, String sharedUserEmail) throws Exception {
    boolean result = false;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    try {
      findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More Option")+"')]")).click();
      WebElement objShare = findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Share")+"']"));
      js.executeScript("arguments[0].click()", objShare);
      waitUntilVisibilityOfElement(By.id("shareDashList"));
      WebElement userChkBox = driver.findElement(By.xpath(
          "//table[@class='shareListTable_RMS']//div[text()='"+ sharedUserEmail+"']/ancestor::tr//input[@disabled]"));
      if (userChkBox.getAttribute("disabled").equals(getLanguageProperty("true"))) {
        findElement(
            By.xpath("(//table[@class='shareListTable_RMS']//div/ancestor::tr//input[not(@disabled)])[1]"))
        .click();
        sharedUserEmail = findElement(By
            .xpath("(//table[@class='shareListTable_RMS']//div/ancestor::tr//input[not(@disabled)])[1]/ancestor::tr/td[3]/div"))
            .getText();
      } else
        driver.findElement(By.xpath(
            "//table[@class='shareListTable_RMS']//div[text()='"+ sharedUserEmail+"']/ancestor::tr//input")).click();

      if (driver.findElements(By.xpath("//ul[@id='ulUser']/li[@id='"+ sharedUserEmail +"']")).size() > 0) {
        findElement(By.id("btnconfirm")).click();
        result = findElement(By.xpath("//div[@id='jqi'][div/div[text()='"+getLanguageProperty("Success")+"']]")).isDisplayed() ? true
            : false;
        findElement(By.xpath("//div[@id='jqi']//button[text()='"+getLanguageProperty("Go to report")+"']")).click();
        waitUntilInvisibilityOfElement(processingLoader);
        Thread.sleep(1500);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

	public void addReportColumns(String...reportColumns) throws Exception {
		try {
			Thread.sleep(5000);
			findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Modify")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Report Type Selection
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Next")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Grouping for Summary Report
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Next")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Report Columns
			for(String column: reportColumns) {
				findElement(By.xpath("(//input[@type='checkbox'][following-sibling::label[text()='"+column+"']])[1]")).click();				
				LogScreenshot("pass",column+" Column Added");
			}
				
			
			//Order Report Column
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Next")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Information To Summarize
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Next")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Report Filter Selection
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Next")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Charts and Highlights
			findElement(By.xpath("//input[@title='"+getLanguageProperty("Next")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			//Click Run Report
			findElement(By.xpath("//div[@id='topbar-inner']//input[@title='"+getLanguageProperty("Run Report")+"']")).click();
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
			
			findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Save As")+"']")).click();
			Thread.sleep(2000);
			LogScreenshot(driver.getPageSource());
			
			if(driver.findElements(By.id("dialog1_RMS")).size()>0) {

				LogScreenshot("info", "The report is currently being refreshed in background. It would require some more time to complete the refresh of data. Please check back in some time.");
				WebElement sendToBackGround = driver.findElement(By.id("saveButton"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click();", sendToBackGround);
			}
			
			//Click Save As
			
			waitUntilVisibilityOfElement(By.id("dialog_RMS"));
			driver.findElement(By.id("reportName")).sendKeys("report_"+generateNo());
			
			//Create New Folder
			findElement(By.id("saveInFolder")).click();
			driver.findElement(By.id("newFolderName_RMS")).sendKeys("folder_"+generateNo());
			
			findElement(By.id("saveButton")).click();
			Thread.sleep(5000);
			//Press Enter key
			 try {
				 waitForAlert();
				 driver.switchTo().alert().accept();
			    } catch (NoAlertPresentException e) {
			        e.printStackTrace();
			    }
			waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

  //exportFormat - .csv, .xlsx, .pdf 
  public boolean exportReport(String reportName, String exportFormat){
    boolean result = false;
    String name = System.getProperty("user.name");
    String filePath = "Y:\\PCS-Shared-Local\\PEG- Automation\\Downloads"; 
    JavascriptExecutor js = (JavascriptExecutor) driver;
    try {
      findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("Export")+"')]")).click();
      WebElement objExport = findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[@class='export_RMS']/img[contains(@title,'"+exportFormat+"')]"));
      js.executeScript("arguments[0].click()", objExport);
      Thread.sleep(5000);
      //Wait for the file to download
      Thread.sleep(8000);
      String fileExtension = null;
      switch(exportFormat){
      case "CSV":
        fileExtension = "csv";
        break;
      case "Excel":
        fileExtension = "xlsx";
        break;
      case "PDF":
        fileExtension = "pdf";
        break;
      }

      Thread.sleep(5000);
      if (checkFileExists(filePath, reportName, fileExtension))
        result = true;
      
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }


  /**
   * <b>Function:</b> closeReportDetails
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param reportName
   * @return result - True/False
   * @throws Exception
   */

  /*public boolean closeReportDetails() throws Exception {
    boolean result = false;
    try {
      findElement(By.xpath("//div[@id='rightButton_RMS']//input[@title='"+getLanguageProperty("Close")+"']")).click();
      waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }
   */
  /**
   * @return the reportLabel
   */
  /*public By getReportLabel() {
    return reportLabel;
  }*/

  /**
   * @param reportLabel
   *            the reportLabel to set
   */
  /*public void setReportLabel(By reportLabel) {
    this.reportLabel = reportLabel;
  }*/

  public boolean verifyColumnExistsInReport(String columnName){
    return driver.findElements(By.xpath("//table[@id='viewReport']/thead/tr/th/span[text()='"+columnName+"']")).size() > 0?true:false;
  }


  public boolean revokeMyReports(String reportName, String sharedUserEmail) throws Exception {
    boolean result = false;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    try {
      findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[contains(text(),'"+getLanguageProperty("More Option")+"')]")).click();
       findElement(By.xpath("//div[@class='topTabNavigation_RMS']//a[text()='"+getLanguageProperty("Revoke")+"']")).click();
       waitUntilInvisibilityOfElement(By.id("revokeloadingdiv"));
       Thread.sleep(5000);
          
      if (driver.findElements(By.xpath("//tr[@class='rowlistReports odd'] | //tr[@class='rowlistReports even']")).size() > 0) {  
        String userNameBeforeRevoke= driver.findElement(By.xpath("//div[@class='overflowByCss_RMS'][1]")).getText();
         Thread.sleep(5000);        
        driver.findElement(By.xpath("(//tr[@class='rowlistReports odd'] | //tr[@class='rowlistReports even']//input[@name='chklist'])[1]")).click();
        driver.findElement(By.xpath("//a[@class='revokeSingle revokReport_RMS iconSmall_RMS'][1]")).click();
        driver.findElement(By.name("jqi_state0_buttonYes")).click();
        waitUntilInvisibilityOfElement(By.id("revokeloadingdiv"));
        driver.findElement(By.xpath("//label[@class='txtbx_RMS']")).sendKeys(userNameBeforeRevoke);
        waitUntilInvisibilityOfElement(By.id("revokeloadingdiv"));
        driver.findElement(By.xpath("//div[@id='saveDialogTitle'][contains(@title,'Revoke')]//..//button[@title='"+getLanguageProperty("Close")+"']")).click();
        driver.findElement(By.xpath("//*[@name='closeBtm']")).click();
        Thread.sleep(5000);
        /*if (driver.findElements(By.xpath("//tr[@class='rowlistReports odd'] | //tr[@class='rowlistReports even']")).isEmpty()) {*/
          result=true;
        /*}*/
      }      
  }
    catch(Exception e)
    {
      e.printStackTrace();
      if (driver.findElement(By.xpath("//div[@id='saveDialogTitle'][contains(@title,'Revoke')]//..//button[@title='"+getLanguageProperty("Close")+"']")).isDisplayed())
        driver.findElement(By.xpath("//div[@id='saveDialogTitle'][contains(@title,'Revoke')]//..//button[@title='"+getLanguageProperty("Close")+"']")).click();
      if (driver.findElement(By.xpath("//*[@name='closeBtm']")).isDisplayed())
        driver.findElement(By.xpath("//*[@name='closeBtm']")).click();
      
    }
    return result;
  }
}
