package com.zycus.eInvoice.Invoice;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/*import com.aventstack.extentreports.ExtentTest;*/
import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;


public class ItemDetails extends eInvoice_CommonFunctions {

	private String description;
	private String product_cat;
	private String market_prc;
	private String quantity;
	private String GLType;
	private String GLAccount;
	private String taxType;
	private int taxRate;
	public int totalAmount;

	private static By mktPricexpath = By
			.xpath("//div[@id='createNewItem']//input[contains(@class,'pricefield txtMarketPrice')]");
	private static By descriptionXpath = By
			.xpath("//div[@id='createNewItem']//*[@id='manTxtFields']/div//li[3]/div[1]/textarea");
	private static By productCategoryxpath = By
			.xpath("//div[@id='createNewItem']//*[@id='manTxtFields']/div//li[5]/div[1]/input");
	private static By saveBtnId = By.id("saveItemSummary");


	public ItemDetails(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		Random rnd = new Random();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice =
				configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("ItemDetails", Datasheet_eInvoice);
		this.description = abc[0][0];
		this.product_cat = abc[0][1];
		//this.market_prc = abc[0][2];
		this.market_prc = String.valueOf(1+rnd.nextInt(10));
		this.quantity = abc[0][3];
		this.GLType = abc[0][4];
		this.GLAccount = abc[0][5];
		this.taxType = abc[0][6];
		this.taxRate = 1+rnd.nextInt(10000);
	}

	/*public ItemDetails(WebDriver driver, ExtentTest logger, String description, String product_cat,
      String market_prc, String quantity, String GLType, String GLAccount) {
    super(driver, logger);

  }*/

	/**
	 * ------------------------------------------------
	 * 
	 * @function add items for invoice/creditmemo
	 * @return boolean
	 * @param item_no,description,product_cat
	 * @param market_prc,quantity
	 * @throws Exception
	 */
	/*
	 * public boolean add_item(String item_no, String description, String
	 * product_cat, String market_prc, String quantity, String GLType, String
	 * GLAccount) throws Exception {
	 */
	/*  public boolean add_item(String description, String product_cat, String market_prc, String quantity, String GLType, String GLAccount)
      throws Exception {*/
	public void add_item() throws Exception {
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			//Item Details
			Thread.sleep(6000);
			driver.findElement(descriptionXpath).sendKeys(description);
			WebElement prod_cat = driver.findElement(productCategoryxpath);
			/*scroll_into_view_element(prod_cat);
			js.executeScript("window.scrollBy(0,-100)");*/
			scroll_into_view_element(prod_cat);
			//Thread.sleep(2000);
			try {
				Thread.sleep(2000);
				enterText_AutoComplete(productCategoryxpath, product_cat);
			} catch (Exception e) {
				try{
					findElement(productCategoryxpath).clear();
					driver.findElement(productCategoryxpath).sendKeys(product_cat);
					Thread.sleep(2000);
					findElement(By.xpath("//div[@id='itemDialog']//ul[contains(@style,'block')]/li[1]")).click();
				}catch(Exception e1){
					LogScreenshot("fail", "Product category not added");
				}
			}
			Thread.sleep(4000);
			driver.findElement(mktPricexpath).sendKeys(market_prc);
			Thread.sleep(4000);
			WebElement creditQty = findElement(
					By.xpath("(//div[@class='frmInpt']//input[contains(@class,'txtQuantity')])[2]"));
			scroll_into_view_element(creditQty);
			creditQty.sendKeys(quantity);
			Thread.sleep(4000);
			LogScreenshot("PASS", "Item summary Details added");
			totalAmount= Integer.parseInt(market_prc) *  Integer.parseInt(quantity);

			//Taxes
			try {        
				findElement(By.xpath("//li[@aria-controls='itemTaxes']/a[text()='"+getLanguageProperty("Taxes")+"']")).click();
				if (driver.findElements(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'selectTaxType')]")).size() > 0){
					findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'selectTaxType')]")).click();
					enterText_AutoCompleteInvoice(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'selectTaxType')]"), taxType);
					/* findElement(By.xpath("//ul[contains(@style,'block')]/li[text()='"+taxType+"']")).click();*/
					Thread.sleep(3000);
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")).click();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")).clear();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")).sendKeys(String.valueOf("AutoTax_"+taxRate));
					Thread.sleep(2000);
					Random rnd = new Random();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxRate')]")).clear();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxRate')]")).sendKeys(String.valueOf(1+rnd.nextInt(10)));
					LogScreenshot("INFO", "Item Line tax Details added");
				}else if (driver.findElements(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'inputTaxType')]")).size() > 0){

					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'inputTaxType')]")).clear();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'inputTaxType')]")).sendKeys(taxType);
					Thread.sleep(2000);
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")).click();
					Thread.sleep(2000);
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")).sendKeys("AutoTax_"+generateNo());
					Thread.sleep(2000);
					Random rnd = new Random();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxRate')]")).clear();
					driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxRate')]")).sendKeys(String.valueOf(1+rnd.nextInt(10)));
					LogScreenshot("PASS", "Item Line tax Details added");
					Thread.sleep(2000);
				}      
			}catch (NullPointerException e) {
				e.printStackTrace();
			}

			Thread.sleep(3000);
			// Accounting
			/*if (driver.findElements(By.xpath("(//li[@id='tabAccounting']/a[contains(text(),'"+getLanguageProperty("Accounting")+"')])[2]")).size() > 0){*/
			if(driver.findElements(By.xpath("//form[@id='frmItemSummary']//li[@id='tabAccounting']/a[contains(text(),'"+getLanguageProperty("Accounting")+"')]")).size()>0){
				Thread.sleep(5000);
				//findElement(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).click();
				//findElement(By.xpath("(//li[@id='tabAccounting']/a)[2]")).click();
				try {
					findElement(By.xpath("//form[@id='frmItemSummary']//li[@id='tabAccounting']/a")).click();
					Thread.sleep(5000);
					Select select= new Select(driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='accountType']/following-sibling::div/select[option]")));
					select.selectByVisibleText(GLType);				
					//   driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='accountType']/following-sibling::div/select[option]/option[contains(text(),'" + GLType + "')]")).click();    	
					Thread.sleep(6000);
					LogScreenshot("INFO", "GL type selected");
					Thread.sleep(2000);
					try{
						driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/span/input[@aria-required]/following-sibling::label")).click();
						Thread.sleep(4000);
						LogScreenshot("Info", "Adding Accounting Details");
						findElement(By.xpath("//ul[li]/li/a[.|@span][contains(.,'"+GLAccount+"')]")).click();
						Thread.sleep(2000);
						LogScreenshot("PASS", "Accounting Details added");
						Thread.sleep(2000);
					}catch(Exception ex){
						driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/span/input[@aria-required]/following-sibling::label")).click();
						Thread.sleep(4000);
						LogScreenshot("Info", "Adding Accounting Details again");
						findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
						Thread.sleep(2000);
						LogScreenshot("PASS", "Accounting Details added");
						Thread.sleep(2000);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else
				LogScreenshot("INFO", "Accounting tab does not exist");

			Thread.sleep(3000);
			// Cost Allocation
			if (driver.findElements(By.xpath("//li[@id='costAllocationTab']/a[contains(text(),'"+getLanguageProperty("Cost Allocation")+"')]")).size() > 0){
				//findElement(By.xpath("//li[@id='costAllocationTab']/a[text()='"+getLanguageProperty("Cost Allocation")+"']")).click();
				try {
					findElement(By.xpath("//li[@id='costAllocationTab']/a")).click();
					//driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/input[@aria-required]")).click();
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/input")).click();
					findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
					LogScreenshot("INFO", "Cost Allocation Details added");
				} catch (NullPointerException e) {
					e.printStackTrace();
				}
			}else
				LogScreenshot("INFO", "Cost Allocation tab does not exist");
			Thread.sleep(2000);

			//driver.findElement(By.xpath("//div[@id='invoiceItemTaxes']//table[@class='zytbl txDetGrid dev_taxTable']/tbody/tr[1]/td[1]")).click();
			//Thread.sleep(2000);


			//Miscellaneous
			Thread.sleep(3000);
			try {
				findElement(By.xpath("//li[@aria-controls='lineLevelItemEform']/a[text()='"+getLanguageProperty("Miscellaneous")+"']")).click();
				try {
					flexiFormDetails(true);
				} catch (Exception e) {
					LogScreenshot("INFO","Flexi-Form is not available");
				}
			} catch (Exception e) {
			}

			Thread.sleep(5000);
			//js.executeScript("arguments[0].click();", findElement(saveBtnId));
			findElement(By.id("saveItemSummary"),"OK button").click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@aria-describedby='changeItemSummary' and contains(@style,'block')]"));
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[text()='"+getLanguageProperty("Item Summary")+"']]//a[@name='cancelItemSummary']")).click();
			throw e;
		}
	}

	public void add_itemwithSelfAssessedTax() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			//Item Details
			Thread.sleep(3000);
			driver.findElement(descriptionXpath).sendKeys(description);
			WebElement prod_cat = driver.findElement(productCategoryxpath);
			//scroll_into_view_element(prod_cat);
			//js.executeScript("window.scrollBy(0,-100)");
			try {
				Thread.sleep(2000);
				enterText_AutoComplete(productCategoryxpath, product_cat);
			} catch (Exception e) {
				findElement(productCategoryxpath).clear();
				driver.findElement(productCategoryxpath).sendKeys(product_cat);
				Thread.sleep(2000);
				findElement(By.xpath("//div[@id='itemDialog']//ul[contains(@style,'block')]/li[1]")).click();
			}
			Thread.sleep(4000);
			driver.findElement(mktPricexpath).sendKeys(market_prc);
			WebElement creditQty = findElement(
					By.xpath("(//div[@class='frmInpt']//input[contains(@class,'txtQuantity')])[2]"));
			scroll_into_view_element(creditQty);
			creditQty.sendKeys(quantity);
			LogScreenshot("INFO", "Details added");
			totalAmount= Integer.parseInt(market_prc) *  Integer.parseInt(quantity);

			// Accounting
			if (driver.findElements(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).size() > 0){
				findElement(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).click();
				try {
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='accountType']/following-sibling::div/select[option]")).click();
					Thread.sleep(1500);
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='accountType']/following-sibling::div/select[option]/option[contains(text(),'" + GLType + "')]")).click();
					Thread.sleep(1500);
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/span/input[@aria-required]/following-sibling::label")).click();
					Thread.sleep(2000);
					findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
					Thread.sleep(2000);
					LogScreenshot("INFO", "Accounting Details added");
				} catch (NullPointerException e) {
					e.printStackTrace();
				}
			}
			// Cost Allocation
			if (driver.findElements(By.xpath("//li[@id='costAllocationTab']/a[text()='"+getLanguageProperty("Cost Allocation")+"']")).size() > 0){
				findElement(By.xpath("//li[@id='costAllocationTab']/a[text()='"+getLanguageProperty("Cost Allocation")+"']")).click();
				try {
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/input[@aria-required]")).click();
					findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
					LogScreenshot("INFO", "Cost Allocation Details added");
				} catch (NullPointerException e) {
					e.printStackTrace();
				}
			}
			Thread.sleep(2000);

			//Taxes
			findElement(By.xpath("//li[@aria-controls='itemTaxes']/a[text()='"+getLanguageProperty("Taxes")+"']")).click();
			findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'selectTaxType')]")).click();
			//Header Level taxes
			enterText_AutoComplete((By.xpath("//div[@id='itemTaxes']//input[contains(@class,'inptTxt dev_input dev_selectTaxType')]")), "self assessed");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")).click();
			enterText_AutoComplete(driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'dev_txtTaxName')]")), "self assessed Tax");
			LogScreenshot("INFO","Tax details added");
			Thread.sleep(4000);
			float expectedLineLevelTax= (float) (totalAmount *0.05);
			String LinelLevelTax= driver.findElement(By.xpath("//div[@id='invoiceItemTaxes']//tr[contains(@class,'lineSubtotalTaxTr')]//span[@class='dev_self_assessedSubTotalTax']")).getText().replaceAll(",", "");
			float actualLineLevelTax= Float.parseFloat(LinelLevelTax);  
			System.out.println("Expected tax"+expectedLineLevelTax);
			System.out.println("Expected tax"+actualLineLevelTax);
			softassert.assertEquals(expectedLineLevelTax, actualLineLevelTax);
			softassert.assertAll();
			LogScreenshot("PASS","Verified self assesed tax");
			driver.findElement(By.xpath("saveItemSummary")).click();


		} catch (Exception e) {
			e.printStackTrace();
			findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[text()='"+getLanguageProperty("Item Summary")+"']]//a[@name='cancelItemSummary']")).click();
			throw new Exception();
		}
		//return result;
	}

	public void editAccountingDetailsOfLineItem(int rowCount) throws Exception {						
		try {				
			JavascriptExecutor js = (JavascriptExecutor) driver;			
			Thread.sleep(4000);			
			driver.findElement(By.xpath("(//span[@id='einvoiceItemList']//a[@class='icon edit splitItem configure'][@title='"+getLanguageProperty("Edit")+"'])["+rowCount+"]")).click();			
						
			Thread.sleep(5000);			
			if (driver.findElements(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).size() > 0){			
				Thread.sleep(5000);		
				findElement(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).click();		
				try {		
					Select select= new Select(driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='accountType']/following-sibling::div/select[option]")));	
					select.selectByVisibleText(GLType);	
					Thread.sleep(5000);	
						
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/span/input[@aria-required]/following-sibling::label")).click();	
					Thread.sleep(2000);	
					findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();	
					Thread.sleep(2000);	
					LogScreenshot("INFO", "Accounting Details added");	
				} catch (Exception e) {		
						
				}		
						
				Thread.sleep(5000);		
				//Miscellaneous		
				try {		
					findElement(By.xpath("//li[@aria-controls='lineLevelItemEform']/a[text()='"+getLanguageProperty("Miscellaneous")+"']")).click();	
					try {	
						flexiFormDetails(true);
					} catch (Exception e) {	
						LogScreenshot("INFO","Flexi-Form is not available");
					}	
					Thread.sleep(5000);	
				} catch (Exception e) {		
					LogScreenshot("INFO","Miscellaneous form not available");	
					e.printStackTrace();	
						
				}		
				js.executeScript("arguments[0].click();", findElement(saveBtnId));		
			}			
		} catch (Exception e) {				
			e.printStackTrace();			
						
		}				
	}		
	
	

	public void editAccountingDetailsOfLineItemForInvoiceNonPO(int rowCount) throws Exception {						
		try {				
			JavascriptExecutor js = (JavascriptExecutor) driver;			
			Thread.sleep(4000);
			scroll_into_view_element(driver.findElement(By.xpath("(//span[@id='einvoiceItemList']//td[contains(@class,'col-actions')]/a[@title='Taxes'])["+rowCount+"]")));
			driver.findElement(By.xpath("(//span[@id='einvoiceItemList']//td[contains(@class,'col-actions')]/a[@title='Taxes'])["+rowCount+"]")).click();				
		
						
			Thread.sleep(5000);			
			if (driver.findElements(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).size() > 0){			
				Thread.sleep(5000);		
				findElement(By.xpath("(//li[@id='tabAccounting']/a[text()='"+getLanguageProperty("Accounting")+"'])[2]")).click();		
				try {		
					Select select= new Select(driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='accountType']/following-sibling::div/select[option]")));	
					select.selectByVisibleText(GLType);	
					Thread.sleep(5000);	
						
					driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/span/input[@aria-required]/following-sibling::label")).click();	
					Thread.sleep(2000);	
					findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();	
					Thread.sleep(2000);	
					LogScreenshot("INFO", "Accounting Details added");	
				} catch (Exception e) {		
					LogScreenshot("INFO", "Accounting Details not added");	
				}		
						
				Thread.sleep(5000);		
				//Miscellaneous		
				try {		
					findElement(By.xpath("//li[@aria-controls='lineLevelItemEform']/a[text()='"+getLanguageProperty("Miscellaneous")+"']")).click();	
					try {	
						flexiFormDetails(true);
					} catch (Exception e) {	
						LogScreenshot("INFO","Flexi-Form is not available");
					}	
					Thread.sleep(5000);	
				} catch (Exception e) {		
					LogScreenshot("INFO","Miscellaneous form not available");	
					e.printStackTrace();	
						
				}		
				js.executeScript("arguments[0].click();", findElement(saveBtnId));		
			}			
		} catch (Exception e) {				
			e.printStackTrace();			
						
		}				
	}		

	public boolean addCatalogItem(){
		boolean result = false;
		Random rnd = new Random();
		int itemCount = 1+rnd.nextInt(100);
		try {
			driver.findElement(By.xpath("//table[@id='itemList_addCollpsBxPad']/tbody/tr[td[2]/a[text()='"+getLanguageProperty("rtt")+"']]/td[last()]//input")).sendKeys(String.valueOf(itemCount));
			findElement(By.xpath("//table[@id='itemList_addCollpsBxPad']/tbody/tr[td[2]/a[text()='"+getLanguageProperty("rtt")+"']]/td[last()]//a[text()='"+getLanguageProperty("Add")+"']")).click();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void editItemQty(int newQty){
		WebElement objItemQty = driver.findElement(By.xpath("//div[@id='itemDialog' and not(contains(@style,'none'))]//input[@name='txtQuantity']"));
		objItemQty.clear();
		objItemQty.sendKeys(String.valueOf(newQty));
		findElement(By.id("saveItemSummary")).click();
	}

	public int getItemQty(){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		int itemQty = Integer.valueOf((String)js.executeScript("return document.evaluate(\"//div[@id='changeItemSummary']//input[@name='txtQuantity']\", document.body, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.value"));
		return itemQty;
	}

	public void editMktPrice(double newPrice){
		WebElement objMktPrice = driver.findElement(By.xpath("//div[@id='itemDialog' and not(contains(@style,'none'))]//input[@name='txtMarketPrice']"));
		objMktPrice.clear();
		objMktPrice.sendKeys(String.valueOf(newPrice));
		findElement(By.id("saveItemSummary")).click();
	}

	public double getItemPrice(){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		double itemPrice = Double.valueOf((String)js.executeScript("return document.evaluate(\"//div[@id='changeItemSummary']//input[@name='txtMarketPrice']\", document.body, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.value"));
		return itemPrice;
	}

	public void bookCostAtItemLevel(String itemLvlCostBookingCategory) throws Exception{
		String objID = null;
		switch(itemLvlCostBookingCategory){
		case "Percentage":
			objID = "rad_item_costing_split_type_percentage";
			break;
		case "Quantity":
			objID = "rad_item_costing_split_type_quantity";
			break;
		case "Quantity proportional to delivery":
			objID = "rad_item_costing_split_type_delivery";
			break;
		}
		findElement(By.xpath("//li[@id='costAllocationTab']/a[text()='"+getLanguageProperty("Cost Allocation")+"']")).click();
		try {
			findElement(By.id("lnkSplitCostingLevelItem"),"Book cost at item Level link").click();
			WebElement objSplitCostCenter = driver.findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Confirm")+"']][div//td[contains(text(),'"+getLanguageProperty("specify cost center information for individual items")+"')]]"));
			objSplitCostCenter.findElement(By.xpath(".//button[span[text()='"+getLanguageProperty("Yes")+"']]")).click();
			switch(itemLvlCostBookingCategory){
			case "Percentage":
				objID = "rad_item_costing_split_type_percentage";
				break;
			case "Quantity":
				objID = "rad_item_costing_split_type_quantity";
				break;
			case "Quantity proportional to delivery":
				objID = "rad_item_costing_split_type_delivery";
				break;
			}
			findElement(By.id(objID)).click();


			driver.findElement(By.xpath("//div[@id='itemAccounting']//label[@for='generalLedger']/following-sibling::div/input")).click();
			findElement(By.xpath("(//ul[contains(@style,'block')]//*[contains(text(),'" + GLAccount + "')])[1]")).click();
			LogScreenshot("INFO", "Cost Allocation Details added");
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	public void deliverItemsToMutiple(List<String>deliverToList, List<String> qtyList) throws Exception{
		findElement(By.xpath("//li/a[text()='"+getLanguageProperty("Delivery and Asset Tagging")+"']")).click();
		findElement(By.id("optMultiSplit")).click();
		int buyerNum = 1;
		for(String buyer : deliverToList){
			buyerNum++;
			findElement(By.xpath("(//table[@id='splitDeliveries']//a[@class='icon add' and contains(@style,'visible')])[1]")).click();
			WebElement objDeliverTo = driver.findElement(By.xpath("(//input[contains(@id,'deliverTo')])["+String.valueOf(buyerNum)+"]"));
			objDeliverTo.clear();
			enterText_AutoComplete(By.xpath("(//input[contains(@id,'deliverTo')])["+String.valueOf(buyerNum)+"]"), buyer);

		}
	}



}
