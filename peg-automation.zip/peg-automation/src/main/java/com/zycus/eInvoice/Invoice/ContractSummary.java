package com.zycus.eInvoice.Invoice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;
import net.bytebuddy.dynamic.scaffold.TypeInitializer.None;

public class ContractSummary extends eInvoice_CommonFunctions {

  private String billingCompany;
  //private String billingBusinessUnit;
  //private String billingLocation;
  //private String CBCostCenter;
  //private String CBProject;
  
  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */
  
  public ContractSummary(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> enterBillingInfo
   * 
   * @author Varun Khurana
   * @since May 2018
   * @return result - True/False
   * @throws None
   */

  public boolean enterBillingInfo(){
    boolean result = false;
    try {
      findElement(By.id("companyAutoComplete")).clear();
      findElement(By.id("companyAutoComplete")).sendKeys(billingCompany);
      findElement(By.id("buAutoComplete")).sendKeys(billingCompany);
      findElement(By.id("locationAutoComplete")).sendKeys(billingCompany);
      findElement(By.xpath("//div[@id='changeInvSummaryTabs']//a[contains(text(),'"+getLanguageProperty("Cost Booking")+"')]")).click();
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

}
