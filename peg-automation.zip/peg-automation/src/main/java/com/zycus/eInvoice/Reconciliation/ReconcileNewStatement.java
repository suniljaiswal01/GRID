package com.zycus.eInvoice.Reconciliation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class ReconcileNewStatement extends eInvoice_CommonFunctions {

  private String batchName;
  private Date stmtDate;
  // private String stmtDate;
  private String bankName;

  private static By pgHead = By.xpath("//h1[span[text()='"+getLanguageProperty("Reconcile New Statement")+"']]");
  private static By processingLoader = By.id("reconciliationList_processing");
  private String filePath;

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * @throws Exception 
   * 
   */

  public ReconcileNewStatement(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
        ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
        String Datasheet_eInvoice =configurationProperties.getProperty("Datasheet_eInvoice");
        String[][] abc = (String[][]) objFunctions.dataProvider("NewStatement", Datasheet_eInvoice);
        this.batchName = "Auto_Batch" + String.valueOf(generateNo());
        this.bankName = abc[0][0];
        Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(abc[0][1]);
        this.stmtDate = date1;
        this.filePath = System.getProperty("user.dir")+configurationProperties.getProperty("upload_csv_path");
  }

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * @param batchName
   * @param bankName
   * @param stmtDate
   * @throws ParseException
   * 
   */

  public ReconcileNewStatement(WebDriver driver, ExtentTest logger, String batchName, String bankName,
      String stmtDate) throws ParseException {
    // String stmtDate) {
    super(driver, logger);
    this.batchName = batchName + String.valueOf(generateNo());
    this.bankName = bankName;
    Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(stmtDate);
    this.stmtDate = date1;
  }

  /**
   * <b>Function:</b> createNewStmt
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param matchChargesWithLine
   * @param paymentDueDate
   * @param filePath
   * @return result - True/False
   * @throws Exception
   */

  public boolean createNewStmt(boolean matchChargesWithLineItems) throws Exception {
    boolean result = false;
    try {
      findElement(By.id("txtBatchName")).sendKeys(batchName);
      if (matchChargesWithLineItems)
        findElement(By.id("txtLineLevel")).click();
      enterText_AutoComplete(By.id("txtBankName"), bankName);
      findElement(By.xpath("//input[@id='txtStatementDate']/following-sibling::img")).click();
      selectDate(stmtDate);
      sendKeys(By.xpath("//*[contains(@id,'attachmentInput')]"), filePath);
      LogScreenshot("INFO", "Statement Details added");      
      waitUntilInvisibilityOfElement(processingLoader);
      // Click 'Upload & Reconcile' button
      clickAndWaitUntilLoaderDisappears(By.id("btnNextGcard"));
      clickAndWaitUntilLoaderDisappears(By
          .xpath("//div[contains(@style,'block')][div/span[text()='"+getLanguageProperty("Information")+"']]//button[span[text()='"+getLanguageProperty("OK")+"']]"));
      LogScreenshot("INFO", "Clicked on Upload & Reconcile");
      Statements objStatements = new Statements(driver, logger);
      if (findElement(objStatements.getPgHead()) != null)
        result = true;
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception();
    }
    return result;
  }

  /**
   * @return the pgHead
   */
  public By getPgHead() {
    return pgHead;
  }

  /**
   * @param pgHead
   *            the pgHead to set
   */
  public void setPgHead(By pgHead) {
    this.pgHead = pgHead;
  }

}
