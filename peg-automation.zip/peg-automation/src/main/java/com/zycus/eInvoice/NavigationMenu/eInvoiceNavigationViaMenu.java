package com.zycus.eInvoice.NavigationMenu;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import common.Functions.eInvoice_CommonFunctions;

public class eInvoiceNavigationViaMenu  extends eInvoice_CommonFunctions {

  public eInvoiceNavigationViaMenu(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  public void createExtentTable(String tab, String subTab) {
    String[][] data = {
        { tab, subTab, "Status",""},
        { "Content.1.1", "Content.2.1", "Content.3.1" },
        { "Content.1.2", "Content.2.2", "Content.3.2" },
        { "Content.1.3", "Content.2.3", "Content.3.3" },
        { "Content.1.4", "Content.2.4", "Content.3.4" }
    };
    Markup m = MarkupHelper.createTable(data);
  }

  public void verifyPageNavigation(String... navigationTabs) throws Exception {

    String tab= navigationTabs[0];
    String subTab= navigationTabs[1];
    boolean pgDisplayed = false;
    switch(tab) {  
    case "Invoice":
      switch(subTab){
      case "Invoices":        
        if (driver.findElements(By.xpath("//div[@class='mnBtn mnBtn-drop setfocus']//span[text()='"+getLanguageProperty("Add")+"']")).size() > 0) {
          if ((driver.findElements(By.xpath("//h1[text()='"+getLanguageProperty("Invoice")+"']")).size() > 0) && (driver.findElements(By.xpath("//table[@id='invoicelisting']")).size() > 0))
            pgDisplayed = true;
        }      
        break;  
      case "e-Invoice Mailbox":
        if (driver.findElements(By.xpath("//div[@class='head clearfix']//h1[text()='"+getLanguageProperty("Invoice")+"']")).size() > 0) {
          if (driver.findElements(By.xpath("//table[@id='invoicelisting']")).size() > 0)         
            pgDisplayed = true;
        }
        break;
      }
      break; 


    case "Approval":
      switch(subTab) {
      case "Approvals":
        if (driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("Approval Requests")+"')]")).size() > 0) {
          if ((driver.findElements(By.xpath("//ul[@class='product-tabs-nav']//li//a[text()='"+getLanguageProperty("Invoice")+"']")).size() > 0) && (driver.findElements(By.xpath("//ul[@class='product-tabs-nav']//li//a[text()='"+getLanguageProperty("Recurring Contract")+"']")).size() > 0))  {      
            if (driver.findElements(By.xpath("//table[@id='workflowApproval']")).size() > 0)   
              pgDisplayed = true;
          }
        }
        break;          
      case "All Requests":
        if (driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("All Requests")+"')]")).size() > 0) {
          if ((driver.findElements(By.xpath("//ul[@class='product-tabs-nav']//li//a[text()='"+getLanguageProperty("Invoice")+"']")).size() > 0) && (driver.findElements(By.xpath("//ul[@class='product-tabs-nav']//li//a[text()='"+getLanguageProperty("Recurring Contract")+"']")).size() > 0))  {      
            if (driver.findElements(By.xpath("//table[@id='workflowApproval']")).size() > 0)   
              pgDisplayed = true;
          }
        }
        break;
      case "My Settings":
        if (driver.findElements(By.xpath("//div[text()='"+getLanguageProperty("Settings")+"']")).size() > 0) {
          if (driver.findElements(By.xpath("//li//label[text()='Delegate Approval From:']")).size() > 0)   
            pgDisplayed = true;
        }
        break;
      }
      break;


    case "PO":
      if (driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("Purchase Orders")+"')]")).size() > 0) {
        if (driver.findElements(By.xpath("//table[@id='polisting']")).size() > 0)   
          pgDisplayed = true;
      }    
      break;



    case "Payment":
      switch(subTab){
      case "Batches":
        if ((driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("Payment Batches")+"')]")).size() > 0) && (driver.findElements(By.id("lnkCreatePaymentBatch")).size() > 0))  {        
          if (driver.findElements(By.xpath("//table[@id='batchlisting']")).size() > 0)   
            pgDisplayed = true;    
        }
      }
      break;


    case "Reports":
      if (driver.findElements(By.xpath("//table[@class='reportsListTable_RMS']")).size() > 0) {
        if (driver.findElements(By.xpath("//div[@class='prepackedRep_RMS']")).size() > 0)   
          pgDisplayed = true;
      }    
      break;

    case "Reconciliation":
      if ((driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("Statements")+"')]")).size() > 0) && (driver.findElements(By.xpath("//a[@id='addBatch']")).size() > 0))  {    
        if (driver.findElements(By.xpath("//table[@id='reconciliationList']")).size() > 0)   
          pgDisplayed = true;
      }    
      break;


    case "Setup":
      switch(subTab){
      case "Customize":
        if ((driver.findElements(By.xpath("//h2[contains(text(),'"+getLanguageProperty("Customize")+"')]")).size() > 0) && (driver.findElements(By.xpath("//h2[contains(text(),'"+getLanguageProperty("Configuration")+"')]")).size() > 0))                  
          pgDisplayed = true;          
      }
      break;


    case "Workflow":
      if ((driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("All Workflows")+"')]")).size() > 0) && (driver.findElements(By.id("curLstForms")).size() > 0))  {
        if (driver.findElements(By.xpath("//div[@id='workflowGrid_processing']")).size() > 0)   

          pgDisplayed = true;  
      }
      break;

    case "eForms":
      switch(subTab){
      case "Process forms":
        if ((driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("All Forms")+"')]")).size() > 0) && (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("New eForm")+"']")).size() > 0))  {
          if (driver.findElements(By.xpath("//div[@id='processFormGrid_wrapper']")).size() > 0)   
            pgDisplayed = true;  
        }
      }

      break;

    case "Uploads":
      if ((driver.findElements(By.xpath("//h1[contains(text(),'"+getLanguageProperty("Uploads")+"')]")).size() > 0) && (driver.findElements(By.id("lnkInvoiceAttachments")).size() > 0))  {    
        if (driver.findElements(By.xpath("//table[@id='uploadsListing']")).size() > 0)   
          pgDisplayed = true;
      }    
      break;

    case "Settings":
      if ((driver.findElements(By.xpath("//h2[contains(text(),'"+getLanguageProperty("Company")+"')]")).size() > 0) && (driver.findElements(By.xpath("//div[@id='systemTenant']/following-sibling::div[@id='company']")).size() > 0))    

        pgDisplayed = true;

      break;

    case "Recurring Contracts":
      if ((driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Add")+"']")).size() > 0))  {  
        if (driver.findElements(By.xpath("//table[@id='contractlisting']")).size() > 0)   
          pgDisplayed = true;
      }    
      break;

    }

    if (pgDisplayed)
      LogScreenshot("Pass", "navigated to " +tab+" - "+subTab+" page");
    else
      LogScreenshot("Fail", "failed to navigate to " +tab+" - "+subTab+" page");    
  }






  public void validateNavigation(String navigationID) throws Exception {
    switch(navigationID){
    case"1":
      try {
        if (driver.findElements(By.xpath("//div[@class='breadCrumb'][contains(text(),'You are here: Track')]")).size() > 0) {
          driver.findElement(By.xpath("//input[@type='button'][@title='"+getLanguageProperty("Create New Entity")+"']")).click();
          if (driver.findElements(By.xpath("//div[@id='selectPopUp']/table//tr[td//div//h2[text()='"+getLanguageProperty("Program")+"']]")).size() > 0)   
            LogScreenshot("PASS", "Entities are displayed");
          else
            LogScreenshot("FAIL", "Entities are not displayed");

          LogScreenshot("Pass", "navigated to Workbench> Track");
        }
      }catch(Exception e) {
        driver.navigate().back();       
        LogScreenshot("Fail", "failed to navigate to Workbench> Track");
      }

      break;
    case"2":
      if (driver.findElements(By.xpath("//div[@class='breadCrumb'][contains(text(),'You are here : Approval ')]")).size() > 0) {  

        if (driver.findElements(By.xpath("//table[@id='approver-grid']")).size() > 0)   
          LogScreenshot("PASS", "Approval grid is displayed");
        else
          LogScreenshot("FAIL", "Approval grid is not displayed");
        LogScreenshot("Pass", "navigated to Workbench> Approval page");
      }
      else {          
        LogScreenshot("Fail", "failed to navigate to Workbench> Approval pag");
      }        
      break;

    case"3":
      if (driver.findElements(By.xpath("//div[@class='breadCrumb']/div[contains(text(),'You are here : My Tasks')]")).size() > 0) {
        if (driver.findElements(By.xpath("//table[@id='approver-grid']")).size() > 0)   
          LogScreenshot("PASS", "Approval grid is displayed");
        else
          LogScreenshot("FAIL", "Approval grid is not displayed");
        LogScreenshot("Pass", "navigated to Workbench> Approval page");

        LogScreenshot("Pass", "navigated to   Workbench> Tasks");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to  Workbench> Tasks");
      }

      break;
    case"4":
      if (driver.findElements(By.xpath("//div[@class='sectiontitle'][contains(text(),'"+getLanguageProperty("Manage Translations")+"')]")).size() > 0) {

        LogScreenshot("Pass", "navigated to Manage Translations");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to  Manage Translations");
      }
      break;
    case"5":
      if (driver.findElements(By.id("createView")).size() > 0) {

        LogScreenshot("Pass", "navigated to   Create View");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to  Create View");
      }
      break;
    case"6":
      if (driver.findElements(By.xpath("//input[@name='Create WorkFlow']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Define Workflow");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Define Workflow");
      }
      break;
    case"7":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Approval Hierarchy")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Approval hierarchy");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Approval hierarchy");
      }
      break;
    case"8":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty(" Notification Template List")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Notification Template List");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Notification Template List");
      }
      break;
    case"9":
      if (driver.findElements(By.xpath("//input[@value='"+getLanguageProperty("Create New Master")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to manage reference master");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to manage reference master");
      }
      break;
    case"10":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Download Historical Data Template")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Import Historical Supplier");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Import Historical Supplier");
      }
      break;
    case"11":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Application Configuration")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Application Configuration");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Application Configuration");
      }
      break;
    case"12":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Data Governance")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Data Governance");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Data Governance");
      }
      break;
    case"13":

      if (driver.findElements(By.xpath("//td[contains(text(),'"+getLanguageProperty("Classification Settings")+"')]")).size() > 0) {

        LogScreenshot("Pass", "navigated to Classification Settings");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Classification Settings");
      }

      break;
    case"14":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Supplier Blacklists")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Supplier Blacklists");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Supplier Blacklists");
      }
      break;
    case"15":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Associated Facilities")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Associated Facilities");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Associated Facilities");
      }
      break;
    case"16":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Manage Users")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Manage Users");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Manage Users");
      }
      break;
    case"17":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty("Manage Roles")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Manage Roles");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Manage Roles");
      }
      break;
    case"18":
      if (driver.findElements(By.xpath("//td[text()='"+getLanguageProperty(" My Notification Preferences ")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to My Preferences");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to My Preferences");
      }
      break;
    case"19":

      if (driver.findElements(By.xpath("//span[@title='"+getLanguageProperty("Pre Canned Reports")+"']")).size() > 0) {

        LogScreenshot("Pass", "navigated to Pre-Packaged Reports");
      }
      else {

        LogScreenshot("Fail", "failed to navigated to Pre-Packaged Reports");
      }
      break;
    }
  }
}

