package com.zycus.eInvoice.Reports;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Reports.Common_Reports;

public class Reports extends Common_Reports {

  private String[] prePackagedReports;
  private String[] reportColumns;

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * @throws Exception 
   * 
   */

  public Reports(WebDriver driver, ExtentTest logger) throws Exception {
    super(driver, logger);
    CommonFunctions1 objFunctions = new CommonFunctions1();
    ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
    String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eInvoice");
    String[][] abc = (String[][]) objFunctions.dataProvider("Pre-Packaged Reports", Datasheet_eInvoice);
    prePackagedReports = abc[0];
    String[][] columnsList = (String[][]) objFunctions.dataProvider("ReportColumnsToAdd", Datasheet_eInvoice);
    reportColumns = columnsList[0];
  }

  /**
   * <b>Function:</b> searchReport
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param reportType
   * @param reportName
   * @return result - True/False
   * @throws Exception
   */

  /*public boolean searchReport(String reportType, String reportName) throws Exception {
    boolean result = false;
    try {
      findElement(By.xpath("//select[@id='optionSelect_RMS']/option[text()='" + reportType + "']")).click();
      findElement(By.id("searchBox_RMS")).sendKeys(reportName);
      findElement(By.id("searchButton")).click();
      waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
      Thread.sleep(2000);
      // if (findElement(By.xpath("//table[@class='reportsListTable_RMS']//tr[*]//a/span[text()='"+reportName+"']"))!=null)
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception();
    }
    return result;
  }*/

  /**
   * <b>Function:</b> viewReportDetails
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param reportName
   * @return result - True/False
   * @throws Exception
   */

  /*public boolean viewReportDetails(String reportName) throws Exception {
    boolean result = false;
    try {
      // findElement(By.xpath("//table[@class='reportsListTable_RMS']//tr[*]//a/span[contains(text(),'"+reportName+"')]")).click();
      findElement(By.xpath("//table[@class='reportsListTable_RMS']//tr[2]/td[1]/div/a/span")).click();
      waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
      ReportDetail objRepDetail = new ReportDetail(driver, logger);
      if (findElement(objRepDetail.getReportLabel()).getAttribute("title").equals(reportName)) {
        result = true;
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception();
    }
    return result;
  }*/

  /**
   * <b>Function:</b> selectMyReports
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param reportName
   * @return result - True/False
   * @throws Exception
   */

  public boolean selectMyReports(String reportName) throws Exception {
    boolean result = false;
    try {
      /*findElement(By.xpath("//div[div[text()='"+getLanguageProperty("My Reports")+"']]//a[@title='" + reportName + "']")).click();
      waitUntilInvisibilityOfElement(By.id("viewdetailsloadingdiv"));
       */

      JavascriptExecutor je = (JavascriptExecutor) driver;    
      WebElement element = driver.findElement(By.xpath("//div[div[text()='"+getLanguageProperty("My Reports")+"']]//a[@title='" + reportName + "']"));  
      je.executeScript("arguments[0].scrollIntoView(true);",element);
      
      Thread.sleep(4000);
      clickAndWaitUntilLoaderDisappears(By.xpath("//div[div[text()='"+getLanguageProperty("My Reports")+"']]//a[@title='" + reportName + "']"), By.id("viewdetailsloadingdiv"));
      viewReportDetails(reportName);
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception();
    }
    return result;
  }

  public boolean searchInvoicePrePackagedReports() throws Exception {
    boolean status=false;
    try {
      for(String reportName: prePackagedReports){
        if (searchReport("Pre-Packaged Reports", reportName)){
          if (viewReportDetails(reportName)){
            LogScreenshot("PASS", reportName+" viewed successfully");
            ReportDetail objRepDetail = new ReportDetail(driver, logger);
            Thread.sleep(5000);
            objRepDetail.closeReportDetails();
            status=true;
          }else
            LogScreenshot("warning","unable to view "+reportName);
        }else
          LogScreenshot("warning","unable to search "+reportName);
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception();
    }
    return status;
  }

  //Chooses a pre-packaged Report randomly to modify
  public boolean modifyReport(){
    boolean status=false;
    Random rnd = new Random();
    try {
      Thread.sleep(5000);
      String reportName = prePackagedReports[rnd.nextInt(prePackagedReports.length)];
      System.out.println("Search report : "+reportName);
      if (searchReport("Pre-Packaged Reports", reportName)){
        if (viewReportDetails(reportName)){
          ReportDetail objRepDetail = new ReportDetail(driver, logger);
          objRepDetail.addReportColumns(reportColumns);
          objRepDetail.closeReportDetails();
           status = true;
        }else
          LogScreenshot("warning","unable to view "+reportName );
      }else
        LogScreenshot("warning","unable to search "+reportName);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return status;
  }

  public void modifyReport(String reportName, String...reportColumns){
    try {
      if (searchReport("Pre-Packaged Reports", reportName)){
        if (viewReportDetails(reportName)){
          ReportDetail objRepDetail = new ReportDetail(driver, logger);
          objRepDetail.addReportColumns(reportColumns);
          objRepDetail.closeReportDetails();
        }else
          LogScreenshot("FAIL","unable to view "+reportName );
      }else
        LogScreenshot("FAIL","unable to search "+reportName );
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void verifyReportModified(String folderName, String reportName, String...reportColumns) throws Exception{
    findElement(By.xpath("//div[@id='scrollbar1_RMS']//ul/li//label[contains(text(),'"+folderName+"')]")).click();
    waitUntilVisibilityOfElement(By.xpath("//select[@id='optionSelect_RMS']/option[@selected and @value='"+folderName+"']"));
    if (searchReport(folderName, reportName)){
      if (viewReportDetails(reportName)){
        boolean allColAdded = true;
        ReportDetail objRepDetail = new ReportDetail(driver, logger);
        for(String columnName : reportColumns){
          if (!objRepDetail.verifyColumnExistsInReport(columnName)){
            LogScreenshot("FAIL",columnName + "not added to the Report : "+reportName+" in folder : "+folderName);
            allColAdded = false;
          }
        }
        if (allColAdded)
          LogScreenshot("PASS","All columns added to the Report : "+reportName+" in folder : "+folderName);
      }else
        LogScreenshot("FAIL","unable to view "+reportName );
    }else
      LogScreenshot("FAIL","unable to search "+reportName );
  }


}
