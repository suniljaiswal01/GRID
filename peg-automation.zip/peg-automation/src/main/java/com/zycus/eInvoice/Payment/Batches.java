package com.zycus.eInvoice.Payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;
import net.bytebuddy.dynamic.scaffold.TypeInitializer.None;

public class Batches extends eInvoice_CommonFunctions {

  By statusXpath = By.xpath("//table[@id='batchlisting']//td[1]/div");

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public Batches(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> createNewBatch
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param None
   * @return result - True/False
   * @throws None
   */

  public boolean createNewBatch(NewPaymentBatch objPaymentBatch) {
    boolean result = false;
    try {
      Thread.sleep(5000);
      findElement(By.id("lnkCreatePaymentBatch"),"+ Create New Batch button").click();
      LogScreenshot("Info", "Create New Batch button clicked");
      if (driver.findElement(objPaymentBatch.getPgHead()) != null)
        result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> searchBatchNo
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param batchNo
   * @return result - True/False
   * @throws None
   */

  public boolean searchBatchNo(String batchNo) throws Exception {
    boolean result = false;
    try {
      Thread.sleep(5000);
      result = filterByText("Batch No", batchNo) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> searchCreatedBy
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param createdBy
   * @return result - True/False
   * @throws None
   */

  public boolean searchCreatedBy(String createdBy) throws Exception {
    boolean result = false;
    try {
      Thread.sleep(5000);
      result = filterByText_AutoComplete("Created By", createdBy) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * <b>Function:</b> searchBankAccount
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param bankAcct
   * @return result - True/False
   * @throws None
   */

  public boolean searchBankAccount(String bankAcct) throws Exception {
    boolean result = false;
    try {
      result = filterByText("Bank Account", bankAcct) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  public boolean searchByStatus(String batchNo) throws Exception {
    boolean result = false;
    try {
      Thread.sleep(5000);
      result = filterByText("Batch No", batchNo) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  public boolean filterByStatus(String checkBoxLbl) throws Exception {

    boolean result = false;
    try {
      waitUntilInvisibilityOfElement(processingLoader);
      Thread.sleep(10000);
      /*WebElement filterIconHeader = driver.findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr')]"));
      if (!filterIconHeader.getAttribute("class").contains("fltr-active")){*/
      findElement(By.xpath("//th[contains(@class,'dev_batchStatusFltrHdr')]//b")).click();
      //filterIconHeader.findElement(By.xpath("//b")).click();
      result = filterByChkbox(checkBoxLbl, statusXpath);
      //}
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }


  public boolean selectActionForPayments(String action) throws Exception {
    boolean result = false;
    waitUntilInvisibilityOfElement(By.xpath("//div[@id='batchlisting_processing'][contains(@style,'block')]"));
    try {
      findElement(By.xpath("//*[@id='batchlisting']/tbody/tr[1]//a[text()='"+getLanguageProperty("Actions")+"']")).click();

      findElement(By.xpath("//*[@id='batchlisting']/tbody/tr[1]//li/a[contains(text(),'" + action + "')]"))

      .click();
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  public boolean issuePayment(String batchNo) throws Exception {
    boolean result = false;
    try {
      WebElement actionBtn = driver.findElement(By.xpath("//table[@id='batchlisting']/tbody/tr[td/a[text()='"+batchNo+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']"));
      actionBtn.click();
      actionBtn.findElement(By.xpath("//following-sibling::ul/li/a[text()='"+getLanguageProperty("Issue Payment")+"']")).click();
      waitUntilVisibilityOfElement(By.id("issuePaymentDialog"));
      Thread.sleep(5000);
      driver.findElement(By.id("paymentComments")).sendKeys("Issue payment");
      LogScreenshot("INFO","Payment Comments added");
      Thread.sleep(2000);
      if(driver.findElements(By.xpath("//input[contains(@id,'txtExRate')]")).size()>0) {
    	  LogScreenshot("INFO","Exchange rates text field present");
    	  driver.findElement(By.xpath("//input[contains(@id,'txtExRate')]")).sendKeys("10");
    	  LogScreenshot("INFO","Exchange rates entered");
      }
      findElement(By.id("issuePayment"),"Issue Payment button").click();
      LogScreenshot("INFO","Issue Payment button clicked");
      waitUntilInvisibilityOfElement(By.xpath("//div[@id='batchlisting_processing'][contains(@style,'block')]"));
      Thread.sleep(6000);
    
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  public boolean editBatch() throws Exception {
    boolean result = false;
    clearAllFilters();
    waitUntilInvisibilityOfElement(By.xpath("//div[@id='batchlisting_processing'][contains(@style,'block')]"));
    filterByStatus("Draft");
    selectActionForPayments("Modify");
    waitUntilVisibilityOfElement(By.id("paymentBatchForm"));
    driver.findElement(By.id("txtBatchComments")).clear();
    driver.findElement(By.id("txtBatchComments")).sendKeys("Edit Payment Batch");
    LogScreenshot("INFO","Batch is being edited");    
    Thread.sleep(2000);
    driver.findElement(By.id("btnSaveAsDraft")).click();  
    waitUntilInvisibilityOfElement(By.xpath("//div[@id='batchlisting_processing'][contains(@style,'block')]"));
    Thread.sleep(2000);
    LogScreenshot("PASS","Batch is saved as draft");
    result = true;
    return result;
  }
  
  
  public boolean verifyBatchStatus(String batchNo, String status) throws Exception {
    boolean result = false;
    try {
      clearAllFilters();
      waitUntilInvisibilityOfElement(By.xpath("//div[@id='batchlisting_processing'][contains(@style,'block')]"));
      Thread.sleep(6000);
      searchByStatus(batchNo);
      if (driver.findElement(By.xpath("//table[@id='batchlisting']//td[@class=' status']//div")).getText().equals(status)) {
        LogScreenshot("PASS",batchNo+" with status "+status+" is searched successfully");
      }
      else
        LogScreenshot("FAIL",batchNo+" not searched with "+status);
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }


}
