package com.zycus.eInvoice.RecurringContracts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class RecurringContractDetails extends eInvoice_CommonFunctions {

  private static By pgHead = By.xpath("//li[@id='lnkInvoice']/span[contains(text(),'"+getLanguageProperty("Recurring Contract")+"')]");

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public RecurringContractDetails(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> downloadReport
   * 
   * @author Varun Khurana
   * @since June 2018
   * @param startDt
   * @param EndDt
   * @return result - True/False
   * @throws Exception
   */

  public boolean verifyContractDetailsForContract(String contractName) {
    boolean result = false;
    try {
      if (driver.findElement(By.xpath("//label[contains(text(),'Contract Name:')]/following-sibling::div/div"))
          .getText().trim().equals(contractName))
        result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }
  
  public boolean verifyReleaseDetailsDisplayed() {
    boolean result = false;
    try {
      if (driver.findElement(By.id("contractReleaseDetailsHead")).isDisplayed()){
        findElement(By.xpath("//h2[@id='contractReleaseDetailsHead']/span")).click();
        if (driver.findElement(By.id("releaseDetailsListing")).isDisplayed()) {
          LogScreenshot("PASS", "Release Details section displayed");
          result = true;
        }
      }else
        LogScreenshot("FAIL", "Release Details section not displayed");
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * @return the pgHead
   */
  public static By getPgHead() {
    return pgHead;
  }

  /**
   * @param pgHead
   *            the pgHead to set
   */
  public static void setPgHead(By pgHead) {
    RecurringContractDetails.pgHead = pgHead;
  }

}
