package com.zycus.eInvoice.Invoice;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> InvoiceNonPO.java
 * <br>
 * <b> Description: </b> create new Invoice for nonPO
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewInvoice: user is able to create a Non PO Invoice 
 * <br>
 * 
 * @author Anisha
 * @since May 2018
 */

public class InvoiceNonPO extends eInvoice_CommonFunctions {

	private String supplierName;
	private String paymentTerm;
	private String currency_value;
	private String purchaseType;
	private String invoiceDate;
	private String headLvlTaxType;
	private String headLvlTaxRate;
	/*private String description;
  private String product_cat;
  private String market_prc;
  private String quantity;
  private String GLType;
  private String GLAccount;
  private By supplierNameId = By.id("txtSupplierName");
  private By paymentTermXpath = By.xpath("//*[@id='slctPaymentTerms']/option[contains(text(),'" + paymentTerm + "')]");
  private By invoiceNoId = By.id("txtInvoiceNumber");
  private By invoiceDateImgXpath = By.xpath("//input[@name='txtInvoiceDate']/following-sibling::img");
  private By addItemImgXpath = By.xpath(".//*[@id='addMoreItems']//span[contains(text(),'"+getLanguageProperty("Add Item")+"')]");
  private By purchaseTypeXpath = By.xpath("//*[@id='slctPurchaseType']/option[contains(text(),'" + purchaseType + "')]");
  private By btnSubmitId = By.xpath("//a[@id='btnSubmit' and text()='Submit']");
  private By confirmationPopupXpath = By.xpath("//div[contains(@class,'workflowDialog ')]//input[contains(@class,'dev_submit ')]");
  private By successBoxId = By.xpath("//div[@id='hedaerSuccessBox']//li");*/
	private String company;
	private String businessUnit;
	private String location;
	private String costCenter;
	private String supplierSelectCategory;


	public InvoiceNonPO(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = System.getProperty("user.dir")
				+ configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("InvoiceNonPONew", Datasheet_eInvoice);
		this.supplierSelectCategory = abc[0][0];
		this.supplierName = abc[0][1];
		this.paymentTerm = abc[0][2];
		this.currency_value = abc[0][3];
		this.invoiceDate = abc[0][4];
		this.purchaseType = abc[0][5];
		this.company = abc[0][6];
		this.businessUnit = abc[0][7];
		this.location = abc[0][8];
		this.costCenter = abc[0][9];
		this.headLvlTaxType = abc[0][10];
		this.headLvlTaxRate = abc[0][11];
		
	}
	/*
  public InvoiceNonPO(WebDriver driver, ExtentTest logger, String supplierName, String paymentTerm,
      String currency_value, String invoiceDate, String purchaseType, String description, String product_cat,
      String market_prc, String quantity, String GLType, String GLAccount) {
    super(driver, logger);
    //this.logger = logger;
    //this.driver = driver;
    this.supplierName = supplierName;
    this.paymentTerm = paymentTerm;
    this.currency_value = currency_value;
    this.purchaseType = purchaseType;
    this.invoiceDate = invoiceDate;
    this.description = description;
    this.product_cat = product_cat;
    this.market_prc = market_prc;
    this.quantity = quantity;
    this.GLType = GLType;
    this.GLAccount = GLAccount;
  }*/

	public InvoiceNonPO(WebDriver driver, ExtentTest logger, String supplierSelectCategory, String supplierName, String paymentTerm, 
			String currency_value,  String invoiceOrCreditMemoDate, String purchaseType, String company, String businessUnit,  String location,  String costCenter, String headLvlTaxType, String headLvlTaxRate) {
		super(driver, logger);
		//this.logger = logger;
		//this.driver = driver;
		this.supplierSelectCategory = supplierSelectCategory;
		this.supplierName = supplierName;
		this.paymentTerm = paymentTerm;
		this.currency_value = currency_value;
		this.purchaseType = purchaseType;
		this.headLvlTaxType = headLvlTaxType;
		
		this.company = company;
		this.businessUnit = businessUnit;
		this.location = location;
		this.costCenter = costCenter;
		this.headLvlTaxRate=headLvlTaxRate;
		/*this.description = description;
    this.product_cat = product_cat;
    this.market_prc = market_prc;
    this.quantity = quantity;
    this.GLType = GLType;
    this.GLAccount = GLAccount;*/
	}

	/**
	 * <b>Function:</b> createNewInvoice
	 * 
	 * @author Anisha
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 * @throws Exception 
	 */
	/*public boolean createNewInvoice() {
    boolean result = false;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    String invoiceNo = String.valueOf(generateNo());
    try {
      enterText_AutoComplete(supplierNameId , supplierName);
      Thread.sleep(3000);
      findElement(paymentTermXpath).click();
      Thread.sleep(2000);
      selectAddress();
      Thread.sleep(2000);
      selectCurrency(currency_value);
      sendKeys(invoiceNoId , invoiceNo);
      WebElement elem = findElement(invoiceDateImgXpath);
      js.executeScript("arguments[0].click()", elem);
      selectDate_v1(invoiceDate);
      findElement(purchaseTypeXpath).click();
      addAttachment();
      scroll_into_view_element(
      findElement(addItemImgXpath ));
      findElement(addItemImgXpath).click();
      Thread.sleep(2000);
      add_item(description, product_cat, market_prc, quantity, GLType);
      Thread.sleep(2000);
      findElement(btnSubmitId).click();
      findElement(confirmationPopupXpath ).click();
      waitUntilVisibilityOfElement(successBoxId );
      LogScreenshot("INFO", "created invoice nonPO : " + invoiceNo);
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;

  }*/

	public String createNewInvoice() throws Exception {
		String invoiceNo = null;

		String invoice = createNewInvoiceOrCreditMemo("invoice",supplierSelectCategory,   supplierName, paymentTerm, 
				currency_value, invoiceDate, purchaseType, company,businessUnit,  location, costCenter, headLvlTaxType, headLvlTaxRate);
		invoiceNo = invoice;
		return invoiceNo;

	}

	public String editInvoiceDetails() throws Exception {
		String invoiceNo=null;
		editInvoice(driver, logger,supplierSelectCategory,   supplierName, paymentTerm, 
				currency_value, invoiceDate, purchaseType, company,businessUnit,  location, costCenter, headLvlTaxType);
		return invoiceNo;
	}

	public void verifySelfAssessedTaxAtHeaderLevel() throws Exception {
		verifySelfAssessedHeaderLevelTax("invoice",supplierSelectCategory,   supplierName, paymentTerm, 
				currency_value, invoiceDate, purchaseType, company,businessUnit,  location, costCenter, headLvlTaxType);  
	}

	public void verifySelfAssessedTaxAtLineLevel() throws Exception {
		verifySelfAssessedLineLevelTax("invoice",supplierSelectCategory,   supplierName, paymentTerm, 
				currency_value, invoiceDate, purchaseType, company,businessUnit,  location, costCenter, headLvlTaxType);
	}


}
