package com.zycus.eInvoice.RecurringContracts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ContractList extends eInvoice_CommonFunctions {

  /** Xpath for all the displayed Status in the Grid */
  //private static By statusXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
  @FindBys(@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[1]/div"))
  private static List<WebElement> objStatus;
  private String delegateApprovalTo = "Chaitali";

  /** Xpath for Action button on first row */
  //private static By actionBtnXpath = By
  //.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
  /*@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")
  private static WebElement objFirstRowActionBtn;*/

  /** ID for the approval comments text area */
  @FindBy(how = How.ID, using="txtContractActivateComment")
  private static WebElement objActivateComment;

  /**ID for contract change comments*/
  @FindBy(how = How.ID, using="txtInvoiceStatusComments")
  private static WebElement changeComments;

  /** Xpath for the 'Approve' button */
  @FindBy(how = How.XPATH, using=".//*[@id='frmContractActivate']//input[contains(@class,'dev_contractActivate')]")
  private static WebElement objActivateBtn;

  @FindBy(how = How.ID, using="status_overlay_deactivating")
  private static WebElement objDeactivatingMsg;

  /** ID for the approval comments text area */
  @FindBy(how = How.ID, using="txtContractDeactivateComment")
  private static WebElement objDeactivateComment;

  /** Xpath for the 'Approve' button */
  @FindBy(how = How.XPATH, using=".//*[@id='frmContractDeactivate']//input[contains(@class,'dev_contractDeactivate')]")
  private static WebElement objDeactivateBtn;

  @FindBy(how = How.ID, using="status_overlay_activating")
  private static WebElement objActivatingMsg;


  /** ID for the approval comments text area */
  //private static By delegateNameId = By.id("txtDelegateName");
  @FindBy(how = How.ID, using="txtDelegateName")
  private static WebElement objDelegateName;

  /** ID for the delegate comments text area */
  //private static By delegateCommentId = By.id("delegateComments");
  @FindBy(how = How.ID, using="delegateComments")
  private static WebElement objDelegateComment;

  /** Xpath for the 'Delegate' button */
  private static By objSaveDelegateBtn = By.id("btnDelegateSave");
  /*@FindBy(how = How.ID, using="btnDelegateSave")
  private static WebElement objSaveDelegateBtn;*/

  /** Xpath for green colored global message indicating Document is delegated */
  private static By objDelegateMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]");
  /*  @FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]")
  private static WebElement objDelegateMsg;*/

  /** Xpath for Action button on first row */
  private static By objFirstRowActionBtn = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
  /*@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")
  private static WebElement objFirstRowActionBtn;*/

  /** Xpath for Action button on first row */
  private static By objSecondRowActionBtn = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
  /*@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//tr[2]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")
  private static WebElement objSecondRowActionBtn;*/

  By confirmationPopupXpath = By
      .xpath("//div[contains(@class,'workflowDialog ')]//input[contains(@class,'dev_submit')]");

  /** ID for the approval comments text area */
  //private static By approveCommentId = By.id("approvalComments");
  @FindBy(how = How.ID, using="approvalComments")
  private static WebElement objApproveComment;

  /** Xpath for the 'Approve' button */
  private static By objApproveBtn = By.xpath(".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]");
  /*@FindBy(how = How.XPATH, using=".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]")
  private static WebElement objApproveBtn;*/

  /** Xpath for green colored global message indicating Document is approved */
  private static By objApprovedMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]");
  /*  @FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]")
  private static WebElement objApprovedMsg;
   */

  /** ID for the reject comments text area */
  //private static By rejectCommentId = By.id("rejectComments");
  @FindBy(how = How.ID, using="rejectComments")
  private static WebElement objRejectComment;

  /** Xpath for the 'Reject' button */
  private static By objRejectBtn = By.xpath("//*[@id='frmReject']//input[contains(@class,'dev_reject')]");
/*  @FindBy(how = How.XPATH, using="//*[@id='frmReject']//input[contains(@class,'dev_reject')]")
  private static WebElement objRejectBtn;*/



  /** Xpath for green colored global message indicating Document is rejected */
  private static By objRejectMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]");
  /*  @FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]")
  private static WebElement objRejectMsg;*/


  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public ContractList(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    PageFactory.initElements(driver, this);
  }

  public boolean filterByStatus(String checkBoxLbl) throws Exception {
    /** Click Status Filter icon */
    findElement(By.xpath("//th[contains(@class,'statusFilter')]//b")).click();
    return filterByChkbox(checkBoxLbl, objStatus);
  }

  public boolean filterByContractName(String contractName) throws Exception {
    return filterByText("Contract Name", contractName);
  }

  public boolean filterByContractStatus(String checkBoxLbl) throws Exception {
    /** Click Status Filter icon */
    findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr ')]//b")).click();
    return filterByChkbox(checkBoxLbl, objStatus);
  }

  /**
   * <b>Function:</b> navigateToContract
   * 
   * @author Varun Khurana
   * @since June 2018
   * @param startDt
   * @param EndDt
   * @return result - True/False
   * @throws Exception
   */

  public void navigateToContract(String contractName) {
    try {
      filterByText("Contract Name", contractName);
      findElement(By.xpath("//table[@id='contractlisting']/tbody/tr/td[2]/a")).click();
      RecurringContractDetails objDetails = new RecurringContractDetails(driver, logger);
      if (driver.findElement(RecurringContractDetails.getPgHead()).isDisplayed()){
        if (objDetails.verifyContractDetailsForContract(contractName))
          LogScreenshot("PASS", "Recurring Contract page displayed for Contract : "+contractName);
        if (objDetails.verifyReleaseDetailsDisplayed())
          LogScreenshot("PASS", "Release Details displayed for Contract : "+contractName);
      }else
        LogScreenshot("FAIL", "Recurring Contract page not displayed for Contract : "+contractName);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public boolean performActionOnContract(String action, String delegateApprovalTo) throws Exception {
    boolean result = false;
    String contractName = null;
    waitUntilInvisibilityOfElement(processingLoader);
    Thread.sleep(5000);
    if (driver.findElements(By.xpath("//table[contains(@class,'dataTable')]//tr//td[contains(text(),'"+getLanguageProperty("No results found")+"')]")).size() > 0)
      LogScreenshot("INFO","No Recurring contracts found");
    else
    {
      contractName = driver.findElement(By.xpath("(//td[@class=' entityStatus'])[1]/a  | (//td[@class=' invoiceNumber'])[1]/a"))
          .getText();
      clickElement(objFirstRowActionBtn);
      if (driver.findElements(By.xpath("//table[contains(@class,'dataTable')]//tr[1]//li/a[contains(text(),'" + action + "')]")).size() > 0) {
        findElement(
            By.xpath("//table[contains(@class,'dataTable')]//tr[1]//li/a[contains(text(),'" + action + "')]"))
        .click();
      }
      else if (driver.findElements(By.xpath("//table[contains(@class,'dataTable')]//tr[2]//li/a[contains(text(),'" + action + "')]")).size() > 0){
        LogScreenshot("INFO", "Item row 2 selected");
        clickElement(objFirstRowActionBtn);
        clickElement(objSecondRowActionBtn);
        findElement(
            By.xpath("//table[contains(@class,'dataTable')]//tr[2]//li/a[contains(text(),'" + action + "')]"))
        .click();        
      }else {
        LogScreenshot("INFO", "No Recurring contracts found to perform action");
      }

      try {
        switch (action) {
        case "Deactivate":
          objDeactivateComment.sendKeys("deactivating the document");
          clickAndWaitUntilElementAppears(objDeactivateBtn, objDeactivatingMsg);
          Thread.sleep(15000);
          if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[1]/div")).getText()
              .equals(getLanguageProperty("Deactivated"))) {
            LogScreenshot("PASS", "Contract : " + contractName + " deactivated");
            result = true;
          }
          break;
        case "Activate":
          objActivateComment.sendKeys("activating the document");
          clickAndWaitUntilElementAppears(objActivateBtn, objActivatingMsg);
          Thread.sleep(15000);
          if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[1]/div")).getText()
              .equals(getLanguageProperty("Activated"))) {
            LogScreenshot("PASS", "Contract : " + contractName + " Activated");           
            result = true;
          }        
          break;

        case "Approve":
          objApproveComment.sendKeys("approving the document");
          clickAndWaitUntilElementAppears(objApproveBtn, objApprovedMsg);      
          Thread.sleep(15000);
          clrAllFilters();
          Thread.sleep(10000);

          if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[2]/div")).getText()
              .equals(getLanguageProperty("Approved"))) {
            LogScreenshot("PASS", "Contract : " + contractName + " approved");

            result = true;
          }
          break;
        case "Delegate":
          enterText_AutoComplete(objDelegateName, delegateApprovalTo);
          objDelegateComment.sendKeys("delegating the document");
          clickAndWaitUntilElementAppears(objSaveDelegateBtn, objDelegateMsg);
          Thread.sleep(8000);
          clrAllFilters();

          if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[2]/div")).getText()
              .equals(getLanguageProperty("Delegated"))) {
            LogScreenshot("PASS", "Contract : " + contractName + " delegated");

            result = true;
          }
          break;
        case "Reject":
          objRejectComment.sendKeys("rejecting the document");
          clickAndWaitUntilElementAppears(objRejectBtn, objRejectMsg);
          Thread.sleep(8000);
          clrAllFilters();

          if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[2]/div")).getText()
              .equals(getLanguageProperty("Rejected"))) {
            LogScreenshot("PASS", "Contract : " + contractName + " rejected");

            result = true;
          }
          break;
        case "View":
          String contractNamePage;
          contractNamePage = driver.findElement(By.xpath("//div[@class='cntPnl']//span[@class='val']"))
              .getText();

          if (contractNamePage.equals(contractName)) {  
            LogScreenshot("PASS", "Contract : " + contractName + " Viewed");
            /*driver.findElement(By.xpath("//div[@class='cntPnl']//a[contains(@class,'back')]")).click();
            waitUntilInvisibilityOfElement(processingLoader);*/
            result = true;
          }
          break;
        case "Edit":
          driver.findElement(By.id("slctPaymentTerms")).click(); 
          driver.findElement(By.xpath("//select[@id='slctPaymentTerms']/option[@value='Net12']")).click();          
          changeComments.sendKeys("Payment terms updated");          
          driver.findElement(By.id("btnSubmit")).click();
          setApproversCount();
          findElement(confirmationPopupXpath).click();
          waitUntilVisibilityOfElement(By.id("status_overlay_updateInvoice"));
          result = true;                    

          break;
        }

        waitUntilInvisibilityOfElement(processingLoader);
      } catch (Exception e) {
        /*Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_ESCAPE);
        robot.keyRelease(KeyEvent.VK_ESCAPE);*/
      }
    }    

    return result;
  }

}
