package com.zycus.eInvoice.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class OnlineHelp extends eInvoice_CommonFunctions {

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public OnlineHelp(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> clickCreateWorkflow
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param displayName
   * @return result - True/False
   * @throws Exception
   */

  public boolean verifyOnlineHelpPage(String onlineHelpManualHeader) throws Exception {
    boolean result = false;
    try {
      //Switch to tab 'Purpose'
      String parent = driver.getWindowHandle();
      switchWindowHandles(parent, "Purpose");
      Thread.sleep(2000);
      WebElement objHelpManualHeader = driver.findElement(By.id("c1headerText"));
      Assert.assertEquals(objHelpManualHeader.getText(), onlineHelpManualHeader);
      WebElement objTopicHeader = driver.findElement(By.xpath("//div[@id='c1topic']/h2/a"));
      Assert.assertEquals(objTopicHeader.getText(), "Purpose");
      result = true;
      driver.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

}
