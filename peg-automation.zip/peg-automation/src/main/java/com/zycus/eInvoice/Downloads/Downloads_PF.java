package com.zycus.eInvoice.Downloads;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class Downloads_PF extends eInvoice_CommonFunctions {

  //private WebDriver driver;
  //private ExtentTest logger;
  private String APReportCriteria;
  //private By processingLoader = By.id("downloadsGrid_processing");
  
  @FindBy(how = How.XPATH, using = "//img[@class='ui-datepicker-trigger' and contains(@alt,'start date')]")
  private static WebElement objStartDtImg;
  
  @FindBy(how = How.XPATH, using = "//img[@class='ui-datepicker-trigger' and contains(@alt,'end date')]")
  private static WebElement objEndDtImg;
  
  @FindBy(how = How.ID, using = "btnSubmit")
  private static WebElement objSubmitBtn;
  
  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public Downloads_PF(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    //this.driver = driver;
    //this.logger = logger;
    PageFactory.initElements(driver, this);
  }

  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public Downloads_PF(WebDriver driver, ExtentTest logger, String APReportCriteria) {
    super(driver, logger);
    //this.driver = driver;
    //this.logger = logger;
    this.APReportCriteria = APReportCriteria;
    PageFactory.initElements(driver, this);
  }

  /**
   * <b>Function:</b> downloadReport
   * 
   * @author Varun Khurana
   * @since June 2018
   * @param startDt
   * @param EndDt
   * @return result - True/False
   * @throws Exception
   */

  public boolean downloadReport(String startDt, String EndDt) {
    boolean result = false;
    try {
      findElement(By.xpath("//select[@id='criteriabased']/option[text()='" + APReportCriteria + "']")).click();
      //findElement(By.id("dateRadioRange"));
      objStartDtImg.click();
      selectDate_v1(startDt);
      objEndDtImg.click();
      selectDate_v1(EndDt);
      clickAndWaitUntilLoaderDisappears(objSubmitBtn);
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }
  
  /**
   * <b>Function:</b> downloadReport
   * 
   * @author Varun Khurana
   * @since June 2018
   * @param monthsSince
   * @return result - True/False
   * @throws Exception
   */
  
  public boolean downloadReport(int monthsSince) {
    boolean result = false;
    try {
      findElement(By.xpath("//select[@id='criteriabased']/option[text()='" + APReportCriteria + "']")).click();
      findElement(By.xpath("//select[@id='monthVal']/option[@value='"+String.valueOf(monthsSince)+"']"));
      clickAndWaitUntilLoaderDisappears(objSubmitBtn);
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

}
