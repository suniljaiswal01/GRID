package com.zycus.eInvoice.Invoice;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.logging.Logs;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.ZSN.MyInvoices.CreateNonPOInvoice;
import com.zycus.eInvoice.Approval.Approval;
import com.zycus.eInvoice.PO.CreditMemoagainstPO;
import com.zycus.eInvoice.PO.PurchaseOrder;
import com.zycus.eInvoice.Uploads.Uploads;

import common.Functions.eInvoice_CommonFunctions;
import net.bytebuddy.dynamic.scaffold.TypeInitializer.None;

public class Invoices extends eInvoice_CommonFunctions {

	private String invoiceDate;
	//private String invoiceNo;
	private String supplierName;
	private String paymentTerm;
	private String purchaseType;
	private String currency_value;
	private String description;
	private String product_cat;
	private String market_prc;
	private String quantity;
	private String creditMemoDate;
	private String GLType;

	private static By InvoiceHeader = By.xpath("//h1[@class='pgHead']");
	private static By processingLoader = By.id("invoicelisting_processing");
	private static By invProcessingLoader = By.xpath("//div[@id='invoicelisting_processing' and contains(@style,'block')]");
	//private By tableXpath = By.xpath("//table[@id='invoicelisting']");
	//private By docTypeXpath = By.xpath("//table[@id='invoicelisting']//tr[*]/td[3]");
	private static By statusXpath = By.xpath("//table[@id='invoicelisting']//td[1]/div");
	private static By referenceXpath = By.xpath("//table[@id='invoicelisting']//td[5]");
	private static By docTypeXpath = By.xpath("//table[@id='invoicelisting']//td[3]");
	private static By docDateXpath = By.xpath("//table[@id='invoicelisting']//td[contains(@class,'invoiceDate')]");
	private static By docDueDateXpath = By.xpath("//table[@id='invoicelisting']//td[contains(@class,'invoiceDueDate')]");
	private static By amountXpath = By.xpath("//table[@id='invoicelisting']//td[contains(@class,'amount') and not(contains(@class,'paidamount'))]");
	private static By filterBtnXpath = By.xpath(
			"//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='"+getLanguageProperty("Filter")+"']");
	private static By paginateXpath = By.xpath("//*[@id='invoicelisting_paginate']//input[@name='text']");
	private static By saveFavId = By.xpath("//a[contains(@id,'saveFavorite')]");
	//private By favFilterPopupId = By.id("favouriteFilterPopup");
	private static By favViewPopupId = By.id("new_favoriteViewPopup");
	//private By favContinueId = By.id("favourite-continue");
	private static By revertFavId = By.id("revertMultipleFavorite");
	private static By voidInvoiceCommentId = By.id("txtInvoiceCancelComment");
	private static By voidCreditMemoCommentId = By.id("txtCMCancelComment");
	private static By closeInvoiceCommentId = By.id("txtInvoiceCloseComment");
	private static By returnInvoiceCommentId = By.id("txtInvoiceReturnComment");
	private static By restrictPaymentCommentId = By.id("txtAdjustAmountComment");
	private static By adjustCreditCommentId = By.id("txtInvoiceAdjustComment");
	private static By saveDraftId = By.id("saveAsDraft");
	By confirmationPopupXpath = By
			.xpath("//div[contains(@class,'workflowDialog ')]//input[contains(@class,'dev_submit ')]");
	By successBoxId = By.xpath("//div[@id='headerSuccessBox']//li");

	private static By updateInvStatusXpath = By.xpath(".//*[@id='status_overlay_updateInvoice']");
	private String GLAccount;
	private String company;
	private String businessUnit;
	private String location;
	private String costCenter;
	private String supplierSelectCategory;
	private String headLvlTaxType;
	private String headLvlTaxRate;
	SoftAssert softAssert= new SoftAssert();
	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * @throws Exception 
	 * 
	 */

	public Invoices(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
	}

	public Invoices(WebDriver driver, ExtentTest logger, String supplierSelectCategory, String supplierName) throws Exception {
		super(driver, logger);
		this.supplierSelectCategory =  supplierSelectCategory;
		this.supplierName = supplierName;
	}



	/**
	 * Constructor for the class
	 * @param driver
	 * @param logger
	 * @param supplierName
	 * @param purchaseType
	 * @param creditMemoDate
	 * @param currency_value
	 * @param description
	 * @param product_cat
	 * @param market_prc
	 * @param quantity
	 * @param GLType
	 */

	// for CM without reference
	public Invoices(WebDriver driver, ExtentTest logger, String supplierSelectCategory, String supplierName, String currency_value,
			String creditMemoDate, String purchaseType, String company, String businessUnit, String location, String costCenter, String headLvlTaxType) {
		super(driver, logger);
		this.supplierSelectCategory = supplierSelectCategory;
		this.supplierName = supplierName;
		this.purchaseType = purchaseType;
		this.creditMemoDate = creditMemoDate;
		this.currency_value = currency_value;
		this.company = company;
		this.businessUnit = businessUnit;
		this.location = location;
		this.costCenter = costCenter;
		this.headLvlTaxType = headLvlTaxType;
		this.headLvlTaxRate=  headLvlTaxRate;
	}

	/**
	 * Constructor for the class
	 * @param driver
	 * @param logger
	 * @param supplierName
	 * @param invoiceDate
	 * @param paymentTerm
	 * @param purchaseType
	 * @param currency_value
	 * @param description
	 * @param product_cat
	 * @param market_prc
	 * @param quantity
	 * @param GLType
	 */

	// for nonPO
	public Invoices(WebDriver driver, ExtentTest logger, String supplierSelectCategory, String supplierName, String paymentTerm, String currency_value,
			String invoiceDate, String purchaseType, String headLvlTaxType) {
		super(driver, logger);
		this.invoiceDate = invoiceDate;
		this.supplierSelectCategory = supplierSelectCategory;
		this.supplierName = supplierName;
		this.paymentTerm = paymentTerm;
		this.purchaseType = purchaseType;
		this.currency_value = currency_value;
		this.headLvlTaxType = headLvlTaxType;
		this.headLvlTaxRate= headLvlTaxRate;
		this.company = company;
	}



	/**
	 * <b>Function:</b> changeNoOfRecordsPerPage
	 * 
	 * @author Anisha
	 * @param noOfRecord
	 * @since May 2018
	 * @throws Exception
	 * @return status
	 */
	//public boolean changeNoOfRecordsPerPage(int noOfRecord) throws Exception {
	public void changeNoOfRecordsPerPage() throws Exception {
		Random rnd = new Random();
		int optionsCount = driver.findElements(By.xpath("//select[@name='invoicelisting_length']/option")).size();
		int noOfRecord = Integer.parseInt(findElement(By.xpath("//select[@name='invoicelisting_length']/option["
				+ String.valueOf(2 + rnd.nextInt(optionsCount - 1)) + "]")).getAttribute("value"));

		findElement(By.xpath("//select[@name='invoicelisting_length']/option[text()='" + noOfRecord + "']"))
		.click();

		waitUntilInvisibilityOfElement(processingLoader);
		int rowsDisplayed = driver.findElements(By.xpath("//table[@id='invoicelisting']/tbody/tr")).size();
		if (rowsDisplayed==noOfRecord)
			LogScreenshot("Pass", "Number of records changed to "+noOfRecord);
		else
			LogScreenshot("Fail", "Number of records not changed to "+noOfRecord);
	}

	/**
	 * <b>Function:</b> navigateToPageNo
	 * 
	 * @author Anisha
	 * @param pageNo
	 * @since May 2018
	 * @throws Exception
	 * @return status
	 */
	public void navigateToPageNo() throws Exception {
		Random rnd = new Random();
		waitUntilInvisibilityOfElement(By.id("invoicelisting_processing"));
		Thread.sleep(8000);
		int totalPages = Integer.parseInt((driver.findElement(By.xpath("//li[@class='text nOf']/label")).getText().split(" "))[1]);
		int pageNo = 2+rnd.nextInt(totalPages);
		driver.findElement(paginateXpath).clear();

		searchAndWaitUntilLoaderDisappears(paginateXpath, String.valueOf(pageNo), processingLoader);
		int displayedPageNo = Integer.parseInt(driver.findElement(paginateXpath).getAttribute("value"));
		if (displayedPageNo==pageNo)
			LogScreenshot("PASS","Navigated to page number: "+pageNo);
		else
			LogScreenshot("FAIL","Not Navigated to page number: "+pageNo);  

	}

	/**
	 * <b>Function:</b> saveViewAsFavorite
	 * 
	 * @author Anisha
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public boolean saveViewAsFavorite() throws Exception {
		boolean result = false;
		Random rnd = new Random();
		try {

			waitUntilInvisibilityOfElement(By.id("invoicelisting_processing"));
			Thread.sleep(5000);
			clrAllFilters();
			Thread.sleep(5000);
			findElement(saveFavId,"Save View as Favorite link").click();
			waitUntilVisibilityOfElement(By.xpath("//span[text()='"+getLanguageProperty("Create new view")+"']"));
			Thread.sleep(3000);
			//if (findElement(favFilterPopupId).isDisplayed())
			driver.findElement(By.xpath("//span[text()='"+getLanguageProperty("Create new view")+"']")).click();
			Thread.sleep(5000);
			if (findElement(favViewPopupId).isDisplayed()){
				driver.findElement(By.id("favoriteNewName")).sendKeys("MyFavoriteName_"+String.valueOf(rnd.nextInt(9999)));
				findElement(By.xpath("//div[@id='new_favoriteViewPopup']//input[@value='"+getLanguageProperty("Save")+"']"),"Save button").click();
			}

			// TODO add wait until invisible - processing element
			waitUntilInvisibilityOfElement(processingLoader);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			LogScreenshot("FAIL", "unable to create Favorite view");
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
		}
		return result;
	}

	/**
	 * <b>Function:</b> revertToDefaultView
	 * 
	 * @author Anisha
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public void revertToDefaultView() throws Exception {
		findElement(revertFavId, "Revert to eInvoice filter link").click();
		waitUntilInvisibilityOfElement(By.xpath("//span[@class='currentActiveView' and contains(@style,'none')]"));
		if (!driver.findElement(revertFavId).isDisplayed())
			LogScreenshot("Pass", "View Reverted to Default");
		else
			LogScreenshot("Fail", "View not reverted to Default");

	}

	public void deleteFavView(String favView) throws Exception {
		findElement(By.id("listFavoriteView"),"Favorite View link").click();
		try {
			findElement(By.xpath("//div[@class='favoriteviewList']/table/tbody//td/a[text()='"+favView+"']")).click();
			//findElement(By.xpath("//div[contains(@class,'promptbx iConfirmBox')]//button/span[text()='"+getLanguageProperty("Delete")+"']"), "Delete icon").click();
			waitUntilInvisibilityOfElement(processingLoader);
		} catch (Exception e) {}
		findElement(By.id("listFavoriteView"), "Favorite View link").click();
		if (!(driver.findElements(By.xpath("//div[@class='favoriteviewList']/table/tbody//td/a[text()='"+favView+"']")).size()==1))
			LogScreenshot("Pass", "Favorite View "+favView + " deleted");
		else
			LogScreenshot("Fail", "Favorite View "+favView + " could not deleted");
	}


	/**
	 * <b>Function:</b> editInvoice
	 * 
	 * @author Anisha
	 * @param none
	 * @since May 2018
	 * @throws Exception
	 * @return status
	 */
	public boolean editInvoiceCreditMemo(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType, String headLvlTaxRate) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(invProcessingLoader);
			filterByDocType("Invoice");
			Thread.sleep(5000);
			filterByStatus("Draft");
			Thread.sleep(5000);
			filterBySupplier(supplierName);
			waitUntilInvisibilityOfElement(invProcessingLoader);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ajaxGridLoading']"));
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']")); 
			Thread.sleep(5000);
			selectAction("Edit");  
			InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
					currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headLvlTaxRate);
			objInv.editInvoiceDetails();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean editCreditMemo(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType, String headLvlTaxRate) throws Exception {
		boolean result = false;
		try {
			filterByDocType("Credit Memo");
			Thread.sleep(5000);
			filterCreditMemoByStatus("Draft");
			Thread.sleep(5000);
			filterBySupplier(supplierName);
			Thread.sleep(5000);
			waitUntilInvisibilityOfElement(processingLoader);
			selectAction("Edit");  
			InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
					currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headLvlTaxRate);
			objInv.editInvoiceDetails();      
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> createInvoiceagainstPO
	 * 
	 * @author Anisha
	 * @param invoiceNo
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public String[] createInvoiceAgainstPO(String PO, String buyer) throws Exception {
		boolean result = false;
		String[] invoiceCreditMemo = new String[2];
		try {
			Thread.sleep(1000);
			addInvoiceOrCreditMemo("Invoice", "Against PO");
			findElement(By.xpath("//div/button[contains(@class,'pri')]/span[text()='"+getLanguageProperty("Continue")+"']"), "Continue button under 'Confirm' popup").click();
			PurchaseOrder objPO = new PurchaseOrder(driver, logger);
			Thread.sleep(2000);
			String invoiceNo = objPO.addInvoice(PO, buyer);
			invoiceCreditMemo[0]=invoiceNo;
			if (findElement(objPO.getPOHeader()).getText().contains("Purchase Order")){
				LogScreenshot("PASS", "Redirected to Purchase Orders page");
				result = true;
			} else
				LogScreenshot("FAIL", "Not Redirected to Purchase Orders page");

			addCreditMemoOnPoPage();
			CreditMemoagainstPO objCreditMemo = new CreditMemoagainstPO(driver, logger);
			String creditMemoNo = objCreditMemo.createCreditMemo();

			invoiceCreditMemo[1]=creditMemoNo;

		} catch (Exception e) {
			LogScreenshot("FAIL", "unable to create Invoice/Credit memo against PO");
			if (driver.findElements(By.id("cancelInvoice")).size() > 0)
				driver.findElement(By.id("cancelInvoice")).click();
			e.printStackTrace();
		}
		return invoiceCreditMemo;
	}

	public void addCreditMemoOnPoPage() throws Exception {
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		WebElement addInvoiceBtn= driver.findElement(By.xpath("//*[@class='b-button b-primary b-small mnBtnTxt']"));
		action. moveToElement(addInvoiceBtn). perform();
		WebElement creditMemoBtn= driver.findElement(By.id("createCreditMemo"));
		action.moveToElement(creditMemoBtn).click().perform();
		waitUntilVisibilityOfElement(By.id("frmInvoice"));

	}

	/**
	 * <b>Function:</b> createInvoiceNonPO
	 * 
	 * @author Anisha
	 * @param invoiceNo
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public String createInvoiceNonPO(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType, String headLvlTaxRate) throws Exception {
		String invoiceNo = null;
		String invoice = null;
		try {
			addInvoiceOrCreditMemo("Invoice", "Non-PO");  
			InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
					currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headLvlTaxRate);
			invoiceNo = objInv.createNewInvoice();
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(8000);
			if (driver.findElements(By.xpath("//h1[@class='pgHead' and text()='Invoice']")).size() > 0){
				LogScreenshot("PASS", "Navigated to create Invoice page");
				invoice = invoiceNo;
			} else
				LogScreenshot("FAIL", "unable to navigate to create Invoice page");
		} catch (Exception e) {

			e.printStackTrace();
		}
		return invoice;
	}


	/**
	 * <b>Function:</b> createCreditMemoagainstPO
	 * 
	 * @author Anisha
	 * @param invoiceNo
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public String createCreditMemoAgainstPO(String PO, String project) throws Exception {
		String creditMemo = null;
		try {
			addInvoiceOrCreditMemo("Credit Memo", "Against PO");
			findElement(By.xpath("//div/button[contains(@class,'pri')]/span[text()='"+getLanguageProperty("Continue")+"']"), "Continue button under 'Confirm' popup").click();
			//PurchaseOrder objPO = new PurchaseOrder(driver, logger, invoiceNo, invoiceDate);
			Thread.sleep(5000);

			PurchaseOrder objPO = new PurchaseOrder(driver, logger);
			String creditMemoNo = objPO.addCreditMemo(PO, project);
			if (findElement(objPO.getPOHeader()).getText().contains("Purchase Order")) {
				LogScreenshot("INFO", "Redirected to Purchase Orders page");
				creditMemo = creditMemoNo;

			} else      
				LogScreenshot("INFO", "Not Redirected to Purchase Orders page");
		} catch (Exception e) {
			LogScreenshot("FAIL", "unable to create Invoice against PO");
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
			e.printStackTrace();
		}
		return creditMemo;
	}


	/**
	 * <b>Function:</b> createCreditMemowithoutReference
	 * 
	 * @author Anisha
	 * @param
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public String createCreditMemowithoutReference(String supplierSelectCategory, String supplierName,
			String currency_value, String creditMemoDate, String purchaseType,String itemNo, String company, String businessUnit, String location, String costCenter,String headerLevelTaxType, String headLvlTaxRate) throws Exception {
		String creditMemo = null;

		addInvoiceOrCreditMemo("Credit Memo", "Without Reference");
		if (driver.findElement(By.xpath("//*[@id='cntInvoice']//span[text()='"+getLanguageProperty("Credit Memo")+"']")).isDisplayed()) {
			LogScreenshot("PASS", "Navigated to Invoice => Credit Memo page");
			CreditMemowithoutReference objCreditMemo = new CreditMemowithoutReference(driver, logger, supplierSelectCategory, supplierName,
					currency_value, creditMemoDate, purchaseType, company, businessUnit, location, costCenter, headerLevelTaxType, headLvlTaxRate);
			String creditMemoNo = objCreditMemo.createCreditMemo();
			creditMemo = creditMemoNo;
		} else
			LogScreenshot("FAIL", "Unable to navigate to Invoice => Credit Memo page");
		return creditMemo;
	}

	public String verifyCreditMemoOrInvoiceStatus(String documentNo) throws Exception{
		waitUntilInvisibilityOfElement(By.id("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		clearAllFilters();
		Thread.sleep(2000);
		System.out.println(documentNo);
		filterByDocNo(documentNo);
		waitUntilInvisibilityOfElement(By.id("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		//String flag= driver.findElement(statusXpath).getText();
		String flag= driver.findElement(By.xpath("//table[@id='invoicelisting']//tr[td[contains(@class,'invoiceNumber')]/a[text()='"+documentNo+"']]/td[1]/div")).getText();
		if (flag.contains("Submitted")) {
			LogScreenshot("INFO","Invoice created in Submitted status");
			Thread.sleep(5000);
			findElement(By.xpath("(//table[@id='invoicelisting']//td[@class='actions iAct iNum actionsAlign actionHTML poactions']//a)[1]")).click();
			findElement(By.xpath("(//table[@id='invoicelisting']//td[@class='actions iAct iNum actionsAlign actionHTML poactions']//div//li//a[text()='"+getLanguageProperty("Confirm and Match")+"'])")).click();
			LogScreenshot("INFO","Invoice- Confirmed and matched");
			waitUntilInvisibilityOfElement(By.id("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			Thread.sleep(5000);
		}
		String status= driver.findElement(By.xpath("//table[@id='invoicelisting']//tr[td[contains(@class,'invoiceNumber')]/a[text()='"+documentNo+"']]/td[1]/div")).getText();
		System.out.println(status);
		if(status.equals("In Approval") || status.equals("Approved")) {
			LogScreenshot("PASS", "Invoice is displayed with status "+status);
		}else
			LogScreenshot("PASS", "Invoice is not displayed");
		return status;
	}

	public boolean verifyCreditMemoOrInvoiceStatusonPO(String status) throws Exception{
		Thread.sleep(2000);
		return driver.findElement(statusXpath).getText().equals(status)?true:false;
	}


	/**
	 * <b>Function:</b> user is able to Void/ Close/ Return/ Adjust Credits/
	 * Restrict Payment of an invoice.
	 * 
	 * @author Anisha
	 * @param
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	public boolean takeActionOnInvoice(String action) throws Exception {
		boolean result = false;
		try {
			/*  selectAction(action);*/    
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//*[@id='invoicelisting']//tr[td//div[text()='"+getLanguageProperty("Approved")+"']])[1]//div//a[text()='"+getLanguageProperty("Actions")+"']")).click();
			driver.findElement(By.xpath("(//*[@id='invoicelisting']//tr[td//div[text()='"+getLanguageProperty("Approved")+"']])[1]//div//a[text()='"+getLanguageProperty("Actions")+"']//..//li//a[text()='"+action+"']")).click();

			Thread.sleep(5000);
			if (driver.findElements(By.xpath("//div[@role='dialog' and contains(@style, 'block')]/div/span[contains(text(),'"+getLanguageProperty("Alert")+"')]")).size() > 0){
				LogScreenshot("FAIL", "unable to perform : "+action+ " on invoice" );        
				findElement(By.xpath("//div[@role='dialog' and contains(@style, 'block')][div/span[contains(text(),'"+getLanguageProperty("Alert")+"')]]//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
				//driver.switchTo().alert().accept();
			} else {
				switch (action) {
				case "Void Invoice":
					driver.findElement(voidInvoiceCommentId).sendKeys("void invoice comment");
					LogScreenshot("INFO", "Performing "+action);  
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'invoiceCancel')]"), By.xpath("//*[@id='status_overlay_cancellingInvoice']/div"));
					if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
						driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
						result = false;
					}
					result = true;
					break;
				case "Void Credit Memo":
					driver.findElement(voidCreditMemoCommentId).sendKeys("void Credit Memo comment");
					LogScreenshot("INFO", "Performing "+action);  
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'CMCancel')]"), By.xpath("//*[@id='status_overlay_cancellingCreditMemo']/div"));
					if (driver.findElement(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).isDisplayed()) {
						driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
						result = false;
					}
					result = true;
					break;
				case "Close":
					driver.findElement(closeInvoiceCommentId).sendKeys("close invoice comment");
					LogScreenshot("INFO", "Performing "+action);  
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'invoiceClose')]"), By.xpath("//*[@id='status_overlay_closingInvoice']/div"));
					if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
						driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
						result = false;
					}
					result = true;
					break;
				case "Return":
					driver.findElement(returnInvoiceCommentId).sendKeys("return invoice comment");
					LogScreenshot("INFO","Performing "+action);  
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'invoiceReturn')]"), By.xpath("//*[@id='status_overlay_returnInvoice']/div"));
					if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
						driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
						result = false;
					}
					result = true;
					break;
				case "Adjust Credit":
					driver.findElement(adjustCreditCommentId).sendKeys("Adjust Credit comment");
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'invoiceAdjust')]"), By.xpath("//*[@id='status_overlay_adjustingInvoice']/div"));
					if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
						driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
						driver.findElement(By.xpath("//form[@id='frmAdjustCredit']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
						result = false;
					}  
					result = true;
					break;
				case "Restrict Payment":
					driver.findElement(restrictPaymentCommentId).sendKeys("restrict payment comment");
					clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'adjustAmount')]"), By.xpath("//*[@id='status_overlay_adjustingAmount']/div"));
					if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
						driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
						driver.findElement(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
						result = false;
					}
					result = true;
					break;
				case "Edit":
					break;
				case "Resend for integration":
					break;
				}
				/*if (driver.findElements(By.xpath("//div[@class='ui-widget-overlay ui-front']")).size() > 0)
          waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"));
        else*/ 
				if (driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')]")).size() > 0){
					LogScreenshot("FAIL", "unable to perform : "+action+ " on invoice");
					findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
					if (driver.findElements(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).size() > 0)
						driver.findElement(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
				}
			}
		} catch (Exception e) {
			LogScreenshot("FAIL", "unable to perform : "+action+ " on invoice");
			findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')]//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
			//driver.findElement(By.xpath("//a[@title='"+getLanguageProperty("Close")+"']")).click();
			if (driver.findElements(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).size() > 0)
				driver.findElement(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();

			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
			//driver.switchTo().alert().accept();
			e.printStackTrace();
		}
		return result;
	}

	public void takeActionOnRecurringContract(String action) throws Exception {
		try {
			selectAction(action);
			Thread.sleep(2000);
			if (driver.findElements(By.xpath("//div[@role='dialog' and contains(@style, 'block')]/div/span[contains(text(),'"+getLanguageProperty("Are you sure")+"')]")).size() > 0){
				LogScreenshot("FAIL", "unable to perform : "+action+ " on invoice");
				findElement(By.xpath("//div[@role='dialog' and contains(@style, 'block')]/div/span[contains(text(),'"+getLanguageProperty("Are you sure")+"')]/../..//button[span[text()='"+getLanguageProperty("Keep")+"']]")).click();
			}
			switch (action) {
			case "Edit":
				driver.findElement(By.id("txtInvoiceStatusComments")).sendKeys("contract change comments");
				clickAndWaitUntilLoaderDisappears(By.id("btnSubmit"), By.xpath("//*[contains(@id,'status_overlay')]"));
				if (driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[contains(text(),'"+getLanguageProperty("Submit for approval")+"')]]")).size() > 0)
					driver.findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[contains(text(),'"+getLanguageProperty("Submit for approval")+"')]]//input[@value='"+getLanguageProperty("Send for confirmation")+"']")).click();
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='status process']"));
				waitUntilInvisibilityOfElement(processingLoader);
				break;
			}
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"));
		} catch (Exception e) {
			LogScreenshot("FAIL", "unable to perform : "+action+ " on invoice" );

			e.printStackTrace();
		}
	}


	/**
	 * <b>Function:</b> addInvoiceOrCreditMemo
	 * 
	 * @author Anisha
	 * @param addItem,subItem
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return result
	 */
	public void addInvoiceOrCreditMemo(String addItem, String subItem) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 320); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]")));
		findElement(By.xpath("//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]"), "Add button").click();
		findElement(
				By.xpath("//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]/following-sibling::div/div/div/span[text()='"
						+ addItem + "']"),addItem + " link under Add button").click();
		findElement(
				By.xpath("//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]/following-sibling::div/div/div[span[text()='"
						+ addItem + "']]//a[span[text()='" + subItem + "']]"), subItem + "->"+ subItem + " link under Add button").click();  
	}

	/**
	 * <b>Function:</b> addInvoiceOrCreditMemo
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param addItem
	 * @param subItem
	 * @return result - True/False
	 * @throws Exception
	 */

	/*
	 * public boolean addInvoiceOrCreditMemo(String addItem, String subItem)
	 * throws Exception { boolean result = false; try {
	 * click(By.xpath("//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]"));
	 * click(By.xpath(
	 * "//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]/following-sibling::div/div/div/span[text()='"
	 * + addItem + "']")); click(By.xpath(
	 * "//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]/following-sibling::div/div/div[span[text()='"
	 * + addItem + "']]//a[span[text()='" + subItem + "']]")); try { if
	 * (subItem.equals(getLanguageProperty("Against PO"))) findElement(By .xpath(
	 * "//div[contains(@class,'iConfirmBox')][//td[contains(text(),'"+getLanguageProperty("You will be redirected to PO Listing")+"')]]//span[text()='"+getLanguageProperty("Continue")+"']"
	 * )) .click(); PurchaseOrder objPO = new PurchaseOrder(driver, logger); if
	 * (findElement(objPO.getPOHeader()).getText() == "Purchase Orders")
	 * System.out.println("Redirected to Purchase Orders page"); else
	 * System.out.println("Not Redirected to Purchase Orders page"); } catch
	 * (Exception e) { System.out.println(
	 * "You will be directed to PO listing pop up not displayed"); } } catch
	 * (Exception e) { e.printStackTrace(); }
	 * 
	 * return result; }
	 */

	/**
	 * <b>Function:</b> filterByStatus
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param checkBoxLbl
	 * @return result - True/False
	 * @throws Exception
	 */

	/*public boolean filterByStatus(String checkBoxLbl) throws Exception {
    boolean result = false;
    try {
      Thread.sleep(3000);
      WebDriverWait wait = new WebDriverWait(driver, 15);
      WebElement objElem = wait.until(ExpectedConditions
          .visibilityOfElementLocated(By.xpath("//th[contains(@class,'invstatusFltrHdr')]//b")));
      // findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr')]//b")).click();
      objElem.click();
      filterByChkbox(checkBoxLbl);
      waitUntilInvisibilityOfElement(processingLoader);
      // if
      // (findElement(processingLoader).getAttribute("style").contains("block"))
      // {
      List<WebElement> objfilteredList = driver.findElements(statusXpath);
      for (WebElement obj : objfilteredList) {
        if (obj.getText().equals(checkBoxLbl))
          result = true;
        else {
          result = false;
          break;
        }
      }
      // }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	/*public boolean applyMultipleFilters(String...filterList){
    boolean result = false;
    try {
      for(String filter:filterList){
        switch(){
        case "Status":

          break;
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByStatus(String checkBoxLbl) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(10000);
			/*WebElement filterIconHeader = driver.findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr')]"));
      if (!filterIconHeader.getAttribute("class").contains("fltr-active")){*/
			findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr')]//b")).click();
			//filterIconHeader.findElement(By.xpath("//b")).click();
			result = filterByChkbox(checkBoxLbl, statusXpath);
			//}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public void switchToRecurringContract(){
		try {
			findElement(By.xpath("//div[@class='productSelectionTab pos-rel']//a[text()='"+getLanguageProperty("Recurring Contract")+"']")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * <b>Function:</b> filterByDate
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromDt
	 * @param ToDt
	 * @return result - True/False
	 * @throws ParseException
	 */

	/*private boolean filterByDate(Date fromDt, Date ToDt) throws ParseException {
    boolean result = false;
    try {
      filterByDateRange(fromDt, ToDt);
      waitUntilInvisibilityOfElement(processingLoader);
      // if
      // (findElement(processingLoader).getAttribute("style").contains("block"))
      // {
      List<WebElement> objfilteredDateList = driver.findElements(dateXpath);
      for (WebElement obj : objfilteredDateList) {
        DateFormat format = new SimpleDateFormat("dd/mm/yyyy");
        Date dt = format.parse(obj.getText());
        if (dt.compareTo(fromDt) >= 0 && dt.compareTo(ToDt) <= 0)
          result = true;
        else {
          result = false;
          break;
        }
      }
      // }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	/**
	 * <b>Function:</b> filterByDocumentDt
	 * 
	 * @author Varun Khurana
	 * @param fromDt
	 * @param ToDt
	 * @return result - True/False
	 * @throws None
	 */

	public boolean filterByDocumentDt(Date fromDt, Date ToDt) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'invdateFltrHdr')]//b")).click();
			result = filterByDateRange(fromDt, ToDt, docDateXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByDueDt
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromDt
	 * @param ToDt
	 * @return result - True/False
	 * @throws None
	 */

	public boolean filterByDueDt(Date fromDt, Date ToDt) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'invduedateFltrHdr')]//b")).click();
			result = filterByDateRange(fromDt, ToDt, docDueDateXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByAmountRange
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromAmt
	 * @param ToAmt
	 * @param currType
	 * @return result - True/False
	 * @throws ParseException
	 */

	/*private boolean filterByAmountRange(float fromAmt, float ToAmt, String currType) throws ParseException {
    boolean result = false;
    try {
      filterByAmtRange(fromAmt, ToAmt, currType);
      waitUntilInvisibilityOfElement(processingLoader);
      // if
      // (findElement(processingLoader).getAttribute("style").contains("block"))
      // {
      List<WebElement> objfilteredAmtList = driver.findElements(amountXpath);
      for (WebElement obj : objfilteredAmtList) {
        Float amount = Float.parseFloat((obj.getText().split(" "))[1]);
        String currencyType = null;
        if (amount >= fromAmt && amount <= ToAmt) {
          if (currType != "")
            currencyType = (obj.getText().split(" "))[0];
          if (currencyType == currType)
            result = true;
          else
            result = true;
        } else {
          result = false;
          break;
        }
      }
      // }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	/**
	 * <b>Function:</b> filterByAmount
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromAmt
	 * @param ToAmt
	 * @return result - True/False
	 * @throws None
	 */

	public boolean filterByAmount(float fromAmt, float ToAmt) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'invamountFltrHdr')]//b")).click();
			result = filterByAmtRange(fromAmt, ToAmt, amountXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByAmount
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromAmt
	 * @param ToAmt
	 * @param currType
	 * @return result - True/False
	 * @throws None
	 */

	public boolean filterByAmount(float fromAmt, float ToAmt, String currType) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'invamountFltrHdr')]//b")).click();
			Thread.sleep(1500);
			result = filterByAmtRange(fromAmt, ToAmt, currType, amountXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByPaidAmount
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromAmt
	 * @param ToAmt
	 * @return result - True/False
	 * @throws None
	 */

	public boolean filterByPaidAmount(float fromAmt, float ToAmt) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'invpaidamountFltrHdr')]//b")).click();
			result = filterByAmtRange(fromAmt, ToAmt, amountXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByPaidAmount
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param fromAmt
	 * @param ToAmt
	 * @param currType
	 * @return result - True/False
	 * @throws None
	 */

	public boolean filterByPaidAmount(float fromAmt, float ToAmt, String currType) {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'invpaidamountFltrHdr')]//b")).click();
			result = filterByAmtRange(fromAmt, ToAmt, currType, amountXpath) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterBySupplier
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param supplier
	 * @return result - True/False
	 * @throws ParseException
	 */

	/*public boolean filterBySupplier(String supplier) throws ParseException {
    boolean result = false;
    try {
      // modified by Anisha in try block
      sendKeys(By.id("txtFltrSupplier"), supplier);
      Thread.sleep(3000);
      findElement(By.xpath("//ul[contains(@style,'block')]//a")).click();
      waitUntilInvisibilityOfElement(processingLoader);
      // int intColNo = getColNum("Supplier");
      List<WebElement> objfilteredTxtList = driver.findElements(By.xpath("//tbody//td[4]"));
      for (WebElement obj : objfilteredTxtList) {
        if (obj.getText().contains(supplier))
          result = true;
        else {
          result = false;
          break;
        }
        // result = filterByText("Supplier", supplier) ? true : false;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/


	public boolean filterBySupplier(String supplier) throws ParseException {
		boolean result = false;
		try {
			result = filterByText_AutoComplete("Supplier", supplier) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByDocType
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param checkBoxLbl
	 * @return result - True/False
	 * @throws Exception
	 */

	/*public boolean filterByDocType(String checkBoxLbl) throws Exception {
    boolean result = false;
    try {
      waitUntilInvisibilityOfElement(processingLoader);
      // Thread.sleep(3000);
      findElement(By.xpath("//th[contains(@class,'docTypeFltrHdr')]//b")).click();
      System.out.println("checkbox here is " + checkBoxLbl);
      filterByChkbox(checkBoxLbl);
      waitUntilInvisibilityOfElement(processingLoader);
      // if
      // (findElement(processingLoader).getAttribute("style").contains("block"))
      // {
      List<WebElement> objfilteredList = driver.findElements(statusXpath);
      for (WebElement obj : objfilteredList) {
        if (obj.getText().equals(checkBoxLbl))
          result = true;
        else {
          result = false;
          break;
        }
      }
      // }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByDocType(String checkBoxLbl) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(processingLoader);
			findElement(By.xpath("//th[contains(@class,'docTypeFltrHdr')]//b")).click();
			result = filterByChkbox(checkBoxLbl, docTypeXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByDocNo(String DocumentNo) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(By.id("invoicelisting_processing"));
			Thread.sleep(8000);
			findElement(By.xpath("//th[contains(@class,'invNumFltrHdr ')]//b")).click();
			Thread.sleep(6000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Thread.sleep(2000);
			findElement(By.xpath("//div[@class='qtip-content']//span[@class='watermarkTxtWrap']//input[@id='txtFltrInvoiceNum']")).sendKeys(DocumentNo);
			Thread.sleep(4000);
			findElement(filterBtnXpath).click();
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(3000);
			List<WebElement> objfilteredList = driver.findElements(By.xpath("//table[@id='invoicelisting']/tbody//td[2]/a[1]"));
			for (WebElement obj : objfilteredList) {
				if (obj.getText().equals(DocumentNo))
					result = true; 
				else {
					result = false;
					break;
				}
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByReference
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param checkBoxLbl
	 * @param optionTxt
	 * @return result - True/False
	 * @throws Exception
	 */

	public boolean filterByReference(String referenceOption, String optionTxt) throws Exception {
		boolean result = false;
		List<WebElement> objfilteredList;
		try {
			findElement(By.xpath("//th[contains(@class,'invPoNumFltrHdr')]//b")).click();
			if (referenceOption == "PO") {
				findElement(By.id("txtFltrWithPo")).click();
				sendKeys(By.id("txtFltrPoNum"), optionTxt);
				clickAndWaitUntilLoaderDisappears(filterBtnXpath, processingLoader);
				Thread.sleep(3000);
				String modifiedXpath = referenceXpath.toString()+"/a";
				objfilteredList = driver.findElements(By.xpath(modifiedXpath));
			} else{
				findElement(By.id("txtFltrWithoutPo")).click();
				referenceOption = "-";
				clickAndWaitUntilLoaderDisappears(filterBtnXpath, processingLoader);
				Thread.sleep(3000);
				objfilteredList = driver.findElements(referenceXpath);
			}
			/*findElement(filterBtnXpath).click();
      waitUntilInvisibilityOfElement(processingLoader);*/

			for (WebElement obj : objfilteredList) {
				//LogScreenshot("INFO", "required label is : "+obj.getText());
				if (obj.getText().equals(referenceOption))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterCreditMemoByStatus(String checkBoxLbl) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(processingLoader);
			Thread.sleep(10000);
			/*WebElement filterIconHeader = driver.findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr')]"));
      if (!filterIconHeader.getAttribute("class").contains("fltr-active")){*/
			findElement(By.xpath("//th[contains(@class,'invstatusFltrHdr')]//b")).click();
			//filterIconHeader.findElement(By.xpath("//b")).click();
			result = filterByChkboxCreditMemo(checkBoxLbl, statusXpath);
			//}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String createRecurringContract(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String contractOwner,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType,String buyer, String requester, String notes,String description,String frequencyNo,String frequency, String headerLevelTaxRate) throws Exception {
		String contractNo = null;

		addRecurringContract("Manual Contract");

		RecurringContractCreation objInv = new RecurringContractCreation(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
				currency_value,  contractOwner, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, buyer, requester,  notes, description, frequencyNo, frequency, headerLevelTaxRate);
		contractNo = objInv.createContract();
		waitUntilInvisibilityOfElement(processingLoader);
		Thread.sleep(8000);

		return contractNo;
	}

	public void addRecurringContract(String addItem) throws Exception {
		findElement(By.xpath("//*[@id='wrapper']//a[span[2][text()='"+getLanguageProperty("Add")+"']]"), "Add button").click();
		findElement(
				By.xpath("//a[@class='scLnk createInvoice']//span[@class='p bld'][text()='"+ addItem +"']"),addItem + " link under Add button").click();

	}

	public String copyInvoice(String documentNo) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String createdEntity = null;
		By invoiceOrCreditMemoNoId = By.id("txtInvoiceNumber");
		System.out.println(documentNo);
		clearAllFilters();
		filterByDocNo(documentNo);  
		LogScreenshot("INFO","Filtered By "+ documentNo);
		selectAction("Copy");
		LogScreenshot("INFO","Clicked on Copy Invoice");
		String invoiceOrCreditMemoNo = String.valueOf(generateNo())+"_copied";   
		waitUntilInvisibilityOfElement(By.xpath("//div[@id='processing_cntInvoice' and not(contains(@style,'none'))]"));
		driver.findElement(invoiceOrCreditMemoNoId).sendKeys(invoiceOrCreditMemoNo);
		selectTodayDate();
		if (addAttachment())
			LogScreenshot("INFO","Attachment added");
		else
			LogScreenshot("INFO","Attachment is not added");
		LogScreenshot("INFO","Invoice number updated - About to click Submit button");
		js.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[@class='b-button b-final b-big'][@id='btnSubmit']")));
		LogScreenshot("INFO","Submit button clicked");
		Thread.sleep(30000);
		waitUntilInvisibilityOfElement(By.id("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		//try {
		Thread.sleep(2000);
		waitUntilInvisibilityOfElement(By.id("status_overlay_updateInvoice"));
		if (driver.findElements(By.xpath("//span[@class='ui-dialog-title'][text()='"+getLanguageProperty("Invoicing Error")+"']")).size() > 0){
			driver.findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Ignore & Submit")+"']")).click();
		}
		setApproversCount();
		findElement(confirmationPopupXpath).click();
		waitUntilVisibilityOfElement(By.id("status_overlay_updateInvoice"));
		//} catch (Exception e) {e.printStackTrace();}

		waitUntilInvisibilityOfElement(By.id("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(30000);
		createdEntity = invoiceOrCreditMemoNo;
		/*  
    Invoices objInvoice= new Invoices(driver, logger); 
    if (objInvoice.filterByDocNo(invoiceOrCreditMemoNo)) {
      LogScreenshot("PASS",invoiceOrCreditMemoNo+" copied successfully");  
      result = true;
    }else {
      LogScreenshot("FAIL",invoiceOrCreditMemoNo+" not searched");  
    }*/
		return createdEntity;

	}

	public String createDuplicateRecurringContract(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String contractOwner,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType,String buyer, String requester, String notes,String description,String frequencyNo,String frequency, String contractName) throws Exception {
		String contractNo = null;
		addRecurringContract("Manual Contract");
		RecurringContractCreation objInv = new RecurringContractCreation(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
				currency_value,  contractOwner, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, buyer, requester,  notes, description, frequencyNo, frequency, headLvlTaxRate);
		contractNo = objInv.createDuplicateContract(contractName);
		waitUntilInvisibilityOfElement(processingLoader);
		Thread.sleep(8000);

		return contractNo;
	}

	public void verifyHeaderLevelTax(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType, String headLvlTaxRate) throws Exception {


		try {
			addInvoiceOrCreditMemo("Invoice", "Non-PO");  
			InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
					currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headLvlTaxRate);
			objInv.verifySelfAssessedTaxAtHeaderLevel();

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void verifyLineLevelTax(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType, String headLvlTaxRate) throws Exception {

		try {
			addInvoiceOrCreditMemo("Invoice", "Non-PO");  
			InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
					currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headLvlTaxRate);
			objInv.verifySelfAssessedTaxAtLineLevel();

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void submitRejectedInvoice() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		clrAllFilters();
		filterByDocType("Invoice");
		filterByStatus("Rejected");  
		selectAction("Edit");
		driver.findElement(By.id("txtInvoiceStatusComments")).sendKeys("Re-submiting invoice");
		System.out.println("about to click Submit button");
		js.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[@class='b-button b-final b-big'][@id='btnSubmit']")));
		System.out.println("Submit button clicked");
		Thread.sleep(3000);
		try {
			Thread.sleep(2000);
			if (driver.findElements(By.xpath("//span[@class='ui-dialog-title'][text()='"+getLanguageProperty("Invoicing Error")+"']")).size() > 0)
			{
				driver.findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Ignore & Submit")+"']")).click();
			}
			setApproversCount();
			findElement(confirmationPopupXpath).click();
			waitUntilVisibilityOfElement(By.id("status_overlay_updateInvoice"));
		} catch (Exception e) {e.printStackTrace();}

		waitUntilVisibilityOfElement(successBoxId);

	}

	public void editInvoiceFromMailBox(String invoiceOrCreditMemoNo,String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType,String headerLevelTaxRate) throws Exception {
		waitUntilInvisibilityOfElement(processingLoader);
		/*clearAllFilters();
		filterByDocNo(invoiceOrCreditMemoNo);*/
		selectAction("Edit");
		/*	InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
				currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headLvlTaxRate);*/
		InvoiceNonPO objInv = new InvoiceNonPO(driver, logger, supplierSelectCategory, supplierName, paymentTerm, 
				currency_value,  "", purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headerLevelTaxRate);
		objInv.editInvoiceDetails();

	}
	public void verifyVersionDetailsinAuditTrail() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitUntilInvisibilityOfElement(processingLoader);
		clrAllFilters();
		filterByDocType("Invoice");
		filterByStatus("Approved");  
		filterBySupplier("GDQA");
		driver.findElement(By.xpath("//*[@id='invoicelisting']/tbody/tr[1]//td[@class=' invoiceNumber']/a[1]")).click();
		Thread.sleep(5000);
		WebElement objAuditTrailButton = driver.findElement(By.id("invoiceauditTrailHead"));
		js.executeScript("arguments[0].scrollIntoView();", objAuditTrailButton);
		findElement(By.id("invoiceauditTrailHead")).click();
		Thread.sleep(1500);
		if (driver.findElements(By.id("auditTrailList_EINVOICE")).size() > 0) {
			String Parent_Window = driver.getWindowHandle();  
			driver.findElement(By.xpath("(//table[@id='auditTrailList_EINVOICE']//td[@class=' version']/a)[1]")).click();  
			// Switching from parent window to child window   
			for (String Child_Window : driver.getWindowHandles())        
			{          
				driver.switchTo().window(Child_Window);
				String childWindowTitle = driver.getTitle();
				System.out.println(childWindowTitle);

				if ((childWindowTitle.contains("Zycus Procure-to-Pay") && driver.findElements(By.xpath("//div[@id='wrapper']/div/h1[text()='"+getLanguageProperty("Invoice Details")+"']")).size() > 0)) {
					try {
						// Performing actions on child window  
						driver.manage().window().maximize();
						softAssert.assertTrue(driver.findElement(By.xpath("//h2[contains(text(),'"+getLanguageProperty("Supplier Details")+"')]")).isDisplayed());
						softAssert.assertTrue(driver.findElement(By.xpath("//h2[contains(text(),'"+getLanguageProperty("Invoice Details")+"')]")).isDisplayed());
						softAssert.assertAll();
						LogScreenshot("PASS","Invoice-Version Details Verified");           
					}
					catch(Exception e) {}
				} 
			}
			driver.close();
			//Switching back to Parent Window  
			driver.switchTo().window(Parent_Window);  

		}  

	}
	
	public void contractApproval(String contractName) throws Exception {
		Approval objApproval = new Approval(driver, logger);
		waitUntilInvisibilityOfElement(By.xpath("//div[@id='workflowApproval_processing'][contains(@style,'block')]"));
		driver.findElement(By.xpath("//ul[@class='product-tabs-nav']//a[text()='"+getLanguageProperty("Recurring Contract")+"']")).click();
		approveInvoiceCreditMemo(contractName);
		driver.navigate().refresh();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(8000);
		LogScreenshot("INFO","After refreshing the page"); 
		objApproval.clrAllFilters();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(5000);
		
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(5000);
		
		while(!driver.findElement(By.xpath("//div[@class='clearfix statusTxt postatusTxt']")).getText().equals(getLanguageProperty("Approved"))) {
			approveInvoiceCreditMemo(contractName);
			objApproval.clrAllFilters();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			Thread.sleep(3000);

			objApproval.filterByDocumentNo(contractName);
			Thread.sleep(8000);
			LogScreenshot("INFO","Filtered by "+contractName);     
		}
		if (driver.findElement(By.xpath("//div[@class='clearfix statusTxt postatusTxt']")).getText().equals(getLanguageProperty("Approved")))
			LogScreenshot("PASS","Approved "+contractName); 
		else
			LogScreenshot("FAIL","Not approved "+contractName); 
	}

	public void InvoiceApproval(String InvoiceNo) throws Exception {
		try {
			Approval objApproval = new Approval(driver, logger);

			approveInvoiceCreditMemo(InvoiceNo);
			driver.navigate().refresh();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			Thread.sleep(8000);
			objApproval.clrAllFilters();
			Thread.sleep(5000);
			while(driver.findElement(By.xpath("//table[@id='workflowApproval']//div[@class='clearfix statusTxt postatusTxt']")).getText().equals(getLanguageProperty("Pending"))) {
				LogScreenshot("INFO",InvoiceNo+ ": in Pending status"); 
				approveInvoiceCreditMemo(InvoiceNo);
				objApproval.clrAllFilters();
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
				Thread.sleep(3000);

				objApproval.filterByDocumentNo(InvoiceNo);	
				Thread.sleep(8000);
				LogScreenshot("INFO","Filtered by "+InvoiceNo);     
			}
			if (driver.findElement(By.xpath("//table[@id='workflowApproval']//tr/td[a[text()='"+InvoiceNo+"']]/preceding-sibling::td//div[@class='clearfix statusTxt postatusTxt']")).getText().equals(getLanguageProperty("Approved")))
				LogScreenshot("PASS","Approved "+InvoiceNo); 
			else
				LogScreenshot("FAIL","Not approved "+InvoiceNo); 
		}catch(Exception e) {
			LogScreenshot("FAIL",InvoiceNo+ " :Invoice is not approved");
			throw e;
		}
	}
	
	


	
	public void approveInvoiceCreditMemo(String Invoice) throws Exception {
		Approval objApproval = new Approval(driver, logger);
		driver.navigate().refresh();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(8000);
		objApproval.clrAllFilters();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		waitUntilVisibilityOfElement(By.id("workflowApproval_wrapper"));
		Thread.sleep(8000);
		driver.navigate().refresh();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(8000);
		LogScreenshot("INFO","After refreshing the page for second time"); 
		objApproval.clrAllFilters();
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		objApproval.filterByDocumentNo(Invoice);
		Thread.sleep(8000);
		LogScreenshot("INFO","Invoice listing page displayed");
		if(driver.findElements(By.xpath("//tr[td/a[text()='"+Invoice+"']]")).size()>0){   		
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			Thread.sleep(8000);
			LogScreenshot("INFO",Invoice+ " filtered");
			driver.findElement(By.xpath("(//tr[td/a[text()='"+Invoice+"']]//td//a[text()='"+getLanguageProperty("Actions")+"'])[1]")).click();
			Thread.sleep(8000);
			driver.findElement(By.xpath("(//tr[td/a[text()='"+Invoice+"']]//td//div[a[text()='"+getLanguageProperty("Actions")+"']])[1]//a[text()='"+getLanguageProperty("Approve")+"']")).click();
			waitUntilVisibilityOfElement(By.id("frmApprove"));
			driver.findElement(By.id("approvalComments")).sendKeys("Approving");
			LogScreenshot("PASS",Invoice+ " approved");   
			driver.findElement(By.xpath("//input[@type='button'][@value='"+getLanguageProperty("Approve")+"']")).click();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		}else{
			LogScreenshot("Fail",Invoice+ " not found on the Invoice listing page");
			throw new Exception();
		}

	}
	
	public void approveInvoice(String Invoice) throws Exception{
		//boolean result = false;
		Approval objApproval = new Approval(driver, logger);
		//try {
		int timer=0;
		while(true) {
			if(driver.findElements(By.xpath("//table[@id='workflowApproval']//tr/td/a[text()='"+Invoice+"']")).size()>0 || timer>3) {
				break;
			}else {
				timer++;
				LogScreenshot("info","Waiting for 1 Minute and refreshing the page");
				Thread.sleep(60000);
				driver.navigate().refresh();
				waitUntilVisibilityOfElement(By.id("workflowApproval"));
				clrAllFilters();
				objApproval.filterByDocumentNo(Invoice);
			}    		
		}


		int approvedInv = driver.findElements(By.xpath("//table[@id='workflowApproval']/tbody/tr[td[3]/a[text()='"+Invoice+"']]/td[2]/div[text()='"+getLanguageProperty("Approved")+"']")).size();
		/*clrAllFilters();
    	filterByPONo(PONum);*/
		waitUntilInvisibilityOfElement(processingLoader,4);
		findElement(By.xpath("//table[@id='workflowApproval']/tbody/tr[td[3]/a[text()='"+Invoice+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")).click();
		LogScreenshot("Info", "Actions button clicked");
		findElement(By.xpath("//table[@id='workflowApproval']/tbody/tr[td[3]/a[text()='"+Invoice+"']]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']/following-sibling::ul/li/a[text()='"+getLanguageProperty("Approve")+"']")).click();
		driver.findElement(By.id("approvalComments")).sendKeys("approval Comments");
		LogScreenshot("Info", "Comments entered to approve");
		findElement(By.xpath("//input[@type='button'][@value='"+getLanguageProperty("Approve")+"']")).click();
		waitUntilInvisibilityOfElement(processingLoader, 4);
		Thread.sleep(10000);
		clrAllFilters();
		LogScreenshot("Info", "searching "+ Invoice+" Invoice to approve");	
		objApproval.filterByDocumentNo(Invoice);
		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//table[@id='workflowApproval']/tbody/tr[td[3]/a[text()='"+Invoice+"']]/td[2]/div[text()='"+getLanguageProperty("Approved")+"']")).size()>approvedInv) {
			LogScreenshot("Pass", Invoice + " Approved");
		} else {
			LogScreenshot("Fail", Invoice + " not approved");
		}
		Thread.sleep(3000);
		//clrAllFilters();
		if (driver.findElements(By.xpath("//table[@id='workflowApproval']/tbody/tr[td[3]/a[text()='"+Invoice+"']]/td[2]/div[text()='"+getLanguageProperty("Pending")+"']")).size() > 0){
			approveInvoice(Invoice);
			/*if (getPOStatus(PONum).equals("Approved"))
      LogScreenshot("Fail", PONum + " not approved");*/
		}
		/*} catch (Exception e) {
  e.printStackTrace();
  }*/
		//return result;
	}

	public void restrictPayment(String InvoiceNo, String creditMemo) throws Exception {  
		Thread.sleep(3000);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		clearAllFilters();
		Thread.sleep(8000);
		filterByDocNo(creditMemo);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(8000);
		LogScreenshot("INFO","Filtered by " + creditMemo);     
		String creditMemoAmt= driver.findElement(By.xpath("//table[@id='invoicelisting']//tr//td[@class=' amount']")).getText();
		String[] creditAmt= creditMemoAmt.split(" ");
		String actualAmount= creditAmt[1];
		String creditMemoAmount= actualAmount.replaceAll(",", "");  
		clrAllFilters();
		Thread.sleep(8000);
		filterByDocNo(InvoiceNo);  
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(8000);
		String invAmt= driver.findElement(By.xpath("//table[@id='invoicelisting']//tr//td[@class=' amount']")).getText();
		String[] invoiceAmt= invAmt.split(" ");
		String actualInvAmount= invoiceAmt[1];
		String InvoiceAmount= actualInvAmount.replaceAll(",", "");    
		Double toBeRestrictedAmount= Double.parseDouble(InvoiceAmount) - Double.parseDouble(creditMemoAmount);
		String toBeRestrictedAmountDouble= String.valueOf(toBeRestrictedAmount);     
		selectAction("Restrict Payment");
		LogScreenshot("INFO","Restricting Payment - Action selected");
		driver.findElement(By.id("adjust_amount")).clear();
		driver.findElement(By.id("adjust_amount")).sendKeys(toBeRestrictedAmountDouble);
		LogScreenshot("INFO",toBeRestrictedAmountDouble+" Amount to be restricted added");
		driver.findElement(restrictPaymentCommentId).sendKeys("restrict payment comment");
		clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'adjustAmount')]"), By.xpath("//*[@id='status_overlay_adjustingAmount']/div"));
		Thread.sleep(2000);
		if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
			LogScreenshot("INFO","Alert displayed");
			driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
			driver.findElement(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
		}else
			LogScreenshot("PASS","Invoice is restricted successfully");

	}
	public boolean verifyZSNInvoiceCreditMemo(String InvoiceNo) throws Exception {  
		boolean flag;
		int timer = 0;
		while(true) {
			timer++;
			driver.navigate().refresh();
			Thread.sleep(30000);
			if (timer>14)
				break;
		}
		LogScreenshot("INFO","Waited for 7 minutes");
		clearAllFilters();
		try {
			driver.findElement(By.xpath("//th[contains(@class,'invnum ')]//span[@title='"+getLanguageProperty("Clear Filter")+"']")).click();
		}catch(Exception e) {}
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		boolean status = filterByDocNo(InvoiceNo);
		waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
		Thread.sleep(8000);
		if (status) 
			flag= true;
		else {
			LogScreenshot("WARNING","Invoice/Credit Memo not found");
			while(true) {
				timer++;
				driver.navigate().refresh();
				Thread.sleep(30000);
				if (timer>8)
					break;
			}

			LogScreenshot("INFO","Waited for 4 minutes");
			clearAllFilters();
			try {
				driver.findElement(By.xpath("//th[contains(@class,'invnum ')]//span[@title='"+getLanguageProperty("Clear Filter")+"']")).click();
			}catch(Exception e) {}
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			boolean status2 = filterByDocNo(InvoiceNo);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			if(status2)
				flag= true;
			else
				flag= false;
		}		
		return flag; 
	}


	public void allowPayment(String InvoiceNo) throws Exception {
		try {  
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			clearAllFilters();
			filterByDocNo(InvoiceNo);
			Thread.sleep(8000);
			LogScreenshot("INFO","Filtered by " + InvoiceNo);       
			selectAction("Adjust Credit");  
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			LogScreenshot("INFO","Adjusting Credit");    
			Thread.sleep(5000);    
			driver.findElement(By.xpath("//tbody[@id='cm_list']//input[@class='itemChk autoCheckItem']")).click();
			driver.findElement(adjustCreditCommentId).sendKeys("Adjust Credit comment");    
			LogScreenshot("INFO","Credit Memo selected and comments added");    
			clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'invoiceAdjust')]"), By.xpath("//*[@id='status_overlay_adjustingInvoice']/div"));    
			LogScreenshot("PASS","Clicked on Adjust Credit Button");
			Thread.sleep(5000);
			if (driver.findElements(By.xpath("//div[contains(@class,'iConfirmBox')]")).size() > 0) {
				driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("Yes")+"']")).click();
			}
			LogScreenshot("PASS","Credit is adjusted successfully");
			Thread.sleep(5000);
			if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
				driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
				driver.findElement(By.xpath("//form[@id='frmAdjustCredit']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
			}
		}
		catch(Exception e) {       
			if (driver.findElements(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).size() > 0)
				driver.findElement(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
		}
	}

	public void voidReturnClose(String InvoiceNo) throws Exception {
		try {  
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			clrAllFilters();
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			filterByDocNo(InvoiceNo);
			waitUntilInvisibilityOfElement(By.xpath("//div[@class='dataTables_processing' and contains(@style,'block')]"));
			Thread.sleep(8000);
			LogScreenshot("INFO","Filtered by " + InvoiceNo);       
			selectAction("Void Invoice");  
			driver.findElement(voidInvoiceCommentId).sendKeys("void invoice comment");
			clickAndWaitUntilLoaderDisappears(By.xpath("//input[contains(@class,'invoiceCancel')]"), By.xpath("//*[@id='status_overlay_cancellingInvoice']/div"));
			if (driver.findElements(By.xpath("//span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0) {
				driver.findElement(By.xpath("//button[@type='button']//span[text()='"+getLanguageProperty("OK")+"']")).click();
			}  
		}
		catch(Exception e) {       
			if (driver.findElements(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).size() > 0)
				driver.findElement(By.xpath("//form[@id='frmAdjustAmt']//a[@title='"+getLanguageProperty("Cancel")+"']")).click();
		}
	}


}
