package com.zycus.eInvoice.Help;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class ProductVideos_v1 extends eInvoice_CommonFunctions {

  private WebDriver driver;
  private ExtentTest logger;
  
  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public ProductVideos_v1(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
    this.driver = driver;
    this.logger = logger;
  }

  /**
   * <b>Function:</b> clickCreateWorkflow
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param displayName
   * @return result - True/False
   * @throws Exception
   */

  protected boolean verifyLatestProductVideo() throws Exception {
    boolean result = false;
    JavascriptExecutor js = (JavascriptExecutor)driver; 
    try {
      //Switch to tab 'Self Training Videos'
      String parent = driver.getWindowHandle();
      switchWindowHandles(parent, "Self Training Videos");
      Thread.sleep(2000);
      driver.navigate().refresh();
      findElement(By.xpath("//table[@id='productVideoTab']/tbody/tr[1]//a[1]")).click();
      waitUntilVisibilityOfElement(By.xpath("//div[@class='modal' and //video]"));
      Thread.sleep(2000);
      js.executeScript("document.getElementById(\"videoPlayer\").play()");
      Thread.sleep(4000);
      js.executeScript("document.getElementById(\"videoPlayer\").pause()");
      Double d  = new Double((double) js.executeScript("return document.getElementById(\"videoPlayer\").currentTime"));
      int timePlayedFor = d.intValue();
      if (timePlayedFor == 4){
        LogScreenshot("PASS", "video played for 4 seconds");
        result = true;
      }
    } catch (Exception e) {
      e.printStackTrace();
      LogScreenshot("FAIL", "latest help video not opened");
    }
    return result;
  }

}
