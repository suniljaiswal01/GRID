package com.zycus.eInvoice.Approval;

import java.awt.AWTException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.main.ProjectConfig1;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> Approval.java
 * <br>
 * <b> Description: </b> Perform operations on a purchase order
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.filterByStatus: user shall be able to download PO as PDF 
 * <br>
 * 2.previewPOascXML: user shall be able to preview PO cXML 
 * <br>
 * 3.createShipmentNotice: user shall be able to create a shipment notice 
 * 
 * @author Anisha
 * @since April 2018
 */

public class AllRequests extends eInvoice_CommonFunctions {

	/** Xpath for all the displayed Status in the Grid */
	//private static By statusXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
	@FindBys(@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[2]/div"))
	private static List<WebElement> objStatus;

	/** Xpath for all the displayed Document No in the Grid */
	//private static By documentNoXpath = By.xpath("//table[contains(@class,'dataTable')]//td[2]/div");
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[2]/div")
	private static List<WebElement> objDocumentNo;

	/** Xpath for all the displayed Date in the Grid */
	//private static By dateXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'receivedOn')]");
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[contains(@class,'receivedOn')]")
	private static List<WebElement> objDate;

	/** Xpath for all the displayed Amount in the Grid */
	//private static By amountXpath = By.xpath("//table[contains(@class,'dataTable')]//td[contains(@class,'entityAmount')]");
	@FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//td[contains(@class,'entityAmount')]")
	private static List<WebElement> objAmount;

	/** Xpath for the 'Filter' button associated with filter icons */
	private static By objFilterBtn = By.xpath(
			"//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='"+getLanguageProperty("Filter")+"']");
	//WebElement objFilterBtn= driver.findElement(By.xpath("//div[contains(@id,'qtip') and @aria-hidden='false']//div[contains(@class,'FilterBtnbx')]//a[text()='"+getLanguageProperty("Filter")+"']"));


	/** ID for the approval comments text area */
	//private static By approveCommentId = By.id("approvalComments");
	@FindBy(how = How.ID, using="approvalComments")
	private static WebElement objApproveComment;

	/** Xpath for the 'Approve' button */
	private static By objApproveBtn = By.xpath(".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]");
	/*@FindBy(how = How.XPATH, using=".//*[@id='frmApprove']//input[contains(@class,'dev_approve')]")
  private static WebElement objApproveBtn;*/

	/** Xpath for green colored global message indicating Document is approved */
	private static By objApprovedMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]");
	/*@FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("approved")+"')]")
  private static WebElement objApprovedMsg;*/

	/** ID for the reject comments text area */
	//private static By rejectCommentId = By.id("rejectComments");
	@FindBy(how = How.ID, using="rejectComments")
	private static WebElement objRejectComment;

	/** Xpath for the 'Reject' button */
	private static By objRejectBtn = By.xpath("//*[@id='frmReject']//input[contains(@class,'dev_reject')]");
	/*  @FindBy(how = How.XPATH, using="//*[@id='frmReject']//input[contains(@class,'dev_reject')]")
  private static WebElement objRejectBtn;
	 */
	/** Xpath for green colored global message indicating Document is rejected */
	private static By objRejectMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]");
	/*  @FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("rejected")+"')]")
  private static WebElement objRejectMsg;*/

	/** ID for the approval comments text area */
	//private static By delegateNameId = By.id("txtDelegateName");
	@FindBy(how = How.ID, using="txtDelegateName")
	private static WebElement objDelegateName;

	/** ID for the delegate comments text area */
	//private static By delegateCommentId = By.id("delegateComments");
	@FindBy(how = How.ID, using="delegateComments")
	private static WebElement objDelegateComment;

	/** Xpath for the 'Delegate' button */
	private static By objSaveDelegateBtn = By.id("btnDelegateSave");
	/*  @FindBy(how = How.ID, using="btnDelegateSave")
  private static WebElement objSaveDelegateBtn;*/

	/** Xpath for green colored global message indicating Document is delegated */
	private static By objDelegateMsg = By.xpath("//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]");
	/*@FindBy(how = How.XPATH, using="//div[contains(@class,'globalMessage')]//span[contains(text(),'"+getLanguageProperty("delegated")+"')]")
  private static WebElement objDelegateMsg;*/

	/** Xpath for Action button on first row */
	private static By objFirstRowActionBtn = By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']");
	/*  @FindBy(how = How.XPATH, using="//table[contains(@class,'dataTable')]//tr[1]/td[last()]//a[text()='"+getLanguageProperty("Actions")+"']")
  private static WebElement objFirstRowActionBtn;*/

	private String delegateApprovalTo;


	//private String delegateApprovalTo = "Chaitali";

	/**
	 * Constructor for the class
	 * @param driver 
	 * 
	 * @param driver
	 * @param logger
	 * @throws Exception 
	 */

	public AllRequests(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		PageFactory.initElements(driver, this);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = System.getProperty("user.dir")
				+ configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("Approvals", Datasheet_eInvoice);
		this.delegateApprovalTo = abc[0][0];

	}

	public boolean performActionOnInvoice(String action) throws AWTException {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(processingLoader);
			String documentNo = driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[3]/a"))
					.getText();
			//waitUntilInvisibilityOfElement(processingLoader);
			clickElement(objFirstRowActionBtn);
			findElement(
					By.xpath("//table[contains(@class,'dataTable')]//tr[1]//li/a[contains(text(),'" + action + "')]"), action +" Link")
			.click();
			try {
				switch (action) {
				case "Approve":
					objApproveComment.sendKeys("approving the document");
					clickAndWaitUntilElementAppears(objApproveBtn, objApprovedMsg);
					clrAllFilters();
					filterByDocumentNo(documentNo);
					if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[2]/div")).getText()
							.equals(getLanguageProperty("Approved"))) {
						LogScreenshot("INFO", "Invoice : " + documentNo + " approved");
						result = true;
					}
					break;
				case "Reject":
					objRejectComment.sendKeys("rejecting the document");
					clickAndWaitUntilElementAppears(objRejectBtn, objRejectMsg);
					clrAllFilters();
					filterByDocumentNo(documentNo);
					if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[2]/div")).getText()
							.equals(getLanguageProperty("Rejected"))) {
						LogScreenshot("INFO", "Invoice : " + documentNo + " rejected");
						result = true;
					}
					break;
				case "Delegate":
					enterText_AutoComplete(objDelegateName, delegateApprovalTo);
					objDelegateComment.sendKeys("delegating the document");
					clickAndWaitUntilElementAppears(objSaveDelegateBtn, objDelegateMsg);
					clrAllFilters();
					filterByDocumentNo(documentNo);
					if (driver.findElement(By.xpath("//table[contains(@class,'dataTable')]//tr[1]/td[2]/div")).getText()
							.equals(getLanguageProperty("Delegated"))) {
						LogScreenshot("INFO", "Invoice : " + documentNo + " delegated");
						result = true;
					}
					break;
				default:
					break;
				}
				waitUntilInvisibilityOfElement(processingLoader);
			} catch (Exception e) {
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean approveInvoice(String invoiceNo) throws Exception{
		boolean result = false;
		int approverCount = ProjectConfig1.getCountofInvoiceApprovers();
		if (approverCount==1){
			performActionOnInvoice("Approve");
			result = true;
		}else if (approverCount>1){
			for(int i=1; i<=approverCount; i++){
				waitUntilInvisibilityOfElement(processingLoader);
				filterByDocumentNo(invoiceNo);
				performActionOnInvoice("Approve");
				findElement(By.xpath("//ul[@class='product-tabs-nav']/li/a[text()='"+getLanguageProperty("Invoice")+"']"), "Invoice Tab").click();
				waitUntilInvisibilityOfElement(processingLoader);
				//Invoice click responds late
				Thread.sleep(2000);
			}
			result = true;
		}
		return result;
	}

	public boolean performActionOnInvoice(String DocumentNo, String action) throws AWTException {
		boolean result = false;
		try {
			filterByDocumentNo(DocumentNo);
		} catch (Exception e) {
		}
		if (performActionOnInvoice(action))
			result = true;
		return result;
	}

	/*public boolean filterByStatus(String checkBoxLbl) throws Exception {
    boolean result = false;
    try {
	 *//** Click Status Filter icon *//*
      findElement(By.xpath("//th[contains(@class,'statusFilter')]//b")).click();
      result = filterByChkbox(checkBoxLbl, statusXpath);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByStatus(String checkBoxLbl) throws Exception {
		boolean result = false;
		try {
			/** Click Status Filter icon */
			findElement(By.xpath("//th[contains(@class,'statusFilter')]//b"), "Status Filter icon").click();
			result = filterByChkbox(checkBoxLbl, objStatus);
			//result = filterByChkbox(checkBoxLbl, objReqPg.objStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*public boolean filterByStatus(int pendingDays) throws Exception {
    boolean result = false;
    try {
	 *//** Click Status Filter icon *//*
      findElement(By.xpath("//th[contains(@class,'statusFilter')]//b")).click();
      findElement(By.xpath("//input[contains(@class,'pendingSince') and @type='checkbox']")).click();
      findElement(By.xpath("//input[contains(@class,'pendingSince') and @type='text']"))
          .sendKeys(String.valueOf(pendingDays));
      clickAndWaitUntilLoaderDisappears(filterBtnXpath);
      List<WebElement> objfilteredList = driver.findElements(statusXpath);
      for (WebElement obj : objfilteredList) {
        if (obj.getText().equals(getLanguageProperty("Pending")))
          result = true;
        else {
          result = false;
          break;
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByStatus(int pendingDays) throws Exception {
		boolean result = false;
		try {
			/** Click Status Filter icon */
			findElement(By.xpath("//th[contains(@class,'statusFilter')]//b"), "Status Filter icon").click();
			findElement(By.xpath("//input[contains(@class,'pendingSince') and @type='checkbox']"), "Pending Since Checkbox").click();
			driver.findElement(By.xpath("//input[contains(@class,'pendingSince') and @type='text']"))
			.sendKeys(String.valueOf(pendingDays));
			clickAndWaitUntilLoaderDisappears(objFilterBtn);
			//List<WebElement> objfilteredList = driver.findElements(statusXpath);
			//for (WebElement obj : objfilteredList) {
			for (WebElement obj : objStatus) {
				if (obj.getText().equals(getLanguageProperty("Pending")))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*public boolean filterByReceivedOn(Date fromDt, Date ToDt) throws Exception {
    boolean result = false;
    try {
      findElement(By.xpath("//th[contains(@class,'receivedOnFilter')]//b")).click();
      result = filterByDateRange(fromDt, ToDt, dateXpath);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByReceivedOn(Date fromDt, Date ToDt) throws Exception {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'receivedOnFilter')]//b"),"Received On filter icon").click();
			result = filterByDateRange(fromDt, ToDt, objDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByAmountToApprove
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromDt,ToDt
	 * @return result
	 * @throws Exception
	 */

	/*public boolean filterByAmountToApprove(float fromAmt, float ToAmt) throws Exception {
    boolean result = false;
    try {
      findElement(By.xpath("//th[contains(@class,'amountFilter')]//b")).click();
      result = filterByAmtRange(fromAmt, ToAmt, amountXpath) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }
	 */
	public boolean filterByAmountToApprove(float fromAmt, float ToAmt) throws Exception {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'amountFilter')]//b"), "Amount to Approve filter icon").click();
			result = filterByAmtRange(fromAmt, ToAmt, objAmount) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	/**
	 * <b>Function:</b> filterByAmountToApprove
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param fromDt,
	 *            ToDt, currType
	 * @return result
	 * @throws Exception
	 */

	/*public boolean filterByAmountToApprove(float fromAmt, float ToAmt, String currType) throws Exception {
    boolean result = false;
    try {
      findElement(By.xpath("//th[contains(@class,'amountFilter')]//b")).click();
      result = filterByAmtRange(fromAmt, ToAmt, currType, amountXpath) ? true : false;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public boolean filterByAmountToApprove(float fromAmt, float ToAmt, String currType) throws Exception {
		boolean result = false;
		try {
			findElement(By.xpath("//th[contains(@class,'amountFilter')]//b"), "Amount to Approve filter icon").click();
			result = filterByAmtRange(fromAmt, ToAmt, currType, objAmount) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterBySupplier
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param supplier
	 * @throws ParseException
	 * @return result
	 */
	@Deprecated
	public boolean filterBySupplier(String supplier) throws ParseException {
		boolean result = false;
		try {
			result = filterByText("Supplier", supplier) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean filterByInitiator(String initiator) throws ParseException {
		boolean result = false;
		try {
			result = filterByText("Initiator", initiator) ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * <b>Function:</b> filterByDocumentNo
	 * 
	 * @author Varun Khurana
	 * @since April 2018
	 * @param checkBoxLbl,
	 *            invoiceNo
	 * @throws ParseException
	 * @return result
	 * @throws Exception
	 */

	/*
	 * public boolean filterByDocumentNo(String checkBoxLbl, String invoiceNo)
	 * throws Exception { boolean result = false; try {
	 * findElement(By.xpath("//th[contains(@class,'numberFilter')]//b")).click()
	 * ; driver.findElement(By.id("txtFltrInvoiceNum")).sendKeys(invoiceNo);
	 * findElement(By.xpath(
	 * "(//div[contains(@id,'qtip')]//input[following-sibling::text()[contains(.,'"
	 * + checkBoxLbl + "')]])[1]")).click();
	 * clickAndWaitUntilLoaderDisappears(filterBtnXpath); List<WebElement>
	 * objfilteredList = driver.findElements(documentNoXpath); for (WebElement
	 * obj : objfilteredList) { if (obj.getText().equals(invoiceNo)) result =
	 * true; else { result = false; break; } } } catch (Exception e) {
	 * e.printStackTrace(); } return result; }
	 */

	public boolean filterByDocumentNo(String invoiceNo) throws Exception {
		boolean result = false;
		try {
			waitUntilInvisibilityOfElement(processingLoader);
			findElement(By.xpath("//th[contains(@class,'numberFilter')]//b"), "Document no filter icon").click();
			Thread.sleep(2000);
			driver.findElement(By.id("txtFltrInvoiceNum")).sendKeys(invoiceNo);
			clickElement(objFilterBtn);
			//List<WebElement> objfilteredList = driver.findElements(documentNoXpath);
			//for (WebElement obj : objfilteredList) {
			for (WebElement obj : objDocumentNo) {
				if (obj.getText().equals(invoiceNo))
					result = true;
				else {
					result = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
