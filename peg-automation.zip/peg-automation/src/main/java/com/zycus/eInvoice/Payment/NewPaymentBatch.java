package com.zycus.eInvoice.Payment;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

public class NewPaymentBatch extends eInvoice_CommonFunctions {

	private static By pgHead = By.id("cntPayBatch");
	private String company;
	private String bankAcct;

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * 
	 */

	public NewPaymentBatch(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	/**
	 * Constructor for the class
	 * 
	 * @param driver
	 * @param logger
	 * @param batchNo
	 * @param currency
	 * @param company
	 * @param bankAcct
	 * 
	 */

	//public NewPaymentBatch(WebDriver driver, ExtentTest logger, String batchNo, String currency, String company,
	public NewPaymentBatch(WebDriver driver, ExtentTest logger, String company,
			String bankAcct) {
		super(driver, logger);
		this.company = company;
		this.bankAcct = bankAcct;
	}

	/**
	 * @return the pgHead
	 */
	public By getPgHead() {
		return pgHead;
	}

	/**
	 * @param pgHead
	 *            the pgHead to set
	 */
	public void setPgHead(By pgHead) {
		this.pgHead = pgHead;
	}

	/**
	 * <b>Function:</b> selectOrgUnit_and_Bank
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param None
	 * @return result - True/False
	 * @throws Exception
	 */

	public void selectOrgUnit_and_Bank() throws Exception {
		try {
			findElement(By.id("lnkOU"),"..Organization Unit(s) selected").click();
			Thread.sleep(2000);
			if (driver.findElement(By.xpath("//div[div/span[text()='"+getLanguageProperty("Select Organization Unit and Bank Details")+"']]"))
					.isDisplayed()) {
				LogScreenshot("INFO", "Company here is "+ company);
				try {
					driver.findElement(By.id("txtOrganizationalUnit")).clear();
					enterText_AutoCompleteOrgDetails(By.id("txtOrganizationalUnit"),company);
					if (driver.findElement(By.xpath("//div[@class='treeContainer treeview']/ul"))!=null){
						//Selecting first organization unit from the displayed list tree
						findElement(By.xpath("//div[@class='treeContainer treeview']//li[1]//input")).click();
						findElement(By.xpath("//select[@id='txtBankName']/option[text()='"+bankAcct+"']")).click();
						try {
							findElement(By.xpath("//div[@id='diagCompanyUnitTree']//input[@value='"+getLanguageProperty("Save")+"']")).click();
							LogScreenshot("INFO","Organization Unit details added");
						} catch (Exception e) {
							if (driver.findElement(By.xpath("//div[contains(@class,'promptbx')][//td[contains(text(),'"+getLanguageProperty("Please select atleast one Organization Unit")+"')]]")).isDisplayed())
								findElement(By.xpath("//button/span[text()='"+getLanguageProperty("OK")+"']")).click();
							LogScreenshot("INFO", "Please select atleast one Organization Unit - message displayed");
						}
					}else
						LogScreenshot("INFO", "No results found - message displayed");
				}catch(Exception e) {
					e.printStackTrace();
				}
				Thread.sleep(5000);
			}else
				LogScreenshot("Fail", "Organization Unit and Bank Details popup not displayed");
		} catch (Exception e) {
			LogScreenshot("FAIL","Organization Unit and Bank Details not selected");
			e.printStackTrace();
			throw new Exception();
		}
	}

	/**
	 * <b>Function:</b> enterBatchDetails
	 * 
	 * @author Varun Khurana
	 * @since May 2018
	 * @param scheduledFor
	 * @param approver
	 * @param notes
	 * @param reviewer
	 * @return result - True/False
	 * @throws Exception
	 */

	//public void enterBatchDetails(Date scheduledFor, String approver, String notes, String reviewer) throws Exception {
	public String enterBatchDetails(String approver, String notes, String reviewer, NewVoucher objVoucher) throws Exception {
		String batchNo = null;
		try {
			//Enter Batch details
			selectOrgUnit_and_Bank();
			String batch = String.valueOf(generateNo());
			driver.findElement(By.id("txtBatchNo")).clear();
			driver.findElement(By.id("txtBatchNo")).sendKeys(batch);

			enterText_AutoComplete(By.id("txtApprover"), approver);

			findElement(By.id("txtBatchComments")).sendKeys(notes);

			enterText_AutoComplete(By.id("txtReviewer"), reviewer); 

			Thread.sleep(2000);
			LogScreenshot("INFO","Batch Details added");

			//Enter Voucher Details
			if (addVoucher(objVoucher)){
				Thread.sleep(6000);
				findElement(By.id("btnSubmit"), "Submit button").click();
				waitUntilInvisibilityOfElement(By.xpath("//div[@class='ui-widget-overlay ui-front']"));
				batchNo = batch;
				LogScreenshot("PASS",batchNo +" Batch created");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
		return batchNo;
	}

	public boolean addVoucher(NewVoucher objVoucher) throws Exception{
		boolean result = false;
		try {
			/*findElement(By.id("addVoucher")).click();
      waitUntilInvisibilityOfElement(By.id("status_overlay_savePaymentBatch"));*/
			clickAndWaitUntilLoaderDisappears(By.id("addVoucher"), By.id("status_overlay_savePaymentBatch"));
			try {
				if (driver.findElement(By.xpath("//label[contains(text(),'"+getLanguageProperty("Duplicate batch number")+"')]")) != null){
					String batchNo = String.valueOf(generateNo());
					WebElement objBatchNum = findElement(By.id("txtBatchNo"));
					objBatchNum.clear();
					objBatchNum.sendKeys(batchNo);
					LogScreenshot("INFO","Batch Number added");
					//addVoucher();
					/*findElement(By.id("addVoucher")).click();
          waitUntilInvisibilityOfElement(By.id("status_overlay_savePaymentBatch"));*/
					clickAndWaitUntilLoaderDisappears(By.id("addVoucher"), By.id("status_overlay_savePaymentBatch"));
				}
			}catch(Exception ex){}
			//NewVoucher objVoucher = new NewVoucher(driver, logger, "GDQA_SUPPLIER","chk123","voucher123");
			if (objVoucher.getPgHead()!=null){
				LogScreenshot("INFO", "Navigated to 'Create New Voucher' page");
				//objVoucher.createNewVoucher(voucherDate, supplierEmail, description, invoiceNo);
				objVoucher.createNewVoucher("abc@zycus.com", "desc", "123abc4");
				result = true;
			}
			else
				LogScreenshot("INFO", "Not Navigated to 'Create New Voucher' page");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	public boolean enterText_AutoCompleteOrgDetails(By field, String text) throws Exception {
		boolean result = false;
		try{
			driver.findElement(field).sendKeys(text);
			waitUntilInvisibilityOfElement(By.xpath("//input[@id='txtOrganizationalUnit' and contains(@class,'ui-autocomplete-loading')]"));
			Thread.sleep(1000);
			findElement(By.xpath("//div[@id='diagCompanyUnitTree']/following-sibling::ul[contains(@class,'autocomplete')]/li[text()='"+text+"']")).click();
			Thread.sleep(1000);
			result = true;
		}catch(Exception ex){
			try {
				driver.findElement(field).sendKeys(text);
				waitUntilVisibilityOfElement(By.xpath("//ul[contains(@class,'autocomplete') and contains(@style,'block')]"));
				Thread.sleep(1000);
				findElement(By.xpath("(//ul[contains(@style,'block')]//*[text()='" + text + "'])[1]")).click();
				Thread.sleep(1000);
				result = true;
			} catch (Exception e) {
				e.printStackTrace();
				JavascriptExecutor js = (JavascriptExecutor)driver;
				driver.findElement(field).clear();
				Thread.sleep(1500);
				driver.findElement(field).sendKeys(text);
				waitUntilInvisibilityOfElement(By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"));
				Thread.sleep(2000);
				WebElement ele = driver.findElement(By.xpath("(//ul[contains(@class,'autocomplete') and contains(@style,'block')]/li[contains(@class,'ui-menu-item')])[1]"));
				js.executeScript("arguments[0].click();", ele);
				Thread.sleep(3000);
				LogScreenshot("Info", "Text entered into the field is "+text);
			}
		}
		return result;
	} 


}
