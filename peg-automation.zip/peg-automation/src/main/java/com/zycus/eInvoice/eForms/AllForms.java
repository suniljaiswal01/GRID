package com.zycus.eInvoice.eForms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> AllForms.java
 * <br>
 * <b> Description: </b> To perform select New eForm 
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewForm: user shall be able to filter by Status 
 * <br>
 * 2.addSection: user shall be able to filter by Received On 
 * <br>
 * 3.addfield 
 * 
 * @author Varun Khurana
 * @since April 2018
 */

public class AllForms extends eInvoice_CommonFunctions {

  private static By pgHead = By.xpath("//h1[@class='pgHead'][contains(text(),'"+getLanguageProperty("All Forms")+"')]");
  String eFormName;
  /**
   * Constructor for the class
   * 
   * @param driver
   * @param logger
   * 
   */

  public AllForms(WebDriver driver, ExtentTest logger) {
    super(driver, logger);
  }

  /**
   * <b>Function:</b> selectNewFormCreationProcess
   * 
   * @author Varun Khurana
   * @since May 2018
   * @param formCreationProcess
   * @return result - True/False
   * @throws Exception
   */

  public String selectNewFormCreationProcess(String formCreationProcess, String formName, String formType,
      String formRelatedProcess, String businessUnit, String sectionName, String fieldToDisplayInSection, String fieldName, String formDescription, String sectionDescription, String sectionLayout, String defaultValue, String maxChar, String hideField, String enterSpace, String enterSplChar,
      String mandatory) throws Exception {
    Actions builder = new Actions(driver);
    try {
      WebElement hoverElem = findElement(By.xpath("//a[span[text()='"+getLanguageProperty("New eForm")+"']]"));
      builder.moveToElement(hoverElem).build().perform();
      findElement(By.xpath("//a[span[text()='"+formCreationProcess+"']]"), formCreationProcess +" link under + New eForm button").click();
      FormWizard objWizard = new FormWizard(driver, logger, formName, formType, formRelatedProcess,
          businessUnit, sectionName, fieldToDisplayInSection, fieldName, "Auto_display_Name"); 
      if (objWizard.getPgHead()!=null){
        eFormName= objWizard.createNewForm(formDescription, sectionDescription, sectionLayout, defaultValue, Integer.parseInt(maxChar), Boolean.parseBoolean(hideField), Boolean.parseBoolean(enterSpace), Boolean.parseBoolean(enterSplChar), Boolean.parseBoolean(mandatory));
      
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
    return eFormName;

  }


  public void searchEForm(String formCreationProcess, String eformName, String formType,
      String formRelatedProcess, String businessUnit, String sectionName, String fieldToDisplayInSection, String fieldName, String formDescription, String sectionDescription, String sectionLayout, String defaultValue, String maxChar, String hideField, String enterSpace, String enterSplChar,
      String mandatory) throws Exception {
    try {
      FormWizard objWizard = new FormWizard(driver, logger, eformName, formType, formRelatedProcess,
          businessUnit, sectionName, fieldToDisplayInSection, fieldName, "Auto_display_Name"); 
      driver.findElement(By.xpath("//a[@title='"+getLanguageProperty("Clear Filters")+"']")).click();
      waitUntilVisibilityOfElement(By.id("txtSrchApp"));  
      driver.findElement(By.id("txtSrchApp")).clear();
      driver.findElement(By.id("txtSrchApp")).sendKeys(eformName + Keys.ENTER);
      waitUntilVisibilityOfElement(By.id("processFormGrid"));  
      LogScreenshot("PASS",eformName+" searched successfully");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public boolean updateEForm(String formCreationProcess, String formName, String formType,
      String formRelatedProcess, String businessUnit, String sectionName, String fieldToDisplayInSection, String fieldName, String formDescription, String sectionDescription, String sectionLayout, String defaultValue, String maxChar, String hideField, String enterSpace, String enterSplChar,
      String mandatory) throws Exception {
    boolean result = false;
    Actions builder = new Actions(driver);
    try {
      FormWizard objWizard = new FormWizard(driver, logger, formName, formType, formRelatedProcess,
          businessUnit, sectionName, fieldToDisplayInSection, fieldName, "Auto_display_Name"); 
      Thread.sleep(3000);
      /*WebElement eFormTable = findElement(By.id("processFormGrid"));
      builder.moveToElement(eFormTable).build().perform();*/
      Thread.sleep(2000);
      driver.findElement(By.xpath("(//a[contains(@class,'eModify')][text()='"+getLanguageProperty("Modify")+"'])[1]")).click();
      //driver.findElement(By.xpath("//a[contains(@class,'eModify')][text()='"+getLanguageProperty("Modify")+"']")).click();
      waitUntilVisibilityOfElement(By.id("frmProcess"));
      objWizard.updateProcessFormDetails(formDescription, sectionDescription, sectionLayout, defaultValue, Integer.parseInt(maxChar), Boolean.parseBoolean(hideField), Boolean.parseBoolean(enterSpace), Boolean.parseBoolean(enterSplChar), Boolean.parseBoolean(mandatory));
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }  

  public boolean filterEForm(String filterType, String filterByProcessForm) throws Exception {
    boolean result = false;
    Actions builder = new Actions(driver);
    try {
      Thread.sleep(3000);
      driver.findElement(By.xpath("//a[@title='"+getLanguageProperty("Clear Filters")+"']")).click();
      filterByFormTypes(filterType,filterByProcessForm);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }  

  public void filterByFormTypes(String filterType,String filterByProcessForm) throws Exception {
    SoftAssert softAssert= new SoftAssert();
    driver.findElement(By.xpath("//a[@title='"+filterType+"']/following-sibling::a[contains(@title,'"+filterByProcessForm+"')]")).click();
    Thread.sleep(1500);
    if (driver.findElements(By.xpath("//h1[contains(text(),'"+filterByProcessForm+"')]")).size() > 0){
      List<WebElement> headLevelFormList= driver.findElements(By.xpath("//table[@id='processFormGrid']//tr//div[contains(text(),'"+filterByProcessForm+"')]"));
      for(WebElement xyz : headLevelFormList) {
        softAssert.assertTrue(xyz.isDisplayed());
      }
      softAssert.assertAll();
      LogScreenshot("PASS", "Filtered by "+filterByProcessForm);
    }  
  }  

  public void filterByStatus(String filterType) throws Exception {
  
    Actions builder = new Actions(driver);
    Thread.sleep(3000);
    driver.findElement(By.xpath("//a[@title='"+getLanguageProperty("Clear Filters")+"']")).click();
    if (driver.findElements(By.xpath("//table[@id='processFormGrid']//div[contains(text(),'"+filterType+"')]")).size() > 0){
      WebElement eFormTable = findElement(By.xpath("(//table[@id='processFormGrid']//div[contains(text(),'"+filterType+"')])[1]"));
      builder.moveToElement(eFormTable).build().perform();
      
      LogScreenshot("PASS", "Filtered by "+filterType);
    }else
      LogScreenshot("FAIL", "No records found");
  }  

  public void deactivateEForm() throws Exception {
    Actions builder = new Actions(driver);
    try {
      Thread.sleep(2000);
      WebElement eFormTable = findElement(By.id("processFormGrid"));
      builder.moveToElement(eFormTable).build().perform();
      Thread.sleep(2000);
      waitUntilVisibilityOfElement(By.xpath("//a[contains(@class,'statusdeactive')][text()='"+getLanguageProperty("Deactivate")+"']"));
      driver.findElement(By.xpath("//a[contains(@class,'statusdeactive')][text()='"+getLanguageProperty("Deactivate")+"']")).click();
      LogScreenshot("INFO","E-form to be deactivated");
      driver.findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Yes")+"']")).click();
      LogScreenshot("PASS","E-form deactivated successfully");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void deleteEForm() throws Exception {
    Actions builder = new Actions(driver);
    try {
      Thread.sleep(2000);
      WebElement eFormTable = findElement(By.id("processFormGrid"));
      builder.moveToElement(eFormTable).build().perform();
      Thread.sleep(2000);
      waitUntilVisibilityOfElement(By.xpath("//a[contains(@class,'eDelete')][text()='"+getLanguageProperty("Delete")+"']"));
      driver.findElement(By.xpath("//a[contains(@class,'eDelete')][text()='"+getLanguageProperty("Delete")+"']")).click();
      LogScreenshot("INFO","E-form to be deleted");
      driver.findElement(By.xpath("//span[@class='ui-button-text'][text()='"+getLanguageProperty("Yes")+"']")).click();
      LogScreenshot("PASS","E-form deleted successfully");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  /**{
   * 
   * @return the pgHead
   */
  public By getPgHead() {
    return pgHead;
  }

  /**
   * @param pgHead the pgHead to set
   */
  public void setPgHead(By pgHead) {
    this.pgHead = pgHead;
  }

}
