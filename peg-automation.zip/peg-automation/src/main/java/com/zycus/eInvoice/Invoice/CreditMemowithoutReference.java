package com.zycus.eInvoice.Invoice;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import common.Functions.eInvoice_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> CreditMemowithoutReference.java
 * <br>
 * <b> Description: </b> create Credit Memo without Reference
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createCreditMemo: user is able to create a Credit Memo without reference
 * 
 * <br>
 * 
 * @author Anisha
 * @since May 2018
 */

public class CreditMemowithoutReference extends eInvoice_CommonFunctions {

	private String supplierName;
	private String currency_value;
	private String creditMemoDate;
	private String purchaseType;
	/*private String description;
  private String product_cat;
  private String market_prc;
  private String quantity;
  private String GLType;
  private String GLAccount;
  private By supplierNameID = By.id("txtSupplierName");
  private By creditMemoNoID = By.id("txtInvoiceNumber");
  private By invoiceDateImgXpath = By.xpath("//input[@name='txtInvoiceDate']/following-sibling::img");
  private By purchaseTypeXpath = By
      .xpath("//*[@id='slctPurchaseType']/option[contains(text(),'" + purchaseType + "')]");
  private By addItemXpath = By.xpath("//*[@id='addMoreItems']//span[contains(text(),'"+getLanguageProperty("Add Item")+"')]");
  private By submitBtnId = By.xpath("//a[@id='btnSubmit' and text()='Submit']");*/
	private String company;
	private String businessUnit;
	private String location;
	private String costCenter;
	private String supplierSelectCategory;
	private String headerLvlTaxType;
	private String headLvlTaxRate;

	public CreditMemowithoutReference(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	public CreditMemowithoutReference(WebDriver driver, ExtentTest logger, String supplierSelectCategory, String supplierName, String currency_value,
			String creditMemoDate, String purchaseType, String company, String businessUnit, String location, String costCenter, String headerLvlTaxType, String headLvlTaxRate) {
		super(driver, logger);
		this.supplierSelectCategory = supplierSelectCategory;
		this.supplierName = supplierName;
		this.currency_value = currency_value;
		this.creditMemoDate = creditMemoDate;
		this.purchaseType = purchaseType;
		this.company = company;
		this.businessUnit = businessUnit;
		this.location = location;
		this.costCenter = costCenter;
		this.headerLvlTaxType = headerLvlTaxType;
		this.headLvlTaxRate= headLvlTaxRate;
		/*this.description = description;
    this.product_cat = product_cat;
    this.market_prc = market_prc;
    this.quantity = quantity;
    this.GLType = GLType;
    this.GLAccount = GLAccount;*/

	}

	/**
	 * <b>Function:</b> createCreditMemo
	 * 
	 * @author Anisha
	 * @since May 2018
	 * @param none
	 * @throws Exception
	 * @return status
	 */
	/*public boolean createCreditMemo() {
    boolean result = false;
    String creditMemoNo = String.valueOf(generateNo());
    JavascriptExecutor js = (JavascriptExecutor) driver;
    try {
      enterText_AutoComplete(supplierNameID, supplierName);
      selectCurrency(currency_value);
      selectAddress();
      sendKeys(creditMemoNoID, creditMemoNo);
      WebElement elem = findElement(invoiceDateImgXpath);
      js.executeScript("arguments[0].click()", elem);
      selectDate_v1(creditMemoDate);
      findElement(purchaseTypeXpath).click();
      addAttachment();
      scroll_into_view_element(findElement(addItemXpath));
      findElement(addItemXpath).click();
      Thread.sleep(3000);
      add_item(description, product_cat, market_prc, quantity, GLType);
      Thread.sleep(2000);
      findElement(submitBtnId).click();
      Thread.sleep(2000);
      LogScreenshot("INFO", "created CM without reference : " + creditMemoNo);
      result = true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }*/

	public String createCreditMemo() throws Exception {
		String creditMemo = null;
		creditMemo = createNewInvoiceOrCreditMemo(
				supplierSelectCategory,supplierName, currency_value, creditMemoDate,purchaseType, company, businessUnit, location, costCenter, headerLvlTaxType, headLvlTaxRate);
		return creditMemo;

	}

}
