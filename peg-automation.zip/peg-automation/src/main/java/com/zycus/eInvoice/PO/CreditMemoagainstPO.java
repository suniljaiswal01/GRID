package com.zycus.eInvoice.PO;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.zycus.eInvoice.Invoice.ItemDetails;

import Framework.ConfigurationProperties;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.iManage_CommonFunctions;

/**
 * <p>
 * <b> Title: </b> InvoiceAgainstPO.java
 * <br>
 * <b> Description: </b> create new Invoice against PO
 * <br>
 * <b> Functions: 
 * </b> <br>
 * 1.createNewInvoice: user is able to create an Invoice against a PO 
 * <br>
 * @author Anisha
 * @since May 2018
 */

public class CreditMemoagainstPO extends eInvoice_CommonFunctions {
	private String taxType;
	String invoiceStatus;
	String company;
	String businessUnit;
	String location;
	String costCenter;
	String project;
	//private String creditMemoNo;
	//private Date creditMemoDate;
	private static By saveBtnId = By.id("saveItemSummary");
	iManage_CommonFunctions objFunctions = new iManage_CommonFunctions(driver, logger);

	public CreditMemoagainstPO(WebDriver driver, ExtentTest logger) throws Exception {
		super(driver, logger);
		CommonFunctions1 objFunctions = new CommonFunctions1();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String Datasheet_eInvoice = configurationProperties.getProperty("Datasheet_eInvoice");
		String[][] abc = (String[][]) objFunctions.dataProvider("ItemDetails", Datasheet_eInvoice);
		this.taxType = abc[0][6];  
		String[][] abc1 = (String[][]) objFunctions.dataProvider("InvoiceNonPONew", Datasheet_eInvoice);
		this.company= abc1[0][6];
		this.businessUnit= abc1[0][7];
		this.location= abc1[0][8];
		this.costCenter= abc1[0][9];
		String[][] abc2 = (String[][]) objFunctions.dataProvider("CreditMemoAgainstPO", Datasheet_eInvoice);
		this.project = abc2[0][0];  
	}

	/**
	 * <b>Function:</b> createCreditMemo
	 * 
	 * @author Anisha
	 * @param none
	 * @since May 2018
	 * @throws Exception
	 * @return status
	 */

	public String createCreditMemo() throws Exception {
		String creditMemo = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		if (driver.findElements(By.xpath("//div[@role='dialog' and contains(@style,'block')]/div/span[text()='"+getLanguageProperty("Alert")+"']")).size() > 0){
			findElement(By.xpath("//div[@role='dialog' and contains(@style,'block')][div/span[text()='"+getLanguageProperty("Alert")+"']]//button[span[text()='"+getLanguageProperty("OK")+"']]")).click();
			findElement(By.id("cancelInvoice")).click();
			throw new Exception();
		}
		String creditMemoNo = String.valueOf(generateNo());
		driver.findElement(By.id("txtInvoiceNumber")).sendKeys(creditMemoNo);
		selectTodayDate();
		LogScreenshot("INFO","Date Details added");
		try {
			if (driver.findElements(By.id("txtBaseExchangeRate")).size() > 0) {
				driver.findElement(By.id("txtBaseExchangeRate")).sendKeys("50");
			}
		}catch(Exception e) {}
		if (addAttachment())
			LogScreenshot("INFO","Attachment added");
		else
			LogScreenshot("INFO","Attachment is not added");
		LogScreenshot("INFO","Attachment added");

		editBillingCostBookingforPOInvoice(company, businessUnit, location, costCenter, project);

		Thread.sleep(2000);
		scroll_into_view_element(findElement(By.id("einvoiceItemList")));
		ItemDetails objItem = new ItemDetails(driver, logger);  

		if (driver.findElement(By.id("vng-collapsibleGrid")).isDisplayed()) {

			/*  scroll_into_view_element(driver.findElement(By.id("vng-collapsibleGrid")));*/
			/*  Thread.sleep(2000);*/
			WebElement foo = driver.findElement(By.xpath(
					"//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)][1]"));
			if (foo.isDisplayed()) {
				Thread.sleep(2000);
				scroll_into_view_element(foo);
				Thread.sleep(2000);

				if (driver.findElements(By.xpath("//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)]")).size() > 0) {
					List<WebElement> itemLines= driver.findElements(By.xpath("//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)]"));        
					for(int i=1;i<=itemLines.size();i++)  
					{  System.out.println(itemLines.size());
					driver.findElement(By.xpath("//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)]["+i+"]")).click();
					objItem.editAccountingDetailsOfLineItem(i);
					}
					LogScreenshot("INFO","Item row selected");
				}  
			}else {
				LogScreenshot("FAIL","Item row disabled/not displayed");
			}
			Thread.sleep(3000);

			try {
				//Expand Item Details
				try {
					findElement(By.xpath("(//tbody/tr[contains(@id,'itemRow')]//input[not(@disabled)][1]/parent::td/following-sibling::td//span)[1]")).click();
				}catch(Exception e) {
					LogScreenshot("FAIL", "Item row is not clickable hence cannot proceed");
				}
				/*findElement(By.xpath("(//table[@id='vng-collapsibleGrid']/tbody//tr[contains(@id,'itemRow')]//input[not(@disabled)])[1]/ancestor::tr/following-sibling::tr[1]//td[contains(@class,'taxes')]//a[text()='"+getLanguageProperty("Edit")+"']")).click();
        driver.findElement(By.xpath("//div[@id='itemTaxes']//input[contains(@class,'selectTaxType')]")).click();
        findElement(By.xpath("//ul[contains(@style,'block')]/li[text()='"+taxType+"']")).click();
        driver.findElement(By.id("saveItemSummary")).click();*/
			}catch(Exception e) {}  

			try {
				if (driver.findElement(By.xpath("(//input[contains(@class,'txtInvoicedQty')])[1]")).getAttribute("data-invoiced-quantity").equals("0")) {
					driver.findElement(By.xpath("(//input[contains(@class,'txtInvoicedQty')])[1]")).sendKeys("6");  
					driver.findElement(By.xpath("(//input[contains(@class,'txtInvoicedQty')])[1]")).sendKeys(Keys.ENTER);  
				}
			}catch(Exception e) {}  
			Thread.sleep(5000);

			try {
				if (driver.findElement(By.xpath("(//input[contains(@class,'priceTxtbx txtMarketPrice')])[1]")).getAttribute("data-market-price").equals("0")) {
					driver.findElement(By.xpath("(//input[contains(@class,'priceTxtbx txtMarketPrice')])[1]")).sendKeys("2");
				}
			}catch(Exception e) {}  
			Thread.sleep(2000);


			Thread.sleep(5000);
			try {
				flexiFormDetails(false);      
			}catch(Exception e) {

			}
			//Workaround for Conversion rate getting empty
			try {
				if (driver.findElements(By.id("txtBaseExchangeRate")).size() > 0) {
					driver.findElement(By.id("txtBaseExchangeRate")).sendKeys("50");
				}
			}catch(Exception e) {}
			/*    findElement(saveBtnId).click();*/

			//DO NOT REMOVE THIS WAIT
			Thread.sleep(6000);
			LogScreenshot("INFO", "Before submit button");
			clickAndWaitUntilLoaderDisappears(By.id("btnSubmit"), By.xpath("//*[@id='status_overlay_updateInvoice']"));
			LogScreenshot("INFO","Details submitted");
			Thread.sleep(5000);
			if (driver
					.findElements(By.xpath("//*[@id='invoiceGrid']/tbody/tr[*]/td[1]/a[text()='" +creditMemoNo+"']")).size() > 0) {
				creditMemo = creditMemoNo;
				LogScreenshot("PASS",creditMemo+ "Credit Memo created");
			}
			return creditMemo;
		}
		return creditMemoNo;
	}
}
