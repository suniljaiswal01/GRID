package com.main;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;

public class SampleTransformerClass extends CommonTests1{
	
	boolean byPassAuthorStage = true;
	boolean commonWorkFlowEnabled = true;
	boolean authWorkflowAvailable = true;
	boolean signOffWorkflowAvailable = true;
	boolean isTouchFreeContract = true;
	
	boolean isNegotiating = true;
			
	public SampleTransformerClass() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	
	/**
	 * @param contractNumber
	 *            the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	private ExtentTest logger;
	private String Product = "iContract";
	private WebDriver driver1;
	eInvoice_CommonFunctions objFunctions;
	private String contractNumber;
	
	//ZCS production - Navisite
	//private String clauseCategory = "Test";
	//ZCS RM
	//private String clauseCategory = "Category 1";
	private String clauseTitle;
	private String templateName;
	private String contractTitle = null;
	private boolean isFileDownloaded = true;
	private String newDashboardName;
	private String dashboardName;
	
	private boolean isNegotiationAllowed = false;
	private boolean isExternalTemplateAvailable = false;
	
	private boolean sendForSigning = true;
	
	//Verify if signoffWorkflow is active or not
	private boolean isSignoffWorkflowActive = false;
	
	@Test(dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login")
	@TestDetails(TestID="iContract_1")
	public void Login_AuthContract(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		System.out.println("Sign off Workflow Active :"+isSignoffWorkflowActive);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "TypeSubType",description = "",
			dependsOnMethods = "loginNoNegotiate",
			priority = 2)
	@TestDetails(TestID="iContract_4")
	public void SignOffWorkflow(String contractType, String contractSubType) throws Exception {
		System.out.println("Sign off Workflow Active :"+isSignoffWorkflowActive);
	}
	
	}
