package com.main.iPerformFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Analyze.BySuppliers;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import common.Functions.SupplierDetails;
import common.Functions.iPerform_CommonFunctions;

public class SPMAnalyze  extends CommonTests1 {
	
	public String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;

	public SPMAnalyze() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}
	@Test(groups = "Login", dependsOnMethods = "com.main.iPerformFlows.CreateEvent.createNewEvent",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginAnalyze()
			throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}
	@Test( dependsOnMethods = {"com.main.iPerformFlows.CreateEvent.closeNewEvent","loginAnalyze"},alwaysRun=true)	
	@TestDetails(TestID = "iPerform_39")
	public void supplierDashboard() throws Exception {
		
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierName = supplierDetails.getCompanyName();
		BySuppliers bySuppliers = new BySuppliers(driver, logger);
		bySuppliers.supplierDashboard(supplierName,ScoreCard.Scorecard);
	}
	

	@Test(dependsOnMethods = "supplierDashboard")
	@TestDetails(TestID = "iPerform_39")
	public void trendDashboard() throws Exception {
		
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierName = supplierDetails.getCompanyName();
		BySuppliers bySuppliers = new BySuppliers(driver, logger);
		bySuppliers.trendDashboard(supplierName);
	}
	
/*
	@Test( dependsOnMethods = "com.main.iPerformFlows.CreateEvent.createNewEvent",priority = 3)
	@TestDetails(TestID = "iPerform_38")
	public void summaryReport() throws Exception {
		ByEvents byEvents = new ByEvents(driver, logger);
		byEvents.summaryEvent(CreateEvent.NewEvent);
	}*/
	
	
	/*@Test(dependsOnMethods = "loginAnalyze",dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider = "Dashboard",priority = 3)
	@TestDetails(TestID = "iPerform_39")
	public void hierarchicalDashboard(String supplierName) throws Exception {
		BySuppliers bySuppliers = new BySuppliers(driver, logger);
		bySuppliers.hierarchicalDashboard(supplierName);
	}
	
	@Test(dependsOnMethods = "loginAnalyze",dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider = "Dashboard",priority = 4)
	@TestDetails(TestID = "iPerform_39")
	public void facilityWiseKPI(String supplierName) throws Exception {
		BySuppliers bySuppliers = new BySuppliers(driver, logger);
		bySuppliers.trendDashboard(supplierName);
	}*/
}
