package com.main.iPerformFlows;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Develop.ProgramTemplates;
import com.zycus.iPerform.Develop.Programs;
import com.zycus.iPerform.Setup.ProductConfigurations;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import Framework.CommonUtility;
import common.Functions.SupplierDetails;
import common.Functions.iPerform_CommonFunctions;

public class CreateProgram extends CommonTests1{

//	private ExtentTest logger;
//	private String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;
	CommonUtility commonUtility;
	public static boolean flexiFormCreate;

	public static String linkedNewProgFromScratch = null;
	public static String programType = null;
	public static String programBenefit = null;
	public static String newProgFromScratch= null;

	public CreateProgram() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)

	@TestDetails(TestID="login")
	public void loginProgram() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods = "loginProgram")
	@TestDetails(TestID="iPerform_11")
	public void createNewProgramType() throws Exception {
		//Setup->Product Configurations

		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		programType = objConfig.addProgType();
		flexiFormCreate = objConfig.createFlexiform_FlexiformConfigurations("Develop",programType);
//				programType = "AutoProgType_633330";
	}
	
	@Test(dependsOnMethods = "createNewProgramType")
	@TestDetails(TestID="iPerform_11")
	public void deleteProgramBenefit() throws Exception {
		//Setup->Product Configuration
		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		objConfig.deleteProgbenfits();
//				programType = "AutoProgType_633330";
	}

	@Test(dependsOnMethods = "deleteProgramBenefit")
	@TestDetails(TestID="iPerform_12")
	public void createNewProgramBenefits() throws Exception {
		//Setup->Product Configurations
		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		programBenefit = objConfig.addProgBenefit();
//				programBenefit = "AutoProgBenefit_111989";
	}

	@Test(dependsOnMethods = "createNewProgramBenefits")
	@TestDetails(TestID="iPerform_16")
	public void createNewProgramTemplate() throws Exception {
		//Develop->Program Templates
		ProgramTemplates objTemplates = new ProgramTemplates(driver, logger);
		objTemplates.createNewProgramTemplate(programType, programBenefit);
	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,  dependsOnMethods = {"com.main.iPerformFlows.CreateEvent.closeNewEvent","createNewProgramTemplate"},dataProvider = "Suppliers", alwaysRun = true)	
//	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dataProvider = "Suppliers",dependsOnMethods = "createNewProgramTemplate")
	@TestDetails(TestID="iPerform_14")
	public void createNewProgFromScratch(String scoreCardType, String kpiRange) throws Exception {
		//Develop->Programs

		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierName = supplierDetails.getCompanyName();
		Programs objProg = new Programs(driver, logger);
		newProgFromScratch = objProg.createProgramFromScratch(supplierName, programType, programBenefit, scoreCardType, ScoreCard.Scorecard, kpiRange, KPI.KPI);
//		newProgFromScratch = objProg.createProgramFromScratch(supplierName, programType, programBenefit, scoreCardType, "Scorecard_482534", kpiRange, "KPI_986004", ProgStartDt, ProgEndDt, taskStartDt, taskEndDt);
		if(newProgFromScratch!=null)
			objProg.LogScreenshot("pass", "New Program From Scratch : "+newProgFromScratch);
		else
			objProg.LogScreenshot("fail", "New Program From Scratch : "+newProgFromScratch +"creation failed");
	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider = "Suppliers",dependsOnMethods = "createNewProgFromScratch")
	@TestDetails(TestID="iPerform_18")
	public void linkNewProgFromScratch(String scoreCardType, String kpiRange) throws Exception {
		//Develop->Programs
		
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierName = supplierDetails.getCompanyName();
		Programs objProg = new Programs(driver, logger);
		linkedNewProgFromScratch = objProg.linkNewProgramFromScratch(newProgFromScratch,supplierName,programType, programBenefit, scoreCardType, ScoreCard.Scorecard, kpiRange, KPI.KPI);
	}
	
	//UAT
	@Test(dependsOnMethods = {"createNewProgFromScratch","linkNewProgFromScratch"})
	@TestDetails(TestID="iPerform_14")
	public void concludeProgram() throws Exception {
		//Develop->Programs
		Programs objProg = new Programs(driver, logger);
		objProg.concludeProgram(newProgFromScratch);
		objProg.checkMilestoneCompletion(newProgFromScratch);
	}
	
	
}

