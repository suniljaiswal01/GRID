package com.main.iPerformFlows;

import java.util.HashMap;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Measure.EventLibrary;
import com.zycus.iPerform.Measure.ScoreEvents;
import com.zycus.iPerform.Setup.ProductConfigurations;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iPerform_CommonFunctions;

public class CreateEvent extends CommonTests1{

	iPerform_CommonFunctions objFunctions;

	public static String NewEvent =null;
	String cloneEvent =null;
	public static String eventType = null;
	HashMap<Boolean, String> inviteeMap = new HashMap<Boolean, String>();
	public static boolean flexiFieldCheck;


	public CreateEvent() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginEvent() throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginEvent")
	@TestDetails(TestID="iPerform_7")
	public void createNewEventType() throws Exception {
		//Setup->Product Configurations

		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		eventType = objConfig.addNewEventType();
		flexiFieldCheck = objConfig.createFlexiform_FlexiformConfigurations("Measure",eventType);
	}


	@Test(dataProviderClass = iPerform_DataProviderTestNG.class, dependsOnMethods = {"com.main.iPerformFlows.ScoreCard.createNewScorecard","createNewEventType"},dataProvider = "NewEvent", alwaysRun = true)
	@TestDetails(TestID="iPerform_8")
	public void createNewEvent(String searchSupplierBy, String searchScorecardBy, String invitee) throws Exception {
		//Measure->Scorecard Library
		EventLibrary objLibrary = new EventLibrary(driver, logger,eventType);
		
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String searchSupplierValue = supplierDetails.getCompanyName();
		inviteeMap.put(true, invitee);
		inviteeMap.put(false, searchSupplierValue);
		String measurePerfMethod = "One Time";
		int timeToOpenScoringEvent = 0;
		int scoringEventOpenedDays = 1;
		NewEvent = objLibrary.createNewEvent(flexiFieldCheck,searchSupplierBy, searchSupplierValue, searchScorecardBy, ScoreCard.Scorecard, KPI.KPI, inviteeMap, measurePerfMethod, timeToOpenScoringEvent, scoringEventOpenedDays);
		if(NewEvent!=null)
			objLibrary.LogScreenshot("pass", NewEvent+"Event created Successfully");
		else
			objLibrary.LogScreenshot("fail", NewEvent+"Event not created");
	}

	@Test(dependsOnMethods = "createNewEvent")
	@TestDetails(TestID="iPerform_1")
	public void scoreNewEventFromZSN() throws Exception {
	
		try {
			boolean isInviteeInternalMember = false;
			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String externalSupplier = supplierDetails.getSupplierEmail();
			String externalPass = supplierDetails.getSupplierPassword();
			Login objLogin = new Login(driver1, logger, externalSupplier, externalPass);
			callAndLog(driver1,logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Performance", "View Score Events", configurationProperties.getProperty("Tenant"));
			ScoreEvents scoreEvent = new ScoreEvents(driver1, logger);	
			scoreEvent.scoreTheEvent(NewEvent,isInviteeInternalMember);
			objLogin.logout();
		}catch (Exception e) {
			LogScreenshot("fail", "Scoring Failed From ZSN");
		}
		driver1.quit();
	}
	
	@Test(dependsOnMethods = {"createNewEvent","scoreNewEventFromZSN"})
	@TestDetails(TestID="iPerform_41")
	public void scoreNewEventFromInternalMember() throws Exception {

		boolean isInviteeInternalMember = true;
		ScoreEvents scoreEvent = new ScoreEvents(driver, logger);	
		scoreEvent.scoreTheEvent(NewEvent,isInviteeInternalMember);
	}



	@Test(dependsOnMethods= {"scoreNewEventFromInternalMember","scoreNewEventFromZSN"})
	@TestDetails(TestID="iPerform_38")
	public void closeNewEvent() throws Exception {
		ScoreEvents scoreEvent = new ScoreEvents(driver, logger);	
		scoreEvent.closeEvent(NewEvent);
	}

	@Test(dependsOnMethods= {"com.main.iPerformFlows.SPMAnalyze.supplierDashboard","com.main.iPerformFlows.CreateProgram.linkNewProgFromScratch"})
	@TestDetails(TestID="iPerform_8")
	public void reopenNewEvent() throws Exception {

		EventLibrary objLibrary = new EventLibrary(driver, logger);
		objLibrary.reOpenEvent(NewEvent);
		objLibrary.recallEvent(NewEvent);

	}
}

