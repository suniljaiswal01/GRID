package com.main.iPerformFlows;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Measure.EventLibrary;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class CloneEventTest extends CommonTests1{

	
	private String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;

	public static String NewEvent =null;
	public static String cloneEvent =null;
	String eventType = null;
	HashMap<Boolean, String> inviteeMap = new HashMap<Boolean, String>();


	public CloneEventTest() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login", dependsOnMethods = "com.main.iPerformFlows.CreateEvent.createNewEvent",alwaysRun = true)
	@TestDetails(TestID="login")
	public void cloneEvent() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	@Test(dependsOnMethods = {"com.main.iPerformFlows.CreateEvent.scoreNewEvent","cloneEvent"}, alwaysRun = true)
	@TestDetails(TestID="iPerform_8")
	public void cloneExistingEvent() throws Exception {
		//Measure->Scorecard Library
		EventLibrary objLibrary = new EventLibrary(driver, logger);

		String measurePerfMethod = "One Time";
		int timeToOpenScoringEvent = 0;
		int scoringEventOpenedDays = 1;

		cloneEvent = objLibrary.cloneExistingEvent(CreateEvent.NewEvent, measurePerfMethod, timeToOpenScoringEvent, scoringEventOpenedDays);
//		cloneEvent = objLibrary.cloneExistingEvent("AutoEvent_104761", measurePerfMethod, timeToOpenScoringEvent, scoringEventOpenedDays);
		if(cloneEvent!=null)
			objLibrary.LogScreenshot("pass", cloneEvent+"Event Cloned Successfully");
		else
			objLibrary.LogScreenshot("fail", cloneEvent+"Event not Cloned");
	}
	
	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dependsOnMethods = "cloneExistingEvent", dataProvider = "scoreEvent")
	@TestDetails(TestID="iPerform_1")
	public void delegateEvent(String internalSupplier) throws Exception {
		
		WebDriver driver1 = null;
		try {
			
			driver1 =startSession(internalSupplier,this.getClass().getName());
			displayStyle = getDisplayStyle(driver1, logger, CommonTests1.loginCredentials,internalSupplier);
			objFunctions = new iPerform_CommonFunctions(driver1, logger);
			objFunctions.navigateToMainPage(displayStyle, Product, "Measure","Score Events");
			EventLibrary objLibrary = new EventLibrary(driver1, logger);
			objLibrary.delegateEvent(cloneEvent);
		}catch (Exception e) {
			objFunctions.LogScreenshot("fail","Failed");
		}
		
		driver1.quit();	
	}
}

