package com.main.iPerformFlows;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.SCAR.SCARListing;
import com.zycus.iPerform.SCAR.SCARTemplate;
import com.zycus.iPerform.Setup.ProductConfigurations;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import Framework.CommonUtility;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iPerform_CommonFunctions;

public class CreateSCAR extends CommonTests1{


	iPerform_CommonFunctions objFunctions;
	CommonUtility commonUtility;

	private String newSCARTemplate;
	public static String newSCAR = null;
	String incidentType = null;


	public CreateSCAR() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginSCAR() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginSCAR")
	@TestDetails(TestID="iPerform_10")
	public void createNewIncidentType() throws Exception {
		//Setup->Product Configurations

		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		incidentType = objConfig.addIncidentTypes();
		objConfig.createFlexiform_FlexiformConfigurations("SCAR",incidentType);
	}


	@Test(dependsOnMethods = "createNewIncidentType")
	@TestDetails(TestID="iPerform_13")
	public void createNewSCARTemplate() throws Exception {
		//Develop->Program Templates

		SCARTemplate objTemplate = new SCARTemplate(driver, logger);
		newSCARTemplate = objTemplate.createNewTemplate(incidentType);
	}

	// 	@Test(dependsOnMethods = "createNewSCARTemplate", priority =14)
	@Test(dependsOnMethods = "createNewSCARTemplate",dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider = "SCAR")
	@TestDetails(TestID="iPerform_20")
	public void createNewSCAR(String severityLevel) throws Exception {
		//Develop->Program Templates

		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierName = supplierDetails.getCompanyName();
		String facility = supplierDetails.getFacility();
		String supplierContact = supplierDetails.getFirstName();
		
		SCARListing objNewScar = new SCARListing(driver, logger);
		newSCAR = objNewScar.createNewScar(facility, supplierName, severityLevel, supplierContact,newSCARTemplate);	
	}



	@Test(dependsOnMethods = "createNewSCAR")
	@TestDetails(TestID="iPerform_20")
	public void scoreSCAR() throws Exception {
		//Develop->Program Templates 
		try {
			SCARListing objNewScar = new SCARListing(driver, logger);
			objNewScar.internalApproval(newSCAR);

			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String supplier = supplierDetails.getSupplierEmail();
			String pass = supplierDetails.getSupplierPassword();
			
			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			Login objLogin = new Login(driver1, logger, supplier, pass);
			callAndLog(driver1,logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objNewScar = new SCARListing(driver1, logger);
			objZSNFunctions.navigate_path1("My Performance", "View SCARs", configurationProperties.getProperty("Tenant"));

			String status = objNewScar.externalApproval1(newSCAR);
			if(status.equals("Approval Pending")) {
				objNewScar = new SCARListing(driver, logger);
				objNewScar.verifyResponse(newSCAR,2);
			}

			objNewScar = new SCARListing(driver1, logger);
			status = objNewScar.externalApproval2(newSCAR);
			if(status.equals("Approval Pending")) {
				objNewScar = new SCARListing(driver, logger);
				objNewScar.verifyResponse(newSCAR,3);
			}
			objLogin.logout();
		}catch (Exception e) {
			LogScreenshot("fail", "Failed");
		}
		driver1.quit();
	}



	//UAT
	@Test(dependsOnMethods = "scoreSCAR")
	@TestDetails(TestID="iPerform_20")
	public void SCARArchive() throws Exception {

		SCARListing objNewScar = new SCARListing(driver, logger);
		objNewScar.closeScar(newSCAR); 	
		objNewScar.checkInSCARArchive(newSCAR);

	}

}

