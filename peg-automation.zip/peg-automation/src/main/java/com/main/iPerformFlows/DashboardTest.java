package com.main.iPerformFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Dashboard.CommonDashboard;
import com.zycus.iPerform.Dashboard.Dashboard;
import com.zycus.iPerform.Reports.Reports;
import com.zycus.iPerform.SCAR.SupplierSegmentation;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class DashboardTest  extends CommonTests1 {


	public String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;

	public DashboardTest() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginDashboard()throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginDashboard",dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider ="standardDashboard")
	@TestDetails(TestID = "iPerform_34")
	public void standardDashboard(String...Reports) throws Exception {

		Dashboard dashboard = new Dashboard(driver, logger);
		for(String report : Reports)
			dashboard.exportStdReport(report);
	}

	@Test(dependsOnMethods = "standardDashboard",dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider ="report",alwaysRun = true)
	@TestDetails(TestID = "iPerform_35")
	public void addReportToDashboard(String report,String dashboardFolder,String dashboardLayout) throws Exception {

		Reports dashboard = new Reports(driver, logger);
		dashboard.addReportToNewDashboard(report,dashboardFolder,dashboardLayout);
	}
	
	

	@Test(dependsOnMethods = "addReportToDashboard",alwaysRun = true)
//	@Test(dependsOnMethods = "loginDashboard",alwaysRun = true)
	@TestDetails(TestID = "iPerform_36")
	public void exportDashboard() throws Exception {

		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
        objCustomDashboard.exportDashboard("Excel");
        objCustomDashboard.exportDashboard("Word");
        objCustomDashboard.exportDashboard("PowerPoint");
        objCustomDashboard.exportDashboard("PDF");
	}
	
	
	@Test(dependsOnMethods = "exportDashboard",alwaysRun = true)
	@TestDetails(TestID="iPerform_24")
	public void createSegmentation() throws Exception {
		//Develop->Program Templates

		SupplierSegmentation supplierSegmentation = new SupplierSegmentation(driver, logger);
		String configuration = supplierSegmentation.createSegmentation();
		if(configuration!=null)
			supplierSegmentation.deleteSegementation(configuration);
		else
			LogScreenshot("info","Segmentation Not added");
		
	}

	/*@Test(dependsOnMethods = "createSegmentation",alwaysRun = true)
	@TestDetails(TestID="iPerform_24")
	public void viewSegmentation() throws Exception {
		
		SupplierSegmentation supplierSegmentation = new SupplierSegmentation(driver, logger);
		supplierSegmentation.checkListingPage();
	}*/
	
	
	/*@Test(dependsOnMethods = {"viewSegmentation","com.main.iPerformFlows.KPI.createNewKPI"},dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider ="Dashboard")
	@TestDetails(TestID = "iPerform_37")
	public void createAlert(String supplierName) throws Exception {

		AlertsReminders alertsReminders = new AlertsReminders(driver, logger);
		alertsReminders.createNewAlert(supplierName);

	}*/

}
