package com.main.iPerformFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class SPM_CRMS_Integration  extends CommonTests1 {
	//	private ExtentTest logger;
	public String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;

	public SPM_CRMS_Integration() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true,dependsOnMethods="com.main.iPerformFlows.CreateProgram.createNewProgramTemplate")
	@TestDetails(TestID = "login")
	public void SPMloginCRMSIntegration()
			throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}


	@Test(dependsOnMethods = {"SPMloginCRMSIntegration","com.main.iPerformFlows.CreateProgram.createNewProgFromScratch"}, dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider ="crms_reportGeneration",alwaysRun=true)
	@TestDetails(TestID = "iPerform_CRMSIntegration")
	public void crms_reportGeneration(String category, String... data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		if(createNewReport.selectProduct(Product)) {
			createNewReport.selectParams(category, data);
			VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
			verifyReportsField.iPerformFieldCheck(category);
			verifyReportsField.backToReportListing();
		}
	}
}
