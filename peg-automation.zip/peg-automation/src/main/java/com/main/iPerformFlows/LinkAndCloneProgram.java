package com.main.iPerformFlows;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Develop.Programs;
import com.zycus.iPerform.Setup.ProductConfigurations;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import Framework.CommonUtility;
import common.Functions.iPerform_CommonFunctions;

public class LinkAndCloneProgram extends CommonTests1{

	iPerform_CommonFunctions objFunctions;
	CommonUtility commonUtility;

	private String newClonedProg = null;
	public LinkAndCloneProgram() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}


	@Test(groups = "Login", alwaysRun = true,dependsOnMethods="com.main.iPerformFlows.CreateEvent.closeNewEvent")
	@TestDetails(TestID="login")
	public void loginLinkAndCloneProgram() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = "com.main.iPerformFlows.CreateProgram.createNewProgFromScratch")
	@TestDetails(TestID="iPerform_15")
	public void cloneExistingProg() throws Exception {
		//Develop->Programs
		Programs objProg = new Programs(driver, logger);
		newClonedProg  = objProg.cloneExistingProg(CreateProgram.newProgFromScratch);
	}


	@Test(dependsOnMethods = {"cloneExistingProg","com.main.iPerformFlows.CreateProgram.linkNewProgFromScratch"})
	@TestDetails(TestID="iPerform_19")
	public void linkWithClonedProg() throws Exception {
		//Develop->Programs
		Programs objProg = new Programs(driver, logger);
		objProg.linkClonedNewProgram(newClonedProg, CreateProgram.linkedNewProgFromScratch);
	}

	@Test(dependsOnMethods = "linkWithClonedProg",alwaysRun=true)
	@TestDetails(TestID="iPerform_12")
	public void deleteProgramBenefit() throws Exception {
		//Setup->Product Configurations
		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		objConfig.deleteProgBenefit(CreateProgram.programBenefit);
	}


}

