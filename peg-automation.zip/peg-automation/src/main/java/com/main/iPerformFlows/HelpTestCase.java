package com.main.iPerformFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Help.AboutIPerform;
import com.zycus.iPerform.Help.HelpVideos;
import com.zycus.iPerform.Help.ReleaseNotes;
import com.zycus.iPerform.Help.ScorerOnlineHelp;
import com.zycus.iPerform.Help.UserManualProduct;
import com.zycus.iPerform.Help.UserOnlineHelp;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class HelpTestCase  extends CommonTests1 {


	public String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;

	public HelpTestCase() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginHelp()
			throws Exception {
	
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}


	@Test(dependsOnMethods = "loginHelp", priority = 1)
	@TestDetails(TestID = "iPerform_27")
	public void releaseNote() throws Exception {

		ReleaseNotes releaseNote = new ReleaseNotes(driver, logger);
		releaseNote.verifyLatestReleaseNote("18.12.1.0");
	}
		
	@Test(dependsOnMethods = "loginHelp", priority = 2)
	@TestDetails(TestID = "iPerform_28")
	public void releaseVideo() throws Exception {

		HelpVideos releaseVideo = new HelpVideos(driver, logger);
		releaseVideo.verifyLatestRelVideo();
	}

	@Test(dependsOnMethods = "loginHelp", priority = 3)
	@TestDetails(TestID = "iPerform_29")
	public void userOnlineHelp() throws Exception {


		UserOnlineHelp userOnlineHelp = new UserOnlineHelp(driver, logger);
		userOnlineHelp.verifyOnlineHelpPage("abc");
	}

	@Test(dependsOnMethods = "loginHelp", priority = 4)
	@TestDetails(TestID = "iPerform_30")
	public void scorerOnlineHelp() throws Exception {

		ScorerOnlineHelp scorerOnlineHelp = new ScorerOnlineHelp(driver, logger);
		scorerOnlineHelp.verifyScorerOnlineHelp("iPerform Scorer Manual - Green (Rainbow)");
	}
	
	@Test(dependsOnMethods = "loginHelp", priority = 5)
	@TestDetails(TestID = "iPerform_31")
	public void userManualForProduct() throws Exception {

		UserManualProduct userManualProduct = new UserManualProduct(driver, logger);
		userManualProduct.verifyOnlineHelpPage("abc");
	}
	
	@Test(dependsOnMethods = "loginHelp", priority = 6)
	@TestDetails(TestID = "iPerform_32")
	public void userManualForScorer() throws Exception {

		AboutIPerform aboutiPerform = new AboutIPerform(driver, logger);
		aboutiPerform.verifyVersion("abc");
	}
	
	@Test(dependsOnMethods = "loginHelp", priority = 7)
	@TestDetails(TestID = "iPerform_33")
	public void aboutIPerform() throws Exception {

		AboutIPerform aboutiPerform = new AboutIPerform(driver, logger);
		aboutiPerform.verifyVersion("abc");
	}
	
}