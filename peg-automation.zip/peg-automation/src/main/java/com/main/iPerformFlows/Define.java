package com.main.iPerformFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Define.ScoreRange;
import com.zycus.iPerform.Define.SupplierRank;
import com.zycus.iPerform.Define.TargetStatus;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class Define  extends CommonTests1 {

	public String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;

	public Define() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginDefine()
			throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dataProvider = "",dependsOnMethods = "loginDefine", alwaysRun=true)
	@TestDetails(TestID="iPerform_21")
	public void modifySupplierRank() throws Exception {
		SupplierRank supplierRank = new SupplierRank(driver, logger);
		supplierRank.verifyModificationAllowed();		
	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dataProvider = "",dependsOnMethods = "modifySupplierRank", alwaysRun=true)
	@TestDetails(TestID="iPerform_23")
	public void modifyTargetStatus() throws Exception {
		TargetStatus targetStatus = new TargetStatus(driver, logger);
		targetStatus.verifyModificationAllowed();
	}
	
	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dataProvider = "",dependsOnMethods = "modifyTargetStatus", alwaysRun=true)
	@TestDetails(TestID="iPerform_22")
	public void modifyScoreRange() throws Exception {
		ScoreRange scoreRange = new ScoreRange(driver, logger);
		scoreRange.verifyModificationAllowed();
		
	}

}
