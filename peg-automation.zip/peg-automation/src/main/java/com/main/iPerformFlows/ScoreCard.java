package com.main.iPerformFlows;


import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.main.ZycusConfig;
import com.zycus.iPerform.Define.ScorecardLibrary;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import Framework.CommonUtility;
import common.Functions.iPerform_CommonFunctions;

public class ScoreCard extends CommonTests1{

	iPerform_CommonFunctions objFunctions;
	CommonUtility commonUtility;

	public static String Scorecard = null;
	String newClonedScoreCard =null;
	HashMap<Boolean, String> inviteeMap = new HashMap<Boolean, String>();


	public ScoreCard() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}
	

	@Test(groups = "Login",alwaysRun = true)

	@TestDetails(TestID="login")
	public void loginScoreCard() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	
	@Test(dependsOnMethods = {"loginScoreCard","com.main.iPerformFlows.KPI.createNewKPI"} ,alwaysRun=true)
	@TestDetails(TestID="iPerform_5")
	public void createNewScorecard() throws Exception {
		//Define->Scorecard Library
		ScorecardLibrary objLibrary = new ScorecardLibrary(driver, logger);
		Scorecard = objLibrary.createNewScorecard("KPI Name",KPI.KPI);
		objLibrary.exportScoreCard(Scorecard);
//		ZycusConfig ocfg = new ZycusConfig();
		objLibrary.filterByText("Scorecard Name", Scorecard);
		String userName = getUserName();
		objLibrary.filterByText("Created By",userName);
	}
	
	
	@Test(dependsOnMethods = "createNewScorecard")
	@TestDetails(TestID="iPerform_6")
	public void cloneExistingScorecard() throws Exception {
		//Define->Scorecard Library
		ScorecardLibrary objLibrary = new ScorecardLibrary(driver, logger);
		newClonedScoreCard = objLibrary.cloneExistingScorecard("Scorecard Name",Scorecard);
	}
	
	
	
}

