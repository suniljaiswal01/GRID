package com.main.iPerformFlows;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Setup.ClientSettings_ProdConfig;
import com.zycus.iPerform.Setup.ProductConfigurations;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import Framework.CommonUtility;
import common.Functions.iPerform_CommonFunctions;

public class DeleteProjectData extends CommonTests1{

//	private ExtentTest logger;
//	private String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;
	CommonUtility commonUtility;
	public static String linkedNewProgFromScratch = null;
	public static String programType = null;
	public static String programBenefit = null;
	public static String newProgFromScratch= null;

	public DeleteProjectData() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)

	@TestDetails(TestID="login")
	public void loginProgram() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	/*@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dependsOnMethods = "loginProgram")
	@TestDetails(TestID="iPerform_3")
	public void deleteKPI() throws Exception {
		//Define->KPI Library
		KPILibrary objLibrary = new KPILibrary(driver, logger);
		objLibrary.deleteKPI();
	}*/
	
//	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dependsOnMethods = "loginProgram")
//	@TestDetails(TestID="iPerform_2")
//	public void deleteKPICategory() throws Exception {
//		//Setup -> Product Configurations
//		ClientSettings_ProdConfig objSettings = new ClientSettings_ProdConfig(driver, logger);
//		objSettings.navigateToKPICategories();
//		objSettings.deleteKPiCategory();
//
//	}

	
//	@Test(dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider = "",dependsOnMethods = "loginProgram")
//	@TestDetails(TestID="iPerform_11")
//	public void deleteProgramType() throws Exception {
//		//Setup->Product Configuration
//		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
//		objConfig.deleteProgType();
////				programType = "AutoProgType_633330";
//	}
//	
	
	@Test(dataProviderClass = iPerform_DataProviderTestNG.class, dataProvider = "",dependsOnMethods = "loginProgram")
	@TestDetails(TestID="iPerform_11")
	public void deleteProgramBenefit() throws Exception {
		//Setup->Product Configuration
		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		objConfig.deleteProgbenfits();
//				programType = "AutoProgType_633330";
	}
	
	
	@Test(dependsOnMethods = "loginProgram")
	@TestDetails(TestID="iPerform_10")
	public void createNewIncidentType() throws Exception {
		//Setup->Product Configurations

		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		objConfig.deleteIncidentType();
	}
	

	@Test(dependsOnMethods = "loginProgram")
	@TestDetails(TestID="iPerform_7")
	public void createNewEventType() throws Exception {
		//Setup->Product Configurations

		ProductConfigurations objConfig = new ProductConfigurations(driver, logger);
		objConfig.deleteEventType();
	}

}

