package com.main.iPerformFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Reports.Reports;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;

public class SPMReport extends CommonTests1{

//	private ExtentTest logger;
	/*private String Product = "iSave";
	eInvoice_CommonFunctions objFunctions;*/

	String projectType = null;

	public SPMReport() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReport() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dependsOnMethods = "loginReport",dataProvider = "Reports")
	@TestDetails(TestID="iPerform_35")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class, dependsOnMethods = "Reports",dataProvider = "ModifyReports")
	@TestDetails(TestID="iPerform_35")
	public void ModifyReport(String report) throws Exception {

		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
	}
}
