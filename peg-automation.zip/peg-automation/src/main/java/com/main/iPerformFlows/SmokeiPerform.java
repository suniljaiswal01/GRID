package com.main.iPerformFlows;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.iPerform_DataProviderTestNG;
import common.Functions.NavigationViaMenu;
import common.Functions.eInvoice_CommonFunctions;

public class SmokeiPerform extends CommonTests1{

//	private ExtentTest logger;
	private String Product = "iPerform";
	eInvoice_CommonFunctions objFunctions;

	public SmokeiPerform() throws Exception {
		super();
		setProduct("iPerform");
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}
	

	@Test(dataProviderClass =iPerform_DataProviderTestNG.class, dataProvider = "navigateViaSideMenu")
	@TestDetails(TestID = "login")
	public void navigateViaSideMenu(String Username, String Password, String Customer, String userAccount, String Environment, String...navigation) throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
		objFunctions.navigateToMainPage(displayStyle, Product, navigation);
		NavigationViaMenu navigateViaMenu = new NavigationViaMenu(driver, logger);
		navigateViaMenu.validateNavigation(Product,navigation);
	}
}

