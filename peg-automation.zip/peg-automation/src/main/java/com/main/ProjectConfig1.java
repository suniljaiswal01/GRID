package com.main;

import org.openqa.selenium.WebDriver;

import Framework.ConfigurationProperties;
import Framework.FrameworkUtility;

public class ProjectConfig1 {

	private static String scriptID;
	private static String displayStyle;
	private static int countofInvoiceApprovers;
	private static WebDriver driver;

	public static String getScriptID() {
		return scriptID;
	}

	public static void setScriptID(String scriptID) {
		ProjectConfig1.scriptID = scriptID;
	}

	/**
	 * @return the displayStyle
	 */
	public static String getDisplayStyle() {
		return displayStyle;
	}

	/**
	 * @param displayStyle the displayStyle to set
	 */
	public static void setDisplayStyle(String displayStyle) {
		ProjectConfig1.displayStyle = displayStyle;
	}

	/**
	 * @return the countofInvoiceApprovers
	 */
	public static int getCountofInvoiceApprovers() {
		return countofInvoiceApprovers;
	}

	/**
	 * @param count the countofInvoiceApprovers to set
	 */
	public static void setCountofInvoiceApprovers(int count) {
		ProjectConfig1.countofInvoiceApprovers = count;
	}
	
	public static WebDriver getDriver() throws Exception {
		FrameworkUtility objFrameworkUtility = new FrameworkUtility();
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		ProjectConfig1.driver = objFrameworkUtility.getWebDriverInstance1(configurationProperties);
		return ProjectConfig1.driver;
	} 

}
