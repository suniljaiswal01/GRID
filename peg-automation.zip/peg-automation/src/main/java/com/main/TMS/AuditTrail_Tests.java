package com.main.TMS;

import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.UserCreation;

import Framework.ConfigurationProperties;




public class AuditTrail_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "TMS";
	ConfigurationProperties config = ConfigurationProperties.getInstance();



	public AuditTrail_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.iManage_CommonFunctions");

	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_AuditTrail() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods = "com.main.TMS.CreateRole_Tests.createNewRole")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForRoleCreation() throws Exception {
		if(CreateRole_Tests.roleName!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = config.getProperty("UserAccount");
			String roleCreated= CreateRole_Tests.roleName; 
			objUserCreation.verifyAuditTrail(userCreatedBy, roleCreated, "Role Created","Role Management");
		}else
			throw new SkipException("Skipping AverifyAuditTrailForRoleCreation()");
	}

	@Test(dependsOnMethods = {"com.main.TMS.UserGroups_Tests.userGroup","verifyAuditTrailForRoleCreation"})
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForUserGroupCreation() throws Exception {
		if(UserGroups_Tests.groupName!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = config.getProperty("UserAccount");
			String groupCreated= UserGroups_Tests.groupName; 
			objUserCreation.verifyAuditTrail(userCreatedBy, groupCreated, "User Group Created","User Groups");
		}else
			throw new SkipException("Skipping verifyAuditTrailForUserGroupCreation()");
	}

	@Test(dependsOnMethods = {"com.main.TMS.UserListing_Tests.createNewUser","verifyAuditTrailForUserGroupCreation"})
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForUserCreation() throws Exception {
		if(UserListing_Tests.userNew!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = config.getProperty("UserAccount");
			String userCreated= UserListing_Tests.userNew; 
			objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "User Created","Users");
		}else
			throw new SkipException("Skipping verifyAuditTrailForUserCreation()");

	}

	@Test(dependsOnMethods = {"com.main.TMS.UserActions_Test.resetPassword","verifyAuditTrailForUserCreation"})
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForPasswordReset() throws Exception {
		if(UserListing_Tests.userNew!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = config.getProperty("UserAccount");
			String userCreated= UserListing_Tests.userNew;
			objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "Password Reset","Users");

		}else
			throw new SkipException("Skipping verifyAuditTrailForPasswordReset()");
	}


	@Test(dependsOnMethods = {"com.main.TMS.UserListing_Tests.editUserEmailID","verifyAuditTrailForPasswordReset"})
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForUserEdit() throws Exception {
		if(UserListing_Tests.userEdited!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = config.getProperty("UserAccount");
			String userEdited= UserListing_Tests.userEdited; 
			objUserCreation.verifyAuditTrail(userCreatedBy, userEdited, "User Updated","Users");
		}else
			throw new SkipException("Skipping verifyAuditTrailForUserEdit()");
	}


	@Test(dependsOnMethods = {"com.main.TMS.UserActions_Test.activateDeactivateUser","verifyAuditTrailForUserEdit"})
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForActivateDeactivateUser() throws Exception {
		UserCreation objUserCreation= new UserCreation(driver, logger);
		String userCreatedBy = config.getProperty("UserAccount");
		if(UserActions_Test.userToActivate!=null) {
			String userCreated= UserActions_Test.userToActivate;
			if(UserActions_Test.activationFlag!=false)
			objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "User Activated","Users");
			if(UserActions_Test.deactivationflag!=false)
			objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "User Deactivated","Users");
		}
		else if(UserGroups_Tests.groupName!=null) {
			String groupCreated= UserGroups_Tests.groupName;
			objUserCreation.verifyAuditTrail(userCreatedBy, groupCreated, "User Group Deactivated","User Groups");
		}else
			throw new SkipException("Skipping verifyAuditTrailForActivateDeactivateUser()");
	}


}
