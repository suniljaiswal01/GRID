package com.main.TMS;


import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.RoleCreation;
import com.zycus.TMS.UserCreation;

import DataProviders.TMS_DataproviderTestNG;
import Framework.CommonUtility;
import Framework.ConfigurationProperties;
import common.Functions.TMS_CommonFunctions;

public class CreateRole_Tests extends CommonTests1{

//	private ExtentTest logger;
	private String Product = "TMS";
	TMS_CommonFunctions objFunctions;
	CommonUtility commonUtility;
	ConfigurationProperties config = ConfigurationProperties.getInstance();

	String KPICategory =null;
	public static String  KPI = null;
	String newClonedKPI =null;
	public static String roleName;

	public CreateRole_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.TMS_CommonFunctions");
	}
	

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginTMS() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = TMS_DataproviderTestNG.class,dependsOnMethods = "loginTMS")
	@TestDetails(TestID="TMS_3")
	public void createNewRole() throws Exception {
		RoleCreation roleCreation = new RoleCreation(driver,logger);
		roleName= roleCreation.newRole();
		roleCreation.assignRoleToUser();
		roleCreation.changeRole();
	}	
	
	@Test(dependsOnMethods = "createNewRole")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForRoleCreation() throws Exception {
		if(roleName!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = getUserEmail(getClassName());
			objUserCreation.verifyAuditTrail(userCreatedBy, roleName, "Role Created","Role Management");
		}else
			throw new SkipException("Skipping AverifyAuditTrailForRoleCreation()");
	}
}
