package com.main.TMS;

import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.UserCreation;

import DataProviders.TMS_DataproviderTestNG;
import Framework.ConfigurationProperties;

public class UserListing_Tests extends CommonTests1 {

	private String Product = "TMS";
	public static String userNew;
	public static String groupName;
	public static String userEdited=null;
	ConfigurationProperties config = ConfigurationProperties.getInstance();

	public UserListing_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_UserListing() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}

	@Test(dependsOnMethods = "login_UserListing")
	@TestDetails(TestID = "TMS_2")
	public void createNewUser() throws Exception {
		UserCreation objUserCreation = new UserCreation(driver, logger);
		userNew = objUserCreation.createNewUser();
		objUserCreation.searchByEmailID(userNew);		
	}
	
	@Test(dependsOnMethods = "createNewUser")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForUserCreation() throws Exception {
		if(userNew!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);		
			String userCreatedBy = getUserEmail(getClassName());
		//	String userCreated= UserListing_Tests.userNew; 
			objUserCreation.verifyAuditTrail(userCreatedBy, userNew, "User Created","Users");
		}else
			throw new SkipException("Skipping verifyAuditTrailForUserCreation()");

	}

	@Test(dependsOnMethods = {"createNewUser","verifyAuditTrailForUserCreation"},  dataProvider = "EditUser", dataProviderClass = TMS_DataproviderTestNG.class)
	@TestDetails(TestID = "TMS_2")
	public void editUser(String role, String scope) throws Exception {
		UserCreation objUserCreation = new UserCreation(driver, logger);
		objUserCreation.searchByEmailID(userNew);
		objUserCreation.editNewUser();
		objUserCreation.editUserRole(role);
		if (!config.getProperty("Setup").contains("AWS Australia Production"))
			objUserCreation.editUserScope(scope);
		objUserCreation.editProductAllocation();
	}


	@Test(dependsOnMethods = "editUser")
	@TestDetails(TestID = "TMS_2")
	public void editUserEmailID() throws Exception {
		UserCreation objUserCreation = new UserCreation(driver, logger);
		userEdited = objUserCreation.editUserEmailID(userNew);
		//objUserCreation.searchByEmailID(userEdited);
	}
	

	@Test(dependsOnMethods = "editUserEmailID")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForUserEdit() throws Exception {
		if(userEdited!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = getUserEmail(getClassName());
			//String userEdited= UserListing_Tests.userEdited; 
			objUserCreation.verifyAuditTrail(userCreatedBy, userEdited, "User Updated","Users");
		}else
			throw new SkipException("Skipping verifyAuditTrailForUserEdit()");
	}

	

}
