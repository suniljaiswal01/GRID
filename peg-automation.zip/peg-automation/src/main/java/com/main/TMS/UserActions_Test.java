package com.main.TMS;

import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.UserCreation;

import Framework.ConfigurationProperties;

public class UserActions_Test extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "TMS";
	static String userToCopy;
	static String userToActivate;
	static boolean deactivationflag;
	static boolean activationFlag;
	ConfigurationProperties config = ConfigurationProperties.getInstance();
	public UserActions_Test() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.iManage_CommonFunctions");

	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_UserActions() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}



	@Test(dependsOnMethods = "com.main.TMS.UserListing_Tests.createNewUser")
	@TestDetails(TestID="TMS_2")
	public void resetPassword() throws Exception {
		UserCreation objUserCreation= new UserCreation(driver, logger);
		objUserCreation.searchByEmailID(UserListing_Tests.userNew);
		objUserCreation.resetPassword(UserListing_Tests.userNew);
	}


	@Test(dependsOnMethods = "resetPassword")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForPasswordReset() throws Exception {
		if(UserListing_Tests.userNew!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = getUserEmail(getClassName());
			String userCreated= UserListing_Tests.userNew;
			objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "Password Reset","Users");

		}else
			throw new SkipException("Skipping verifyAuditTrailForPasswordReset()");
	}



	@Test(dependsOnMethods = {"com.main.TMS.UserListing_Tests.editUserEmailID","verifyAuditTrailForPasswordReset"})
	@TestDetails(TestID="TMS_2")
	public void copyUser() throws Exception {
		if(UserListing_Tests.userEdited!=null) {
			userToCopy = UserListing_Tests.userEdited;
		}else {
			userToCopy = UserListing_Tests.userNew;
		}

		UserCreation objUserCreation= new UserCreation(driver, logger);
		objUserCreation.searchByEmailID(userToCopy);
		objUserCreation.copyUser(userToCopy);
	}



	@Test(dependsOnMethods = "copyUser", alwaysRun= true)
	@TestDetails(TestID="TMS_2")
	public void activateDeactivateUser() throws Exception {

		UserCreation objUserCreation= new UserCreation(driver, logger);
		if(UserListing_Tests.userEdited!=null) {
			userToActivate = UserListing_Tests.userEdited;
		}else {
			userToActivate = UserListing_Tests.userNew;
		}	
		objUserCreation.searchByEmailID(userToActivate);
		deactivationflag= objUserCreation.deactivateUser(userToActivate);		
		objUserCreation.searchByEmailID(userToActivate);
		activationFlag= objUserCreation.activateUser(userToActivate);
	}

	@Test(dependsOnMethods = "activateDeactivateUser")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForActivateDeactivateUser() throws Exception {
		UserCreation objUserCreation= new UserCreation(driver, logger);
		String userCreatedBy = getUserEmail(getClassName());
		if(UserActions_Test.userToActivate!=null) {
			String userCreated= UserActions_Test.userToActivate;
			if(UserActions_Test.activationFlag!=false)
				objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "User Activated","Users");
			if(UserActions_Test.deactivationflag!=false)
				objUserCreation.verifyAuditTrail(userCreatedBy, userCreated, "User Deactivated","Users");
		}else
			throw new SkipException("Skipping verifyAuditTrailForActivateDeactivateUser()");
	}


}
