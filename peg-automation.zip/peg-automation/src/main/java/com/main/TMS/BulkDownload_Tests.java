package com.main.TMS;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.UserCreation;

import DataProviders.TMS_DataproviderTestNG;
import Framework.ConfigurationProperties;

public class BulkDownload_Tests extends CommonTests1 {

	private String Product = "TMS";
	public static String userNew;
	public static String groupName;
	public static String userEdited;
	ConfigurationProperties config = ConfigurationProperties.getInstance();

	public BulkDownload_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_BulkDownload() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}


	@Test(dependsOnMethods = "login_BulkDownload", dataProvider = "EditUser", dataProviderClass = TMS_DataproviderTestNG.class , alwaysRun = true)
	@TestDetails(TestID = "TMS_2")
	public void downloadBulkUsers(String role, String scope) throws Exception {
		UserCreation objUserCreation = new UserCreation(driver, logger);
		objUserCreation.bulkUsersDownload("Bulk Users");
		//objUserCreation.verifyUserExports();

	}
	
	@Test(dependsOnMethods = "downloadBulkUsers", dataProvider = "EditUser", dataProviderClass = TMS_DataproviderTestNG.class , alwaysRun = true)
	@TestDetails(TestID = "TMS_3")
	public void downloadBulkRoles(String role, String scope) throws Exception {
		UserCreation objUserCreation = new UserCreation(driver, logger);
		objUserCreation.bulkRolesDownload("Bulk Roles");
		//objUserCreation.verifyRoleExports();
	}
	
	


}
