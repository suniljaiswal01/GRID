package com.main.TMS;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.MyReports.Reports;

import DataProviders.TMS_DataproviderTestNG;
import Framework.CommonUtility;
import common.Functions.TMS_CommonFunctions;

public class Report_Tests extends CommonTests1{

//	private ExtentTest logger;
	private String Product = "TMS";
	TMS_CommonFunctions objFunctions;
	CommonUtility commonUtility;

	public Report_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.TMS_CommonFunctions");
	}
	

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginTMSReport() throws Exception {		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	
	@Test(dataProviderClass = TMS_DataproviderTestNG.class,dependsOnMethods = "loginTMSReport",dataProvider = "Reports")
	@TestDetails(TestID="TMS_4")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
		if(displayStyle.contains("Rainbow"))
			driver.findElement(By.xpath("//a[@class='backToProd']")).click();
	}
	
	@Test(dataProviderClass = TMS_DataproviderTestNG.class, dependsOnMethods = "Reports",dataProvider = "ModifyReports")
	@TestDetails(TestID="TMS_4")
	public void newReport(String report) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.addNewReport();
	}

	@Test(dataProviderClass = TMS_DataproviderTestNG.class, dependsOnMethods = "newReport",dataProvider = "ModifyReports")
	@TestDetails(TestID="TMS_4")
	public void ModifyReport(String report) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
		if(displayStyle.contains("Rainbow"))
			driver.findElement(By.xpath("//a[@class='backToProd']")).click();
	}
	
}
