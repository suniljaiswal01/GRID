package com.main.TMS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.UserCreation;

import DataProviders.TMS_DataproviderTestNG;
import Framework.ConfigurationProperties;

public class AssignRoleAutomation extends CommonTests1 {

	private String Product = "TMS";
	public static String userNew;
	public static String groupName;
	public static String userEdited=null;
	ConfigurationProperties config = ConfigurationProperties.getInstance();

	public AssignRoleAutomation() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_UserListing() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}

	@Test(dependsOnMethods = "login_UserListing",  dataProvider = "EditUser", dataProviderClass = TMS_DataproviderTestNG.class)
	@TestDetails(TestID = "TMS_2")
	public void editUser(String user,String...roles) throws Exception {
		
//		String products[] = {"Dashboard","Field Library","FlexiForm Studio","IMT","Import Studio","MAS","OneView","ReportStudio","SIM","SPM","Supplier Portal","TMS","Usage Tracker","eInvoice","eProc","iAnalyze","iConsole","iContract","iCost","iManage","iRequest","iSave","iSource"};
		UserCreation objUserCreation = new UserCreation(driver, logger);
		System.out.println(user);
		objUserCreation.searchByEmailID(user);
		objUserCreation.editNewUser();
//		objUserCreation.editProductAllocation(products);
		objUserCreation.editUserRole(roles);
		
		
		
		/*
		objUserCreation.editUserRole(role);
		if (!config.getProperty("Setup").contains("AWS Australia Production"))
			objUserCreation.editUserScope(scope);*/
		
	}

}
