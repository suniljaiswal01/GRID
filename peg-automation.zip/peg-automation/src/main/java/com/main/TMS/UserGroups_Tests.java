package com.main.TMS;

import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.ImpersonateUserGroups;
import com.zycus.TMS.UserCreation;
import com.zycus.TMS.UserGroups;

import Framework.ConfigurationProperties;

public class UserGroups_Tests extends CommonTests1 {

	private String Product = "TMS";
	public static String userNew;
	public static String groupName;
	public static String userEdited;
	ConfigurationProperties config = ConfigurationProperties.getInstance();

	public UserGroups_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_UserGroups() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}


	@Test(dependsOnMethods = "login_UserGroups")
	@TestDetails(TestID = "TMS_8")
	public void impersonateUserRequest() throws Exception {
		ImpersonateUserGroups impersonateUserGroups = new ImpersonateUserGroups(driver, logger);
		impersonateUserGroups.checkImpersonatePage();


	}

	@Test(dependsOnMethods = "impersonateUserRequest", alwaysRun = true)
	@TestDetails(TestID = "TMS_2")
	public void ToverifyFunctionalityOfReceivingscope() throws Exception {
		UserCreation objUserCreation = new UserCreation(driver, logger);
		objUserCreation.verifyScopeIsNotSelectedTwice();
	}


	@Test(dependsOnMethods = "ToverifyFunctionalityOfReceivingscope", alwaysRun = true)
	@TestDetails(TestID = "TMS_7")
	public void userGroup() throws Exception {
		UserGroups userGroup = new UserGroups(driver, logger);
		groupName = userGroup.createNewUserGroup();
		userGroup.editUserGroup(groupName);
		userGroup.changeRole(groupName);
	}

	@Test(dependsOnMethods = "userGroup")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForUserGroupCreation() throws Exception {
		if(groupName!=null) {
			UserCreation objUserCreation= new UserCreation(driver, logger);
			String userCreatedBy = getUserEmail(getClassName());
			objUserCreation.verifyAuditTrail(userCreatedBy, groupName, "User Group Created","User Groups");
		}else
			throw new SkipException("Skipping verifyAuditTrailForUserGroupCreation()");
	}

	@Test(dependsOnMethods = "userGroup")
	@TestDetails(TestID="TMS_12")
	public void verifyAuditTrailForActivateDeactivateGroup() throws Exception {
		UserCreation objUserCreation= new UserCreation(driver, logger);
		String userCreatedBy = getUserEmail(getClassName());
		if(groupName!=null) {
			//String groupCreated= UserGroups_Tests.groupName;
			objUserCreation.verifyAuditTrail(userCreatedBy, groupName, "User Group Deactivated","User Groups");
		}else
			throw new SkipException("Skipping verifyAuditTrailForActivateDeactivateGroup()");
	}


}
