package com.main.TMS;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.Preferences;

import DataProviders.TMS_DataproviderTestNG;
import Framework.CommonUtility;
import common.Functions.TMS_CommonFunctions;

public class Preference_Tests extends CommonTests1{

//	private ExtentTest logger;
	private String Product = "TMS";
	TMS_CommonFunctions objFunctions;
	CommonUtility commonUtility;

	public Preference_Tests() throws Exception {
		super();
		setProduct("TMS");
		setClassToLoad("common.Functions.TMS_CommonFunctions");
	}
	

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginTMSPreference() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = TMS_DataproviderTestNG.class, dependsOnMethods = "loginTMSPreference")
	@TestDetails(TestID="TMS_5")
	public void securityPolicies() throws Exception {
		
		Preferences preference = new Preferences(driver, logger);
		preference.checkSecurityPolicies();
	}
	
	@Test(dataProviderClass = TMS_DataproviderTestNG.class, dependsOnMethods = "loginTMSPreference")
	@TestDetails(TestID="TMS_6")
	public void displaySetting() throws Exception {

		Preferences preference = new Preferences(driver, logger);
		preference.checkDisplaySetting();
	}	
	
}
