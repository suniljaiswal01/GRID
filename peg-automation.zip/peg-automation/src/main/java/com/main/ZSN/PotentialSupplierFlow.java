package com.main.ZSN;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.ManageCompanies.ConnectToCustomer;
import com.zycus.iSupplier.Dashboard.MyWork;
import com.zycus.iSupplier.ManageSuppliers.CreateSupplier;
import com.zycus.iSupplier.ManageSuppliers.EditSupplierDetails;
import com.zycus.iSupplier.SearchSuppliers.StandardSearch;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSupplier_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.eInvoice_CommonFunctions;

public class PotentialSupplierFlow extends CommonTests1 {

	private String Product = "iSupplier";
	eInvoice_CommonFunctions objFunctions;
	private String potentialSupplierName = "";
	String title = null;

	public PotentialSupplierFlow() throws Exception {
		super();
		setProduct("ZSN");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginPotential()
			throws Exception {

		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

		@Test(dataProvider="createPotentialSupplier", alwaysRun = true,dataProviderClass = iSupplier_DataProviderTestNG.class, dependsOnMethods = "loginPotential")
	@TestDetails(TestID = "iSupplier_11")
	public void createPotentialSupplier(String environment,String username, String password) throws Exception {
		String customer = configurationProperties.getProperty("Customer");
		WebDriver driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
		Login objLogin = new Login(driver1, logger, username, password);
		callAndLog(logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		ConnectToCustomer objConnect = new ConnectToCustomer(driver1, logger);
		objConnect.connectToCustomer(customer);
		String companyName = objConnect.enterCompanyInfo().toUpperCase();
		objConnect.acceptTNC();
		CreateSupplier objSupplier = new CreateSupplier(driver1, logger);
		potentialSupplierName = objSupplier.createNewSupplier("Potential", companyName);
		driver1.close();
	}


	@Test(dataProvider="createPotentialSupplier",dataProviderClass = iSupplier_DataProviderTestNG.class, dependsOnMethods = "createPotentialSupplier")
	@TestDetails(TestID = "iSupplier_3")
	public void searchApprovePotentialSupplierRequests(String environment,String username, String password) throws Exception {
		MyWork objWork = new MyWork(driver, logger);
		System.out.println(CreateSupplier.status);
		if(!CreateSupplier.status.equals("Approved")) {
			Thread.sleep(2000);
			objWork.editRequest("potential supplier requests", "Supplier Name", potentialSupplierName);
			objWork.performEdit();
			objWork.approveRequestPotentialSupplier(potentialSupplierName);	
		}else
			throw new SkipException("Skipping approving supplier as supplier is auto-approved as per workflow");
	}			
	 
	@Test(dependsOnMethods = "searchApprovePotentialSupplierRequests")
	@TestDetails(TestID = "iSupplier_8")
	public void onBoardPotentialSupplier() throws Exception {
		boolean includePotentialSuppliers = true;
		StandardSearch objSearch = new StandardSearch(driver, logger);
		if (!potentialSupplierName.isEmpty()) {
			objSearch.performSearchSupplierAction(potentialSupplierName,includePotentialSuppliers);
			objSearch.onboardSupplier(potentialSupplierName);
			CreateSupplier createSupplierObj = new CreateSupplier(driver, logger);
			createSupplierObj.fillSystemDetails_random();
			MyWork objWork = new MyWork(driver, logger);
			objWork.searchRequests("My Requests", "Supplier Name", potentialSupplierName);
			Thread.sleep(8000);
			if (objWork.getRequestStatus(potentialSupplierName).equals("Pending Approval")) {
				LogScreenshot("Pass","Supplier : " + potentialSupplierName + " is onboarded and sent for approval");

			} else
				LogScreenshot("Fail", "Supplier is not onboarded");

		} else {
			LogScreenshot("Fail", "failed to search the supplier from system");			
		}

	}

	@Test(dataProvider="createPotentialSupplier",dataProviderClass = iSupplier_DataProviderTestNG.class, dependsOnMethods = "onBoardPotentialSupplier")
	@TestDetails(TestID = "iSupplier_3")
	public void approveOnboardRequestRequests(String environment,String username, String password) throws Exception {
		MyWork objWork = new MyWork(driver, logger);
		Thread.sleep(2000);
		objWork.approveOnboardingPotentialSupplier(potentialSupplierName);	
	}	
	
	@Test(dependsOnMethods = "approveOnboardRequestRequests", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "extendSupplier")
	@TestDetails(TestID = "iSupplier_3")
	public void deletePotentialSupplier(String supplierSystem, String supplierPlant) throws Exception {
		EditSupplierDetails editSupplierDetails = new EditSupplierDetails(driver, logger);
		if (!potentialSupplierName.isEmpty()) {		
			editSupplierDetails.deleteSupplier(potentialSupplierName);	
		}
	}

}


