package com.main.ZSN;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Templates.Templates;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class CreateTemplateTest extends CommonTests1{

//	private ExtentTest logger;
	private String Product = "iContract";
	iPerform_CommonFunctions objFunctions;
	public static String templateName=null;
	
	public CreateTemplateTest() throws Exception {
		super();
		setProduct("ZSN");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginTemplate() throws Exception {	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = {"loginTemplate","com.main.ZSN.CreateClauseTest.createClause"},dataProviderClass = iContract_DataProviderTestNG.class, dataProvider = "ClauseCategory")
	@TestDetails(TestID = "iContract_5")
	public void createTemplate(String clauseCategory,String reviewerName,String accocBaseType,String language) throws Exception {
		
		Templates createTemplate = new Templates(driver, logger);
		templateName = createTemplate.createTemplate(CreateClauseTest.clauseName);
		
		
	}
}

