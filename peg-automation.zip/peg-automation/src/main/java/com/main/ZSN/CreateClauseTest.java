package com.main.ZSN;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.ClauseLibrary.CreateClause;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class CreateClauseTest extends CommonTests1{

//	private ExtentTest logger;
	private String Product = "iContract";
	iPerform_CommonFunctions objFunctions;
	public static String clauseName = null;

	public CreateClauseTest() throws Exception {
		super();
		setProduct("ZSN");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginClause() throws Exception {	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginClause",dataProviderClass = iContract_DataProviderTestNG.class, dataProvider = "ClauseCategory")
	@TestDetails(TestID = "iContract_4")
	public void createClause(String clauseCategory,String reviewerName,String accocBaseType,String language) throws Exception {
		
		CreateClause createClause = new CreateClause(driver, logger,clauseCategory,reviewerName,accocBaseType,language);
		clauseName=createClause.createClause();
	}
	
	
	
}

