package com.main.ZSN;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iPerform.Define.KPILibrary;
import com.zycus.iPerform.Setup.ClientSettings_ProdConfig;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iPerform_DataProviderTestNG;
import Framework.CommonUtility;
import common.Functions.iPerform_CommonFunctions;


public class KPI extends CommonTests1{

	//	private ExtentTest logger;
	private String Product = "iPerform";
	iPerform_CommonFunctions objFunctions;
	CommonUtility commonUtility;

	String KPICategory =null;
	public static String  KPI = null;
	String newClonedKPI =null;

	public KPI() throws Exception {
		super();
		setProduct(getLanguageProperty("ZSN"));
		setClassToLoad("common.Functions.iPerform_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginKPI() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style Classic");
	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dependsOnMethods = "loginKPI")
	@TestDetails(TestID="iPerform_2")
	public void createNewKPICategory() throws Exception {
		//Setup -> Product Configurations
		ClientSettings_ProdConfig objSettings = new ClientSettings_ProdConfig(driver, logger);
		objSettings.navigateToKPICategories();
		KPICategory = objSettings.addKPICategory();

	}

	@Test(dataProviderClass = iPerform_DataProviderTestNG.class,dependsOnMethods = "createNewKPICategory")
	@TestDetails(TestID="iPerform_3")
	public void createNewKPI() throws Exception {
		//Define->KPI Library
		KPILibrary objLibrary = new KPILibrary(driver, logger);
		KPI = objLibrary.createNewKPI(KPICategory);
	}


	
}
