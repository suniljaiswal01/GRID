package com.main.ZSN;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.ManageContracts.AuthorContract;
import com.zycus.IContract.ManageContracts.CreateContract;
import com.zycus.IContract.Setup.ProductConfig.ProdConfig;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;;

public class CreateContractTest extends CommonTests1{
	
	
	boolean byPassAuthorStage;
	boolean commonWorkFlowEnabled = true;
	boolean authWorkflowAvailable = true;
	boolean signOffWorkflowAvailabl;
	boolean isTouchFreeContract;	
	boolean isNegotiating = true; 
	
//	private ExtentTest logger;
	private String Product = "iContract";
	eInvoice_CommonFunctions objFunctions;
	public static String  contractNumber=null;
	public static String contractTitle = null;
	private boolean isAuthoringWorkflowActive;
	
	public CreateContractTest() throws Exception {
		super();
		setProduct("ZSN");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	
	
	/**
	 * @param contractNumber
	 *            the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginContract() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}
		
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class,dataProvider = "TypeSubType",dependsOnMethods = "loginContract")
	@TestDetails(TestID="iContract_15")
	public void verifyProdSettings(String contractType, String contractSubType) throws Exception {
		ProdConfig objProdConfig = new ProdConfig(driver, logger);
		objProdConfig.navigateToApplicationSettings();
		isTouchFreeContract = objProdConfig.verifyIfTouchFree(contractType, contractSubType);
		System.out.println("Is touch free contract "+isTouchFreeContract);
		byPassAuthorStage = objProdConfig.verifyByPassAuthWorkflow();
		System.out.println("By Pass Auth Workflow "+byPassAuthorStage);
		if(byPassAuthorStage==false)
			isAuthoringWorkflowActive = true;
		objProdConfig.exitFromAppSettingsPage();
	}
	
//	@Test(dependsOnMethods = "verifyProdSettings")
	@Test(dependsOnMethods = {"verifyProdSettings","com.main.ZSN.CreateTemplateTest.createTemplate"},alwaysRun=true)
	@TestDetails(TestID="iContract_2")
	public void AuthorContract_Negotiate() throws Exception {
		
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.createContract(CreateTemplateTest.templateName);
//		objAuthor.createContract("876");
		CreateContract objContract = new CreateContract(driver, logger);
		contractNumber =  objContract.contractSummaryDetails();
		contractTitle =  objContract.getContractTitle();
	}
	
	@Test(dependsOnMethods = "AuthorContract_Negotiate")
	@TestDetails(TestID="iContract_1")
	public void AuthorContract() throws Exception {
			
		CreateContract objContract = new CreateContract(driver, logger,contractNumber,contractTitle);
		objContract.enterContractDetails(contractNumber,displayStyle,isTouchFreeContract,byPassAuthorStage,isNegotiating);	
	}
	
	

}
