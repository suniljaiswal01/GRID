package com.main.ZSN;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.BidOptimization;
import com.zycus.iSource.MyEvents.Collect;
import com.zycus.iSource.MyEvents.MyEvents;
import com.zycus.iSource.MyEvents.ViewOptimizationResult;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.iSource_CommonFunctions;

public class RFQEventBidOptimization extends CommonTests1 {

	public RFQEventBidOptimization() throws Exception {
		super();
		setProduct("ZSN");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}

	private String Product = "iSource";
	iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	Collect objCollect;
	private String eventType;
	private String scoreSheet;

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void Login_RFQ() throws Exception {
		
		 displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		 callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "Login_RFQ")
	@TestDetails(TestID="iSource_2")
	public void createRFQEvent() throws Exception {
			//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
			MyEvents objEvents = new MyEvents(driver, logger);
			eventID = objEvents.createNewEvent("Full Source", "From Start", "RFQ", false);
			System.out.println("Event ID in flowIsource is "+eventID);
			if(eventID!=null){
				LogScreenshot("Pass", "RFQ Event created with ID "+eventID);
			}else
				LogScreenshot("fail", "RFQ Event not created");
		
	}
	
	

	@Test(dataProviderClass = iSource_DataProviderTestNG.class, dataProvider = "SurrogateBid",dependsOnMethods = "createRFQEvent")
	@TestDetails(TestID = "iSource_1")
	public void placeSurrogateBidRFQ(String supplierEmail,	String supplierPassword,String SupplierContactName,String SupplierCompanyName ) throws Exception {
		if(eventID!=null) {
		objCollect = new Collect(driver, logger);
			objCollect.surrogateBid("RFQ", SupplierContactName);
		}else
			throw new SkipException("Executing this method in Rainbow View");
	}

	@Test(dependsOnMethods = "placeSurrogateBidRFQ",dataProviderClass = iSource_DataProviderTestNG.class, dataProvider = "SupplierContacts")
	@TestDetails(TestID="iSource_1")
	public void approveRFQEvent(String supplierEmail, String supplierPassword, String SupplierContactName, String SupplierCompanyName) throws Exception {
		
		this.eventType = "RFQ";
		WebDriver driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
		Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
		callAndLog(driver1,logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
		
		ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
		objEvents.selectSupplierCompany();
		objEvents.filterByEventID(eventID);
		objEvents.enterEvent(eventID, eventType);
		driver1.quit();
	}

	@Test(dependsOnMethods = "approveRFQEvent")
	@TestDetails(TestID="iSource_1")
	public void analyzeRFQEvent() throws Exception {
	
		//Verify Response received for the Event
		Collect objCollect = new Collect(driver, logger);
		objCollect.verifyResponseReceived();
		//Wait for the Event to get closed
		objFunctions = new iSource_CommonFunctions(driver, logger);
		objFunctions.waitForEventToClose();
		Analyze objAnalyze = new Analyze(driver, logger);
		scoreSheet = objAnalyze.analyzeEvent();
		if(scoreSheet!=null){
			objAnalyze.scoreResponses(scoreSheet);
			objAnalyze.whatIfAnalysis(scoreSheet);
			objAnalyze.goToBidOptimization();
			BidOptimization objOptimization = new BidOptimization(driver, logger);
			objOptimization.selectStandardScenario("Cherry Picking");
			ViewOptimizationResult objResult= new ViewOptimizationResult(driver,logger);
			String scenarioName = objResult.saveScenario();
			
			try {
				objResult.goToOptimizedScenarioList(scenarioName);
				LogScreenshot("Pass","Event analyzed");
			}catch (Exception e) {
				LogScreenshot("fail","Event analyzation failed");
			}
		}

	}
}
