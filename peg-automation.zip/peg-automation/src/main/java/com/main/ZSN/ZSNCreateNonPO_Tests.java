package com.main.ZSN;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyInvoices.CreateNonPOInvoice;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class ZSNCreateNonPO_Tests extends CommonTests1 {

	private String Product = "eInvoice";
	eInvoice_CommonFunctions objFunctions;
	String invoiceNonPO;
	String creditMemoNonPO;
	String invoicePO;
	String creditMemoPO;
	WebDriver driver1= null;
	String invStatus;

	String title = null;
	public ZSNCreateNonPO_Tests() throws Exception {
		super();
		setProduct("ZSN");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginZSNcreateNonPOInvoice()
			throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle =getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProvider="ZSN_IntegrationInvoiceNonPO", dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods="loginZSNcreateNonPOInvoice")
	@TestDetails(TestID = "loginZSN")
	public void createNonPOInvoice(String environment,String username, String password,String companyCode,String businessUnit,String location,String costCentre,String	currency,String	paymentTerms,String	headerLevelTaxType,String headerLevelTaxName,String lineItemLevelTaxType,String lineItemLevelTaxName, String SupplierCompany) throws Exception {
		String tenant = configurationProperties.getProperty("Tenant");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(zsnDriver, logger);
		objZSNFunctions.navigate_path1("My Invoices", "Create Non PO Invoice",tenant);
		CreateNonPOInvoice objInvoice= new CreateNonPOInvoice(zsnDriver, logger);
		invoiceNonPO=objInvoice.createNonPOInvoiceCreditMemo("invoice", tenant,companyCode, businessUnit, location, costCentre,currency,paymentTerms,headerLevelTaxType, headerLevelTaxName, lineItemLevelTaxType, lineItemLevelTaxName,SupplierCompany);		
		objInvoice.searchByDocNo(invoiceNonPO);
		zsnDriver.close();
	}

	


}
