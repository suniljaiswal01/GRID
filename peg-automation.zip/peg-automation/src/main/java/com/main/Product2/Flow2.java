package com.main.Product2;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.Common_DataProviderTestNG;



public class Flow2 extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	

	public Flow2() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login", dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login",alwaysRun = true, priority = 1)
	@TestDetails(TestID="iManage_1")
	public void login_Flow2(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?false:true, "Display style is Rainbow", "Display style is not rainbow");
	}
}
