package com.main.iSaveFlows;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSave.MyProjects.ExportProject;
import com.zycus.iSave.MyProjects.StrategicProject;
import com.zycus.iSave.SharedStrategicProject.SharedStrategicProjList;

import DataProviders.iSave_DataProviderTestNG;
import Framework.CommonUtility;


public class StrategicProjectReplicate extends CommonTests1{

	//	private ExtentTest logger;
	private String Product = "iSave";
	//	eInvoice_CommonFunctions objFunctions;
	CommonUtility objUtility;
	private String replicatedProjID= null;

	public StrategicProjectReplicate() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginStrategicProjectReplicate() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}



	@Test(dependsOnMethods = "com.main.iSaveFlows.StrategicProjectFlow.createNewStrategicProject")
	@TestDetails(TestID="iSave_5")
	public void replicateProject() throws Exception {
		
		try{
			StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
			objProject.clearAllFilters();
			objProject.filterByProjectID(StrategicProjectFlow.projId);
			replicatedProjID = objProject.replicateProject(StrategicProjectFlow.projId, "In Draft");
			if(replicatedProjID!=null)
				objProject.LogScreenshot("pass", "Replicated Project ID created as Project ID : "+replicatedProjID);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test(dependsOnMethods =  {"com.main.iSaveFlows.StrategicProjectFlow.createNewStrategicProject","replicateProject"})
	@TestDetails(TestID="iSave_6")
	public void editStrategicProject() throws Exception {
		try{
			StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
			objProject.editDraftProject(replicatedProjID);
			//			objProject.editInitiatedProject();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test(dataProviderClass = iSave_DataProviderTestNG.class, dependsOnMethods = {"com.main.iSaveFlows.StrategicProjectFlow.createNewStrategicProject","editStrategicProject"},dataProvider = "ShareProject")
	@TestDetails(TestID="iSave_6")
	public void shareProject(String stakeHolderFirstNames) throws Exception {
		try{
			StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
			objProject.clearAllFilters();
			objProject.filterByProjectID(StrategicProjectFlow.projId);
			objProject.shareProject(StrategicProjectFlow.projId, stakeHolderFirstNames);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test(dependsOnMethods =  {"com.main.iSaveFlows.StrategicProjectFlow.createNewStrategicProject","shareProject"})
	@TestDetails(TestID="iSave_6")
	public void deleteProject() throws Exception {
		try{
			StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
			objProject.clearAllFilters();
			objProject.filterByProjectID(replicatedProjID);
			objProject.deleteProject();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	

	//	UAT
	@Test(dependsOnMethods = {"com.main.iSaveFlows.StrategicProjectFlow.createNewStrategicProject","deleteProject"})
	@TestDetails(TestID="iSave_16")
	public void exportReport() throws Exception {
		try{
			ExportProject exportProject = new ExportProject(driver, logger);
			exportProject.export(StrategicProjectFlow.projId);
		}catch(Exception e){
			e.printStackTrace();
		}
	}



	@Test(dependsOnMethods = {"com.main.iSaveFlows.StrategicProjectFlow.createNewStrategicProject","exportReport"})
	@TestDetails(TestID="iSave_15")
	public void viewSharedStrategicProject() throws Exception {
		try{
			SharedStrategicProjList objProject = new SharedStrategicProjList(driver, logger);
			objProject.viewSharedStrategicProject(StrategicProjectFlow.projId);
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
