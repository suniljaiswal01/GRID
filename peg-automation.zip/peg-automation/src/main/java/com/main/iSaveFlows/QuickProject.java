package com.main.iSaveFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSave.MyConfiguration.ProjectTypes;
import com.zycus.iSave.MyConfiguration.SavingsFormula;
import com.zycus.iSave.MyProjects.QuickSavingsEntry;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSave_DataProviderTestNG;
import Framework.CommonUtility;

public class QuickProject extends CommonTests1{

	
//	private ExtentTest logger;
	private String Product = "iSave";
//	eInvoice_CommonFunctions objFunctions;
	CommonUtility objUtility;
	public static String quickProjName=null;
	private String savingFormulaValue = null;
	static String  projectTypeValue = null;

	public QuickProject() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}
		
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginQuickProject() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginQuickProject")
	@TestDetails(TestID="iSave_10")
	public void createSavingFormula() throws Exception {
		SavingsFormula savingFormula = new SavingsFormula(driver, logger);
		savingFormulaValue = savingFormula.addNewSavingsFormula();
	}
	
	@Test(dependsOnMethods = "createSavingFormula")
	@TestDetails(TestID="iSave_11")
	public void createProjectType() throws Exception {

		ProjectTypes projectType = new ProjectTypes(driver, logger);
		projectTypeValue = projectType.addProjectType();
	}
	
	@Test(dependsOnMethods = "createProjectType")
	@TestDetails(TestID="iSave_2")
	public void createNewQuickProject() throws Exception {
		//My Projects -> Strategic Project
		QuickSavingsEntry objProject = new QuickSavingsEntry(displayStyle, Product,driver, logger);
		quickProjName = objProject.createNewQuickProject(projectTypeValue);
		if(quickProjName!=null)
			objProject.LogScreenshot("Pass","Quick Project created with Project Name :"+quickProjName);
		else
			objProject.LogScreenshot("fail","Unable to Create Quick Project");
	}
	
	@Test(dataProviderClass = iSave_DataProviderTestNG.class,dataProvider = "Strategicproject",	dependsOnMethods = "createNewQuickProject")
	@TestDetails(TestID="iSave_1")
	public void appprovecreateNewQuickProject(String approver,String projectType) throws Exception {
		//My Projects -> Strategic Project
		QuickSavingsEntry objProject = new QuickSavingsEntry(displayStyle, Product,driver, logger);
		try {
			objProject.manageSavings(approver,quickProjName,savingFormulaValue);
			objProject.LogScreenshot("Pass", "Quick Project Approval Completed");
		}catch(Exception e) {
			objProject.LogScreenshot("Fail", "Unable to Approved Quick Project");
		}
	}

	@Test(dependsOnMethods = "appprovecreateNewQuickProject")
	@TestDetails(TestID="iSave_11")
	public void deleteProjectType() throws Exception {
		
		ProjectTypes projectType = new ProjectTypes(driver, logger);
		projectType.deleteProjectType();
	
	}
	
}
