package com.main.iSaveFlows;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSave.MyProjects.StrategicProject;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSave_DataProviderTestNG;
import Framework.CommonUtility;


public class StrategicProjectFlow extends CommonTests1{

	//	private ExtentTest logger;
	private String Product = "iSave";
	//	eInvoice_CommonFunctions objFunctions;
	CommonUtility objUtility;
	public static String projId= null;
	public static String strategicProjName= null;

	public StrategicProjectFlow() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}

	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginStrategicProject() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is Classic");
	}


	@Test(dataProviderClass = iSave_DataProviderTestNG.class,dataProvider = "ManageSavings",dependsOnMethods = "loginStrategicProject")
	@TestDetails(TestID="iSave_3")
	public void createNewStrategicProject(String approver,String projectType) throws Exception {
		
		StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
		try{
			projId = objProject.createNewStrategicProject(projectType);
			System.out.println("Project Id:"+projId);
			if(projId!=null)
				objProject.LogScreenshot("pass","Strategic Project created with Project ID : "+projId);				
			else
				objProject.LogScreenshot("fail","Unable to create Strategic Project");
		
		}catch(Exception e){
			e.printStackTrace();
			objProject.LogScreenshot("fail","Unable to create Strategic Project");
			throw new Exception();
		}
	}


	@Test(dataProviderClass = iSave_DataProviderTestNG.class,dataProvider = "ManageSavings",dependsOnMethods = "createNewStrategicProject")
	@TestDetails(TestID="iSave_3")
	public void approveStrategicProject(String approver,String projectType) throws Exception {

		StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
		try {		
		objProject.manageSavings(approver, projId );
		objProject.financialView(projId);
		objProject.LogScreenshot("pass","Strategic Project Approval Completed");
		}catch(Exception e) {
			objProject.LogScreenshot("fail","Unable to Approve Strategic Project");
			objProject.LogScreenshot("info",e.getStackTrace().toString());
		}
	}
	@Test(dependsOnMethods = "approveStrategicProject")
	@TestDetails(TestID="iSave_4")
	public void markAsComplete() throws Exception {
		
		StrategicProject objProject = new StrategicProject(displayStyle,Product,driver, logger);
		try{
			objProject.clearAllFilters();
			objProject.filterByProjectID(projId);
			objProject.markAsComplete(projId);
		}catch(Exception e){
			objProject.LogScreenshot("fail", "Unable to Mark Project As Complete");
		}
	}
}
