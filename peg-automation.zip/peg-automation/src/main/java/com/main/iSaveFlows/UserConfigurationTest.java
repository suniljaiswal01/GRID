package com.main.iSaveFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSave.MyConfiguration.LinkUsers;

import DataProviders.Common_DataProviderTestNG;
import Framework.CommonUtility;

public class UserConfigurationTest extends CommonTests1{

	
//	private ExtentTest logger;
//	private String Product = "iSave";
//	eInvoice_CommonFunctions objFunctions;
	CommonUtility objUtility;
	public static String quickProjName;
	private String savingFormulaValue;
	static String  projectTypeValue;

	public UserConfigurationTest() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}
		
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginQuickProject() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginQuickProject",priority= 1)
	@TestDetails(TestID="iSave_17")
	public void createSavingFormula() throws Exception {
		String userName ="John Zcs";
		String divisions[] = {"Czech Republic","Delhi","Karnataka","Maharashtra"};
		String commodities[] = {"Advertising and Printing","Apparel and Personal Care","Appliances and Supplies","Business Management Services"};
		LinkUsers linkUser = new LinkUsers(driver, logger);
		linkUser.navigateToConfigTabs("Link Users");
		linkUser.filterByUserName(userName);
		linkUser.performActionOnUser(userName, "Edit Divisions",divisions);
		linkUser.performActionOnUser(userName, "Edit Commodities",commodities);
		
		
	}
		
}
