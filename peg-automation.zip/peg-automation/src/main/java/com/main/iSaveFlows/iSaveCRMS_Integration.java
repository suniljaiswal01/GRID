package com.main.iSaveFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSave_DataProviderTestNG;

public class iSaveCRMS_Integration  extends CommonTests1 {
	//	private ExtentTest logger;
	public String Product = "iSave";
	//	iPerform_CommonFunctions objFunctions;

	String types[] = {"Quick Project","Strategic Project"};
	//	String types[] = {"Quick Project"};

	public iSaveCRMS_Integration() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}

	@Test(groups = "Login",  dependsOnMethods = {"com.main.iSaveFlows.StrategicProjectFlow.approveStrategicProject","com.main.iSaveFlows.QuickProject.appprovecreateNewQuickProject"}, alwaysRun = true)
	//	@Test(groups = "Login", dataProviderClass = Common_DataProviderTestNG.class, dataProvider = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginiSaveCRMSIntegration()
			throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}


	@Test(dependsOnMethods = {"loginiSaveCRMSIntegration","com.main.iSaveFlows.StrategicProjectFlow.approveStrategicProject","com.main.iSaveFlows.QuickProject.appprovecreateNewQuickProject"},dataProviderClass = iSave_DataProviderTestNG.class, dataProvider ="crms_reportGeneration",alwaysRun = true)
	//	@Test(dependsOnMethods = "loginiSaveCRMSIntegration",dataProviderClass = iSave_DataProviderTestNG.class, dataProvider ="crms_reportGeneration",alwaysRun = true)
	@TestDetails(TestID = "iSave_CRMSIntegration")
	public void crms_reportGeneration(String category, String... data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		if(createNewReport.selectProduct(Product)) {
			createNewReport.selectParams(category, data);
			VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);

			for(String type : types) {
				verifyReportsField.iSaveFieldCheck(type);
			}

			verifyReportsField.backToReportListing();	
		}
	}
}
