package com.main.iSaveFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSave.MyReports.Reports;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSave_DataProviderTestNG;

public class ISaveReport extends CommonTests1{

//	private ExtentTest logger;
	/*private String Product = "iSave";
	eInvoice_CommonFunctions objFunctions;*/

	String projectType = null;

	public ISaveReport() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReport() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iSave_DataProviderTestNG.class, dependsOnMethods = "loginReport",dataProvider = "Reports")
	@TestDetails(TestID="iSave_7")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}

	@Test(dataProviderClass = iSave_DataProviderTestNG.class, dependsOnMethods = "Reports",dataProvider = "ModifyReports")
	@TestDetails(TestID="iSave_8")
	public void ModifyReport(String report) throws Exception {

		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
	}
	
	/*@Test(dependsOnMethods = {"com.main.iSaveFlows.QuickProject.createProjectType","ModifyReport"})
//	@Test(dependsOnMethods="loginReport")
	@TestDetails(TestID="iSave_9")
	public void DataUpload() throws Exception {
			
		if(QuickProject.projectTypeValue!=null) {
			DataUpload objUpload = new DataUpload(driver, logger);
			objUpload.uploadProjectTemplate(QuickProject.projectTypeValue);
//			objUpload.uploadProjectTemplate("Expense");
		}else
			throw new SkipException("Failure in DataUpload");
//		objUpload.uploadProjectTemplate("AutoProjType_243200");
	
	}*/

	/*	@Test(dataProviderClass = iSave_DataProviderTestNG.class, 
			dependsOnMethods = "createNewStrategicProject", 
			dataProvider = "DataUpload", priority=9)
	public void ProjectSavingUpdate() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "My Configuration","Project Savings Update");
		ProjectSavingsUpdate objUpdate = new ProjectSavingsUpdate(driver, logger);
		objUpdate.filterByProjectId(projId);
	}*/

}
