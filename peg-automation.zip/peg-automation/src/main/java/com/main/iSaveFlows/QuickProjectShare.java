package com.main.iSaveFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSave.MyProjects.QuickSavingsEntry;
import com.zycus.iSave.sharedQuickSavingsEntry.SharedQuickSavingsProjList;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSave_DataProviderTestNG;
import Framework.CommonUtility;

public class QuickProjectShare extends CommonTests1{


	//	private ExtentTest logger;
	private String Product = "iSave";
	//	eInvoice_CommonFunctions objFunctions;
	CommonUtility objUtility;

	public QuickProjectShare() throws Exception {
		super();
		setProduct("iSave");
		setClassToLoad("common.Functions.iSave_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true,dependsOnMethods = {"com.main.iSaveFlows.iSaveCRMS_Integration.loginiSaveCRMSIntegration"})
	@TestDetails(TestID="login")
	public void loginQuickProjectShare() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	//UAT
	@Test(dependsOnMethods ="loginQuickProjectShare")
	@TestDetails(TestID="iSave_14")
	public void sharedQuickEntry() throws Exception {
		SharedQuickSavingsProjList sharedQuickEntry = new SharedQuickSavingsProjList(driver, logger);
		sharedQuickEntry.viewQuickSavingProject();
	}


	@Test(dataProviderClass = iSave_DataProviderTestNG.class, dependsOnMethods= {"loginQuickProjectShare","com.main.iSaveFlows.QuickProject.createNewQuickProject"},dataProvider = "ShareProject")
	@TestDetails(TestID="iSave_2")
	public void shareQuickEntry(String stakeHolderFirstNames) throws Exception {
		QuickSavingsEntry objProject = new QuickSavingsEntry(displayStyle, Product,driver, logger);
		objProject.clearAllFilters();
		objProject.filterByProjectTitle(QuickProject.quickProjName);
		objProject.shareProject(QuickProject.quickProjName, stakeHolderFirstNames);
	}


	//UAT
	@Test(dependsOnMethods = {"loginQuickProjectShare","shareQuickEntry","com.main.iSaveFlows.iSaveCRMS_Integration.crms_reportGeneration"})
	@TestDetails(TestID="iSave_2")
	public void deleteQuickEntry() throws Exception {
		QuickSavingsEntry objProject = new QuickSavingsEntry(displayStyle, Product,driver, logger);
		/*objProject.clearAllFilters();
		objProject.filterByProjectTitle(QuickProject.quickProjName);*/
		objProject.deleteProject(QuickProject.quickProjName);
	}



}
