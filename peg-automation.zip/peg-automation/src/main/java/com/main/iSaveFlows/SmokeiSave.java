package com.main.iSaveFlows;


import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSave_DataProviderTestNG;
import common.Functions.NavigationViaMenu;
import common.Functions.eInvoice_CommonFunctions;

public class SmokeiSave extends CommonTests1{

	private ExtentTest logger;
	private String Product = "iSave";
	eInvoice_CommonFunctions objFunctions;

	public SmokeiSave() throws Exception {
		super();
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReport() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(description = "loginReport", dataProviderClass =iSave_DataProviderTestNG.class, dataProvider = "navigateViaSideMenu")
	@TestDetails(TestID = "iSave_2")
	public void navigateViaSideMenu(String...navigation) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigation);
		NavigationViaMenu navigateViaMenu = new NavigationViaMenu(driver, logger);
		navigateViaMenu.validateNavigation(Product,navigation);
	}
	
	
}

