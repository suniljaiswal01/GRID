package com.main;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.common.ExtentManager;
import com.aventstack.extentreports.common.ExtentTestManager;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import Framework.CommonUtility;
import Framework.ConfigurationProperties;
import Framework.FrameworkUtility;
import Framework.UserProperties;
import SanityDefault.Login;

public class CommonTests1 extends CommonUtility{

	//	public WebDriver driver;
	//	public WebDriver driver1;
	//public static ExtentTest startingTest;
	public static ExtentTest parent;
	public ExtentTest parentLogger;
	public static HashMap<String, String> loginCredentials;
	public String displayStyle = "Rainbow";
	protected FrameworkUtility objFrameworkUtility = new FrameworkUtility();
	protected ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
	protected UserProperties userProperties = UserProperties.getInstance();
	private static String testStatus = "pass";


	public static HashMap <String, ExtentTest> ExtentTestProductMap = new HashMap<String,ExtentTest>();


	private String classToLoad;


	//	public ExtentTest logger;
	private String Product;
	private ExtentTest parentTest;
	public static ExtentTest skippedLogger;

	public String getProduct() {
		return Product;
	}

	public void setProduct(String product) throws Exception {

		ConfigurationProperties config = ConfigurationProperties.getInstance();
		if((config.getProperty("Setup").equals("Staging") || config.getProperty("Setup").contains("DevInt")) && config.getProperty("Product").contains("eInvoice"))
			Product = "Invocus";
		else
			Product = product;
	}

	public CommonTests1() throws Exception{
		super();
	}

	@BeforeSuite
	public void beforeSuite() throws Exception {
		ZycusCoreReporter.createReportFile();
		//startingTest = ExtentTestManager.createTest("Automation Execution");
	}


	//************************************Uncomment it*******************************

	public ExtentTest getParent() {
		return parent;
	}

	public void setParent(ExtentTest parent) {
		CommonTests1.parent = parent;
	}

	@BeforeTest
	public void startTest() throws Exception {
		parent = ExtentTestManager.createTest(Product , "Tenant : "+ configurationProperties.getProperty("Tenant"));
		ExtentTestProductMap.put(Product, parent);

		skippedLogger = ExtentTestProductMap.get(Product).createNode("Skipped Classes");
		System.out.println(ExtentTestProductMap);
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() throws ClientProtocolException, IOException, JSONException{
		//ExtentManager.getInstance().flush();
		//driver.close();
		try{
//			String className = getClassName();
//			LogScreenshot("info", "Class for which session is destroyed:"+ className);
			deleteToken.add(driver.manage().getCookieNamed("SAAS_COMMON_BASE_TOKEN_ID").getValue());
//			deleteSession(token);
		}catch(Exception e){
			e.printStackTrace();
		}
		driver.quit();
		if(driver1!=null)
			driver1.quit();
		//objZCD.deleteSession();
	}

	@AfterTest(alwaysRun = true)
	public void afterTest(){
		//ExtentManager.getInstance().flush();
		if(driver1!=null)
			driver1.quit();
		String executionStatus = ExtentTestManager.getTest().getStatus().toString();
		System.out.println("Pass Percentage:"+ExtentTestManager.getTest().getExtent().getStats().getChildPercentagePass());
		System.out.println("Fail Percentage:"+ExtentTestManager.getTest().getExtent().getStats().getChildPercentageFail());
		System.out.println("Skip Percentage:"+ExtentTestManager.getTest().getExtent().getStats().getChildPercentageSkip());
		System.out.println("Test Status "+executionStatus);
		if(executionStatus.equals("fail") && testStatus.equals("pass"))
			testStatus = "fail";
	}

	@AfterSuite(alwaysRun = true)
	public void tearDown1() {
		ExtentManager.getInstance().flush();
		//SendMail objMail = new SendMail();
		for(String token: deleteToken) {
			try {
				deleteSession(token);
			} catch (IOException | JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*String executionStatus = ExtentTestManager.getTest().getStatus().toString();
		System.out.println("Pass Percentage:"+ExtentTestManager.getTest().getExtent().getStats().getChildPercentagePass());
		System.out.println("Fail Percentage:"+ExtentTestManager.getTest().getExtent().getStats().getChildPercentageFail());
		System.out.println("Skip Percentage:"+ExtentTestManager.getTest().getExtent().getStats().getChildPercentageSkip());
		System.out.println("Test Status "+executionStatus);*/
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.createStatusFile(testStatus);
		//objMail.sendMail("");
		//driver.quit();
	}

	public void callAndLog(ExtentTest logger,  boolean condition, String passMsg, String failMsg) throws Exception {
		failMsg = "Display style is Classic";
		String msg = condition ? passMsg : failMsg;
		String status = condition ? "Pass" : "Pass";
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.LogScreenshot(status, msg);
	}

	public void callAndLog(WebDriver driver,ExtentTest logger,  boolean condition, String passMsg, String failMsg) throws Exception {

		failMsg = "Display style is Classic";
		String msg = condition ? passMsg : failMsg;

		String status = condition ? "Pass" : "Pass";
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.LogScreenshot(status, msg);
	}

	/*
	public void callAndLog(WebDriver driver,ExtentTest logger,  boolean condition, String passMsg, String failMsg) throws Exception {
		String msg = condition ? passMsg : failMsg;
		String status = condition ? "Pass" : "Fail";
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.LogScreenshot(status, msg);
	}*/

	@AfterMethod
	public void getResult(ITestResult result) throws Exception {
		if(result.getStatus() == ITestResult.FAILURE) {

			LogScreenshot("fail", "failure Reason");
			logger.fail(MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
			logger.fail(result.getThrowable());

		}
		else if(result.getStatus() == ITestResult.SUCCESS) {
			//logger.pass(MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
		}
		else {
			logger.skip(MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
			logger.skip(result.getThrowable());
		}
	}

	@BeforeClass
	public void beforeClass() throws Exception{
		//parent = ExtentTestManager.createTest(Product);

		//		System.out.println("Class to execute with "+ExtentTestProductMap.get(Product)+" "+this.getClass().getName()+" "+objZCD);
		
		String testName = this.getClass().getName();
		userAccount = getUserEmail(testName);
		
		if(userAccount==null) {
			userAccount = configurationProperties.getProperty("UserAccount");
		}
		
		driver = startSession(userAccount , this.getClass().getName());
		parentLogger = ExtentTestProductMap.get(Product).createNode(this.getClass().getName() + " -> " + "User : "+ userAccount);
		
		
		String className = this.getClass().getName();
		String sessionID = ((RemoteWebDriver) driver).getSessionId().toString();
		
		classDetails.put(sessionID,className);
	}


	@BeforeMethod
	public void beforeMethod(Method method) throws Exception{
		
		TestDetails set = method.getAnnotation(TestDetails.class);
		logger = parentLogger.createNode(method.getName());
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		
		if(set.TestID().equals("loginZSN")) {
			zsnDriver = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			Login objLogin = new Login(zsnDriver, logger);
			callAndLog(zsnDriver, logger, objLogin.loginViaZSN(configurationProperties), "login successful", "Not logged in");
			//callAndLog(zsnDriver, logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		}else {

		if(driver.findElements(By.id("rainbowHeader")).size()>0)
			displayStyle = "Rainbow";
		else if(driver.findElements(By.id("newHeaderSubNav")).size()>0)
			displayStyle = "Classic";

		if(set.TestID().equals("login"))
			loginCredentials = objConnect.getLoginCredentials(set.TestID());
		

		ClassLoader classLoader = this.getClass().getClassLoader();

		try {
			// Create a new JavaClassLoader
			Class aClass = classLoader.loadClass(classToLoad);
			//System.out.println("aClass.getName() = " + aClass.getName());

			// Create a new instance from the loaded class
			/*Constructor[] cs = aClass.getConstructors();
	        for(int i=0;i<cs.length;i++){
	            System.out.println(cs[i]);        
	        }*/


			Constructor constructor = aClass.getConstructor(new Class[] {WebDriver.class, ExtentTest.class});
			Object myClassObject = constructor.newInstance(new Object[] {driver, logger});

			if(!(set.TestID().equals("login"))) {
				String productToNavigate = set.TestID().split("_")[0];
				// Getting the target method from the loaded class and invoke it using its name
				String tabInfo[] = objConnect.getNavigationInfo(productToNavigate,set.TestID(),displayStyle);
				if(!tabInfo[0].isEmpty()) {				

					Method method1 = aClass.getMethod("navigateToMainPage", new Class[] {String.class, String.class, String[].class});								
					if(Product.equals("Invocus")) {			
						method1.invoke(myClassObject,displayStyle, Product, tabInfo);		
					}else {			
						//System.out.println("Invoked method name: " + method1.getName());			
						method1.invoke(myClassObject,displayStyle, productToNavigate, tabInfo);			
					}			
				}				

				if (set.TestID().contains("CRMSIntegration")) {            	
					Method method1 = aClass.getMethod("navigateToMainPage", new Class[] {String.class, String.class, String[].class});
					// 	            System.out.println("Invoked method name: " + method1.getName());
					method1.invoke(myClassObject,displayStyle, "ReportStudio", tabInfo);
					//    			objFunctions.navigateToMainPage(displayStyle, "ReportStudio", tabInfo);
				}
			}
		
			if (driver.findElements(By.xpath("//div[@class='cns_NotificationBox' and contains(@style,'block')]")).size() > 0) {
				findElement(By.xpath("//label[@class='cns_CancelNotification']")).click();
				Thread.sleep(1500);
			}
			    
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		}

	}



	@AfterMethod
	public void afterMethod() throws Exception{
		Runtime rt = Runtime.getRuntime();
		long freeMemory = rt.totalMemory() - rt.freeMemory();
		System.out.println( "Used Heap memory: " +freeMemory/(1024*1024) );
	}
	public String getClassToLoad() {
		return classToLoad;
	}

	public void setClassToLoad(String classToLoad) {
		this.classToLoad = classToLoad;
	}

}
