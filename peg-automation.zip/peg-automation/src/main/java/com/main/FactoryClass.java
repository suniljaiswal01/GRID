package com.main;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.zycus.eProc.eForms.AllForms;

import Framework.CommonUtility;
import common.Functions.eProc_CommonFunctions;

public class FactoryClass extends CommonTests2{
	
	private String Product = "eProcurement";
	eProc_CommonFunctions objFunctions;
	ZycusCoreDriver objZCD;
	private String newProcessForm_headerLvl;
	private String newProcessForm_LineLvl;
	private String newProcessForm_headerLvlAsDraft;
	
	public FactoryClass() throws Exception {
		super();
		setProduct("eProcurement");
		setClassToLoad("Framework.CommonUtility");
	}
	
	@Test(dataProvider = "dp1")
	@TestDetails(TestID = "eProcurement_1")
	public void Login_ProcessForm(int number)
			throws Exception {
		ZycusCoreDriver objZCD = new ZycusCoreDriver(); 
//		System.out.println("Class to execute with "+ExtentTestProductMap.get(Product)+" "+this.getClass().getName()+" "+objZCD);
		driver = objZCD.startSession(this.getClass().getName());
		parentLogger = ExtentTestProductMap.get(Product).createNode(this.getClass().getName());
		//logger = parentLogger.createNode("FactoryClass");
		displayStyle = objZCD.getDisplayStyle(driver, parentLogger, loginCredentials);
		CommonUtility objUtility = new CommonUtility(driver, parentLogger);
		objUtility.navigateToMainPage(displayStyle, Product, "eForms","Process forms");
		AllForms objForms = new AllForms(driver, parentLogger);
		newProcessForm_headerLvl = objForms.selectNewFormCreationProcess("Online Editor", "Header level form");
		System.out.println("New Process Form is "+newProcessForm_headerLvl);
	}
	
	/*@Test(dependsOnMethods = "Login_ProcessForm", priority = 2, dataProvider = "dp1")
	@TestDetails(TestID = "eProcurement_2")
	public void createProcessForm_headerLevel(int number) throws Exception {
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.navigateToMainPage(displayStyle, Product, "eForms","Process forms");
		AllForms objForms = new AllForms(driver, logger);
		newProcessForm_headerLvl = objForms.selectNewFormCreationProcess("Online Editor", "Header level form");
		System.out.println("New Process Form is "+newProcessForm_headerLvl);
	}*/
	
	
	/*@Test(dataProvider = "dp1")
	//@Test(dependsOnMethods = "Login_ProcessForm", priority = 2)
	@TestDetails(TestID = "eProcurement_2")
	public void createProcessForm_headerLevel() throws Exception {
		AllForms objForms = new AllForms(driver, logger);
		newProcessForm_headerLvl = objForms.selectNewFormCreationProcess("Online Editor", "Header level form");
		System.out.println("New Process Form is "+newProcessForm_headerLvl);
	}*/
	
	
	/*@Test(dataProvider = "dp1")
	//@Test
	//@Parameters({"searchKey1","searchKey2"})
	public void testMethod(int number) throws InterruptedException
	{	
		String analyst = null;
		String division = null;
		int waitTime = 0;
		switch(number){
		case 1:
			analyst = "hgsdjh";
			division = "sa";
			waitTime = 200;
			break;
		case 2:
			analyst = "hsen";
			division = "wagv";
			waitTime = 800;
			break;
		case 3:
			analyst = "has";
			division = "jhs";
			waitTime = 300;
			break;
		case 4:
			analyst = "hga";
			division = "aqwh";
			waitTime = 700;
			break;
		case 5:
			analyst = "je";
			division = "qawh";
			waitTime = 1200;
			break;
		}
		System.out.println(LocalTime.now()+searchKey1);
		System.out.println(LocalTime.now()+searchKey2);
		
		System.out.println(LocalTime.now());
	    Long id = Thread.currentThread().getId();
	    Thread.sleep(waitTime);
	    System.out.println(LocalTime.now());
	    System.out.println(LocalTime.now()+searchKey1);
		System.out.println(LocalTime.now()+searchKey2);
	    System.out.println("HELLO :  " + id);
	}
*/

	@DataProvider(name = "dp1",parallel=true)
	public Object[][] dp1() {
	  return new Object[][] {
	      new Object[] { 1 },
	      new Object[] { 2 },
	      new Object[] { 3 },
	      new Object[] { 4 },
	      new Object[] { 5 }
	  };
	}
}
