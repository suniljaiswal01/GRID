package com.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class ZycusCoreConstants {

	/* Config file Path */
	public String CONFIG_FILE_PATH ;
	public String SYS_CONFIG_FILE_PATH ;
	public String LANG_CONFIG_FILE_PATH;
	public String systemDirectoryPath=  System.getProperty("user.dir");
	public String sharedDirectoryPath=   "//192.168.11.102/public/PEG- Automation";

	/*----------------------------------------DRIVER---------------------------------------------------------------------------------------------------*/
	/*CHROME Driver Path*/
	public String WIN_CHROME_DRIVER_PATH;

	/*FireFox Driver path*/
	public String WIN_GECKO_DRIVER_PATH;

	/*ExtentReportPath*/
	public String EXTENT_REPORTS_PATH;

	/*----------------------------------------Timeout Values---------------------------------------------------------------------------------------------------*/
	//Different Timeout values are list here sorted descending from the highest wait to lowest wait. These many are required for various Implicit wait purpose
	public int HIGHEST;
	public int VERYHIGH;
	public int HIGH;
	public int MEDIUM;
	public int FAIR;
	public int LOW;
	public int BASE;
	public int LOWEST;
	public int UNIT;
	public int HIGHINMILLISEC;
	public int FAIRINMILLISEC;
	public int BaseInMiliSec;
	public int MediumInMiliSec;
	public int LOWESTInMiliSec;
	public int UNITINMILLISEC;

	/*----------------------------------Report logger file -----------------------------------------------------------*/

	public String REPORT_LOG_FILE_NAME;
	public String REPORT_LOG_FILE_PATH; 

	/*-------------------------------- ScreenShort Path ------------------------------------------------------------*/
	public String SCREEN_SHOT_PATH;

	/*------------------------------- Certificate Selection Command -------------------*/
	public String DefaultDownloadFolder;
	public String strFirefoxExceptionHandlerCommand;

	/*-------------------------------- Password Manager URL ------------------------------------------------------------*/
	public static String PasswordMgrURL;

	/*-------------------------------- Credentials Datasheet ------------------------------------------------------------*/
	public String CredentialsDatasheetPath;
	public String PwdMgrCredentialsSheetName;
	public String DirectLoginCredentialsSheetName;

	public String UploadFilesFolderPath;

	public String ProdNavigationDatasheetPath_Rainbow;
	
	public String ProdNavigationDatasheetPath_Classic;

	public String ProdNavigationSheetName;

	public String ExecutionParamsSheetName;

	public String ExecutionParamsPath;
	
	public String languageTranslation;

	public String SystemParamsPath;
	
	public String useraccountPath;
	/**/

	/*-------------------------------- LPLCoreConstents Instance ------------------------------------------------------------*/
	private static ZycusCoreConstants instance = null;

	public static ZycusCoreConstants getInstance() {
		if (instance == null) {
			instance = new ZycusCoreConstants();
		}
		return instance;
	}

	public ZycusCoreConstants() {
		
	/*	String datasheetLocation= null;
		try {
			datasheetLocation = SystemProperties.getInstance().getProperty("DatasheetsLocation");
			System.out.println(datasheetLocation +"test");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();		
		}
		switch(datasheetLocation){
		case "GIT":

			try {
				//Loading the file from the given path
				FileInputStream xmlFile=new FileInputStream(System.getProperty("user.dir") + "/CoreConstents.xml");

				//Parsing the XML file into a document
				Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlFile);
				System.out.println("Before execution params");
				//Retrieve data from XML
				CONFIG_FILE_PATH = systemDirectoryPath + document.getElementsByTagName("CONFIG_FILE_PATH").item(0).getTextContent();
				SYS_CONFIG_FILE_PATH = systemDirectoryPath + document.getElementsByTagName("SYS_CONFIG_FILE_PATH").item(0).getTextContent();
				WIN_CHROME_DRIVER_PATH =systemDirectoryPath + document.getElementsByTagName("WIN_CHROME_DRIVER_PATH").item(0).getTextContent();
				WIN_GECKO_DRIVER_PATH = systemDirectoryPath + document.getElementsByTagName("WIN_GECKO_DRIVER_PATH").item(0).getTextContent();
				EXTENT_REPORTS_PATH = systemDirectoryPath+ document.getElementsByTagName("EXTENT_REPORTS_PATH").item(0).getTextContent();
				HIGHEST = Integer.parseInt(document.getElementsByTagName("HIGHEST").item(0).getTextContent());
				VERYHIGH = Integer.parseInt(document.getElementsByTagName("VERYHIGH").item(0).getTextContent());
				HIGH = Integer.parseInt(document.getElementsByTagName("HIGH").item(0).getTextContent());
				MEDIUM = Integer.parseInt(document.getElementsByTagName("MEDIUM").item(0).getTextContent());
				FAIR = Integer.parseInt(document.getElementsByTagName("FAIR").item(0).getTextContent());
				LOW = Integer.parseInt(document.getElementsByTagName("LOW").item(0).getTextContent());
				BASE = Integer.parseInt(document.getElementsByTagName("BASE").item(0).getTextContent());
				LOWEST = Integer.parseInt(document.getElementsByTagName("LOWEST").item(0).getTextContent());
				UNIT = Integer.parseInt(document.getElementsByTagName("UNIT").item(0).getTextContent());
				BaseInMiliSec = Integer.parseInt(document.getElementsByTagName("BASEINMILISEC").item(0).getTextContent());
				FAIRINMILLISEC = Integer.parseInt(document.getElementsByTagName("FAIRINMILLISEC").item(0).getTextContent());
				MediumInMiliSec = Integer.parseInt(document.getElementsByTagName("MEDIUMINMILISEC").item(0).getTextContent());
				LOWESTInMiliSec = Integer.parseInt(document.getElementsByTagName("LOWESTINMILISEC").item(0).getTextContent());
				HIGHINMILLISEC = Integer.parseInt(document.getElementsByTagName("HIGHINMILLISEC").item(0).getTextContent());
				UNITINMILLISEC = Integer.parseInt(document.getElementsByTagName("UNITINMILLISEC").item(0).getTextContent());
				REPORT_LOG_FILE_NAME = document.getElementsByTagName("REPORT_LOG_FILE_NAME").item(0).getTextContent();
				REPORT_LOG_FILE_PATH = systemDirectoryPath + document.getElementsByTagName("REPORT_LOG_FILE_PATH").item(0).getTextContent();
				SCREEN_SHOT_PATH = systemDirectoryPath + document.getElementsByTagName("SCREEN_SHOT_PATH").item(0).getTextContent(); 

				//-------------------------------------Default Download Folder path ---------------------------
				DefaultDownloadFolder = systemDirectoryPath + document.getElementsByTagName("DEFAULTDOWNLOADFOLDER").item(0).getTextContent();

				//-------------------------------------Upload Files - Folder path ---------------------------
				UploadFilesFolderPath = systemDirectoryPath + document.getElementsByTagName("UPLOADFILESPATH").item(0).getTextContent();			 

				//-------------------------------------Password Manager URL ---------------------------
				PasswordMgrURL = document.getElementsByTagName("PASSWORDMANAGERURL").item(0).getTextContent();

				//-------------------------------------Credentials Datasheet Path ---------------------------
				CredentialsDatasheetPath = systemDirectoryPath + document.getElementsByTagName("CREDENTIALSDATASHEETPATH").item(0).getTextContent();
				PwdMgrCredentialsSheetName =document.getElementsByTagName("PWDMGRCREDENTIALSSHEET").item(0).getTextContent();
				ProdNavigationDatasheetPath = systemDirectoryPath + document.getElementsByTagName("PRODNAVIGATIONDATASHEETPATH").item(0).getTextContent();
				//ProdNavigationSheetName = document.getElementsByTagName("PRODNAVIGATIONSHEET").item(0).getTextContent();
				//ExecutionParamsSheetName =document.getElementsByTagName("EXECUTIONPARAMSSSHEET").item(0).getTextContent();
				ExecutionParamsPath = systemDirectoryPath + document.getElementsByTagName("EXECUTIONPARAMSSHEETPATH").item(0).getTextContent();
				SystemParamsPath = systemDirectoryPath + document.getElementsByTagName("SYSTEMPARAMSSHEETPATH").item(0).getTextContent();

			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (DOMException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			}

			break;
		case "Shared":

			try {
				//Loading the file from the given path
				FileInputStream xmlFile=new FileInputStream(System.getProperty("user.dir") + "/CoreConstents.xml");

				//Parsing the XML file into a document
				Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlFile);

				//Retrieve data from XML
				CONFIG_FILE_PATH = System.getProperty("user.dir") + document.getElementsByTagName("CONFIG_FILE_PATH").item(0).getTextContent();
				SYS_CONFIG_FILE_PATH = System.getProperty("user.dir") + document.getElementsByTagName("SYS_CONFIG_FILE_PATH").item(0).getTextContent();
				WIN_CHROME_DRIVER_PATH = systemDirectoryPath + document.getElementsByTagName("WIN_CHROME_DRIVER_PATH").item(0).getTextContent();
				WIN_GECKO_DRIVER_PATH = systemDirectoryPath + document.getElementsByTagName("WIN_GECKO_DRIVER_PATH").item(0).getTextContent();
				EXTENT_REPORTS_PATH = systemDirectoryPath + document.getElementsByTagName("EXTENT_REPORTS_PATH").item(0).getTextContent();
				HIGHEST = Integer.parseInt(document.getElementsByTagName("HIGHEST").item(0).getTextContent());
				VERYHIGH = Integer.parseInt(document.getElementsByTagName("VERYHIGH").item(0).getTextContent());
				HIGH = Integer.parseInt(document.getElementsByTagName("HIGH").item(0).getTextContent());
				MEDIUM = Integer.parseInt(document.getElementsByTagName("MEDIUM").item(0).getTextContent());
				FAIR = Integer.parseInt(document.getElementsByTagName("FAIR").item(0).getTextContent());
				LOW = Integer.parseInt(document.getElementsByTagName("LOW").item(0).getTextContent());
				BASE = Integer.parseInt(document.getElementsByTagName("BASE").item(0).getTextContent());
				LOWEST = Integer.parseInt(document.getElementsByTagName("LOWEST").item(0).getTextContent());
				UNIT = Integer.parseInt(document.getElementsByTagName("UNIT").item(0).getTextContent());
				BaseInMiliSec = Integer.parseInt(document.getElementsByTagName("BASEINMILISEC").item(0).getTextContent());
				FAIRINMILLISEC = Integer.parseInt(document.getElementsByTagName("FAIRINMILLISEC").item(0).getTextContent());
				MediumInMiliSec = Integer.parseInt(document.getElementsByTagName("MEDIUMINMILISEC").item(0).getTextContent());
				LOWESTInMiliSec = Integer.parseInt(document.getElementsByTagName("LOWESTINMILISEC").item(0).getTextContent());
				HIGHINMILLISEC = Integer.parseInt(document.getElementsByTagName("HIGHINMILLISEC").item(0).getTextContent());
				UNITINMILLISEC = Integer.parseInt(document.getElementsByTagName("UNITINMILLISEC").item(0).getTextContent());
				REPORT_LOG_FILE_NAME = document.getElementsByTagName("REPORT_LOG_FILE_NAME").item(0).getTextContent();
				REPORT_LOG_FILE_PATH = systemDirectoryPath + document.getElementsByTagName("REPORT_LOG_FILE_PATH").item(0).getTextContent();
				SCREEN_SHOT_PATH = systemDirectoryPath + document.getElementsByTagName("SCREEN_SHOT_PATH").item(0).getTextContent(); 

				//-------------------------------------Default Download Folder path ---------------------------
				DefaultDownloadFolder = systemDirectoryPath + document.getElementsByTagName("DEFAULTDOWNLOADFOLDER").item(0).getTextContent();

				//-------------------------------------Upload Files - Folder path ---------------------------
				UploadFilesFolderPath = systemDirectoryPath + document.getElementsByTagName("UPLOADFILESPATH").item(0).getTextContent();			 

				//-------------------------------------Password Manager URL ---------------------------
				PasswordMgrURL = document.getElementsByTagName("PASSWORDMANAGERURL").item(0).getTextContent();

				//-------------------------------------Credentials Datasheet Path ---------------------------
				CredentialsDatasheetPath = sharedDirectoryPath + document.getElementsByTagName("CREDENTIALSDATASHEETPATH").item(0).getTextContent();
				PwdMgrCredentialsSheetName =document.getElementsByTagName("PWDMGRCREDENTIALSSHEET").item(0).getTextContent();
				ProdNavigationDatasheetPath =sharedDirectoryPath+ document.getElementsByTagName("PRODNAVIGATIONDATASHEETPATH").item(0).getTextContent();
				//ProdNavigationSheetName = document.getElementsByTagName("PRODNAVIGATIONSHEET").item(0).getTextContent();
				//ExecutionParamsSheetName =document.getElementsByTagName("EXECUTIONPARAMSSSHEET").item(0).getTextContent();
				ExecutionParamsPath = sharedDirectoryPath + document.getElementsByTagName("EXECUTIONPARAMSSHEETPATH").item(0).getTextContent();
				SystemParamsPath = systemDirectoryPath + document.getElementsByTagName("SYSTEMPARAMSSHEETPATH").item(0).getTextContent();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (DOMException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			}

			break;
		}


*/
	
		try {
			//Loading the file from the given path
			 FileInputStream xmlFile=new FileInputStream(System.getProperty("user.dir") + "/CoreConstant/CoreConstents.xml");

			 //Parsing the XML file into a document
			 Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlFile);

			 //Retrieve data from XML
			 CONFIG_FILE_PATH =systemDirectoryPath + document.getElementsByTagName("CONFIG_FILE_PATH").item(0).getTextContent();
			 SYS_CONFIG_FILE_PATH = systemDirectoryPath + document.getElementsByTagName("SYS_CONFIG_FILE_PATH").item(0).getTextContent();
			 LANG_CONFIG_FILE_PATH = systemDirectoryPath + document.getElementsByTagName("LANG_CONFIG_FILE_PATH").item(0).getTextContent();
			 WIN_CHROME_DRIVER_PATH =systemDirectoryPath + document.getElementsByTagName("WIN_CHROME_DRIVER_PATH").item(0).getTextContent();
			 WIN_GECKO_DRIVER_PATH = systemDirectoryPath + document.getElementsByTagName("WIN_GECKO_DRIVER_PATH").item(0).getTextContent();
			 EXTENT_REPORTS_PATH = systemDirectoryPath + document.getElementsByTagName("EXTENT_REPORTS_PATH").item(0).getTextContent();
			 HIGHEST = Integer.parseInt(document.getElementsByTagName("HIGHEST").item(0).getTextContent());
			 VERYHIGH = Integer.parseInt(document.getElementsByTagName("VERYHIGH").item(0).getTextContent());
			 HIGH = Integer.parseInt(document.getElementsByTagName("HIGH").item(0).getTextContent());
			 MEDIUM = Integer.parseInt(document.getElementsByTagName("MEDIUM").item(0).getTextContent());
			 FAIR = Integer.parseInt(document.getElementsByTagName("FAIR").item(0).getTextContent());
			 LOW = Integer.parseInt(document.getElementsByTagName("LOW").item(0).getTextContent());
			 BASE = Integer.parseInt(document.getElementsByTagName("BASE").item(0).getTextContent());
			 LOWEST = Integer.parseInt(document.getElementsByTagName("LOWEST").item(0).getTextContent());
			 UNIT = Integer.parseInt(document.getElementsByTagName("UNIT").item(0).getTextContent());
			 BaseInMiliSec = Integer.parseInt(document.getElementsByTagName("BASEINMILISEC").item(0).getTextContent());
			 FAIRINMILLISEC = Integer.parseInt(document.getElementsByTagName("FAIRINMILLISEC").item(0).getTextContent());
			 MediumInMiliSec = Integer.parseInt(document.getElementsByTagName("MEDIUMINMILISEC").item(0).getTextContent());
			 LOWESTInMiliSec = Integer.parseInt(document.getElementsByTagName("LOWESTINMILISEC").item(0).getTextContent());
			 HIGHINMILLISEC = Integer.parseInt(document.getElementsByTagName("HIGHINMILLISEC").item(0).getTextContent());
			 UNITINMILLISEC = Integer.parseInt(document.getElementsByTagName("UNITINMILLISEC").item(0).getTextContent());
			 REPORT_LOG_FILE_NAME = document.getElementsByTagName("REPORT_LOG_FILE_NAME").item(0).getTextContent();
			 REPORT_LOG_FILE_PATH =systemDirectoryPath + document.getElementsByTagName("REPORT_LOG_FILE_PATH").item(0).getTextContent();
			 SCREEN_SHOT_PATH = systemDirectoryPath + document.getElementsByTagName("SCREEN_SHOT_PATH").item(0).getTextContent(); 

			 //-------------------------------------Default Download Folder path ---------------------------
			 DefaultDownloadFolder = systemDirectoryPath+ document.getElementsByTagName("DEFAULTDOWNLOADFOLDER").item(0).getTextContent();

			 //-------------------------------------Upload Files - Folder path ---------------------------
			 UploadFilesFolderPath =systemDirectoryPath+ document.getElementsByTagName("UPLOADFILESPATH").item(0).getTextContent();			 

			 //-------------------------------------Password Manager URL ---------------------------
			 PasswordMgrURL = document.getElementsByTagName("PASSWORDMANAGERURL").item(0).getTextContent();

			 //-------------------------------------Credentials Datasheet Path ---------------------------
				CredentialsDatasheetPath = systemDirectoryPath + document.getElementsByTagName("CREDENTIALSDATASHEETPATH").item(0).getTextContent();
				PwdMgrCredentialsSheetName =document.getElementsByTagName("PWDMGRCREDENTIALSSHEET").item(0).getTextContent();
				DirectLoginCredentialsSheetName =document.getElementsByTagName("DIRECTLOGINCREDENTIALSSHEET").item(0).getTextContent();
				ProdNavigationDatasheetPath_Rainbow =systemDirectoryPath + document.getElementsByTagName("PRODNAVIGATIONDATASHEETPATHRAINBOW").item(0).getTextContent();
				
				ProdNavigationDatasheetPath_Classic =systemDirectoryPath + document.getElementsByTagName("PRODNAVIGATIONDATASHEETPATHCLASSIC").item(0).getTextContent();
				//ProdNavigationSheetName = document.getElementsByTagName("PRODNAVIGATIONSHEET").item(0).getTextContent();
				//ExecutionParamsSheetName =document.getElementsByTagName("EXECUTIONPARAMSSSHEET").item(0).getTextContent();
				ExecutionParamsPath = systemDirectoryPath + document.getElementsByTagName("EXECUTIONPARAMSSHEETPATH").item(0).getTextContent();
				SystemParamsPath = systemDirectoryPath + document.getElementsByTagName("SYSTEMPARAMSSHEETPATH").item(0).getTextContent();
				languageTranslation = systemDirectoryPath + document.getElementsByTagName("LANGUAGETRANSLATIONSHEETPATH").item(0).getTextContent();
				useraccountPath = systemDirectoryPath + document.getElementsByTagName("USERACCOUNTPARAMSSHEETPATH").item(0).getTextContent(); 
				xmlFile.close();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DOMException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}

	public static String getURL(){
		String URL = null;
		ZycusConfig objConfig = new ZycusConfig();
		if(objConfig.isLoginWithPwdMgr())
			URL = PasswordMgrURL;
		else{
			switch(objConfig.getEnvironment()){
			case "RM":
				switch(objConfig.getSetup()){
				case "ZCS RM":
					URL = "";
					break;
				}
				break;
			case "Partner":
				switch(objConfig.getSetup()){
				case "ZCS Partner":
					URL = "";
					break;
				}
				break;
			case "Production":
				switch(objConfig.getSetup()){
				case "ZCS Production":
					URL = "";
					break;
				case "Sanity6 AWS Production":
					URL = "";
					break;
				case "ZCS AU":
					URL = "";
					break;
				case "ZCS SG":
					URL = "";
					break;
				}
				break;
			case "DevInt":
				switch(objConfig.getSetup()){
				case "DevInt":
					URL = "https://login-devint.zycus.com/sso/login";
					break;
				}
				break;
			}

		}
		return URL;
	}


	public static String getPwdMgrURL(){
		return PasswordMgrURL;
	}
}
