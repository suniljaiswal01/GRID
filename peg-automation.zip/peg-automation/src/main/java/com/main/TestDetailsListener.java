package com.main;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

public class TestDetailsListener implements IInvokedMethodListener{

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		 if (!method.isTestMethod()) {
             return;
         }
         TestDetails set = method.getTestMethod().getConstructorOrMethod().getMethod().getAnnotation(TestDetails.class);
		 System.out.println("About to execute Script ID : "+set.TestID()); 
		 ProjectConfig1.setScriptID(set.TestID());
		 //Get Navigation Details - Tab, Subtab
		
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		String textMsg = "About to end executing following method : ";
		System.out.println(textMsg); 
		
	}

}
