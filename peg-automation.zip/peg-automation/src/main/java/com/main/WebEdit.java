package com.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebEdit {
	
	public ZycusCoreUtil zycusCoreUtil;
	
	public String strError;
	
	public boolean setWebEditValue(WebDriver driver, By TextBoxbyProperty, String strValue){
		boolean blnWebEditFound = false;
		try{
			zycusCoreUtil = new ZycusCoreUtil(driver);
			WebElement objWebEdit = zycusCoreUtil.waitForWebElement(
					ZycusCoreConstants.getInstance().FAIR,
					TextBoxbyProperty);
			if (objWebEdit.isDisplayed()) {
					objWebEdit.clear();
					objWebEdit.sendKeys(strValue);
					blnWebEditFound = true;
			}
			return blnWebEditFound;
		}
		
		catch(Exception ex){
			strError = strError+ex.getMessage();
			ex.printStackTrace();
			return false;
	   }
	}
	
	public boolean setWebEditValue(By TextBoxbyProperty, String strValue){
		boolean blnWebEditFound = false;
		try{
			zycusCoreUtil = new ZycusCoreUtil();
			WebElement objWebEdit = zycusCoreUtil.waitForWebElement(
					ZycusCoreConstants.getInstance().FAIR,
					TextBoxbyProperty);
			if (objWebEdit.isDisplayed()) {
					objWebEdit.clear();
					objWebEdit.sendKeys(strValue);
					blnWebEditFound = true;
			}
			return blnWebEditFound;
		}
		
		catch(Exception ex){
			strError = strError+ex.getMessage();
			ex.printStackTrace();
			return false;
	   }
	}
	
	/*public boolean setAutoCompleteTxt(WebDriver driver, By field, String text) throws Exception {
		boolean result = false;
		try {
			setWebEditValue(driver, field, text);
			ZycusCoreSync.waitTillInVisible(driver, By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"), ZycusCoreConstants.getInstance().MEDIUM);
			driver.findElement(By.xpath("(//ul[contains(@style,'block')]//*[text()='" + text + "'])[1]")).click();
			result = true;
		} catch (Exception e) {
			strError = strError+e.getMessage();
			e.printStackTrace();
			return false;
		}
		return result;
	}*/
	
	public boolean setAutoCompleteTxt(WebDriver driver, By field, String text) throws Exception {
		boolean result = false;
		try {
			setWebEditValue(field, text);
			ZycusCoreSync.waitTillInVisible(driver, By.xpath("//input[contains(@class,'ui-autocomplete-loading')]"), ZycusCoreConstants.getInstance().MEDIUM);
			zycusCoreUtil = new ZycusCoreUtil();
			WebElement objWebDopdown = zycusCoreUtil.waitForWebElement(
					ZycusCoreConstants.getInstance().FAIR,
					By.xpath("(//ul[contains(@style,'block')]//*[text()='" + text + "'])[1]"));
			if (objWebDopdown.isDisplayed())
				objWebDopdown.click();
			result = true;
		} catch (Exception e) {
			strError = strError+e.getMessage();
			e.printStackTrace();
			return false;
		}
		return result;
	}
}
