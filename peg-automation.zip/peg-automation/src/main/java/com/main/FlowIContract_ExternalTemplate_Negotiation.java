package com.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.zycus.IContract.ManageContracts.AuthorContract;
import com.zycus.IContract.ManageContracts.ContractSummary;
import com.zycus.IContract.ManageContracts.ContractingParty;
import com.zycus.IContract.ManageContracts.ContractsPendingReview;
import com.zycus.IContract.ManageContracts.CreateContract;
import com.zycus.IContract.ManageContracts.Documents;
import com.zycus.IContract.Setup.ProductConfig.ProdConfig;
import com.zycus.IContract.Setup_ProdConfig.Workflow.SignOffStageWorkflowConfig;
import com.zycus.ZSN.MyContracts.ViewContracts;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
//import Framework.NavigationClass;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;;

public class FlowIContract_ExternalTemplate_Negotiation extends CommonTests1{
	
	public FlowIContract_ExternalTemplate_Negotiation() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	
	/**
	 * @param contractNumber
	 *            the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	//private ExtentTest logger;
	private String Product = "iContract";
	private WebDriver driver1;
	eInvoice_CommonFunctions objFunctions;
	private String contractNumber;
	
	//ZCS production - Navisite
	//private String clauseCategory = "Test";
	//ZCS RM
	//private String clauseCategory = "Category 1";
	private String clauseTitle;
	private String templateName;
	private String contractTitle = null;
	private boolean isFileDownloaded = true;
	private String newDashboardName;
	private String dashboardName;
	
	private boolean isNegotiationAllowed = true;
	private boolean isExternalTemplateAvailable = true;
	
	private boolean sendForSigning = true;
	
	//Verify if signoffWorkflow is active or not
	private boolean isSignoffWorkflowActive = false;
	private boolean isAuthoringWorkflowActive = false;
	
	/*@BeforeClass
	public void beforeClass(){
		parentLogger = parent.createNode(Product);
	}
	
	@BeforeMethod
	public void beforeMethod(Method method){
		TestDetails set = method.getAnnotation(TestDetails.class);
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		loginCredentials = objConnect.getLoginCredentials(set.TestID());
		logger = parentLogger.createNode(method.getName());
	}*/
	
	@Test(groups = "Login", dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login",alwaysRun = true)
	@TestDetails(TestID="iContract_1")
	public void loginNegotiation(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		
		driver = startSession(this.getClass().getName());
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		//displayStyle = objZCD.getDisplayStyle(driver, loginCredentials);
		displayStyle = "Rainbow";
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "TypeSubType",description = "",
			dependsOnMethods = "loginNegotiation",
			priority = 4)
	@TestDetails(TestID="iContract_4")
	public void SignOffWorkflow(String contractType, String contractSubType) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Setup", "Product Configuration");
		ProdConfig objConfig = new ProdConfig(driver, logger);
		objConfig.selectWorkflow("SignOff Stage Workflow Configuration");
		SignOffStageWorkflowConfig objWorkflow = new SignOffStageWorkflowConfig(driver, logger);
		System.out.println(contractType);
		System.out.println(contractSubType);
		isSignoffWorkflowActive = objWorkflow.verifyIfWorkflowActive(contractType, contractSubType);
		System.out.println("Sign off Workflow Active :"+isSignoffWorkflowActive);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "TypeSubType",description = "",
			dependsOnMethods = "loginNegotiation",
			priority = 4)
	@TestDetails(TestID="iContract_4")
	public void AuthoringWorkflow(String contractType, String contractSubType) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Setup", "Product Configuration");
		ProdConfig objConfig = new ProdConfig(driver, logger);
		objConfig.selectWorkflow("Author Stage Workflow Configuration");
		SignOffStageWorkflowConfig objWorkflow = new SignOffStageWorkflowConfig(driver, logger);
		System.out.println(contractType);
		System.out.println(contractSubType);
		isAuthoringWorkflowActive = objWorkflow.verifyIfWorkflowActive(contractType, contractSubType);
		System.out.println("Author off Workflow Active :"+isAuthoringWorkflowActive);
		driver.findElement(By.id("close")).click();
	}
	
	
	@Test(description = "",
			dependsOnMethods = "loginNegotiation",
			priority = 4)
	@TestDetails(TestID="iContract_4")
	public void authorContract_noNegotiate() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.createContract("", isNegotiationAllowed, isExternalTemplateAvailable);
		
		//Verify Yellow btn- Draft in Progress
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		contractTitle = objSummary.getContractTitle();
		contractNumber = objSummary.getContractNum();
		System.out.println("Contract Number created here is :"+ contractNumber);
		objContract.closeContract();
		//Check row created with status as 'Draft in Progress'
		objAuthor.verifyContractStatusinGrid(contractNumber);
	}
	
	@Test(description = "",
			dependsOnMethods = "authorContract_noNegotiate",
			priority = 5)
	@TestDetails(TestID="iContract_4")
	public void addContractingParties() throws Exception {
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		CreateContract objContract = new CreateContract(driver, logger);
		objAuthor.navigateToStage(contractNumber, "Author");
		//Contracting Party
		ContractingParty objContParty = new ContractingParty(driver, logger);
		objContract.navigate_ContractSubTabs("Contracting Party");
		objContParty.addContractingParties();
	}
	
	/*@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 6)
	@TestDetails(TestID="iContract_4")
	public void addContractOutline() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Outline");
		ContractOutline objOutline = new ContractOutline(driver, logger);
		objOutline.createVersion();
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractOutline",
			priority = 7)
	@TestDetails(TestID="iContract_4")
	public void addLineItems() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Line Items
		objContract.navigate_ContractSubTabs("Line Items");
		LineItems objItems = new LineItems(driver, logger);
		objItems.createLineItem();
	}
	
	@Test(description = "",
			dependsOnMethods = "addLineItems",
			priority = 8)
	@TestDetails(TestID="iContract_4")
	public void uploadDocuments() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Line Items
		objContract.navigate_ContractSubTabs("Documents");
		Documents objDoc = new Documents(driver, logger);
		//provide no of documents to upload 
		objDoc.selectDocuments(2);
	}
	
	@Test(description = "",
			dependsOnMethods = "addLineItems",
			priority = 9)
	@TestDetails(TestID="iContract_4")
	public void addMilestones() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Add Milestones
		objContract.navigate_ContractSubTabs("Milestones");
		Milestone objMilestone = new Milestone(driver, logger);
		objMilestone.addMilestone();
	}
	
	@Test(description = "",
			dependsOnMethods = "addMilestones",
			priority = 10)
	@TestDetails(TestID="iContract_4")
	public void createVersion() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		Thread.sleep(5000);
		objContract.navigate_ContractSubTabs("Timeline");
		Timeline objTimeline = new Timeline(driver, logger, contractTitle);
		if(objTimeline.verifyVersionCreated())
			logger.pass("Version created and Downloaded");
		else
			logger.fail("Version not created or Downloaded");
		
		//if(isDocUploaded){
		if(objTimeline.verifyDocumentCreated())
			logger.pass("Document visible in timeline and Downloaded");
		else
			logger.fail("Document not visible or Downloaded in timeline");
	}*/
	
	//If negotaiation is allowed then only Contract can be sent for Internal review
	/*@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 11)
	@TestDetails(TestID="iContract_4")
	public void sendForInternalReview() throws Exception {
		//boolean sendForInternalReview = false;
		//if(sendForInternalReview){
		if(isNegotiationAllowed){
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.navigate_ContractSubTabs("Contract Summary");
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.sendForApproval();
			objContract.navigate_ContractSubTabs("Author Review");
			objSummary.authorReview();
			
			objFunctions.closeBrowser();
			
			Login objLogin = new Login(driver, logger);
			objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
			objFunctions.switchToWindow("Rainbow Home");
			objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Authoring Stage", contractNumber, "Approve");
			objFunctions.closeBrowser();
		}else
			throw new SkipException("Skipping this exception");
	}*/
	
	@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 11)
	@TestDetails(TestID="iContract_4")
	public void sendForInternalReview() throws Exception {
		String authoringUser = null;
		//boolean sendForInternalReview = false;
		//if(sendForInternalReview){
		if(isNegotiationAllowed){
			
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.navigate_ContractSubTabs("Contract Summary");
			ContractSummary objSummary = new ContractSummary(driver, logger);
			if(isAuthoringWorkflowActive){
				objSummary.sendForApproval();
			}
			Thread.sleep(2500);
			System.out.println(driver.findElement(By.xpath("//div[@id='conAuthorRev']//table//td[span[contains(text(),'Pending')]]")).getText().trim().split(":")[1].trim());
			String pendingWith = driver.findElement(By.xpath("//div[@id='conAuthorRev']//table//td[span[contains(text(),'Pending')]]")).getText().trim().split(":")[1].trim();
			//objSummary.sendToContractingParty();
			//Thread.sleep(2500);
			authoringUser = configurationProperties.getProperty("UserAccount");
			if(!authoringUser.equals(pendingWith)){
				objFunctions.closeBrowser();
				if(isAuthoringWorkflowActive){
					/*Login objLogin = new Login(driver, logger);
					objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
					objFunctions.switchToWindow("Rainbow Home");*/
					
					//driver = objCore.startSession("admin.zcs@zycus.com");
					driver = startSession(pendingWith);
					objFunctions = new eInvoice_CommonFunctions(driver, logger);
					objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
					ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
					objReview.approveContract("Authoring Stage", contractNumber, "Approve");
					objFunctions.closeBrowser();
				}
			}else{
				objContract.closeContract();
				Thread.sleep(2500);
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
				ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
				objReview.approveContract("Authoring Stage", contractNumber, "Approve");
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
			}
				
		}else
			throw new SkipException("Skipping this exception");
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 12)
	@TestDetails(TestID="iContract_4")
	public void proceedToSignOff() throws Exception {
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		if(isNegotiationAllowed)
			objAuthor.navigateToStage(contractNumber, "Negotiate");
		else
			objAuthor.navigateToStage(contractNumber, "Sign Off");
		//boolean isSignoffWorkflowActive = false;
		CreateContract objContract = new CreateContract(driver, logger);
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		//if(sendForSigning){
		objSummary.sendToContractingParty();
		Thread.sleep(2500);
		//objSummary.proceedToSignOff(isSignoffWorkflowActive);
		/*}else
			objSummary.skipSigning();*/
		
		//objFunctions.closeBrowser();
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 13)
	@TestDetails(TestID="iContract_4")
	public void approveSignOffStage() throws Exception {
		if(sendForSigning){
			if(isSignoffWorkflowActive){
				/*Login objLogin = new Login(driver, logger);
				objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
				objFunctions.switchToWindow("Rainbow Home");*/
				driver = startSession("admin.zcs@zycus.com");
//				driver = objCore.startSession(pendingWith);
				objFunctions = new eInvoice_CommonFunctions(driver, logger);
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
				ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
				objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
				objFunctions.closeBrowser();
			}else
				throw new SkipException("Skipping this exception");
		}else{
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.skipSigning();
		}
			
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 14)
	@TestDetails(TestID="iContract_4")
	public void sendForOfflineSigning() throws Exception {
		boolean isSignoffWorkflowActive = true;
		/*objLogin.loginWithUserAcct_PwdMgr("GDQA-P2P@zycus.com");
		objFunctions.switchToWindow("Rainbow Home");
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		objAuthor.clrAllFilters();
		Thread.sleep(2000);
		objAuthor.filterByContractNum(contractNumber);
		objAuthor.navigateToStage(contractNumber, "Sign off");
	*/
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.sendForSigning(isSignoffWorkflowActive, "Offline Signing");
	}
	
	@Test(description = "",
			dependsOnMethods = "sendForOfflineSigning",
			priority = 15)
	@TestDetails(TestID="iContract_4")
	public void downloadContractInZSN() throws Exception {
		//Download Contract in ZSN
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		Login objLogin = null;
		if(configurationProperties.getProperty("Environment").equals("Production"))
			objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
		else if(configurationProperties.getProperty("Environment").equals("RM"))
			objLogin = new Login(driver1, logger, "gauri.joshi@zycus.com", "Right@123");
		
		callAndLog(driver1,logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		isFileDownloaded  = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
	}
	
	@Test(description = "",
			dependsOnMethods = "sendForOfflineSigning",
			priority = 16)
	@TestDetails(TestID="iContract_4")
	public void uploadContract() throws Exception {
		if(isFileDownloaded){
		try{
				ContractSummary objSummary = new ContractSummary(driver, logger);
				objSummary.uploadContract(contractTitle);
			}catch(Exception e){
				Documents objDoc1 = new Documents(driver, logger);
				objDoc1.addDocument_ForEnd(contractTitle);
			}
		}else
			throw new SkipException("Skipping this exception");
	}

}
