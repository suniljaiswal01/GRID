package com.main.iSupplierFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSupplier.MyReports.Reports;

import DataProviders.iSupplier_DataProviderTestNG;

public class SIMReport extends CommonTests1{

//	private ExtentTest logger;
	/*private String Product = "iSave";
	eInvoice_CommonFunctions objFunctions;*/

	public SIMReport() throws Exception {
		super();
		setProduct("iSupplier");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReport() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iSupplier_DataProviderTestNG.class,alwaysRun = true,dependsOnMethods = "loginReport",dataProvider = "report")
	@TestDetails(TestID="iSupplier_17")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}

	@Test(dataProviderClass = iSupplier_DataProviderTestNG.class, dependsOnMethods = "Reports",alwaysRun = true,dataProvider = "modifyReport")
	@TestDetails(TestID="iSupplier_17")
	public void ModifyReport(String report) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
	}
}
