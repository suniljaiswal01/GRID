package com.main.iSupplierFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.iSupplier_DataProviderTestNG;
import common.Functions.NavigationViaMenu;
import common.Functions.eInvoice_CommonFunctions;

public class FlowSIM_Sanity extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iSupplier";
	eInvoice_CommonFunctions objFunctions;
	String title= null;

	public FlowSIM_Sanity() throws Exception {
		super();
		setProduct("iSupplier");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginNavigation() throws Exception {


		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "navigateViaSideMenu", dependsOnMethods = "loginNavigation")
	@TestDetails(TestID = "iSupplier_1")
	public void navigateViaSideMenu(String... tabInfo) throws Exception {
		NavigationViaMenu navigateViaMenu = new NavigationViaMenu(driver, logger);
		if(displayStyle.equals("Classic")){
			if(tabInfo[0].equals("Manage Translations")|tabInfo[0].equals("Manage Views")|tabInfo[0].equals("Approval Workflow")|tabInfo[0].equals("Master Data Config")|tabInfo[0].equals("User Management")){
				throw new SkipException(tabInfo[0] +"tab does not exist in Classic View");
			}else{
				navigateViaMenu.navigateToPage(displayStyle, Product, tabInfo);
				navigateViaMenu.validateNavigation(Product,tabInfo);
			}
		}else {
			navigateViaMenu.navigateToPage(displayStyle, Product, tabInfo);
			navigateViaMenu.validateNavigation(Product,tabInfo);
		}
	}
}
