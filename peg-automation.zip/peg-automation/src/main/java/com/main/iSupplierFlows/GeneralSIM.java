package com.main.iSupplierFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSupplier.Collaborate.NewAutoAlert;
import com.zycus.iSupplier.Collaborate.NewManualAlert;
import com.zycus.iSupplier.Dashboard.MyWork;
import com.zycus.iSupplier.MasterDataConfig.SupplierPortal;

import DataProviders.iSupplier_DataProviderTestNG;

public class GeneralSIM extends CommonTests1 {

	String title= null;
	
	public GeneralSIM() throws Exception {
		super();
		setProduct("iSupplier");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginGeneral() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(description = "",dependsOnMethods = "loginGeneral",alwaysRun = true)
	@TestDetails(TestID="iSupplier_10")
	public void supplierPortal() throws Exception {
		SupplierPortal objPortal = new SupplierPortal(driver, logger);
		objPortal.verifyNavigationToSupplierPortal();
	}
	
	@Test(description = "", dependsOnMethods = "supplierPortal", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "createManualAlert", alwaysRun = true)
	@TestDetails(TestID="iSupplier_5")
	public void createManualAlert(String...supplierNames) throws Exception{
		NewManualAlert objAlert = new NewManualAlert(driver, logger);
		objAlert.createNewAlert(supplierNames);
	}

	@Test(description = "", dependsOnMethods = "createManualAlert", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "createAutoAlert", alwaysRun = true)
	@TestDetails(TestID="iSupplier_6")
	public void createAutoAlert(String allOrAnyCondition, String view, String field,
		String operatorValue, String fieldValue, String dueInDays,String...supplierName) throws Exception{
		NewAutoAlert objAlert = new NewAutoAlert(driver, logger);
		objAlert.createNewAlert(title, allOrAnyCondition, view, field, operatorValue, fieldValue,Integer.parseInt(dueInDays), supplierName);
	}

}
