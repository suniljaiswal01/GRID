package com.main.iSupplierFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSupplier.Dashboard.MyWork;
import com.zycus.iSupplier.ManageSuppliers.CreateSupplier;
import com.zycus.iSupplier.ManageSuppliers.EditSupplierDetails;
import com.zycus.iSupplier.SearchSuppliers.ContactRegistrationStatus;
import com.zycus.iSupplier.SearchSuppliers.StandardSearch;
import com.zycus.iSupplier.SearchSuppliers.SupplierScreener;

import DataProviders.iSupplier_DataProviderTestNG;
import common.Functions.iRequest_CommonFunctions;

public class OperationalSupplierFlow extends CommonTests1 {

	private String Product = "iSupplier";
	public static String supplierName;
	String title= null;
	public static String requestNo=null;

	public OperationalSupplierFlow() throws Exception {
		super();
		setProduct("iSupplier");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginOperational() throws Exception {

		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(description = "", dependsOnMethods = "loginOperational",alwaysRun = true)
	@TestDetails(TestID="iSupplier_2")
	public void createOperationalSupplier() throws Exception {
		CreateSupplier objSupplier = new CreateSupplier(driver, logger);
		supplierName = objSupplier.createNewSupplier("Operational").toUpperCase();
		System.out.println("Supplier Name : "+supplierName);
	}


	@Test(description = "",dependsOnMethods = "createOperationalSupplier")
	@TestDetails(TestID="iSupplier_3")
	public void approveSupplierCreationRequest() throws Exception {
		iRequest_CommonFunctions objFunctions = new iRequest_CommonFunctions(driver, logger);
		if(CreateSupplier.status.equals("Approved")) {
			objFunctions.LogScreenshot("pass",supplierName+ "Supplier Already Approved");
		}else {
			MyWork objWork = new MyWork(driver, logger);
			objWork.searchRequests("Requests for Approval", "Supplier Name", supplierName);
			objWork.approveRequest(supplierName);
		}
	}
	
	@Test(dependsOnMethods = "approveSupplierCreationRequest", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "extendSupplier",alwaysRun = true)
	@TestDetails(TestID = "iSupplier_4")
	public void extendSupplier(String supplierSystem, String supplierPlant) throws Exception {
		SupplierScreener objSupScreener= new SupplierScreener(driver, logger);
		StandardSearch objSearch= new StandardSearch(driver, logger);
		if (!supplierName.isEmpty()) {		
			objSupScreener.performSupplierScreenerAction(supplierName, "Extend");
			objSearch.extendSupplier(supplierName, supplierSystem, supplierPlant);
			MyWork objWork = new MyWork(driver, logger);
			objWork.editExtendedSupplier();
			objWork.approveOnboardingPotentialSupplier(supplierName);	
		}
	}

	
/*
	@Test(dependsOnMethods = "approveSupplierCreationRequest", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "extendSupplier",alwaysRun = true)
	@TestDetails(TestID = "iSupplier_8")
	public void extendSupplier(String supplierSystem, String supplierPlant) throws Exception {
		StandardSearch objSearch = new StandardSearch(driver, logger);
		if (!supplierName.isEmpty()) {		
			objSearch.performSearchSupplierAction(supplierName, false);
			objSearch.extendSupplier(supplierName, supplierSystem, supplierPlant);
			MyWork objWork = new MyWork(driver, logger);
			objWork.editExtendedSupplier();
			objWork.approveOnboardingPotentialSupplier(supplierName);	
		}
	}*/
	

	/*@Test(description = "", dependsOnMethods = "extendSupplier",alwaysRun=true)
	@TestDetails(TestID = "iSupplier_12")
	public void editSupplierDetails() throws Exception{
		boolean includePotentialSuppliers = false;
		
		EditSupplierDetails editSupplierDetails = new EditSupplierDetails(driver, logger);
		editSupplierDetails.waitForSupplierEdit();
		StandardSearch objSearch = new StandardSearch(driver, logger);
		objSearch.searchBySupplierName(supplierName, includePotentialSuppliers);
		
		editSupplierDetails.selectSupplierForOperation(supplierName);
		editSupplierDetails.performEdit();
		MyWork objWork = new MyWork(driver, logger);
		requestNo= objWork.approveRequest(supplierName);
	}*/
	
	@Test(description = "", dependsOnMethods = "extendSupplier",alwaysRun=true)
	@TestDetails(TestID = "iSupplier_4")
	public void editSupplierDetails() throws Exception{
		SupplierScreener objSupScreener= new SupplierScreener(driver, logger);
		EditSupplierDetails editSupplierDetails = new EditSupplierDetails(driver, logger);
		editSupplierDetails.waitForSupplierEdit();
		objSupScreener.performSupplierScreenerAction(supplierName, "Edit");
		editSupplierDetails.performEdit(supplierName);
		MyWork objWork = new MyWork(driver, logger);
		requestNo= objWork.approveRequest(supplierName);
	}
	
	@Test(description = "", dependsOnMethods = "editSupplierDetails",alwaysRun=true)
	@TestDetails(TestID = "iSupplier_12")
	public void auditTrailOperationalSupplier() throws Exception{
		boolean includePotentialSuppliers = false;
		
		EditSupplierDetails editSupplierDetails = new EditSupplierDetails(driver, logger);
		StandardSearch objSearch = new StandardSearch(driver, logger);
		objSearch.searchBySupplierName(supplierName, includePotentialSuppliers);
		editSupplierDetails.verifyAuditTrailForSupplier(supplierName);
		
	}

	

	@Test(description = "",dependsOnMethods = "editSupplierDetails")
	@TestDetails(TestID="iSupplier_11")
	public void searchOperationalSupplierInContactRegistration() throws Exception {
		ContactRegistrationStatus contactRegistration = new ContactRegistrationStatus(driver, logger);
		contactRegistration.searchSupplier("Company Name", supplierName);
	}

	
	@Test(dependsOnMethods = "searchOperationalSupplierInContactRegistration", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "extendSupplier")
	@TestDetails(TestID = "iSupplier_3")
	public void deleteOperationalSupplier(String supplierSystem, String supplierPlant) throws Exception {
		EditSupplierDetails editSupplierDetails = new EditSupplierDetails(driver, logger);
		if (!supplierName.isEmpty()) {		
			editSupplierDetails.deleteSupplier(supplierName);	
		}
	}
}
