package com.main.iSupplierFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSupplier.SearchSuppliers.StandardSearch;
import com.zycus.iSupplier.SearchSuppliers.SupplierScreener;

import DataProviders.iSupplier_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;

public class SupplierSearch extends CommonTests1  {
	
	private String Product = "iSupplier";
	eInvoice_CommonFunctions objFunctions;
	String title= null;
	
	public SupplierSearch() throws Exception {
		super();
		setProduct("iSupplier");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginSearch() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	/*@Test(description = "",dependsOnMethods = "loginSearch", dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "stdSearch_OperationalSuppliers",alwaysRun = true)
	@TestDetails(TestID="iSupplier_8")
	public void stdSearch_OperationalSuppliers(String supplierName) throws Exception {
		boolean includePotentialSuppliers = false;
		StandardSearch objSearch = new StandardSearch(driver, logger);
		objSearch.searchBySupplierName(supplierName, includePotentialSuppliers);
	}
	
	@Test(description = "",dependsOnMethods = "stdSearch_OperationalSuppliers",alwaysRun = true,dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "stdSearch_PotentialSuppliers")
	@TestDetails(TestID="iSupplier_9")
	public void stdSearch_PotentialSuppliers(String supplierName) throws Exception {
		boolean includePotentialSuppliers = true;
		StandardSearch objSearch = new StandardSearch(driver, logger);
		objSearch.searchBySupplierName(supplierName, includePotentialSuppliers);
		
	}*/
	
	@Test(description = "",dependsOnMethods = "loginSearch",alwaysRun = true)
	@TestDetails(TestID="iSupplier_4")
	public void supplierScreener() throws Exception {
		SupplierScreener objScreener = new SupplierScreener(driver, logger);
		objScreener.addCriteria();
		objScreener.validateSupplierScreenerPg();
	}

	/*@Test(description = "",dependsOnMethods = "com.main.iSupplierFlows.OperationalSupplierFlow.createOperationalSupplier")
	@TestDetails(TestID="iSupplier_7")
	public void searchRequest_MDMWorkbench() throws Exception {
		LocalDate localDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String searchValue = OperationalSupplierFlow.supplierName;
		String ToDt = localDate.format(formatter);
		String fromDt = LocalDate.now().minusDays(Long.valueOf(Integer.parseInt(ToDt.split("/")[0])-1)).format(formatter);
		MDMWorkbench objBench = new MDMWorkbench(driver, logger);
		objBench.searchRequest("Supplier Name", searchValue, fromDt, ToDt);
	}*/
}
