package com.main.iSupplierFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.iSupplier_DataProviderTestNG;
import Framework.CommonUtility;
import common.Functions.eInvoice_CommonFunctions;

public class iSupplierCRMS_Integration  extends CommonTests1{
	private String Product = "iSupplier";
	eInvoice_CommonFunctions objFunctions;
	String title= null;
	CommonUtility commonUtil = new CommonUtility();
	
	public iSupplierCRMS_Integration() throws Exception {
			super();
			setProduct("iSupplier");
			setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	@Test(groups = "Login", alwaysRun = true, dependsOnMethods="com.main.iSupplierFlows.OperationalSupplierFlow.createOperationalSupplier")
	@TestDetails(TestID="login")
	public void loginCRMSIntegration() throws Exception {
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = {"loginCRMSIntegration","com.main.iSupplierFlows.OperationalSupplierFlow.editSupplierDetails"}, dataProviderClass = iSupplier_DataProviderTestNG.class, dataProvider = "crms_reportGeneration",alwaysRun = true)
	@TestDetails(TestID = "iSupplier_CRMSIntegration")
	public void crms_reportGeneration(String category, String... data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		createNewReport.selectProduct(Product);
		createNewReport.selectParams(category, data);
		VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
		verifyReportsField.iSupplierFieldCheck(OperationalSupplierFlow.supplierName);
		verifyReportsField.exportReport();
		verifyReportsField.backToReportListing();
	}
	
}
