package com.main.iSupplierFlows;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.ManageCompanies.ConnectToCustomer;
import com.zycus.iSupplier.Dashboard.MyWork;
import com.zycus.iSupplier.ManageSuppliers.CreateSupplier;
import com.zycus.iSupplier.ManageSuppliers.EditSupplierDetails;
import com.zycus.iSupplier.SearchSuppliers.ContactRegistrationStatus;
import com.zycus.iSupplier.SearchSuppliers.StandardSearch;
import com.zycus.iSupplier.SearchSuppliers.SupplierScreener;

import DataProviders.iSupplier_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.eInvoice_CommonFunctions;
import common.Functions.iRequest_CommonFunctions;

public class PotentialSupplierFlow extends CommonTests1 {

	private String Product = "iSupplier";
	eInvoice_CommonFunctions objFunctions;
	private String potentialSupplierName =null;
	String title = null;
	WebDriver driver1= null;

	public PotentialSupplierFlow() throws Exception {
		super();
		setProduct("iSupplier");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginPotential() throws Exception {
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods="loginPotential", alwaysRun = true)
	@TestDetails(TestID = "loginZSN")
	public void createPotentialSupplier() throws Exception {
		String tenant = configurationProperties.getProperty("Tenant");
		ConnectToCustomer objConnect = new ConnectToCustomer(zsnDriver, logger);
		objConnect.connectToCustomer(tenant);
		String companyName = objConnect.enterCompanyInfo().toUpperCase();
		objConnect.acceptTNC();
		CreateSupplier objSupplier = new CreateSupplier(zsnDriver, logger);
		potentialSupplierName = objSupplier.createNewSupplier("Potential", companyName);
		zsnDriver.close();
	}

	@Test(dependsOnMethods = "createPotentialSupplier",alwaysRun=true)
	@TestDetails(TestID = "iSupplier_3")
	public void searchApprovePotentialSupplierRequests() throws Exception {
		MyWork objWork = new MyWork(driver, logger);
		System.out.println(CreateSupplier.status);
		if(!CreateSupplier.status.equals("Approved")) {
			Thread.sleep(2000);
			objWork.editRequest("potential supplier requests", "Supplier Name", potentialSupplierName);
			objWork.performEdit();
			objWork.approveRequestPotentialSupplier(potentialSupplierName);	
		}else
			throw new SkipException("Skipping approving supplier as supplier is auto-approved as per workflow");
	}	

	@Test( dependsOnMethods="searchApprovePotentialSupplierRequests")
	@TestDetails(TestID = "loginZSN")
	public void editPotentialSupplierCompany() throws Exception {
		EditSupplierDetails editSupplierDetails = new EditSupplierDetails(zsnDriver, logger);
		editSupplierDetails.waitForSupplierEdit();
		String tenant = configurationProperties.getProperty("Tenant");
		ConnectToCustomer objConnect = new ConnectToCustomer(zsnDriver, logger);
		objConnect.editCompany(potentialSupplierName, tenant);
		zsnDriver.close();
	}

	@Test(dependsOnMethods = "editPotentialSupplierCompany")
	@TestDetails(TestID = "iSupplier_3")
	public void approvePotentialSupplierRequests() throws Exception {
		MyWork objWork = new MyWork(driver, logger);
		System.out.println(CreateSupplier.status);
		if(!CreateSupplier.status.equals("Approved")) {
			Thread.sleep(2000);
			objWork.editRequest("potential supplier requests", "Supplier Name", potentialSupplierName);
			objWork.performEdit();
			objWork.approveRequestPotentialSupplier(potentialSupplierName);	
		}else
			throw new SkipException("Skipping approving supplier as supplier is auto-approved as per workflow");
	}	


	@Test(dependsOnMethods = "approvePotentialSupplierRequests")
	@TestDetails(TestID="iSupplier_11")
	public void searchPotentialSupplierInContactRegistration() throws Exception {
		ContactRegistrationStatus contactRegistration = new ContactRegistrationStatus(driver, logger);
		contactRegistration.searchSupplier("Company Name", potentialSupplierName);

	}

	@Test(dependsOnMethods = {"searchApprovePotentialSupplierRequests","searchPotentialSupplierInContactRegistration"}, alwaysRun=true)
	@TestDetails(TestID = "iSupplier_4")
	public void onBoardPotentialSupplier() throws Exception {
		StandardSearch objSearch = new StandardSearch(driver, logger);
		if (potentialSupplierName!=null) {
			SupplierScreener objSupScreener= new SupplierScreener(driver, logger);
			objSupScreener.performSupplierScreenerAction(potentialSupplierName, "Onboard");
			objSearch.onboardSupplier(potentialSupplierName);
			CreateSupplier createSupplierObj = new CreateSupplier(driver, logger);
			createSupplierObj.fillSystemDetails_random();
			MyWork objWork = new MyWork(driver, logger);
			objWork.searchRequests("My Requests", "Supplier Name", potentialSupplierName);
			Thread.sleep(8000);
			if (objWork.getRequestStatus(potentialSupplierName).equals("Pending Approval")) {
				LogScreenshot("Pass","Supplier : " + potentialSupplierName + " is onboarded and sent for approval");

			} else
				LogScreenshot("Fail", "Supplier : " + potentialSupplierName + " is not onboarded");
		} else {
			throw new SkipException("Potential Supplier not created");
		}
	}

	@Test(dependsOnMethods = "onBoardPotentialSupplier")
	@TestDetails(TestID = "iSupplier_3")
	public void approveOnboardRequestRequests() throws Exception {
		MyWork objWork = new MyWork(driver, logger);
		Thread.sleep(2000);
		objWork.approveOnboardingPotentialSupplier(potentialSupplierName);	
	}	
	
	@Test(dependsOnMethods = "approveOnboardRequestRequests")
	@TestDetails(TestID = "iSupplier_8")
	public void deactivatePotentialSupplier() throws Exception {
		boolean includePotentialSuppliers = false;
		StandardSearch objSearch = new StandardSearch(driver, logger);
		if (!potentialSupplierName.isEmpty()) {		
			objSearch.performSearchSupplierAction(potentialSupplierName,includePotentialSuppliers);
			objSearch.deactivateSupplier(potentialSupplierName);	
		}
	}
	
	@Test(dependsOnMethods = "deactivatePotentialSupplier")
	@TestDetails(TestID="iSupplier_3")
	public void approveDeactivationRequest() throws Exception {
		iRequest_CommonFunctions objFunctions = new iRequest_CommonFunctions(driver, logger);
		if(CreateSupplier.status.equals("Approved")) {
			objFunctions.LogScreenshot("pass",potentialSupplierName+ "Supplier Already Approved");
		}else {
			MyWork objWork = new MyWork(driver, logger);
			objWork.searchRequests("Requests for Approval", "Supplier Name", potentialSupplierName);
			objWork.approveRequest(potentialSupplierName);
		}
	}

	@Test(dependsOnMethods = "approveDeactivationRequest")
	@TestDetails(TestID = "iSupplier_8")
	public void deletePotentialSupplier() throws Exception {
		
		boolean includePotentialSuppliers = false;
		StandardSearch objSearch = new StandardSearch(driver, logger);
		if (!potentialSupplierName.isEmpty()) {		
			objSearch.performSearchSupplierAction(potentialSupplierName,includePotentialSuppliers);
			objSearch.deleteSupplier(potentialSupplierName);	
		}
	}
}


