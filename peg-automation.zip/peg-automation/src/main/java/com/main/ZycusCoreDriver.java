package com.main;

import java.awt.List;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import Framework.ConfigurationProperties;
import Framework.FrameworkUtility;
import SanityDefault.Login;

public class ZycusCoreDriver{
	
	
	public static HashMap<String, String> classDetails = new HashMap<String,String>();
	public String className;
	public String userAccount;
	public String userName;
	public WebDriver driver;
	public WebDriver driver1;
	public WebDriver zsnDriver;
	public ExtentTest logger;
	public RemoteWebDriver remoteDriver = null;
	public String token;
	public static ArrayList<String> deleteToken = new ArrayList<String>();
	private String envName;
	public static ZycusConfig ocfg;
	public static HashMap<String, String> loginCredentials = CommonTests1.loginCredentials;
	public static DateFormat dateFormatForReporting;
	public static Timestamp timeStamp;
	public static Date date;
	protected FrameworkUtility objFrameworkUtility = new FrameworkUtility();
	private String downloadFilepath = "Y:\\PCS-Shared-Local\\PEG- Automation\\Downloads\\";

	
	public ZycusCoreDriver(WebDriver driver) {
		this.driver = driver;
	}

	public ZycusCoreDriver(WebDriver driver,ExtentTest logger) {
		this.driver = driver;
		this.logger = logger;
	}
	
	public ZycusCoreDriver() {
		
	}

	public WebDriver startSession(String testName) throws Exception {
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		return startSession(configurationProperties.getProperty("UserAccount"), testName);
	}

	public void setValueInConfigFile(String key, String value) throws Exception {
		
		Properties props = new Properties();
		String propsFileName = "./config/config.properties";
		FileInputStream configStream = new FileInputStream(propsFileName);
		props.load(configStream);
		configStream.close();

		//modifies existing or adds new property
		props.setProperty(key,value);

		//save modified property file
		FileOutputStream output = new FileOutputStream(propsFileName);
		props.store(output, "This description goes to the header of a file");
		output.close();
		
	}

	public WebDriver startSession(String userAccount, String testName) throws Exception {

		boolean SSOCheck = false;

		/** Create the Configuration Object */
		ocfg = new ZycusConfig(); // Configuration object

		/** Get the CoreConstents Values from the XML */
		ZycusCoreConstants ZycusCoreConstents = ZycusCoreConstants.getInstance();

		/** Browser Capabilities Instance */
		DesiredCapabilities capability;

		/** Close all the browser and driver instances */
		//closeAllBrowserProcesses();

		// ****** Create date format and date object for reporting purpose *****
		/*dateFormatForReporting = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
                                timeStamp = new Timestamp(System.currentTimeMillis());
                                date = new Date();

                                // ***** Create the report file with date and time stamp *****
                                ZycusCoreReporter.createReportFile();*/
		if(ocfg.getExecutionType().toUpperCase().equals("NORMAL")){
			/** Launch the browser */
			switch (ocfg.getBrowserType().toUpperCase()) {
			case "FIREFOX":
				System.out.println("---------------firefox driver initialized ---------- OS : "	+ System.getProperty("os.name") + "----------");
				try{	

					//					WebDriverManager.firefoxdriver().setup();
					FirefoxOptions firefoxOptions = new FirefoxOptions();
					firefoxOptions.addPreference("browser.download.folderList", 2); //Use for the default download directory the last folder specified for a download
					firefoxOptions.addPreference("browser.download.useDownloadDir", true);
					firefoxOptions.addPreference("	browser.helperApps.neverAsk.saveToDisk", "application/pdf"); //list of MIME types to save to disk without asking what to use to open the file
					firefoxOptions.addPreference("pdfjs.disabled", true);  // disable the built-in PDF viewer
					DesiredCapabilities capablitiesFirefox = DesiredCapabilities.firefox();
					firefoxOptions.merge(capablitiesFirefox);
					if (ZycusConfig.getExecutionLocation().equalsIgnoreCase("Remote")) {
						String hubIP = ZycusConfig.getHubIP();
						//						firefoxOptions.setBinary("/bin/firefox");
						System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
						remoteDriver = new RemoteWebDriver(new URL("http://" + hubIP + "/wd/hub"), firefoxOptions);

						System.out.println(remoteDriver);
						remoteDriver.setFileDetector(new LocalFileDetector());
						System.out.println(remoteDriver);
						driver = remoteDriver;
					} else {
						System.setProperty("webdriver.gecko.driver", ZycusCoreConstents.WIN_GECKO_DRIVER_PATH);
						driver = new FirefoxDriver(firefoxOptions); 
					}
				}catch (Exception x) {
					x.printStackTrace();
					System.out.print("Encountered fatal error due to exception " + x.getMessage());
					System.exit(1);
				}
				break;
			case "CHROME":
				System.out.println("---------------chrome driver initialized ---------- OS : "
						+ System.getProperty("os.name") + "----------");
				try {
					// -----------------------------------------


					//					WebDriverManager.chromedriver().setup();

					HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
					chromePrefs.put("profile.default_content_settings.popups", 0);
					chromePrefs.put("profile.default_content_setting_values.notifications", 2);
					chromePrefs.put("profile.default_content_setting_values.automatic_downloads", 1);
//					chromePrefs.put("download.default_directory", downloadFilepath );
					ChromeOptions options = new ChromeOptions();
					options.setExperimentalOption("prefs", chromePrefs);
					options.addArguments("no-sandbox");
					options.addArguments("disable-gpu"); 
					options.addArguments("disable-dev-shm-usage");					
					options.addArguments("start-maximized");
					options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
					options.addArguments("--disable-features=VizDisplayCompositor");
					options.addArguments("--force-device-scale-factor=1");
					options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
					options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
					options.setCapability("TestName",testName);
					capability = DesiredCapabilities.chrome();
//					capability.setPlatform(org.openqa.selenium.Platform.LINUX);
					capability.setCapability("idleTimeout", 500);
					capability.setCapability("name", testName);
					capability.setCapability(ChromeOptions.CAPABILITY, options);
					options.merge(capability);
					if (ZycusConfig.getExecutionLocation().equalsIgnoreCase("Remote")) {
						String hubIP = ZycusConfig.getHubIP();
						//System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
						System.setProperty("webdriver.chrome.driver", "/home/devops/Grid/chromedriver");
						remoteDriver = new RemoteWebDriver(new URL("http://"+hubIP+"/wd/hub"), options);
						remoteDriver.setFileDetector(new LocalFileDetector());
						driver = remoteDriver;
					} else{
						System.setProperty("webdriver.chrome.driver", ZycusCoreConstents.WIN_CHROME_DRIVER_PATH);
						driver = new ChromeDriver(options);
					}
				} catch (Exception x) {
					x.printStackTrace();
					System.out.print("Encountered fatal error due to exception " + x.getStackTrace());
					System.exit(1);
				}
				break;
			case "IE":
			case "INTERNETEXPLORER":
			case "IEXPLORE":
				System.out.println("---------------Internet Explorer driver initialized ---------- ");
				break;
			case "EDGE":
				break;
			case "SAFARI":
				break;
			}

		} else if(ocfg.getExecutionType().toUpperCase().equals("HEADLESS")){
			switch (ocfg.getBrowserType().toUpperCase()) {

			case "CHROME":
				System.out.println("---------------chrome driver initialized ---------- OS : "
						+ System.getProperty("os.name") + "----------");


				try {


					HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
					chromePrefs.put("profile.default_content_settings.popups", 0);
					chromePrefs.put("profile.default_content_setting_values.notifications", 2);
					chromePrefs.put("profile.default_content_setting_values.automatic_downloads", 1);

					//					chromePrefs.put("download.default_directory", downloadFilepath);
					ChromeOptions options = new ChromeOptions();
					options.setExperimentalOption("prefs", chromePrefs);
					options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"}); 
					options.addArguments("--start-maximized");
					options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
					options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
					options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
					options.addArguments("window-size=1600,1200");
					options.addArguments("headless");
					options.addArguments("disable-gpu"); 
					options.addArguments("no-sandbox");
					capability = new DesiredCapabilities();
					capability.setCapability("idleTimeout", 300);
					capability.setCapability("name", testName);
					options.merge(capability);
					if (ZycusConfig.getExecutionLocation().equalsIgnoreCase("Remote")) {
						String hubIP = ZycusConfig.getHubIP();

						System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
						remoteDriver = new RemoteWebDriver(new URL("http://"+hubIP+"/wd/hub"), options);
						remoteDriver.setFileDetector(new LocalFileDetector());
						driver = remoteDriver;
					} else{
						System.setProperty("webdriver.chrome.driver", ZycusCoreConstents.WIN_CHROME_DRIVER_PATH);
						driver = new ChromeDriver(options);
					}
				} catch (Exception x) {
					x.printStackTrace();
					System.out.print("Encountered fatal error due to exception " + x.getStackTrace());
					System.exit(1);
				}
				break; 
			case "FIREFOX":
				System.out.println("---------------firefox driver initialized ---------- OS : "	+ System.getProperty("os.name") + "----------");
				try{	

					//					WebDriverManager.firefoxdriver().setup();
					FirefoxOptions firefoxOptions = new FirefoxOptions();
					firefoxOptions.addPreference("browser.download.folderList", 2); //Use for the default download directory the last folder specified for a download
					firefoxOptions.addPreference("browser.download.useDownloadDir", true);
					firefoxOptions.addPreference("	browser.helperApps.neverAsk.saveToDisk", "application/pdf"); //list of MIME types to save to disk without asking what to use to open the file
					firefoxOptions.addPreference("pdfjs.disabled", true); 
					firefoxOptions.addArguments("window-size=1600,1200");
					firefoxOptions.addArguments("headless");
					firefoxOptions.addArguments("disable-gpu"); 
					firefoxOptions.addArguments("no-sandbox");// disable the built-in PDF viewer
					firefoxOptions.setCapability(FirefoxDriver.MARIONETTE,true);

					DesiredCapabilities capablitiesFirefox = new  DesiredCapabilities();
					firefoxOptions.merge(capablitiesFirefox);
					if (ZycusConfig.getExecutionLocation().equalsIgnoreCase("Remote")) {
						String hubIP = ZycusConfig.getHubIP();
						//					firefoxOptions.setBinary("/usr/bin/geckodriver");
						System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
						remoteDriver = new RemoteWebDriver(new URL("http://" + hubIP + "/wd/hub"), firefoxOptions);

						remoteDriver.setFileDetector(new LocalFileDetector());
						System.out.println(remoteDriver);
						driver = remoteDriver;
					} else {
						System.setProperty("webdriver.gecko.driver", ZycusCoreConstents.WIN_GECKO_DRIVER_PATH);
						driver = new FirefoxDriver(firefoxOptions); 
					}
				}catch (Exception x) {
					x.printStackTrace();
					System.out.print("Encountered fatal error due to exception " + x.getMessage());
					System.exit(1);
				}
				break;
			}
		}

		// ********************* Retrieving LogIn Data ***************
		/*String scriptID = ProjectConfig1.getScriptID();
                                loginCredentials = ZycusCoreDBConnect.getLoginCredentials(scriptID);*/

		// ******************* Launch URL **************
		/** Clearing Cookies */
		driver.manage().deleteAllCookies();

		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
		String environment = configurationProperties.getProperty("Environment");
		/*}else
			userAccount = configurationProperties.getProperty("UserAccount");*/
		
		String loginType = configurationProperties.getProperty("LoginType");
		envName = getEnvNameForSSO(environment);

		/** Launch the Application URL */
		try {
			String URL = null;
			if(loginType.equals("SSO")){
				//logger.info("UserAccount to login is "+userAccount);
				token = getToken(userAccount, envName);
				Cookie ck = createCookie("SAAS_COMMON_BASE_TOKEN_ID", token);
				System.out.println("starting browser now");
				
				URL = getEnvURLForSSO(environment);
				driver.get(URL+"/sso/logout"); 
				driver.manage().addCookie(ck);
				System.out.println("Cookie Added into browser");
				driver.get(URL+"/sso/login?SAAS_COMMON_BASE_TOKEN_ID="+token);
				SSOCheck = true;
			}else if(loginType.equals("Direct"))
				URL = getEnvURLForDirectLogin(environment);
				driver.get(URL+"/sso/login");
		} catch (Exception x) {
			try{
				//setValueInConfigFile("LoginWithPwdMgr", "true");
			}catch(Exception e){
				e.printStackTrace();
			}

			driver.get(ZycusCoreConstants.getURL());
			//driver.get(ZycusCoreConstants.getPwdMgrURL());
			if (driver.getTitle().contains("Insecure Connection")) {
				try {
					ZycusCoreUtil objUtil = new ZycusCoreUtil(driver);
					// To click on advanced button
					objUtil.waitForWebElement(ZycusCoreConstents.BASE, By.id("advancedButton")).click();
					ZycusCoreSync.staticWait(ZycusCoreConstents.BaseInMiliSec);
					// To click on Exception button
					objUtil.waitForWebElement(ZycusCoreConstents.BASE, By.id("exceptionDialogButton")).click();
					// firefoxExceptionHandler();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		/** Maximize the Browser Window */
		ZycusCoreSync.staticWait(ZycusCoreConstents.MediumInMiliSec);
		try {
			driver.manage().window().maximize();
		}catch(Exception e) {}
		return driver;
	}

	public void deleteSession(String token) throws ClientProtocolException, IOException, JSONException{
		System.out.println("Token displayed here is "+token);
		String payload = "{" +
				"\"tokenId\": \""+token+"\", " +
				"\"env\": \""+envName+"\", " +
				"\"userId\": \"varun.khurana@zycus.com\", " +
				"\"authToken\": \"YWRtaW5BdXRoQHp5Y3VzLmNvbTojam5LKz1lUTs4JWgu\"" +
				"}";

		StringEntity entity = new StringEntity(payload,	ContentType.APPLICATION_JSON);

		HttpClient httpClient = HttpClientBuilder.create().build();

		String SSOHostedServer = ZycusConfig.getSSOHostedServer(); 

		HttpPost request = new HttpPost("http://"+SSOHostedServer+"/sso/terminate");
		request.setEntity(entity);


		HttpResponse response = httpClient.execute(request);
		System.out.println(response.getStatusLine().getStatusCode());

		HttpEntity entity1 = response.getEntity();
		String responseString = EntityUtils.toString(entity1, "UTF-8");
		System.out.println(responseString);

		// parsing JSON
		JSONObject result = new JSONObject(responseString); //Convert String to JSON Object
		System.out.println("Class session terminated");

	}

	public String getEnvNameForSSO(String environment){
		String envName = null;
		switch(environment){
		case "Production":
			envName = "prod";
			break;
		case "AWS Australia Production":
			envName = "ausprod";
			break;
		case "AWS Singapore":
			envName = "awssingapore";
			break;
		case "AWS UK":
			envName = "awsprod";
			break;
		case "Staging":
			envName = "staging";
			break;
		case "AWS Australia Staging":
			envName = "ausuat";
			break;
		case "RM":
			envName = "rmpartner";
			break;
		case "DevInt":
			envName = "devint";
			break;
		case "Partner":
			envName = "partner";
			break;

		}
		return envName;
	}


	public String getEnvURLForSSO(String environment){
		String URL = null;
		switch(environment){
		case "Production":
			URL = "https://login.zycus.com";
			break;
		case "AWS Australia Production":
			URL = "https://login-au.zycus.com";
			break;
		case "AWS Singapore":
			URL = "https://login-sg.zycus.com";
			break;
		case "AWS UK":
			URL = "https://login1.zycus.com";
			break;
		case "Staging":
			URL = "https://login-staging.zycus.com"; 
			break;
		case "AWS Australia Staging":
			URL = "https://login-ausyut.zycus.com";              
			break;
		case "RM":
			URL = "https://login-rp.zycus.com";
			break;
		case "DevInt":
			URL = "https://login-devint.zycus.com";
			break;
		case "Partner":
			URL = "https://login-partner.zycus.com";
			break;
		}
		return URL;
	}
	
	public String getEnvURLForDirectLogin(String environment){
		String URL = null;
		switch(environment){
		case "Production":
			URL = "https://login.zycus.com";
			break;
		case "AWS Australia Production":
			URL = "https://login-au.zycus.com";
			break;
		case "AWS Singapore":
			URL = "https://login-sg.zycus.com";
			break;
		case "AWS UK":
			URL = "https://login1.zycus.com";
			break;
		case "Staging":
			URL = "https://login-staging.zycus.com"; 
			break;
		case "AWS Australia Staging":
			URL = "https://login-ausyut.zycus.com";              
			break;
		case "RM":
			URL = "https://login-rp.zycus.com";
			break;
		case "DevInt":
			URL = "";
			break;
		case "Partner":
			URL = "https://login-partner.zycus.com";
			break;
		}
		return URL;
	}


	public String getToken(String userAccount, String envName) throws ClientProtocolException, IOException, JSONException{

		String payload = "{" +
				"\"loginId\": \""+userAccount+"\", " +
				"\"env\": \""+envName+"\", " +
				"\"userId\": \"varun.khurana@zycus.com\", " +
				"\"authToken\": \"YWRtaW5BdXRoQHp5Y3VzLmNvbTojam5LKz1lUTs4JWgu\"" +
				"}";

		StringEntity entity = new StringEntity(payload,
				ContentType.APPLICATION_JSON);

		HttpClient httpClient = HttpClientBuilder.create().build();
		String SSOHostedServer = ZycusConfig.getSSOHostedServer();
		HttpPost request = new HttpPost("http://"+SSOHostedServer+"/sso/passwordLessAccess");
		request.setEntity(entity);

		HttpResponse response = httpClient.execute(request);
		System.out.println(response.getStatusLine().getStatusCode());

		HttpEntity entity1 = response.getEntity();
		String responseString = EntityUtils.toString(entity1, "UTF-8");
		System.out.println(responseString);

		// parsing JSON
		JSONObject result = new JSONObject(responseString); //Convert String to JSON Object
		String token = (String) result.get("tokenId");
		return token;
	}

	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public static Cookie createCookie(String cookieName, String cookieValue) {

		Cookie cookie = new Cookie.Builder(cookieName, cookieValue)
				.domain(".zycus.com")
				.path("/")
				.build();

		//driver.manage().addCookie(cookie);
		return cookie;

	}

	public static void setLoginCredentials(){
		// ********************* Retrieving LogIn Data ***************
		String scriptID = ProjectConfig1.getScriptID();
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		loginCredentials = objConnect.getLoginCredentials(scriptID);
	}

	public static void closeAllBrowserProcesses() {
		try {
			if (ZycusConfig.getExecutionLocation().equalsIgnoreCase("Remote")) {
				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe *32");
				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe *32");
				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe *32");
				Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
				Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe *32");
				Runtime.getRuntime().exec("taskkill /F /IM Firefox.exe");
				Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
				Runtime.getRuntime().exec("taskkill /F /IM plugin-container.exe");
				Runtime.getRuntime().exec("taskkill /F /IM WerFault.exe");
				Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public ExtentTest getLogger() {
		return logger;
	}

	public String getDisplayStyle() throws Exception{
		String displayStyle = null;
		ZycusConfig ocfg = new ZycusConfig();
		//try{
		Login objLogin = new Login(driver, loginCredentials.get("Username"), loginCredentials.get("Password"), ocfg.getCustomer(), ocfg.getUserAccount());
		displayStyle = objLogin.login_v1(ocfg);
		/*}catch(Exception e){
                                                e.printStackTrace();
                                }*/
		return displayStyle;
	}

	public String getDisplayStyle(WebDriver driver) throws Exception{
		String displayStyle = null;
		ZycusConfig ocfg = new ZycusConfig();
		//try{
		Login objLogin = new Login(driver, loginCredentials.get("Username"), loginCredentials.get("Password"), ocfg.getCustomer(), ocfg.getUserAccount());
		displayStyle = objLogin.login_v1(ocfg);
		/*}catch(Exception e){
                                                e.printStackTrace();
                                }*/
		return displayStyle;
	}

	public String getDisplayStyle(WebDriver driver, ExtentTest logger ,HashMap<String, String> loginCredentials) throws Exception {
		String displayStyle = null;
		ZycusConfig ocfg = new ZycusConfig();
		//try{
		Login objLogin = new Login(driver,logger, loginCredentials.get("Username"), loginCredentials.get("Password"), ocfg.getCustomer(), ocfg.getUserAccount());
		displayStyle = objLogin.login_v1(ocfg);
		/*}catch(Exception e){
                                                e.printStackTrace();
                                }*/
		return displayStyle;
	}

	public String getDisplayStyle(WebDriver driver, ExtentTest logger ,HashMap<String, String> loginCredentials,String userAccount) throws Exception {
		String displayStyle = null;
		ZycusConfig ocfg = new ZycusConfig();
		//try{
		Login objLogin = new Login(driver,logger, loginCredentials.get("Username"), loginCredentials.get("Password"), ocfg.getCustomer(), userAccount);
		displayStyle = objLogin.login_v1(ocfg);
		/*}catch(Exception e){
                                    e.printStackTrace();
                    }*/
		return displayStyle;
	}
	
	public String getDisplayStyle(WebDriver driver, ExtentTest logger , String userAccount) throws Exception {
		String displayStyle = null;
		ZycusConfig ocfg = new ZycusConfig();
		//try{
		Login objLogin = new Login(driver,logger, "", "", ocfg.getCustomer(), userAccount);
		displayStyle = objLogin.login_v1(ocfg);
		/*}catch(Exception e){
                                    e.printStackTrace();
                    }*/
		return displayStyle;
	}
}
