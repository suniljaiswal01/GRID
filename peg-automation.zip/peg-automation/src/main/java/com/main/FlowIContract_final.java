package com.main;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
//import com.main.iSource.CommonTests1;
import com.zycus.IContract.Dashboard.CommonDashboard;
import com.zycus.IContract.ManageContracts.AuthorContract;
import com.zycus.IContract.ManageContracts.ContractOutline;
import com.zycus.IContract.ManageContracts.ContractSummary;
import com.zycus.IContract.ManageContracts.ContractingParty;
import com.zycus.IContract.ManageContracts.ContractsPendingReview;
import com.zycus.IContract.ManageContracts.CreateContract;
import com.zycus.IContract.ManageContracts.Documents;
import com.zycus.IContract.ManageContracts.LineItems;
import com.zycus.IContract.ManageContracts.Milestone;
import com.zycus.IContract.ManageContracts.Repository;
import com.zycus.IContract.ManageContracts.Timeline;
import com.zycus.IContract.Performance.SpendByContractingParty;
import com.zycus.IContract.Performance.SpendByContracts;
import com.zycus.IContract.Reports.ReportDetail;
import com.zycus.IContract.Reports.Reports;
import com.zycus.IContract.Search.ContractSearch;
import com.zycus.IContract.Setup.ProductConfig.ProdConfig;
import com.zycus.ZSN.MyContracts.ViewContracts;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.eInvoice_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
//import Framework.NavigationClass;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;;

public class FlowIContract_final extends CommonTests1{

	boolean byPassAuthorStage = false;
	boolean commonWorkFlowEnabled = false;
	boolean isTouchFreeContract = false;
	
	boolean isNegotiating = false; 
	
	public FlowIContract_final() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");	
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	private String Product = "iContract";
	eInvoice_CommonFunctions objFunctions;
	private String contractNumber;
	private String contractType = "Procurement";
	private String contractSubType ="Purchase Agreement";
	
	@Test(dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login",alwaysRun = true, priority =1)
	@TestDetails(TestID="iContract_1")
	public void Login(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		ZycusCoreDriver objZCD = new ZycusCoreDriver(); 
		displayStyle = objZCD.getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = "Login", priority =2)
	@TestDetails(TestID="iContract_15")
	public void verifyprodSettings() throws Exception {
		ProdConfig objProdConfig = new ProdConfig(driver, logger);
		objProdConfig.navigateToApplicationSettings();
		isTouchFreeContract = objProdConfig.verifyIfTouchFree(contractType, contractSubType);
		System.out.println("Is touch free contract "+isTouchFreeContract);
		byPassAuthorStage = objProdConfig.verifyByPassAuthWorkflow();
		System.out.println("By Pass Auth Workflow "+byPassAuthorStage);
	}
	
	
	
	/*@Test(dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login", 
			priority = 1, 
			alwaysRun = true)
	public void Login(String Username, String Password, String Customer, String userAccount, String environment) throws Exception {
		this.Username = Username;
		this.Password = Password;
		this.Customer = Customer;
		this.userAccount = userAccount;
		Login objLogin = new Login(driver, logger, Username, Password, Customer, userAccount);
		this.displayStyle = objLogin.Login_via_PwdMgr1(configurationProperties);
		callAndLog(displayStyle.equals(null)?false:true, "login successful and Product Selected", "Not logged in or Product Not selected");
	}*/
	
	/*@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "", 
			priority = 1)
	public void flashTest() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Setup","Product Configuration");
		try{
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.testFlash();
		}catch(Exception e){
			
		}
	}
	*/
	
	/*@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "CreateContract", 
			priority = 2)*/
	
	@Test(dependsOnMethods = "Login", 
			priority = 3)
	@TestDetails(TestID="iContract_2")
	//public void AuthorContract_Negotiate(String internalReviewerEmail, String authoringUserEmail, String supplierEmail, String supplierPassword, boolean isSignoffWorkflowActive, boolean sendForInternalReview) throws Exception {
	public void AuthorContract_Negotiate() throws Exception {
		String contractTitle = null;
		boolean isSignoffWorkflowActive = false;
		boolean sendForInternalReview = true;
		String internalReviewerEmail = "admin.zcs@zycus.com";
		String authoringUserEmail = "GDQA-P2P@zycus.com";
		String supplierEmail = "hinal.shah@zycus.com";
		String supplierPassword = "Right@123";
		try{
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.createContract();
		
		//Verify Yellow btn- Draft in Progress

		CreateContract objContract = new CreateContract(driver, logger);
		//ContractDetails objDetails = new ContractDetails(driver, logger);
		
		//Contract Details
		//objDetails.enterContractDetails();
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		contractTitle = objSummary.getContractTitle();
		contractNumber = objSummary.getContractNum();
		
		System.out.println("Contract Number created here is :"+ contractNumber);
		/**************************Done**********************/
		
		//Close Contract
		//Check row created with status as 'Draft in Progress'
		//Click on Author Stage - should navigate to Contracting Party page
		objContract.closeContract();
		objAuthor.verifyContractStatusinGrid(contractNumber);
		objAuthor.navigateToStage(contractNumber, "Author");
		/************************************************/
		
		//Contracting Party
		ContractingParty objContParty = new ContractingParty(driver, logger);
		objContract.navigate_ContractSubTabs("Contracting Party");
		if(objContParty.addContractingParties()){
			
			/**************************Done**********************/
			//Check in Contract Summary if Contracting party added
			
			/**********************************************/
			
			//Contract Outline
			objContract.navigate_ContractSubTabs("Contract Outline");
			ContractOutline objOutline = new ContractOutline(driver, logger);
			objOutline.createVersion();
			
			
			//Line Items
			objContract.navigate_ContractSubTabs("Line Items");
			LineItems objItems = new LineItems(driver, logger);
			objItems.createLineItem();
			
			
			//Documents
			//boolean isDocUploaded = false;
			
			//Commenting as it has issues uploading
			objContract.navigate_ContractSubTabs("Documents");
			Documents objDoc = new Documents(driver, logger);
			//provide no of documents to upload 
			objDoc.selectDocuments(2);
			
			
			/*if(objContract.navigate_ContractSubTabs("Documents")){
				Documents objDoc = new Documents(driver, logger);
				isDocUploaded = objDoc.selectDocuments();
			}*/
			
			
			//Add Milestones
			objContract.navigate_ContractSubTabs("Milestones");
			Milestone objMilestone = new Milestone(driver, logger);
			objMilestone.addMilestone();
			
			//Timeline
			objContract.navigate_ContractSubTabs("Timeline");
			Timeline objTimeline = new Timeline(driver, logger, contractTitle);
			if(objTimeline.verifyVersionCreated())
				logger.log(Status.PASS, "Version created and Downloaded");
			else
				logger.log(Status.PASS, "Version not created or Downloaded");
			
			//if(isDocUploaded){
			if(objTimeline.verifyDocumentCreated())
				logger.log(Status.PASS, "Document visible in timeline and Downloaded");
			else
				logger.log(Status.PASS, "Document not visible or Downloaded in timeline");
				//}
			
			//If negotaiation is allowed then only Contract can be sent for Internal review
			//Author Review if sent for internal review during Authoring
			if(sendForInternalReview){
				objContract.navigate_ContractSubTabs("Contract Summary");
				objSummary.sendForApproval();
				objContract.navigate_ContractSubTabs("Author Review");
				objSummary.authorReview();
				
				objFunctions.closeBrowser();
				
				Login objLogin = new Login(driver, logger);
				//objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
				objLogin.loginWithUserAcct_PwdMgr(internalReviewerEmail);
				objFunctions.switchToWindow("Rainbow Home");
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
				ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
				objReview.approveContract("Authoring Stage", contractNumber, "Approve");
				objFunctions.closeBrowser();
				
			}
			
			//Contract Summary
			objContract.navigate_ContractSubTabs("Contract Summary");
			
			objSummary.proceedToSignOff(isSignoffWorkflowActive);
			if(isSignoffWorkflowActive){
				objFunctions.closeBrowser();
				
				Login objLogin = new Login(driver, logger);
				//objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
				objLogin.loginWithUserAcct_PwdMgr(internalReviewerEmail);
				objFunctions.switchToWindow("Rainbow Home");
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
				ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
				objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
				objFunctions.closeBrowser();
				
				//objLogin.loginWithUserAcct_PwdMgr("GDQA-P2P@zycus.com");
				objLogin.loginWithUserAcct_PwdMgr(authoringUserEmail);
				objFunctions.switchToWindow("Rainbow Home");
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
				objAuthor.clrAllFilters();
				Thread.sleep(2000);
				objAuthor.filterByContractNum(contractNumber);
				objAuthor.navigateToStage(contractNumber, "Sign off");
			}
			
			
			objSummary.sendForSigning(isSignoffWorkflowActive, "Offline Signing");

			
			//Download Contract in ZSN
			this.driver1 = objFrameworkUtility.getWebDriverInstance(
					System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
			Login objLogin = null;
			/*if(configurationProperties.getProperty("environment").equals("Production"))
				objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
			else if(configurationProperties.getProperty("environment").equals("RM"))
				objLogin = new Login(driver1, logger, "gauri.joshi@zycus.com", "Right@123");*/
			objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
			
			callAndLog(driver1,logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
			ViewContracts objViewContracts = new ViewContracts(driver1, logger);
			boolean isFileDownloaded = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
			
			//Upload Downloaded Contract to 
			if(isFileDownloaded){
				driver1.quit();
				try{
					objSummary.uploadContract(contractTitle);
				}catch(Exception e){
					Documents objDoc1 = new Documents(driver, logger);
					objDoc1.addDocument_ForEnd(contractTitle);
				}
			}
			
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "", 
			priority = 3)
	@TestDetails(TestID="iContract_3")
	public void addReportToExistingDashboard(String dashboardFolder, String existingDashboardName, String reportName, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Reports");
		Reports objReports = new Reports(driver, logger);
		try{
			objReports.addReportToExistingDashboard(reportName, dashboardFolder, existingDashboardName);
			objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard", "Common Dashboard");
			CommonDashboard objDashboard = new CommonDashboard(driver, logger);
			if(objDashboard.verifyReportExistInDashboard(existingDashboardName, reportName))
				logger.log(Status.PASS, reportName +" added to Dashboard "+ existingDashboardName);
		}catch(Exception e){
			e.printStackTrace();
			logger.log(Status.FAIL, reportName +" added to Dashboard "+ existingDashboardName);
		}
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "", 
			priority = 4)
	@TestDetails(TestID="iContract_4")
	public void addReportToNewDashboard(String dashboardFolder, String layout, String reportName, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Reports");
		Reports objReports = new Reports(driver, logger);
		try{
			String newDashboardName = objReports.addReportToNewDashboard(reportName, dashboardFolder, layout);
			objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard", "Common Dashboard");
			CommonDashboard objDashboard = new CommonDashboard(driver, logger);
			if(objDashboard.verifyReportExistInDashboard(newDashboardName, reportName))
				logger.log(Status.PASS, reportName +" added to Dashboard "+ newDashboardName);
		}catch(Exception e){
			e.printStackTrace();
			logger.log(Status.FAIL, reportName +" added to New Dashboard");
		}
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "", 
			priority = 5)
	@TestDetails(TestID="iContract_5")
	public void LinkContractToMaster(String masterContractNum, String contractNumToLink, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts","Repository");
		Repository objRepo = new Repository(driver, logger);
		objRepo.linkMasterToContract(masterContractNum, contractNumToLink);
	}
	
	
	@Test(description = "",
			dependsOnMethods = "Login",
			priority = 6)
	@TestDetails(TestID="iContract_6")
	public void EditContract_AuthoringStage() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.filterByStage("Author");
		objAuthor.filterByStatus("Draft in Progress");
		objAuthor.viewIContractCreatedContract();
	}
	
	@Test(description = "",
			dependsOnMethods = "Login",
			priority = 7)
	@TestDetails(TestID="iContract_7")
	public void CheckAuditTrailForDocs() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.filterByStage("Author");
		objAuthor.filterByStatus("Draft in Progress");
		objAuthor.viewIContractCreatedContract();
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Documents");
		Documents objDocs = new Documents(driver, logger);
		objDocs.selectDocuments(2);
		objDocs.deleteDocument();
		objContract.navigate_ContractSubTabs("Timeline");
	}
	
	
		
	/*@Test(description = "",
			dependsOnMethods = "Login",
			priority = 8)
	public void AuthorContract() throws Exception {
		String contractTitle = null;
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		CreateContract objContract = new CreateContract(driver, logger);
		objAuthor.createContract(objContract);
		ContractDetails objDetails = new ContractDetails(driver, logger);
		
		//Contract Details
		objDetails.enterContractDetails();
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		contractTitle = objSummary.getContractTitle();
		contractNumber = objSummary.getContractNum();
		
		//Contracting Party
		ContractingParty objContParty = new ContractingParty(driver, logger);
		objContract.navigate_ContractSubTabs("Contracting Party");
		if(objContParty.addContractingParties()){
			
			//Contract Outline
			if(objContract.navigate_ContractSubTabs("Contract Outline")){
				ContractOutline objOutline = new ContractOutline(driver, logger);
				objOutline.createVersion();
			}
			
			//Line Items
			if(objContract.navigate_ContractSubTabs("Line Items")){
				LineItems objItems = new LineItems(driver, logger);
				objItems.createLineItem();
			}
			
			//Documents
			Boolean isDocUploaded = false;
			if(objContract.navigate_ContractSubTabs("Documents")){
				Documents objDoc = new Documents(driver, logger);
				isDocUploaded = objDoc.selectDocuments();
			}
			
			//Timeline
			if(objContract.navigate_ContractSubTabs("Timeline")){
				Timeline objTimeline = new Timeline(driver, logger, contractTitle);
				if(objTimeline.verifyVersionCreated())
					logger.log(Status.PASS, "Version created and Downloaded");
				else
					logger.log(Status.PASS, "Version not created or Downloaded");
				
				if(isDocUploaded){
					if(objTimeline.verifyDocumentCreated())
						logger.log(Status.PASS, "Document visible in timeline and Downloaded");
					else
						logger.log(Status.PASS, "Document not visible or Downloaded in timeline");
				}
			}
			
			//Contract Summary
			if(objContract.navigate_ContractSubTabs("Contract Summary")){
				objSummary.proceedToSignOff("Offline Signing");
			}
			
			//Download Contract in ZSN
			this.driver1 = objFrameworkUtility.getWebDriverInstance(
					System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
			Login objLogin = null;
			if(configurationProperties.getProperty("environment").equals("Production"))
				objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
			else if(configurationProperties.getProperty("environment").equals("Production"))
				objLogin = new Login(driver1, logger, "gauri.joshi@zycus.com", "Right@123");
			
			callAndLog(driver1,objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
			ViewContracts objViewContracts = new ViewContracts(driver1, logger);
			boolean isFileDownloaded = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
			
			//Upload Downloaded Contract to 
			if(isFileDownloaded){
				driver1.quit();
				objSummary.uploadContract(contractTitle);
			}
			Actions actions = new Actions(driver);
			actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
			//driver.switchTo().window("Authoring Contract");
			objSummary.closeContract(objAuthor);
			objAuthor.filterByContractNum(contractNumber);
			objAuthor.viewContract(contractNumber, objSummary);
			Signers objSigners = new Signers(driver, logger);
			objSummary.proceedToSignOff("Offline Signing", objSigners);
			callAndLog(objViewContracts.performAction(contractNumber,"Download"), "able to perform action on Contract", "unable to perform action on Contract");
			
			
		}*/
		
		
		/*ContractSummary objSummary = new ContractSummary(driver, logger);
		this.setContractNumber(objSummary.getContractNum());
		objSummary.sendForNegotiation("negotiationComment");
		objSummary.sendToContractingParty();
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		//Login objLogin = new Login(driver1, logger, "suresh.jambhalkar@zycus.com", "Pass@1234");
		Login objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
		callAndLog(objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "IGT");
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		callAndLog(objViewContracts.performAction(contractNumber,"Mark as Reviewed"), "able to perform action on Contract", "unable to perform action on Contract");
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
		//driver.switchTo().window("Authoring Contract");
		objSummary.closeContract(objAuthor);
		objAuthor.filterByContractNum(contractNumber);
		objAuthor.viewContract(contractNumber, objSummary);
		Signers objSigners = new Signers(driver, logger);
		objSummary.proceedToSignOff("Offline Signing", objSigners);
		callAndLog(objViewContracts.performAction(contractNumber,"Download"), "able to perform action on Contract", "unable to perform action on Contract");*/
	//}
	
	
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SearchContract", 
			priority = 8, description = "",dependsOnMethods = "Login")
	@TestDetails(TestID="iContract_8")
	public void Contract_Search(String contractType, String contractCategory, String searchValue, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		ContractSearch objSearch  = new ContractSearch(driver, logger);
		if(objSearch.searchContract(contractType, contractCategory, searchValue))
			logger.log(Status.PASS, "Contract : "+searchValue+" searched successfully");
		else
			logger.log(Status.FAIL, "unable to search Contract : "+searchValue);
		}
	
	/*@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "CommonDashboard", 
			priority = 1, description = "",dependsOnMethods = "Login")
	public void CommonDashboard(String contractType, String contractCategory, String searchValue, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		CommonDashboard objDashboard  = new CommonDashboard(driver, logger);
		objDashboard.saveNewDashboardToMyDashboard(dashboardLayout, prePackagedReports);*/
	
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "Repository", description = "",
			dependsOnMethods = "Login",
			priority = 9)
	@TestDetails(TestID="iContract_9")
	public void Repository(String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		Repository objRepo = new Repository(driver, logger); 
		objRepo.uploadContract();
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "Login",
			priority = 10)
	@TestDetails(TestID="iContract_10")
	public void SpendByContractingParty(String searchBy, String searchValue,String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		SpendByContractingParty objParty = new SpendByContractingParty(driver, logger); 
		objParty.searchContracts(searchBy, searchValue);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContracts", description = "",
			dependsOnMethods = "Login",
			priority = 11)
	@TestDetails(TestID="iContract_11")
	public void SpendByContracts(String searchBy, String searchValue, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		SpendByContracts objContracts = new SpendByContracts(driver, logger); 
		objContracts.searchContracts(searchBy, searchValue);
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "MyReports", 
			priority = 12)
	@TestDetails(TestID="iContract_12")
	public void shareMyReports(String myReportsName, String sharedUserEmail, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		Reports objReports = new Reports(driver, logger);
		if(objReports.selectMyReports(myReportsName))
			logger.log(Status.INFO, "My Report searched & viewed successfully");
		ReportDetail objRepDetail = new ReportDetail(driver, logger);
		if(objRepDetail.shareMyReports(myReportsName, sharedUserEmail));
			logger.log(Status.INFO, "My Report shared successfully");
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "Login", 
			dataProvider = "Reports", 
			priority = 13)
	@TestDetails(TestID="iContract_13")
	public void Reports(String reportType, String reportName, String...navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, navigationTabs);
		Reports objReports = new Reports(driver, logger);
		if(objReports.searchReport(reportType, reportName)){
			logger.log(Status.INFO, "Report searched successfully");
			if(objReports.viewReportDetails(reportName)){
				logger.log(Status.INFO, "Report viewed successfully");
				ReportDetail objRepDetail = new ReportDetail(driver, logger);
				objRepDetail.closeReportDetails();
			}
		}
	}
	
	
	/*
	@Test(description = "",
			dependsOnMethods = "Login",
			priority = 3)
	public void AuthorContract() throws Exception {
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		objFunctions.navigateToMainPage(displayStyle, "Manage Contracts", "Author Contract");
		//objFunctions.navigate_Rainbowpath("Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		CreateContract objContract = new CreateContract(driver, logger);
		objAuthor.createContract(objContract);
		//For IGT
		//objContract.startAuthoring("Procurement", "Direct Material", false,false);
		// For CDK
		//objContract.startAuthoring("Procurement", "Master Business Agreement", true, false);
		//For Mass Mutual - Staging
		//objContract.startAuthoring("Master Agreement", "Hosted Agreement", false, false);
		//For Securian - Staging
		//objContract.startAuthoring("Procurement Agreements", "Services Agreement", true, false);
		//For Lowes - Staging
		//objContract.startAuthoring("Indirect", "Facilities Management", true, false);
		//For Frontier Communications - Staging
		//objContract.startAuthoring("Procurement", "Master Agreement", true, true); //Currently no templates present
		//For AXA Equitable Life Insurance - Staging
		//objContract.startAuthoring("Master", "US MPSA", false, true);
		//For ZCS - GDQA-P2P - Production - Navisite
		//objContract.startAuthoring("Procurement", "Purchase Agreement", true,false);
		//For Sanity6 - Bruce - AWS Prod - UK
		ContractDetails objDetails = new ContractDetails(driver, logger);
		objContract.startAuthoring("Procurement", "Purchase Agreement", false,true, objDetails);
		ContractingParty objContParty = new ContractingParty(driver, logger);
		objDetails.enterContractDetails(objContParty);
		//ContractingParty objContParty = new ContractingParty(driver, logger);
		/*objContParty.addContractingParty("TEST IGT", "Suresh Jambhalkar");
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		this.setContractNumber(objSummary.getContractNum());
		objSummary.sendForNegotiation("negotiationComment");
		objSummary.sendToContractingParty();
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		Login objLogin = new Login(driver1, logger, "suresh.jambhalkar@zycus.com", "Pass@1234");
		callAndLog(objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "IGT");
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		callAndLog(objViewContracts.performAction(contractNumber,"Mark as Reviewed"), "able to perform action on Contract", "unable to perform action on Contract");
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
		//driver.switchTo().window("Authoring Contract");
		objSummary.closeContract(objAuthor);
		objAuthor.filterByContractNum(contractNumber);
		objAuthor.viewContract(contractNumber, objSummary);
		Signers objSigners = new Signers(driver, logger);
		objSummary.proceedToSignOff("Offline Signing", objSigners);
		callAndLog(objViewContracts.performAction(contractNumber,"Download"), "able to perform action on Contract", "unable to perform action on Contract");
	}*/
	
	/*@Test(description = "",
			dependsOnMethods = "Login",
			priority = 3)
	public void AuthorContract() throws Exception {
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		objFunctions.navigateToMainPage(displayStyle, "Manage Contracts", "Author Contract");
		}*/
	
	/*@Test(description = "",
			dependsOnMethods = "AuthorContract",
			priority=3)
	public void AddContractingParty() throws Exception {
		ContractingParty objContParty = new ContractingParty(driver, logger);
		//For IGT & CDK in Partner
		//objContParty.addContractingParty("TEST IGT", "Suresh Jambhalkar");
		//For AXA in Staging
		objContParty.addContractingParty("USER TESTING, INC.", "Hinal Shah");
	}
	
	@Test(description = "",
			dependsOnMethods = "AddContractingParty",
			priority=3)
	public void SendToContractingPartyForNegotiation() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		this.setContractNumber(objSummary.getContractNum());
		objSummary.sendForNegotiation("negotiationComment");
		objSummary.sendToContractingParty();
	}
	
	@Test(description = "",
			dependsOnMethods = "SendToContractingPartyForNegotiation",
			priority=3)
	public void ContractingPartMarkingReviewed() throws Exception {
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		Login objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Mansi@123");
		callAndLog(objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "AXA Equitable Life Insurance Company");
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		callAndLog(objViewContracts.performAction(contractNumber,"Mark as Reviewed"), "able to perform action on Contract", "unable to perform action on Contract");
		
	}
	
	@Test(description = "",
			dependsOnMethods = "ContractingPartMarkingReviewed",
			priority=3)
	public void SendingContractForSignoff() throws Exception {
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		ContractSummary objSummary = new ContractSummary(driver, logger);
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
		//driver.switchTo().window("Authoring Contract");
		objSummary.closeContract(objAuthor);
		objAuthor.filterByContractNum(contractNumber);
		objAuthor.viewContract(contractNumber, objSummary);
		Signers objSigners = new Signers(driver, logger);
		objSummary.proceedToSignOff("Offline Signing", objSigners);
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		callAndLog(objViewContracts.performAction(contractNumber,"Download"), "able to perform action on Contract", "unable to perform action on Contract");
	}*/
	
	/*@AfterMethod
	public void getResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			logger.log(Status.FAIL, "Test Case Failed is " + result.getName());
			logger.log(Status.FAIL, "Test Case Failed is " + result.getThrowable());
		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(Status.SKIP, "Test Case Skipped is " + result.getName());
		}
	}*/

	/**
	 * call and log
	 * 
	 * @throws Exception
	 *//*
	public void callAndLog(boolean condition, String passMsg, String failMsg) throws Exception {
		String msg = condition ? passMsg : failMsg;
		if (condition)
			logger.log(Status.PASS, msg);
		else {
			String screenshotPath = objFunctions.getScreenhot(driver, "screenshot_error");
			logger.log(Status.FAIL, msg + logger.addScreenCaptureFromPath(screenshotPath));
		}
	}*/

}
