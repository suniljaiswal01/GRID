package com.main;


import org.apache.commons.lang.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ZycusCoreSync{

	
	public static boolean waitTillVisible(WebDriver driver, By byLocator, int intTimeOutInSeconds){
		try{
			new WebDriverWait(driver, intTimeOutInSeconds).until(ExpectedConditions.visibilityOfElementLocated(byLocator));
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public static boolean waitTillInVisible(WebDriver driver, By byLocator, int intTimeOutInSeconds){
		try{
			new WebDriverWait(driver, intTimeOutInSeconds).until(ExpectedConditions.invisibilityOfElementLocated(byLocator));
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public static boolean waitTillAttributeContains(WebDriver driver, By byLocator, String strAttribute, String strValue, int intTimeOutInSeconds){
		try{
			new WebDriverWait(driver, intTimeOutInSeconds).until(ExpectedConditions.attributeContains(byLocator, strAttribute, strValue));
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public static void staticWait( int intTimeOutInMilliSeconds){
		try{
			Thread.sleep(intTimeOutInMilliSeconds);
		}catch(Exception e){
			
		}
	}
	
	public static WebElement waitForWebElements(WebDriver driver, int intMaxTimeInSeconds, By... strLocators) throws Exception {
		try {
			Boolean isElementFound = false;
			By foundLocator = null;
			StopWatch sw = new StopWatch();
			try {
				while (!isElementFound && sw.getTime() < intMaxTimeInSeconds * 1000) {
					for (int i = 0; i < strLocators.length; i++) {
						if (driver.findElements(strLocators[i]).size() > 0) {
							isElementFound = true;
							foundLocator = strLocators[i];
							break;
						}
					}

				}
			} catch (Exception e) {
				throw new Exception();
			}
			if (!isElementFound) {
				throw new Exception();
			}
			return driver.findElement(foundLocator);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static WebElement waitForWebElement(WebDriver driver, String strLocatorType, String strLocator, int intMaxTimeInSeconds) {
		Boolean isElementFound = false;
		By byLocator = null;
		try {
			switch (strLocatorType.toUpperCase()) {
			case "CLASS":
				byLocator = By.className(strLocator);
				break;
			case "XPATH":
				byLocator = By.xpath(strLocator);
				break;
			case "TAGNAME":
				byLocator = By.tagName(strLocator);
				break;
			case "CSS":
				byLocator = By.cssSelector(strLocator);
				break;
			case "ID":
				byLocator = By.id(strLocator);
				break;
			case "NAME":
				byLocator = By.name(strLocator);
				break;
			case "LINKTEXT":
				byLocator = By.linkText(strLocator);
				break;
			case "PARTIALLINKTEXT":
				byLocator = By.partialLinkText(strLocator);
				break;
			}
			StopWatch sw = new StopWatch();
			sw.start();
			mywhile: while (!isElementFound && sw.getTime() < intMaxTimeInSeconds * 1000) {
				if (driver.findElements(byLocator).size() > 0) {
					isElementFound = true;
					Thread.sleep(1000);
					break mywhile;
				}
			}
			return driver.findElement(byLocator);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
