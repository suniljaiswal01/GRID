package com.main;

import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

import Framework.ConfigurationProperties;
import Framework.ExcelUtils;

public class ZycusCoreDBConnect {
	ExcelUtils objUtil = new ExcelUtils();
	//public static HashMap<String, String> getLoginCredentials(String scriptID){




	public HashMap<String, String> getLoginCredentials(String scriptID){
		/** 
		 * Create the HashMap to store the Username and Password
		 * Example: Key will be "Username" and Value will be "test.account"
		 * Key will be "Password" and Value will be "P@ssw0rd"
		 */
		HashMap<String, String> loginDataMap = new HashMap<String, String>();

		//ZycusConfig reference
		ZycusConfig config;

		String sheetName = null;

		try {
			//Fetch the Firm & Environment details from Config file 
			config = new ZycusConfig();
			config.getSetup();
			config.getEnvironment();

			ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
			try{
				//if(config.isLoginWithPwdMgr())
				ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
				if(configurationProperties.getProperty("LoginType").equals("Direct"))
					sheetName = zycusCoreConstants.DirectLoginCredentialsSheetName;
				else
					sheetName = zycusCoreConstants.PwdMgrCredentialsSheetName;

//				String loginTestDataID = getLoginTestDataID(scriptID);
				
				//				System.out.println("Login Test Data ID :"+ loginTestDataID);
				//ExcelUtils.setExcelFile(zycusCoreConstants.CredentialsDatasheetPath, sheetName);
				objUtil.setExcelFile(zycusCoreConstants.CredentialsDatasheetPath, sheetName);
				//Header Row
				Row headerRow = objUtil.ExcelWSheet.getRow(0);
				int headersCount = headerRow.getLastCellNum(); 

				//Credentials Row
				List<Integer> RowList;
				if(configurationProperties.getProperty("LoginType").equals("Direct"))
					RowList = objUtil.getRowContains(configurationProperties.getProperty("Environment"), 0);
				else{
					//String loginTestDataID = getLoginTestDataID(scriptID);
					RowList = objUtil.getRowContains(scriptID, 0);
				}
				Row dataRow = objUtil.ExcelWSheet.getRow(RowList.get(0));
				
				
				
				/*List<Integer> RowList = objUtil.getRowContains(loginTestDataID, 0);
				Row dataRow = objUtil.ExcelWSheet.getRow(RowList.get(0));*/

				
				
				
				
				
				dataRow.getLastCellNum(); 
				DataFormatter formatter = new DataFormatter();
				for(int i=0;i<headersCount;i++){
					//for(int j=1;j<=dataCount;j++){
					//loginDataMap.put(headerRow.getCell(i).getStringCellValue(), dataRow.getCell(i).getStringCellValue());

					loginDataMap.put(formatter.formatCellValue(headerRow.getCell(i)), formatter.formatCellValue(dataRow.getCell(i)));
					//break;
					//}
				}
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Failed To Fetch LogIn Data");
			}

			//Return login data 
			return loginDataMap;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return loginDataMap;
		}
	}
	
	


	public HashMap<String, String> getLoginCredentials(){
		/** 
		 * Create the HashMap to store the Username and Password
		 * Example: Key will be "Username" and Value will be "test.account"
		 * Key will be "Password" and Value will be "P@ssw0rd"
		 */
		HashMap<String, String> loginDataMap = new HashMap<String, String>();

		//ZycusConfig reference
		ZycusConfig config;

		String sheetName = null;

		try {
			//Fetch the Firm & Environment details from Config file 
			config = new ZycusConfig();
			config.getSetup();
			config.getEnvironment();


			ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
			try{
				if(config.isLoginWithPwdMgr())
					sheetName = zycusCoreConstants.PwdMgrCredentialsSheetName;
				else
					sheetName = zycusCoreConstants.PwdMgrCredentialsSheetName;

				//String loginTestDataID = getLoginTestDataID(ProjectConfig1.getScriptID());
				//				String loginTestDataID = getLoginTestDataID(scriptID);
				//				System.out.println("Login Test Data ID :"+ loginTestDataID);
				//ExcelUtils.setExcelFile(zycusCoreConstants.CredentialsDatasheetPath, sheetName);
				objUtil.setExcelFile(zycusCoreConstants.CredentialsDatasheetPath, sheetName);
				//Header Row
				Row headerRow = objUtil.ExcelWSheet.getRow(0);
				int headersCount = headerRow.getLastCellNum(); 

				//Credentials Row
				//				List<Integer> RowList = objUtil.getRowContains(loginTestDataID, 0);
				Row dataRow = objUtil.ExcelWSheet.getRow(1);
				dataRow.getLastCellNum(); 
				DataFormatter formatter = new DataFormatter();
				for(int i=0;i<headersCount;i++){
					//for(int j=1;j<=dataCount;j++){
					//loginDataMap.put(headerRow.getCell(i).getStringCellValue(), dataRow.getCell(i).getStringCellValue());

					loginDataMap.put(formatter.formatCellValue(headerRow.getCell(i)), formatter.formatCellValue(dataRow.getCell(i)));
					//break;
					//}
				}
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Failed To Fetch LogIn Data");
			}

			//Return login data 
			return loginDataMap;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return loginDataMap;
		}
	}


	public String[] getNavigationInfo(String appName, String scriptID,String displayStyle) throws Exception{
		String navigationInfo[] = new String[2];
		String productName = scriptID.split("_", 2)[0];
		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
		if(displayStyle.equals("Rainbow"))
			objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath_Rainbow, productName);
		else if(displayStyle.equals("Classic"))
			objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath_Classic, productName);
		List<Integer> RowList = objUtil.getRowContains(scriptID, 0);
		//        System.out.println("rowlist   --- "+ RowList);
		navigationInfo[0] = objUtil.getCellData(RowList.get(0).intValue(),2);
		//        System.out.println("tab   --- "+ navigationInfo[0]);
		navigationInfo[1] = objUtil.getCellData(RowList.get(0).intValue(),3);
		//        System.out.println("subtab   --- "+ navigationInfo[1]);
		return navigationInfo;

	}


	//private static String getLoginTestDataID(String scriptID) throws Exception{
	public String getLoginTestDataID(String scriptID,String displayStyle) throws Exception{
		String loginTestDataID = null;
		String productName = scriptID.split("_", 2)[0];
		//ExcelUtils.setExcelFile("C:\\Users\\varun.khurana\\newWorkspace\\AnotherSample\\Datasheet\\ProductNavigation.xlsx", productName);
		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();

		if(displayStyle.equals("Rainbow"))
			objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath_Rainbow, productName);
		else if(displayStyle.equals("Classic"))
			objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath_Classic, productName);

		//		objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath, productName);

		List<Integer> RowList = objUtil.getRowContains(scriptID, 0);
		loginTestDataID = objUtil.getCellData(RowList.get(0).intValue(),1);
		return loginTestDataID;
	}

	private String getLoginTestDataID(String scriptID) throws Exception{
		String loginTestDataID = null;
		String productName = scriptID.split("_", 2)[0];
		//ExcelUtils.setExcelFile("C:\\Users\\varun.khurana\\newWorkspace\\AnotherSample\\Datasheet\\ProductNavigation.xlsx", productName);
		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();


		objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath_Rainbow, productName);


		//		objUtil.setExcelFile(zycusCoreConstants.ProdNavigationDatasheetPath, productName);

		List<Integer> RowList = objUtil.getRowContains(scriptID, 0);
		loginTestDataID = objUtil.getCellData(RowList.get(0).intValue(),1);
		return loginTestDataID;
	}


	public String[][] getExecutionParameters(String environment) throws Exception{
		String[][] tabArray = null;
		ExcelUtils objUtil = new ExcelUtils();

		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
		//String sheetName = environment.replace("_", " ");
		String sheetName = environment;
		System.out.println("Sheet Name: "+sheetName);
		//		System.out.println("Params Sheet Path: "+zycusCoreConstants.ExecutionParamsPath); 

		objUtil.setExcelFile(zycusCoreConstants.ExecutionParamsPath, sheetName);
		objUtil.ExcelWSheet.getLastRowNum();
		//		System.out.println(totalRows);
		int totalCols = objUtil.ExcelWSheet.getRow(0).getPhysicalNumberOfCells();
		//		System.out.println(totalCols);
		tabArray = new String[1][totalCols];
		int i = 0;
		for (int j = 0; j < totalCols; j++){
			tabArray[i][j] = objUtil.getCellData(i+1, j);
			//			System.out.println(tabArray[i][j]);
		}
		i++;
		objUtil.close();
//		objUtil.ExcelWBook.close();
		return tabArray;
	}

	public String[][] getKeyForLanguageTranslation(String product,String language) throws Exception{
		String[][] tabArray = null;
		ExcelUtils objUtil = new ExcelUtils();

		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
		//String sheetName = environment.replace("_", " ");

		System.out.println("Language: "+language);
		//		System.out.println("Params Sheet Path: "+zycusCoreConstants.ExecutionParamsPath); 

		objUtil.setExcelFile(zycusCoreConstants.languageTranslation, product);

		int totalRows = objUtil.ExcelWSheet.getLastRowNum();
		int totalCols = objUtil.ExcelWSheet.getRow(0).getPhysicalNumberOfCells();
		tabArray = new String[totalRows][2];

		int ColNumber = getColNumberForHeader(objUtil,language,totalCols);
		int i=0;
		for (int j = 0; j < totalRows; j++){

			tabArray[j][i] = objUtil.getCellData(j+1, 0);
			tabArray[j][i+1] = objUtil.getCellData(j+1, ColNumber);
			//			System.out.println(tabArray[i][j]);
		}
		objUtil.close();
//		objUtil.ExcelWBook.close();
		return tabArray;
	}
	
	
	
	public String[][] getUserName(String sheetName) throws Exception{
		String[][] tabArray = null;
		ExcelUtils objUtil = new ExcelUtils();

		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
		//String sheetName = environment.replace("_", " ");

		//		System.out.println("Params Sheet Path: "+zycusCoreConstants.ExecutionParamsPath); 

		objUtil.setExcelFile(zycusCoreConstants.useraccountPath, sheetName);

		int totalRows = objUtil.ExcelWSheet.getLastRowNum();
		objUtil.ExcelWSheet.getRow(0).getPhysicalNumberOfCells();
		tabArray = new String[totalRows][3];

//		int ColNumber = getColNumberForHeader(objUtil,"User",totalCols);
		int i=0;
		for (int j = 0; j < totalRows; j++){

			tabArray[j][i] = objUtil.getCellData(j+1, 0);
			tabArray[j][i+1] = objUtil.getCellData(j+1, 1);
			tabArray[j][i+2] = objUtil.getCellData(j+1, 2);
			//			System.out.println(tabArray[i][j]);
		}
		objUtil.close();
//		objUtil.ExcelWBook.close();
		return tabArray;
	}

	private int getColNumberForHeader(ExcelUtils objUtil, String language, int totalCols) throws Exception {

		String colName = null;
		int colNumber=0;
		for (int j = 0; j < totalCols; j++){

			colName = objUtil.getCellData(0,j);
			if(colName.equals(language)) {
				colNumber = j;
				break;
			}
			//			System.out.println(tabArray[i][j]);
		}
		return colNumber;
	}



	public String[][] getSystemParameters(String environment) throws Exception{
		String[][] tabArray = null;
		ExcelUtils objUtil = new ExcelUtils();

		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();
		//String sheetName = environment.replace("_", " ");
//		String sheetName = "Params";
		String sheetName = environment;
		//		System.out.println("Sheet Name: "+sheetName);
		//		System.out.println("Params Sheet Path: "+zycusCoreConstants.SystemParamsPath); 

		objUtil.setExcelFile(zycusCoreConstants.SystemParamsPath, sheetName);
		objUtil.ExcelWSheet.getLastRowNum();
		//		System.out.println(totalRows);
		int totalCols = objUtil.ExcelWSheet.getRow(0).getPhysicalNumberOfCells();
		//		System.out.println(totalCols);
		tabArray = new String[1][totalCols];
		int i = 0;
		for (int j = 0; j < totalCols; j++){
			tabArray[i][j] = objUtil.getCellData(i+1, j);
			//			System.out.println(tabArray[i][j]);
		}
		i++;
		objUtil.close();
		return tabArray;
	}

}
