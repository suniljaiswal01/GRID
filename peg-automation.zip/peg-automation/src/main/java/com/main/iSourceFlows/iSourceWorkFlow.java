package com.main.iSourceFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSource.Admin.WorkFlow;

import common.Functions.iSource_CommonFunctions;

public class iSourceWorkFlow  extends CommonTests1 {


	public String Product = "iSource";
	iSource_CommonFunctions objFunctions;

	public iSourceWorkFlow() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginWorkflow()throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginWorkflow")
	@TestDetails(TestID = "iSource_5")
	public void activateWorkflow() throws Exception {
		
		WorkFlow workflow = new WorkFlow(driver, logger);
		workflow.activateWorkflow();
	}
}
