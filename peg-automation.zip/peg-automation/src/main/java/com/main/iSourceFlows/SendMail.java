package com.main.iSourceFlows;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendMail
{
   //public static void main(String [] args)
   public void sendMail(String filename)
   {

      // Recipient's email ID needs to be mentioned.
      String to = "varun.khurana@zycus.com";
      // Sender's email ID needs to be mentioned
      String from = "varun.khurana@zycus.com";
      // Assuming you are sending email from localhost
      String host = "devAutoMail.zycus.com";
      // Get system properties
      Properties properties = System.getProperties();
      // Setup mail server
      properties.setProperty("mail.smtp.host", host);
      // Get the default Session object.
      Session session = Session.getDefaultInstance(properties);
      
      String text=
    	         "<table width='100%' border='1' align='center'>"
    	                + "<tr align='center'>"
    	                + "<td><b>Product Name <b></td>"
    	                + "<td><b>Count<b></td>"
    	                + "</tr>";
      text=text+"<tr align='center'>"+"<td>" + "iSource" + "</td>"
              + "<td>" + "1" + "</td>"+"</tr>";

    	    /*for (Map.Entry entry : ProductwiseCount.entrySet()) {
    	                    System.out.println(entry.getKey() + " :" + entry.getValue());
    	                    text=text+"<tr align='center'>"+"<td>" + entry.getValue() + "</td>"
    	                                + "<td>" + entry.getKey() + "</td>"+"</tr>";

    	                }*/
      
      try{
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);
         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));
         // Set To: header field of the header.
         message.addRecipient(Message.RecipientType.TO,
                                  new InternetAddress(to));

         // Set Subject: header field
         message.setSubject("This is the Subject Line!");

         // Create the message part 
         BodyPart messageBodyPart = new MimeBodyPart();

         // Fill the message
         messageBodyPart.setText("This is the Message body");
         
         BodyPart htmlBodyPart = new MimeBodyPart();
         
         htmlBodyPart.setContent("This is the Message body","text/html;charset=UTF-8");

         // Create a multipar message
         Multipart multipart = new MimeMultipart();

         // Set text message part
         multipart.addBodyPart(messageBodyPart);
         multipart.addBodyPart(htmlBodyPart);

         // Part two is attachment
         //messageBodyPart = new MimeBodyPart();
         //String filename = "C:\\Users\\varun.khurana\\newWorkspace\\ExtentTesting\\Reports\\Email_Report.html";
         
         //For Attachment
         if(!filename.equals("")){
	         DataSource source = new FileDataSource(filename);
	         messageBodyPart.setDataHandler(new DataHandler(source));
	         messageBodyPart.setFileName(filename);
         }
         multipart.addBodyPart(messageBodyPart);
         multipart.addBodyPart(htmlBodyPart);

         // Send the complete message parts
         message.setContent(multipart);

         // Send message
         Transport.send(message);
         System.out.println("Sent message successfully....");
      }catch (MessagingException mex) {
         mex.printStackTrace();
      }
   }
}