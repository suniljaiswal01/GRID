package com.main.iSourceFlows;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

public class ReadMail
{
   public static void main(String [] args) throws IOException
  // public void readMail(String filename)
   {

      // Recipient's email ID needs to be mentioned.
      String to = "nitesh.singh@zycus.com";
      // Sender's email ID needs to be mentioned
      String from = "varun.khurana@zycus.com";
      // Assuming you are sending email from localhost
      String host = "devAutoMail.zycus.com";
      // Get system properties
      //Properties properties = System.getProperties();
      // Setup mail server
      //properties.setProperty("mail.smtp.host", host);
      
      
      
      Properties props = new Properties(); 
      props.put("mail.store.protocol", "imap");
      /*properties.setProperty("mail.store.protocol", "imaps");
      properties.setProperty("mail.imap.user", from);
      properties.setProperty("mail.imap.host", host);
      properties.setProperty("mail.imap.port", "143");*/
      
      
      // Get the default Session object.
      //Session session = Session.getDefaultInstance(properties);
      Store mailStore = null;
      Folder inbox = null;
      try{
    	  Session mailSession = Session.getInstance(props);   
    	  mailStore = mailSession.getStore("imap");
    	  mailStore.connect("imap.outlook.com", from, "corp#123");                    
    	  Folder dFolder = mailStore.getDefaultFolder();
    	  inbox = dFolder.getFolder("INBOX");
    	  //inbox.open(Folder.READ_WRITE);
    	  inbox.open(Folder.READ_ONLY);

    	  
    	  Message[] messages = inbox.getMessages();
			System.out.println("No of Messages : " + inbox.getMessageCount());
			System.out.println("No of Unread Messages : " + inbox.getUnreadMessageCount());
			for (int i = 0; i < messages.length; i++) {
				System.out.println("Reading MESSAGE # " + (i + 1) + "...");
				Message msg = messages[i];
				String strMailSubject = "", strMailBody = "";
				// Getting mail subject
				Object subject = msg.getSubject();
				// Getting mail body
				Object content = msg.getContent();
				// Casting objects of mail subject and body into String
				strMailSubject = (String) subject;
				//---- This is what you want to do------
				if (strMailSubject.contains("Polaris")) {
					System.out.println(strMailSubject);
					break;
				}
			}
    	  
      }catch (MessagingException messagingException) {
			messagingException.printStackTrace();
		} catch (IOException ioException) {
			ioException.printStackTrace();
		} finally {
			if (inbox != null) {
				try {
					inbox.close(true);
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (mailStore != null) {
				try {
					mailStore.close();
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
      
      
      /*try{
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);
         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));
         // Set To: header field of the header.
         message.addRecipient(Message.RecipientType.TO,
                                  new InternetAddress(to));

         // Set Subject: header field
         message.setSubject("This is the Subject Line!");

         // Create the message part 
         BodyPart messageBodyPart = new MimeBodyPart();

         // Fill the message
         messageBodyPart.setText("This is message body");

         // Create a multipar message
         Multipart multipart = new MimeMultipart();

         // Set text message part
         multipart.addBodyPart(messageBodyPart);

         // Part two is attachment
         messageBodyPart = new MimeBodyPart();
         //String filename = "C:\\Users\\varun.khurana\\newWorkspace\\ExtentTesting\\Reports\\Email_Report.html";
         DataSource source = new FileDataSource(filename);
         messageBodyPart.setDataHandler(new DataHandler(source));
         messageBodyPart.setFileName(filename);
         multipart.addBodyPart(messageBodyPart);

         // Send the complete message parts
         message.setContent(multipart );

         // Send message
         Transport.send(message);
         System.out.println("Sent message successfully....");
      }*//*catch (MessagingException mex) {
         mex.printStackTrace();
      }*/
   }
}