package com.main.iSourceFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSource.MyEvents.MyEvents;

import DataProviders.Common_DataProviderTestNG;

public class JPNAuction extends CommonTests1{

	public JPNAuction() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}

	String eventID = null;

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void Login_JPN() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods = "Login_JPN")
	@TestDetails(TestID="iSource_2")
	public void createAuctionEvent() throws Exception {
		//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "Japanese-Forward", false);
		if(eventID!=null) 
			LogScreenshot("Event ID For Japanese auction:"+eventID);
		else
			LogScreenshot("Event ID For Japanese auction:"+eventID);
	}
	
	/*@Test(dependsOnMethods = "Login_JPN")
	@TestDetails(TestID="iSource_2")
	public void createAuctionEven_Classict() throws Exception {
		//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "Japanese-Forward", false);
		if(eventID!=null) 
			LogScreenshot("Event ID For Japanese auction:"+eventID);
		else
			LogScreenshot("Event ID For Japanese auction:"+eventID);
	}
*/
	/*@DataProvider
	public Object[][] suppliersProvider() throws Exception {
		return new Object[][] { { "anjali.singh@zycus.com","Mumbai72!","TEST 23/09" }, { "nitesh.singh@zycus.com","Pass@123","TEST_SANITY6" } };
	}
	@Test(dataProvider = "suppliersProvider",
			dependsOnMethods = "createAuctionEvent",
			priority = 2)
	@TestDetails(TestID="iSource_3")
	public void Login_ZSN(String userName, String password, String supplierCompany) throws Exception{
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		//Login objLogin = new Login(driver1, logger, "anjali.singh@zycus.com", "Mumbai72!");
		Login objLogin = new Login(driver1, logger, userName, password);
		callAndLog(driver1, logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
		System.out.println("Japanese Event is "+eventID);
		//this.eventType = "Japanese";
		ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
		objEvents.selectSupplierCompany(supplierCompany);
		objEvents.filterByEventID(eventID);
		objEvents.enterEvent(eventID, "Japanese");
		SupplierResponse objResponse = new SupplierResponse(driver1, logger);
		objResponse.joinBiddding();
		LotDetails objLot = new LotDetails(driver1, logger);
		objLot.waitForLotToStart();
		objLot.acceptRejectBid();
	}*/

	/*@Test(dependsOnMethods = "createAuctionEvent",
			priority = 2)
	@TestDetails(TestID="iSource_3")
	public void Login_ZSN_JPN() throws Exception{
		WebDriver driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		ExtentTest logger1 = logger.createNode("Supplier : Nitesh Singh");
		Login objLogin = new Login(driver1, logger1, "nitesh.singh@zycus.com", "Pass@123");
		//Login objLogin = new Login(driver1, logger1, userName, password);
		callAndLog(driver1, logger1, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger1);
		objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
		System.out.println("Japanese Event is "+eventID);
		//this.eventType = "Japanese";
		ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger1);
		objEvents.selectSupplierCompany("TEST_SANITY6");
		objEvents.filterByEventID(eventID);
		objEvents.enterEvent(eventID, "Japanese");
		SupplierResponse objResponse = new SupplierResponse(driver1, logger1);
		objResponse.waitForLotToStart();
		objResponse.joinBiddding();
		LotDetails objLot = new LotDetails(driver1, logger1);
		//objLot.waitForLotToStart();
		objLot.acceptRejectBid();
	}*/

	/*@Test(dependsOnMethods = "createAuctionEvent",dataProviderClass = iSource_DataProviderTestNG.class, dataProvider = "JPNAuction",priority = 2)
	@TestDetails(TestID="iSource_3")
	public void Login_ZSN_JPN_1(String supplierEmail, String supplierPassword, String SupplierContactName, String SupplierCompanyName) throws Exception{
		if(eventID!=null){
			WebDriver driver1 = objFrameworkUtility.getWebDriverInstance1();
			ExtentTest logger2 = logger.createNode("Supplier : "+SupplierContactName);
			Login objLogin = new Login(driver1, logger2, supplierEmail, supplierPassword);
			//Login objLogin = new Login(driver1, logger2, userName, password);
			callAndLog(driver1, logger2, objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger2);
			objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
			System.out.println("Japanese Event is "+eventID);
			//this.eventType = "Japanese";
			ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger2);
			//objEvents.selectSupplierCompany("TEST 23/09");
			objEvents.selectSupplierCompany();
			objEvents.filterByEventID(eventID);
			objEvents.enterEvent(eventID, "Japanese");
			SupplierResponse objResponse = new SupplierResponse(driver1, logger2);
			objResponse.waitForLotToStart();
			objResponse.joinBiddding();
			LotDetails objLot = new LotDetails(driver1, logger2);
			//objLot.waitForLotToStart();
			objLot.acceptRejectBid();
		}else
			throw new SkipException("Event Not published");
	}
*/
	/*@Test(dependsOnMethods = "createAuctionEvent",
			priority = 3)
	@TestDetails(TestID="iSource_4")
	public void approveJPNEvent() throws Exception {
		System.out.println("Japanese Event is "+eventID);
		this.eventType = "Japanese";
		ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
		objEvents.filterByEventID(eventID);
		objEvents.enterEvent(eventID, eventType);		
	}
	 */

}
