package com.main.iSourceFlows;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.MyEvents;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;

public class DutchAuctionForward extends CommonTests1{

	public String auctionDirection = "Forward";
	private WebDriver driver1;
	//iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	private String eventType;
	private String scoreSheet;

	public DutchAuctionForward() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void LoginDutchForwardAuction() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods = "LoginDutchForwardAuction")
	@TestDetails(TestID="iSource_2")
	public void createDutchForwardAuctionEvent() throws Exception {
		//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "Dutch-Forward", false);
		if(eventID!=null){
			LogScreenshot("Pass", "Dutch Forward Auction Created with ID "+eventID);
		}
	}

	@Test(dependsOnMethods = "createDutchForwardAuctionEvent")
	@TestDetails(TestID="iSource_1")
	public void approveDutchForwardEvent() throws Exception {
		this.eventType = "Dutch";
		driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
		
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierEmail = supplierDetails.getSupplierEmail();
		String supplierPassword = supplierDetails.getSupplierPassword();
		Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
		boolean loginStatus = objLogin.login(configurationProperties);
		callAndLog(driver1,logger,loginStatus, "login successful", "Not logged in");
		if(loginStatus){
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
			ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
			
			objEvents.selectSupplierCompany();
			if(objEvents.filterByEventID(eventID))
				objEvents.enterEvent(eventID, eventType);
	
			MyEvents myEvents = new MyEvents(driver, logger);
			myEvents.enterBid();
			objEvents.acceptBid();
			myEvents.scheduleBidReconciliation();
			objEvents.bidReconciliation(auctionDirection);	
		}
		objLogin.logout();
		driver1.close();
	}
	
	
	@Test(dependsOnMethods = "approveDutchForwardEvent")
	@TestDetails(TestID="iSource_1")
	public void analyzeDutchForwardAuctionEvent() throws Exception {
		//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
		Analyze analyzeAuction = new Analyze(driver, logger);
		scoreSheet = analyzeAuction.analyzeAuction();
		if(scoreSheet!=null){
			analyzeAuction.scoreResponses(scoreSheet);
			analyzeAuction.whatIfAnalysis(scoreSheet);
			analyzeAuction.concludeEvent(scoreSheet);
			analyzeAuction.LogScreenshot("pass", "event analyzed");
		}else
			analyzeAuction.LogScreenshot("fail", "event not analyzed");
		}
}
