package com.main.iSourceFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSource.MyReports.Reports;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;

public class ISourceReport extends CommonTests1{

//	private ExtentTest logger;
	/*private String Product = "iSave";
	eInvoice_CommonFunctions objFunctions;*/

	String projectType = null;

	public ISourceReport() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReport() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iSource_DataProviderTestNG.class, dependsOnMethods = "loginReport",dataProvider = "Reports")
	@TestDetails(TestID="iSource_6")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}

	@Test(dataProviderClass = iSource_DataProviderTestNG.class, dependsOnMethods = "Reports",dataProvider = "ModifyReports")
	@TestDetails(TestID="iSource_6")
	public void ModifyReport(String report) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
	}
}
