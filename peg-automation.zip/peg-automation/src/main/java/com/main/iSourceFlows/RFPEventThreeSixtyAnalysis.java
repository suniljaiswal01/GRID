package com.main.iSourceFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.Collect;
import com.zycus.iSource.MyEvents.MyEvents;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iSource_CommonFunctions;

public class RFPEventThreeSixtyAnalysis extends CommonTests1{


	iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	Collect objCollect;
	private String eventType;
	private String scoreSheet;


	public RFPEventThreeSixtyAnalysis() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void Login_RFP() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "Login_RFP")
	@TestDetails(TestID="iSource_2")
	public void createRFPEvent() throws Exception {
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "RFP", false);
		System.out.println("Event ID in RFP is "+eventID);
		if(eventID!=null){
			objEvents.LogScreenshot("pass", "RFP Event created with ID "+eventID);
		}else
			objEvents.LogScreenshot("fail", "RFP Event not created");
	}
	

	@Test(dependsOnMethods = "createRFPEvent")
	@TestDetails(TestID="iSource_1")
	public void placeSurrogateBidRFP() throws Exception{
		objCollect = new Collect(driver, logger);
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(1);
		String SupplierContactName = supplierDetails.getContactingPerson();
		objCollect.surrogateBid("RFP",SupplierContactName);
	}


	@Test(dependsOnMethods = "placeSurrogateBidRFP")
	@TestDetails(TestID="iSource_1")
	public void approveRFPEvent() throws Exception {
		//if(eventID!=null){


		CommonFunctions1 objZSNFunctions  = null;
		try {
			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String supplierEmail = supplierDetails.getSupplierEmail();
			String supplierPassword = supplierDetails.getSupplierPassword();
			Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
			boolean loginStatus = objLogin.login(configurationProperties);
			callAndLog(driver1,logger, loginStatus, "login successful", "Not logged in");
			if(loginStatus){
				objZSNFunctions = new CommonFunctions1(driver1, logger);
				objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
	
				this.eventType = "RFP";
				ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
				objEvents.selectSupplierCompany();
				objEvents.filterByEventID(eventID);
				objEvents.enterEvent(eventID, eventType);
				objLogin.logout();
			}
		}catch (Exception e) {
			objZSNFunctions.LogScreenshot("fail","Failed during approval");
		}
		driver1.quit();
	}

	@Test(dependsOnMethods = "approveRFPEvent")
	@TestDetails(TestID="iSource_1")
	public void analyzeRFPEvent() throws Exception {

		objCollect = new Collect(driver, logger);
		if(objCollect.verifyResponseReceived()){
			//Wait for the Event to get closed
			objCollect.waitForEventToClose();
			Analyze objAnalyze = new Analyze(driver, logger);
			scoreSheet = objAnalyze.analyzeEvent();
			if(scoreSheet!=null){
				objAnalyze.scoreResponses(scoreSheet);
				objAnalyze.whatIfAnalysis(scoreSheet);
				objAnalyze.degreeAnalysis();
				objAnalyze.concludeEvent(scoreSheet);
				objCollect.LogScreenshot("pass", "event analyzed");
			}else
				objCollect.LogScreenshot("fail", "event not analyzed");
			}else {
			objCollect.LogScreenshot("fail", "Response Not Received");
		}
	}


}
