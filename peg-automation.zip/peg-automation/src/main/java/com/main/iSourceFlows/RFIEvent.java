package com.main.iSourceFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.Collect;
import com.zycus.iSource.MyEvents.MyEvents;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iSource_CommonFunctions;

public class RFIEvent extends CommonTests1 {

	//private ExtentTest logger;
	private String Product = "iSource";
//	private WebDriver driver1;
	iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	private String eventType;
	Collect objCollect;
	private String scoreSheet;

	public RFIEvent() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void Login_RFI()throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "Login_RFI")
	@TestDetails(TestID = "iSource_2")
	public void createRFIEvent() throws Exception {
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "RFI", false);
		System.out.println("Event ID in flowIsource is " + eventID);
		if (eventID != null) {
			objEvents.LogScreenshot("pass", "Event created with ID " + eventID);
		} else
			objEvents.LogScreenshot("fail", "RFI Event not created");
	}
	

	@Test(dependsOnMethods = "createRFIEvent")
	@TestDetails(TestID = "iSource_1")
	public void placeSurrogateBid() throws Exception {
		objCollect = new Collect(driver, logger);
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(1);
		String SupplierContactName = supplierDetails.getContactingPerson();
		objCollect.surrogateBid("RFI", SupplierContactName);
	}

	@Test( dependsOnMethods = "placeSurrogateBid")
	@TestDetails(TestID = "iSource_1")
	public void Login_ZSN_RFI() throws Exception {
		try {
			if (eventID != null) {
				driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
				SupplierDetails supplierDetails = new SupplierDetails();
				supplierDetails.setSupplierData(0);
				String supplierEmail = supplierDetails.getSupplierEmail();
				String supplierPassword = supplierDetails.getSupplierPassword();
				Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
				boolean loginStatus = objLogin.login(configurationProperties);
				callAndLog(driver1,logger, loginStatus, "login successful", "Not logged in");
				if(loginStatus){
					CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
					objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
				}
			} else
				throw new SkipException("Event Not published");
		}catch (Exception e) {
			LogScreenshot("info", "Failed");
		}	
	}

	@Test(dependsOnMethods = "Login_ZSN_RFI")
	@TestDetails(TestID = "iSource_1")
	public void approveRFIEvent() throws Exception {
		this.eventType = "RFI";
		ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
		objEvents.selectSupplierCompany();
		// objEvents.selectSupplierCompany(supplierCompany);
		objEvents.filterByEventID(eventID);
		objEvents.enterEvent(eventID, eventType);
		
		objEvents.logout();
		driver1.close();
	}

	@Test(dependsOnMethods = "approveRFIEvent")
	@TestDetails(TestID = "iSource_1")
	public void analyzeRFIEvent() throws Exception {
		// Verify Response received for the Event
		objCollect = new Collect(driver, logger);
		if (objCollect.verifyResponseReceived()) {
			// Wait for the Event to get closed
			objFunctions = new iSource_CommonFunctions(driver, logger);
			objFunctions.waitForEventToClose();
			Analyze objAnalyze = new Analyze(driver, logger);
			scoreSheet = objAnalyze.analyzeEvent();
			if(scoreSheet!=null){
				objAnalyze.scoreResponses(scoreSheet);
				objAnalyze.whatIfAnalysis(scoreSheet);
				objCollect.LogScreenshot("pass", "event analyzed");
			}else
				objCollect.LogScreenshot("fail", "event not analyzed");
		}
	}

}
