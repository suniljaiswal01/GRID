package com.main.iSourceFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.BidOptimization;
import com.zycus.iSource.MyEvents.Collect;
import com.zycus.iSource.MyEvents.MyEvents;
import com.zycus.iSource.MyEvents.ViewOptimizationResult;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iSource_CommonFunctions;

public class TwoBiddingEnvelope extends CommonTests1{

	/*private ExtentTest logger;
	private String Product = "iSource";*/
	//iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	private String eventType;
	Collect objCollect;
	private String scoreSheet;
	private iSource_CommonFunctions objFunctions;

	public TwoBiddingEnvelope() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void Login_TEB() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "Login_TEB")
	@TestDetails(TestID="iSource_2")
	public void createRFQEvent_TEB() throws Exception {
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "RFQ", true);
		System.out.println("Event ID in flowIsource is "+eventID);
		if(eventID!=null){
			objEvents.LogScreenshot("pass","TEB Event created with ID "+eventID);
		}else
			objEvents.LogScreenshot("fail","TEB Event not created");
	}
	


	@Test(dependsOnMethods = "createRFQEvent_TEB")
	@TestDetails(TestID="iSource_1")
	public void Login_ZSN_TEB_RFQ() throws Exception{
		if(eventID!=null){
			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String supplierEmail = supplierDetails.getSupplierEmail();
			String supplierPassword = supplierDetails.getSupplierPassword();
			Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
			boolean loginStatus = objLogin.login(configurationProperties);
			callAndLog(driver1,logger,loginStatus, "login successful", "Not logged in");
			if(loginStatus){
				CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
				Thread.sleep(5000);
				objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
			}
		}else
			throw new SkipException("Event Not published");
	}
	
	@Test(dependsOnMethods = "Login_ZSN_TEB_RFQ")
	@TestDetails(TestID="iSource_1")
	public void approveRFQEvent_TEB() throws Exception {
		this.eventType = "RFQ";
			ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String supplierCompany = supplierDetails.getCompanyName();
			objEvents.selectSupplierCompany(supplierCompany);
			objEvents.filterByEventID(eventID);
			objEvents.enterEvent(eventID, eventType);
			driver1.close();
	}
	
	@Test(dependsOnMethods = "approveRFQEvent_TEB")
	@TestDetails(TestID="iSource_1")
	public void unlockBid_TEB() throws Exception {
		//Verify Response received for the Event
		Collect objCollect = new Collect(driver, logger);
		objCollect.verifyResponseReceived();
		//Wait for the Event to get closed
		objFunctions = new iSource_CommonFunctions(driver, logger);
		objFunctions.waitForEventToClose();
		objCollect.unlockBid();
	}
	
	
	@Test(dependsOnMethods = "unlockBid_TEB")
	@TestDetails(TestID="iSource_1")
	public void analyzeRFQEvent_TEB() throws Exception {
		Analyze objAnalyze = new Analyze(driver, logger);
		scoreSheet = objAnalyze.analyzeEvent();
		if(scoreSheet!=null){
			objAnalyze.scoreResponses(scoreSheet);
			objAnalyze.rescheduleToCloseScoresheet(scoreSheet);
			Collect objCollect = new Collect(driver, logger);
			objCollect.shortlistResponsesForCommercialAnalysis();
			objAnalyze.republishScoresheetForCommercial(scoreSheet);
			objAnalyze.rescheduleToCloseScoresheet(scoreSheet);
//			objFunctions.waitForScoresheetToClose(scoreSheet);
			objAnalyze.goToBidOptimization();
			BidOptimization objOptimization = new BidOptimization(driver, logger);
			objOptimization.selectStandardScenario("Cherry Picking");
			ViewOptimizationResult objResult= new ViewOptimizationResult(driver,logger);
			String scenarioName = objResult.saveScenario();
			callAndLog(logger, objResult.goToOptimizedScenarioList(scenarioName), "Event analyzed", "Event analyzation failed");	
		}
	
	}
	


}
