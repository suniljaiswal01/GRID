package com.main.iSourceFlows;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.BidOptimization;
import com.zycus.iSource.MyEvents.Collect;
import com.zycus.iSource.MyEvents.Conduct;
import com.zycus.iSource.MyEvents.MyEvents;
import com.zycus.iSource.MyEvents.ViewOptimizationResult;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import Framework.ConfigurationProperties;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.iSource_CommonFunctions;

public class EngAuctionReverse extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iSource";
	public String auctionDirection = "Reverse";
	private WebDriver driver1;
	iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	private String eventType="English";
	private Conduct objConduct;
	ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
	WebDriver driver2;
	private String scoreSheet;

	public EngAuctionReverse() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}



	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void Login_Eng_ReverseAuction() throws Exception {
		
	
		 displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		 callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods = "Login_Eng_ReverseAuction")
	@TestDetails(TestID="iSource_2")
	public void createEnglishReverseAuctionEvent() throws Exception {
		//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "English-Reverse", false);
		if(eventID!=null){
			objEvents.LogScreenshot("PASS", "English Auction created with ID "+eventID);
		}else
			objEvents.LogScreenshot("FAIL", "English Auction  not created");
	}
	

	@Test( dependsOnMethods = "createEnglishReverseAuctionEvent")
	@TestDetails(TestID="iSource_1")
	public void Login_ZSN_EngReverseAuction() throws Exception{
		if(eventID!=null){
			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String supplierEmail = supplierDetails.getSupplierEmail();
			String supplierPassword = supplierDetails.getSupplierPassword();
			String SupplierCompanyName = supplierDetails.getCompanyName();
			Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
			callAndLog(driver1,logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			String tenant = configurationProperties.getProperty("Tenant");
			objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", tenant);
			ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
			objEvents.selectSupplierCompany(SupplierCompanyName);
			if(objEvents.filterByEventID(eventID))
				objEvents.enterEvent(eventID, eventType);
		}else
			throw new SkipException("Event Not published");
	}

	@Test(dependsOnMethods = "Login_ZSN_EngReverseAuction")
	@TestDetails(TestID="iSource_1")
	public void approveEngReverseEvent() throws Exception {
		if(eventID!=null){
			driver2 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			this.eventType = "English";	
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(1);
			String supplierEmail = supplierDetails.getSupplierEmail();
			String supplierPassword = supplierDetails.getSupplierPassword();
			String SupplierCompanyName = supplierDetails.getCompanyName();
			Login objLogin = new Login(driver2, logger, supplierEmail, supplierPassword);
			boolean loginStatus = objLogin.login(configurationProperties);
			callAndLog(driver2,logger,loginStatus, "login successful", "Not logged in");
			if(loginStatus){
				CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver2, logger);
				String tenant = configurationProperties.getProperty("Tenant");
				objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", tenant);
				ViewSourcingEvents objEvents = new ViewSourcingEvents(driver2, logger);
				
				objEvents.selectSupplierCompany(SupplierCompanyName);
				if(objEvents.filterByEventID(eventID))
					objEvents.enterEvent(eventID, eventType);
			}
		}else
			LogScreenshot("FAIL", "Event ID not created as Event not published");

	}

	@Test(dependsOnMethods = "approveEngReverseEvent")
	@TestDetails(TestID="iSource_1")
	public void bidReconciliationEngReverseAuction() throws Exception {
		if(eventID!=null){		
			MyEvents objEvents = new MyEvents(driver, logger);
			objEvents.closeEvent(eventID);
			
			objEvents.scheduleBidReconciliation();
			try {
				ViewSourcingEvents objEvents1 = new ViewSourcingEvents(driver1, logger);
				objEvents1.bidReconciliation(auctionDirection);
				objEvents1.logout();
			}catch (Exception e) {
			LogScreenshot("fail","Bid Reconsilcation Failed");
			}
			
			try {
				ViewSourcingEvents objEvents2 = new ViewSourcingEvents(driver2, logger);
				objEvents2.bidReconciliation(auctionDirection);		
				objEvents2.logout();
			}catch (Exception e) {
			LogScreenshot("fail","Bid Reconsilcation Failed");
			}
			
			
		}
		driver1.close();
		driver2.close();
	}	

	@Test(dependsOnMethods = "bidReconciliationEngReverseAuction")
	@TestDetails(TestID="iSource_1")
	public void analyzeEnglishReverseAuction() throws Exception {

		//Verify Response received for the Event
		Collect objCollect = new Collect(driver, logger);
		//Wait for the Event to get closed
		objFunctions = new iSource_CommonFunctions(driver, logger);
		Analyze objAnalyze = new Analyze(driver, logger);
		scoreSheet = objAnalyze.analyzeEvent();
		if(scoreSheet!=null){
			objAnalyze.goToBidOptimization();
			BidOptimization objOptimization = new BidOptimization(driver, logger);
			objOptimization.selectStandardScenario("Cherry Picking");
			ViewOptimizationResult objResult= new ViewOptimizationResult(driver,logger);
			String scenarioName = objResult.saveScenario();
			try {
				objResult.goToOptimizedScenarioList(scenarioName);
				LogScreenshot("Pass","Event analyzed");
			}catch (Exception e) {
				LogScreenshot("fail","Event analyzation failed");
			}	
		}

	}

}
