package com.main.iSourceFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSource.Dashboard.Dashboard;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import common.Functions.iPerform_CommonFunctions;

public class DashboardTest  extends CommonTests1 {


	public String Product = "iSource";
	iPerform_CommonFunctions objFunctions;

	public DashboardTest() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginDashboard()throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginDashboard",dataProviderClass = iSource_DataProviderTestNG.class, dataProvider ="Dashboard")
	@TestDetails(TestID = "iSource_4")
	public void standardDashboard(String...dashboards) throws Exception {

		Dashboard dashboard = new Dashboard(driver, logger);
		dashboard.verifyDisplayedDashlets(dashboards);
	}
}
