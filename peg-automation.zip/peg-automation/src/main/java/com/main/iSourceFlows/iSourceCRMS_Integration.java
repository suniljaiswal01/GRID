package com.main.iSourceFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.iSource_DataProviderTestNG;

public class iSourceCRMS_Integration  extends CommonTests1 {
	//	private ExtentTest logger;
	public String Product = "iSource";
	//	iPerform_CommonFunctions objFunctions;

	String types[] = {"RFI","RFQ","RFP","Dutch","English","TEB","QuickSource"};

	public iSourceCRMS_Integration() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginiSourceCRMSIntegration()
			throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}


	@Test(dataProviderClass = iSource_DataProviderTestNG.class, dataProvider ="crms_reportGeneration", priority=5,alwaysRun=true)
	@TestDetails(TestID = "iSource_CRMSIntegration")
	public void crms_reportGeneration(String category, String... data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		if(createNewReport.selectProduct(Product)) {
			createNewReport.selectParams(category, data);
			VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
			for(String type : types) {
				verifyReportsField.iSourceFieldCheck(type);
			}
			verifyReportsField.backToReportListing();	
		}
	}
}
