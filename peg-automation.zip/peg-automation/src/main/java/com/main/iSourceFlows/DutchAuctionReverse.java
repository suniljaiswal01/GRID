package com.main.iSourceFlows;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyEvents.ViewSourcingEvents;
import com.zycus.iSource.MyEvents.Analyze;
import com.zycus.iSource.MyEvents.MyEvents;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;

public class DutchAuctionReverse extends CommonTests1{

	public String auctionDirection = "Reverse";
	private WebDriver driver1;
	//iSource_CommonFunctions objFunctions;
	public static String eventID = null;
	private String eventType;
	private String scoreSheet;

	public DutchAuctionReverse() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void LoginDutchReverseAuction() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "LoginDutchReverseAuction")
	@TestDetails(TestID="iSource_2")
	public void createDutchReverseAuctionEvent() throws Exception {
		MyEvents objEvents = new MyEvents(driver, logger);
		eventID = objEvents.createNewEvent("Full Source", "From Start", "Dutch-Reverse", false);
		if(eventID!=null){
			LogScreenshot("Pass", "Dutch Reverse Auction Created with ID "+eventID);
		}
	}

	@Test(dependsOnMethods = "createDutchReverseAuctionEvent")
	@TestDetails(TestID="iSource_1")
	public void approveDutchReverseEvent() throws Exception {
		this.eventType = "Dutch";
		driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierEmail = supplierDetails.getSupplierEmail();
		String supplierPassword = supplierDetails.getSupplierPassword();
		Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
		boolean loginStatus = objLogin.login(configurationProperties);
		callAndLog(driver1,logger,loginStatus, "login successful", "Not logged in");
		if(loginStatus){
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
			ViewSourcingEvents objEvents = new ViewSourcingEvents(driver1, logger);
			
			objEvents.selectSupplierCompany();
			if(objEvents.filterByEventID(eventID))
				objEvents.enterEvent(eventID, eventType);
	
			MyEvents myEvents = new MyEvents(driver, logger);
			myEvents.enterBid();
			objEvents.acceptBid();
			myEvents.scheduleBidReconciliation();
			objEvents.bidReconciliation(auctionDirection);
		}
		objLogin.logout();
		driver1.close();
	}
	
	
	@Test(dependsOnMethods = "approveDutchReverseEvent")
	@TestDetails(TestID="iSource_1")
	public void analyzeDutchReverseAuctionEvent() throws Exception {
		//objFunctions.navigateToMainPage(displayStyle, "iSource", "My Events");
		Analyze analyzeAuction = new Analyze(driver, logger);
		scoreSheet = analyzeAuction.analyzeAuction();
		if(scoreSheet!=null){
			analyzeAuction.scoreResponses(scoreSheet);
			analyzeAuction.whatIfAnalysis(scoreSheet);
			analyzeAuction.degreeAnalysis();
			analyzeAuction.concludeEvent(scoreSheet);
			analyzeAuction.LogScreenshot("pass", "event analyzed");
		}else
			analyzeAuction.LogScreenshot("fail", "event not analyzed");
		}
}
