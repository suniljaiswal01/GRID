package com.main.iSourceFlows;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iSource.MyEvents.QuickSource;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;

public class QuickSourceTest extends CommonTests1{

	private String Product = "iSource";
	public static String eventID = null;

	public QuickSourceTest() throws Exception {
		super();
		setProduct("iSource");
		setClassToLoad("common.Functions.iSource_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void Login_QuickSource() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "Login_QuickSource")
	@TestDetails(TestID="iSource_3")
	public void createQuickSourceEvent() throws Exception {		

		QuickSource quickSource = new QuickSource(driver, logger);
		eventID= quickSource.createInquiry();
		if(eventID!=null) {
			LogScreenshot("pass","Quick Source Event Created :"+eventID);
		}else {
			LogScreenshot("fail","Quick Source Event not Created");
		}
	}
	
	

//	@Test(dependsOnMethods = "Login_QuickSource",dataProviderClass = iSource_DataProviderTestNG.class, dataProvider = "quickSource")
	@Test(dependsOnMethods = "createQuickSourceEvent")
	@TestDetails(TestID="iSource_3")
	public void awardEvent() throws Exception {		

		String SupplierCompanyName = null;
		WebDriver driver1 = null;
		try {
			driver1=objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String supplierEmail = supplierDetails.getSupplierEmail();
			String supplierPassword = supplierDetails.getSupplierPassword();
			SupplierCompanyName = supplierDetails.getCompanyName();
			Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
			boolean loginStatus = objLogin.login(configurationProperties);
			callAndLog(driver1,logger,loginStatus, "login successful", "Not logged in");
			if(loginStatus){
				CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
				objZSNFunctions.navigate_path1("My Events", "View Sourcing Events", configurationProperties.getProperty("Tenant"));
				QuickSource quickSource = new QuickSource(driver1, logger);
				quickSource.responseToEvent(SupplierCompanyName,eventID);
				objLogin.logout();
			}
		}catch (Exception e) {

		}
		
		driver1.quit();
		QuickSource quickSource = new QuickSource(driver, logger);
		quickSource.quickSourceAward(SupplierCompanyName,eventID);
		

	}


}
