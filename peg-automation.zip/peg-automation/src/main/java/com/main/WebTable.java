package com.main;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebTable {
	private By objByHeader;
	private By objByRow;
	private By objByColumn;
	
	public WebTable(By objByHeader, By objByRow, By objByColumn){
		this.objByHeader = objByHeader;
		this.objByRow = objByRow;
		this.objByColumn = objByColumn;
	}
	
	public List<WebElement> getColumnHeaders(WebElement objWebTableHeader){
		List<WebElement> lstColumnHeaders = null;
		
		try{
			if (objWebTableHeader.isDisplayed()){
				lstColumnHeaders = objWebTableHeader.findElements(objByHeader);
				return lstColumnHeaders;
			}else{
				return lstColumnHeaders;
			}
			
		}catch(Exception e){
			return lstColumnHeaders;
		}		
	}
	
	public boolean clickColumnHeader(WebElement objWebTableHeader, String strColumnName){
		boolean blnResult = false;
		List<WebElement> lstColumnHeaders = null;
		
		try{
			if (objWebTableHeader.isDisplayed()){
				lstColumnHeaders = objWebTableHeader.findElements(objByHeader);
				
				for(WebElement objColumnHeader : lstColumnHeaders){
					if (objColumnHeader.getText().trim().equalsIgnoreCase(strColumnName)){
						objColumnHeader.click();
						blnResult = true;
						break;
					}
				}
				return blnResult;
			}else{
				return blnResult;
			}
		}catch(Exception e){
			return blnResult;
		}		
	}
	
	public WebElement getChildItem(WebElement objWebTable, int rowIndex, int colIndex, String elementTag){
		WebElement objChildItem = null;
		String strChildItemTag = ".//tr["+rowIndex+"]/td["+colIndex+"]//"+elementTag;
		try{
			if (objWebTable.isDisplayed()){
				objChildItem = objWebTable.findElement(By.xpath(strChildItemTag));
				return objChildItem;
			}else{
				return objChildItem;
			}
			
		}catch(Exception e){
			return objChildItem;
		}		
	}
	
	public int getRowCount(WebElement objWebTable){
		int intRows = -1;
		try{
			intRows = objWebTable.findElements(objByRow).size();
			return intRows;
		}catch(Exception e){
			return intRows;
		}
	}
	
	public int getColumnIndex(WebElement objTableHeader, String strColumnName){
		int intColumnIndex = 0;
		try{
			List<WebElement> lstColumnHeader = getColumnHeaders(objTableHeader);
			for(WebElement objColumn : lstColumnHeader){
				intColumnIndex++;
				if(objColumn.getText().trim().equalsIgnoreCase(strColumnName)){
					return intColumnIndex;
				}
			}
			return intColumnIndex;
		}catch(Exception e){
			return intColumnIndex;
		}
		
	}
	
	public String getCellValue(WebElement objWebTable, int intRow, int intCol){
		String strCellValue = "";
		try{
			List<WebElement> lstRows = objWebTable.findElements(objByRow);
			WebElement objCell = lstRows.get(intRow).findElements(objByColumn).get(intCol);
			strCellValue = objCell.getText();
			return strCellValue;
		}catch(Exception e){
			return strCellValue;
		}
	}
	
	public Integer[] getCellIndex(WebElement objWebTable, String strCellValue){
		int intRows;
		int intCols;
		Integer[] cellIndex = null;
		try{
			intRows = objWebTable.findElements(objByRow).size();
			intCols = objWebTable.findElements(objByColumn).size();
			boolean blnFlag = false;
			for(int intRowIndex = 1; intRowIndex<=intRows; intRowIndex++){
				for(int intColIndex = 1; intColIndex<=intCols; intColIndex++){
					if(strCellValue.equalsIgnoreCase(getCellValue(objWebTable, intRowIndex, intColIndex))){
						cellIndex = new Integer[]{intRowIndex, intColIndex};
						blnFlag = true;
						break;
					}
				}
				if(blnFlag)
					break;
			}
			return cellIndex;
		}catch(Exception e){
			return cellIndex;
		}
		
	}
	
	public boolean waitTillTableLoaded(WebDriver driver, By byTable, int intTimeOut){
		boolean blnResult = false;
		try{
			ZycusCoreConstants lplCoreConstents = new ZycusCoreConstants();
			new WebDriverWait(driver, lplCoreConstents.MEDIUM).until(ExpectedConditions.visibilityOfElementLocated(byTable));
			while(intTimeOut > 0){
				if (driver.findElement(byTable).findElements(objByRow).size() > 1){
					blnResult = true;
					break;
				}
				intTimeOut--;
			}
			return blnResult;
		}catch(Exception e){
			return blnResult;
		}
		
	}

}
