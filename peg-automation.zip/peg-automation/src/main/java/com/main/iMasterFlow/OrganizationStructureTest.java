package com.main.iMasterFlow;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.OrganizationStructure;

public class OrganizationStructureTest extends CommonTests1{

	public static String company = null;
	public static String businessUnit = null;
	
	public static String costCenter = null;
	public static String region = null;
	public static String location =null;
	
	public OrganizationStructureTest() throws Exception {
		super();
		setProduct("iMaster");
		setClassToLoad("common.Functions.TMS_CommonFunctions");
	}
	

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginOrganizationStructure() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	@Test(dependsOnMethods = "loginOrganizationStructure")
	@TestDetails(TestID="TMS_9")
	public void organizationStructureDependentMaster() throws Exception {
		
		OrganizationStructure organizationStructure = new OrganizationStructure(driver,logger);
		region = organizationStructure.regions();
		String address = organizationStructure.address();
		location =organizationStructure.locations(region,address);
		company = organizationStructure.addCompany(location);
		businessUnit =organizationStructure.addBussinessUnit(location,company);
		costCenter = organizationStructure.addCostCenter(company,businessUnit);
	}
	
	@Test(dependsOnMethods = "organizationStructureDependentMaster")
	@TestDetails(TestID="TMS_9")
	public void organizationStructureIndependentMaster() throws Exception {
		
		OrganizationStructure organizationStructure = new OrganizationStructure(driver,logger);
		organizationStructure.addDepartment();
		organizationStructure.addProject(company,businessUnit,costCenter);
		organizationStructure.adminScope(region);
		organizationStructure.reportingScope(region,company,businessUnit);
		organizationStructure.requestingScope(region,company,businessUnit,costCenter,location);
		organizationStructure.addDesignation();
		organizationStructure.addClientSystems(company,businessUnit,location);	
	}	
}
