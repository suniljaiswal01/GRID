package com.main.iMasterFlow;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.GenericMaster;

import DataProviders.TMS_DataproviderTestNG;

public class GenericMasterTest extends CommonTests1{

	public static String purchaseType = null;

	public GenericMasterTest() throws Exception {
		super();
		setProduct("iMaster");
		setClassToLoad("common.Functions.TMS_CommonFunctions");
	}
	

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginGenericMaster() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginGenericMaster")
	@TestDetails(TestID="TMS_9")
	public void purchaseTypeMaster() throws Exception {

		GenericMaster genericMaster = new GenericMaster(driver,logger);
		purchaseType = genericMaster.purchaseType();
	}	
	
	@Test(dataProviderClass = TMS_DataproviderTestNG.class,dependsOnMethods = "purchaseTypeMaster",dataProvider ="genericMaster")
	@TestDetails(TestID="TMS_9")
	public void genericMaster(String currency,String exchangeRateFrom,String exchangeRateTo,String country,String state,String categoryGroup,String category,String supplier) throws Exception {

		GenericMaster genericMaster = new GenericMaster(driver,logger);
		genericMaster.checkCurrency(currency);
		genericMaster.ExchangeRates(exchangeRateFrom,exchangeRateTo);
		genericMaster.UnitOfMeasure();
		genericMaster.checkCountry(country);
		genericMaster.checkState(state);
//		genericMaster.checkCategory();
		genericMaster.checkCategoryGroup(categoryGroup);
		genericMaster.deliveryTerms();
		genericMaster.paymentTerms();
		try {
			genericMaster.supplierCodeMap(category,supplier);
		}catch (Exception e) {}
		genericMaster.customMaster();	
	}	
}
