package com.main.iMasterFlow;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.TMS.AccountingAndControl;

import DataProviders.TMS_DataproviderTestNG;

public class AccountingAndControlTest extends CommonTests1 {

	public AccountingAndControlTest() throws Exception {
		super();
		setProduct("iMaster");
		setClassToLoad("common.Functions.TMS_CommonFunctions");
	}
	

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginAccountingAndControl() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	@Test(dataProviderClass = TMS_DataproviderTestNG.class,dependsOnMethods = {"loginAccountingAndControl","com.main.iMasterFlow.OrganizationStructureTest.organizationStructureDependentMaster"},dataProvider = "accountingAndControl")
	@TestDetails(TestID="TMS_9")
	public void accountingAndControl(String category,String supplier,String currency,String country,String state,String...userName) throws Exception {
		
		AccountingAndControl  accountingAndControl = new AccountingAndControl(driver, logger);
		String GlAccountType = accountingAndControl.addGlAccountType();
		String GlAccount = accountingAndControl.addGlAccount(GlAccountType,OrganizationStructureTest.company,OrganizationStructureTest.businessUnit);
		accountingAndControl.glRuleMap(GenericMasterTest.purchaseType,OrganizationStructureTest.company,OrganizationStructureTest.businessUnit,GlAccountType,GlAccount,category);
		try {
			accountingAndControl.addCategoryManagerMap(category,supplier);
		}catch (Exception e) {}
		
		accountingAndControl.addApprovalRuleMap(OrganizationStructureTest.costCenter,OrganizationStructureTest.company,OrganizationStructureTest.businessUnit,currency,userName);
		String taxType = accountingAndControl.addTaxType();
		accountingAndControl.addTaxRate(taxType,country,state);
		accountingAndControl.accessCode(OrganizationStructureTest.company,OrganizationStructureTest.businessUnit);
		
	}
}
