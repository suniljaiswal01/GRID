package com.main;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.common.ExtentManager;
import com.aventstack.extentreports.common.ExtentTestManager;

import Framework.ConfigurationProperties;

public class ZycusCoreReporter{
	    
	private static File GlobalScreenshotFolder;
	private static ExtentReports extent;
	public static String reportFileName;

	/*public static void createReportFile() throws Exception{
		String fileName;
		
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
//		String productName = configurationProperties.getProperty("Product");
		String productName = Main_Sanity.productName;
		String envName = configurationProperties.getProperty("Environment").replace(" ", "_");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		
		fileName = System.getProperty("user.dir") + configurationProperties.getProperty("reportpath")
		+ "/Execution_Report_" + productName+"-"+envName+"_"+ sdf.format(timestamp) + ".html";
		
		System.out.println("Creating Report file as : "+ fileName);
		
		ExtentManager.createInstance(fileName);
        ExtentTestManager.setReporter(ExtentManager.getInstance());
	}*/
	
	public static void createReportFile() throws Exception{
		String fileName;
		
		ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
//		String productName = configurationProperties.getProperty("Product");
		String productName = Main_Sanity.productName;
		String envName = configurationProperties.getProperty("Environment").replace(" ", "_");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		
		reportFileName = "Execution_Report_" + productName+"-"+envName+"_"+ sdf.format(timestamp);
		fileName = System.getProperty("user.dir") + configurationProperties.getProperty("reportpath")
		+ "/Execution_Report_" + productName+"-"+envName+"_"+ sdf.format(timestamp) + ".html";
		
		System.out.println("Creating Report file as : "+ fileName);
		
		ExtentManager.createInstance(fileName);
        ExtentTestManager.setReporter(ExtentManager.getInstance());
	}
	
	public static String captureScreenShot(WebDriver driver, String screenShortName) {
	try {
		ZycusCoreConstants zycusCoreConstants = ZycusCoreConstants.getInstance();					
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String dest = zycusCoreConstants.SCREEN_SHOT_PATH + screenShortName + ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		
		//Copying the Screenshot to the global automation snapshots folder
		String strGlobalScreenshotParentFolder = zycusCoreConstants.SCREEN_SHOT_PATH;
		
		//Created Sub folders with respect to Today's date
		Calendar objCalendar = Calendar.getInstance();
		
		GlobalScreenshotFolder = new File(strGlobalScreenshotParentFolder);
		
		//Creating Year , Month, Date folders if not present
		GlobalScreenshotFolder.mkdirs();
		
		//Screenshot Destination
		String strGlobalScreenshotDest = strGlobalScreenshotParentFolder + screenShortName + ".png";
		File GlobalScreenshotDestination = new File(strGlobalScreenshotDest);
		
		//Copy the Screenshot to Global folder
		FileUtils.copyFile(destination, GlobalScreenshotDestination);
		
		return "http:" + strGlobalScreenshotDest;
	    }
	  catch (Exception e)	{
		  System.out.println(e.getMessage());
		  return e.getMessage();
	    }
	}
}