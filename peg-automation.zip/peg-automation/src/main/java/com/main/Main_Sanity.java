package com.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.aventstack.extentreports.common.ListenerTest;

import Framework.ConfigurationProperties;

public class Main_Sanity {

	public static String environment=null;
	static String productName = null;
	static String environmentFromJenkins = null;

	public static void main(String[] args) throws Exception {


		List<String> configParams = new ArrayList<String>();
		List<String> configDetails = new ArrayList<String>();
		List<String> systemParams = new ArrayList<String>();
		List<String> systemDetails = new ArrayList<String>();

		List<String> languageKey = new ArrayList<String>();
		List<String> languageValue = new ArrayList<String>();
		
		
		List<String> classNames = new ArrayList<String>();
		List<String> userAccounts = new ArrayList<String>();
		List<String> userNames = new ArrayList<String>();

		// Create an instance on TestNG
		TestNG myTestNG = new TestNG();

		systemParams= setSystemParams(systemParams);
		configParams= setConfigParams(configParams);


		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();

		configDetails=setConfigDetails(objConnect, args, configDetails);
		ConfigFileCreation objConfig = new ConfigFileCreation();
		objConfig.createConfig(configParams,configDetails);
		
		systemDetails= setSystemDetails(objConnect,environment, systemDetails);
		if(args.length==3)
			systemDetails.set(0,args[2]);
		ConfigFileCreation objSysConfig = new ConfigFileCreation();		
		objSysConfig.createSystemConfig(systemParams, systemDetails);

		HashMap<String,List<String>> userProp= setUserDetails(objConnect, classNames, userAccounts,userNames);
		classNames= userProp.get("key");
		userAccounts= userProp.get("value");
		userNames = userProp.get("names");
		
		ConfigFileCreation objUserConfig = new ConfigFileCreation();		
		objUserConfig.createUserConfig(classNames, userAccounts,userNames);
		

		String language = ConfigurationProperties.getInstance().getProperty("Language");
		if(!(language.contains("English"))){
			HashMap<String,List<String>> languageProp= setLanguageDetails(objConnect, languageKey, languageValue);
			languageKey= languageProp.get("key");
			languageValue= languageProp.get("value");

			ConfigFileCreation objLanguageConfig = new ConfigFileCreation();		
			objLanguageConfig.createLanguageConfig(languageKey, languageValue);
		}
		
		System.out.println("Product Name is : " + productName);

		Runtime rt = Runtime.getRuntime();
		long freeMemory = rt.totalMemory() - rt.freeMemory();
		System.out.println( "After- Used Heap memory: " +freeMemory/(1024*1024) );
		String[] productsList = getListOfProducts(productName);

		XmlSuite mySuite = createXMLSuite();
		// Create a list of XmlTests
		List<XmlTest> myTests = new ArrayList<XmlTest>();
		for(String product : productsList){
			XmlTest myTest = createXMLTest(mySuite, product);		
			addClassesToTest(myTest, product);

			// Print the parameter values
			Map<String, String> params1 = myTest.getAllParameters();
			for (Map.Entry<String, String> entry : params1.entrySet()) {
				System.out.println(entry.getKey() + " => " + entry.getValue());
			}

			// Add the Xmltest you created earlier to list of XmlTests
			myTests.add(myTest);
		}

		// add the list of tests to your Suite.
		mySuite.setTests(myTests);

		// Add the suite to the list of suites.
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(mySuite);

		// Set the list of Suites to the testNG object you created earlier.
		myTestNG.setXmlSuites(mySuites);
		mySuite.setFileName("testng.xml");
		mySuite.setThreadCount(15);
		mySuite.addListener("com.aventstack.extentreports.common.ListenerTest");	

		// Create physical XML file based on the virtual XML content
		for (XmlSuite suite : mySuites) {
			createXmlFile(suite);
		}

		myTestNG.run();

	}

	private static HashMap<String,List<String>> setLanguageDetails(ZycusCoreDBConnect objConnect, List<String> languageKey, List<String> languageValue) throws Exception {
		HashMap<String,List<String>> languageProp= new HashMap<String,List<String>>();


		String language = ConfigurationProperties.getInstance().getProperty("Language");
		String[][] Key = objConnect.getKeyForLanguageTranslation("Translation",language);

		for(String value[] : Key) {
			languageKey.add(value[0]);
			languageValue.add(value[1]);	
		}
		languageProp.put("key", languageKey);
		languageProp.put("value", languageValue);
		
		return languageProp;
	}
	
	
	private static HashMap<String,List<String>> setUserDetails(ZycusCoreDBConnect objConnect, List<String> classNames, List<String> userAccounts,List<String> userNames) throws Exception {
		
		HashMap<String,List<String>> userProp= new HashMap<String,List<String>>();

		String[][] Key = objConnect.getUserName("Username");

		for(String value[] : Key) {
			classNames.add(value[0]);
			userAccounts.add(value[1]);	
			userNames.add(value[2]);
		}
		userProp.put("key", classNames);
		userProp.put("value", userAccounts);
		userProp.put("names", userNames);
		
		return userProp;
	}

	// This method will create an Xml file based on the XmlSuite data
	public static void createXmlFile(XmlSuite mSuite) {
		try {
			FileWriter writer = new FileWriter(new File("testng.xml"));
			writer.write(mSuite.toXml());
			writer.flush();
			writer.close();
			System.out.println(new File("testng.xml").getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void addClassesToTest(XmlTest myTest, String productName){
		// Create a list which can contain the classes that you want to run.
		List<XmlClass> myClasses = new ArrayList<XmlClass>();
		switch (productName) {
		case "iSource":
			//			myTest.setParallel(XmlSuite.ParallelMode.METHODS);
			myClasses.add(new XmlClass("com.main.iSourceFlows.iSourceWorkFlow"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.RFIEvent"));
			//			myClasses.add(new XmlClass("com.main.iSourceFlows.RFPEventBidOptimization"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.RFPEventThreeSixtyAnalysis"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.RFQEventBidOptimization"));
			//			myClasses.add(new XmlClass("com.main.iSourceFlows.RFQEventThreeSixtyAnalysis"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.QuickSourceTest"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.DutchAuctionReverse"));
			//			myClasses.add(new XmlClass("com.main.iSourceFlows.DutchAuctionForward"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.EngAuctionReverse"));
			//			myClasses.add(new XmlClass("com.main.iSourceFlows.EngAuctionForward"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.TwoBiddingEnvelope"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.DashboardTest"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.ISourceReport"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.iSourceCRMS_Integration"));
			break;
		case "iContract":
			myTest.setParallel(XmlSuite.ParallelMode.METHODS);/*
			myClasses.add(new XmlClass("com.main.FlowIContract_WithoutSSO"));*/

			myClasses.add(new XmlClass("com.main.iContractFlows.CreateClauseTest"));
			myClasses.add(new XmlClass("com.main.iContractFlows.CreateContractTest"));
			myClasses.add(new XmlClass("com.main.iContractFlows.CreateTemplateTest"));
			myClasses.add(new XmlClass("com.main.iContractFlows.iContract_FlexiForms"));			
			myClasses.add(new XmlClass("com.main.iContractFlows.iContractCRMS_Integration_Tests"));
			myClasses.add(new XmlClass("com.main.iContractFlows.iContractReport"));		
			myClasses.add(new XmlClass("com.main.iContractFlows.Performance"));
			myClasses.add(new XmlClass("com.main.iContractFlows.ReportsAndDashboard"));			
			myClasses.add(new XmlClass("com.main.iContractFlows.RepositoryTest"));
			myClasses.add(new XmlClass("com.main.iContractFlows.TemplateActions"));
			myClasses.add(new XmlClass("com.main.iContractFlows.WordConnectTest"));


			break;
		case "iSave":
			myClasses.add(new XmlClass("com.main.iSaveFlows.ISaveReport"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.QuickProject"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.QuickProjectShare"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.StrategicProjectFlow"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.StrategicProjectReplicate"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.iSaveCRMS_Integration"));
			break;

		case "iMaster":
			myClasses.add(new XmlClass("com.main.iMasterFlow.GenericMasterTest"));
			myClasses.add(new XmlClass("com.main.iMasterFlow.OrganizationStructureTest"));
			myClasses.add(new XmlClass("com.main.iMasterFlow.AccountingAndControlTest"));
			break;
		case "iManage":			
			myClasses.add(new XmlClass("com.main.iManageFlows.Admin_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.Configuration_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.Dashboard_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.FlexiForms_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.iManageCRMS_Integration_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkQuickProjectToContract_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkQuickProjectToRequest_Tests"));						
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkQuickProjectToSave_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkQuickProjectToSource_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.NewTemplateCreation_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.QuickProjectCreation_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.StrategicProjectFromExistingTemplate_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.StrategicProjectFromScratch_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.StrategicProjectFromExistingProject_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.WorkbenchApproval_Tests"));					
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkStrategicProjectToContract_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkStrategicProjectToRequest_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkStrategicProjectToSave_Tests"));		
			myClasses.add(new XmlClass("com.main.iManageFlows.LinkStrategicProjectToSource_Tests"));		


			break;
		case "SIM":
		case "iSupplier":
			myClasses.add(new XmlClass("com.main.iSupplierFlows.FlowSIM_Sanity"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.GeneralSIM"));	
			myClasses.add(new XmlClass("com.main.iSupplierFlows.PotentialSupplierFlow"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.SupplierSearch"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.SIMReport"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.OperationalSupplierFlow"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.iSupplierCRMS_Integration"));
			break;
		case "iRequest":
			// myClasses.add(new XmlClass("com.main.FlowiRequest_new"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.ContractRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.iManageRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.SourcingRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.CommonNavigation"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.NoneRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.RequestViaZSN"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.CRMS_Integration_iRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.ContractRequestTypeInRequestDefination"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.ManageRequestTypeInRequestDefination"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.NoneRequestTypeInRequestDefination"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.SourcingRequestTypeInRequestDefination"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.iRequestWorkflow"));
			break;
		case "SPM":
		case "iPerform":
			myTest.setParallel(XmlSuite.ParallelMode.METHODS);
			myClasses.add(new XmlClass("com.main.iPerformFlows.KPI"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.ScoreCard"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CreateEvent"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CreateSCAR"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CreateProgram"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.SPMAnalyze"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.SPM_CRMS_Integration"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.DashboardTest"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.Define"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.SPMReport"));
			//			myClasses.add(new XmlClass("com.main.iPerformFlows.HelpTestCase"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.LinkAndCloneProgram"));
			break;

		case "eProc":
		case "eProcurement":
			myClasses.add(new XmlClass("com.main.eProcFlows.BudgetCreation"));
			myClasses.add(new XmlClass("com.main.eProcFlows.BlanketPurchaseOrderCreation"));			
			//myClasses.add(new XmlClass("com.main.eProcFlows.CatalogCreation"));

			myClasses.add(new XmlClass("com.main.eProcFlows.CatalogCreation_AddNewItem"));
			
			myClasses.add(new XmlClass("com.main.eProcFlows.CatalogCreation_ZSN"));
			myClasses.add(new XmlClass("com.main.eProcFlows.CatalogCreationFromFile"));
			myClasses.add(new XmlClass("com.main.eProcFlows.CatalogCreationWithContract"));

			myClasses.add(new XmlClass("com.main.eProcFlows.CategoryFormsCreation"));
			myClasses.add(new XmlClass("com.main.eProcFlows.EprocReports"));
			myClasses.add(new XmlClass("com.main.eProcFlows.PCardCreation"));
			myClasses.add(new XmlClass("com.main.eProcFlows.eProcCRMS_Integration"));
			
			//myClasses.add(new XmlClass("com.main.eProcFlows.ProcessFormsCreation_HeaderLevel"));
			//myClasses.add(new XmlClass("com.main.eProcFlows.ProcessFormsCreation_LineLevel"));
			
			myClasses.add(new XmlClass("com.main.eProcFlows.PurchaseOrderCreation_WithInvoice"));
			myClasses.add(new XmlClass("com.main.eProcFlows.PurchaseOrderCreation_WithNoInvoice"));
			myClasses.add(new XmlClass("com.main.eProcFlows.PurchaseOrderCreation_WithReceiptCreation"));
			
			myClasses.add(new XmlClass("com.main.eProcFlows.Requisition_Receipt"));
			myClasses.add(new XmlClass("com.main.eProcFlows.Requisition_WithCatalogItem"));
			myClasses.add(new XmlClass("com.main.eProcFlows.RequisitionCreation"));
			myClasses.add(new XmlClass("com.main.eProcFlows.SupplierRelatedContractsInRepo"));
			//myClasses.add(new XmlClass("com.main.eProcFlows.QuickSourceFromBuyerDesk"));
			
			break;		
		case "eInvoice":
			

			myClasses.add(new XmlClass("com.main.eInvoice.CreditMemoWithoutCreation_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.EformsForInvoiceCreditMemo_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.EformsForRecurringContracts_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.EInvoiceCRMS_Integration_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.InvoiceCreditAgainstPOCreation_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.InvoiceAction_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.InvoiceNonPOCreation_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.Payment_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.Reconciliation_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.RecurringContractCreation_Test"));				
			myClasses.add(new XmlClass("com.main.eInvoice.Reports_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.Uploads_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.Workflow_PO_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.ZSNCreateNonPO_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.ZSNCreateNonPOCreditMemo_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.ZSNCreatePOCreditMemo_Tests"));		
			myClasses.add(new XmlClass("com.main.eInvoice.ZSNCreatePOInvoice_Tests"));		


			break;

		case "Product1":
			myClasses.add(new XmlClass("com.main.Product1.Flow1"));
			myClasses.add(new XmlClass("com.main.Product1.DependentOnFlow1"));
			break;

		case "Product2":
			myClasses.add(new XmlClass("com.main.Product2.Flow2"));

			break;

		case "TMS":
			myClasses.add(new XmlClass("com.main.TMS.CreateRole_Tests"));		
			myClasses.add(new XmlClass("com.main.TMS.UserListing_Tests"));		
			myClasses.add(new XmlClass("com.main.TMS.Preference_Tests"));		
			myClasses.add(new XmlClass("com.main.TMS.Report_Tests"));		
			//myClasses.add(new XmlClass("com.main.TMS.AuditTrail_Tests"));		
			myClasses.add(new XmlClass("com.main.TMS.UserActions_Test"));		
			myClasses.add(new XmlClass("com.main.TMS.UserGroups_Tests"));		
			myClasses.add(new XmlClass("com.main.TMS.BulkDownload_Tests"));		
			break;


		case "ZSN":
			myClasses.add(new XmlClass("com.main.ZSN.ZSNCreateNonPO_Tests"));		
			myClasses.add(new XmlClass("com.main.ZSN.ZSNCreateNonPOCreditMemo_Tests"));		
			myClasses.add(new XmlClass("com.main.ZSN.ZSNCreatePOCreditMemo_Tests"));			
			myClasses.add(new XmlClass("com.main.ZSN.QuickSourceTest"));
			myClasses.add(new XmlClass("com.main.ZSN.RFQEventBidOptimization"));
			myClasses.add(new XmlClass("com.main.ZSN.CreateClauseTest"));
			myClasses.add(new XmlClass("com.main.ZSN.CreateContractTest"));
			myClasses.add(new XmlClass("com.main.ZSN.CreateTemplateTest"));
			myClasses.add(new XmlClass("com.main.ZSN.PotentialSupplierFlow"));
			myClasses.add(new XmlClass("com.main.ZSN.RequestViaZSN"));
			myClasses.add(new XmlClass("com.main.ZSN.KPI"));
			myClasses.add(new XmlClass("com.main.ZSN.ScoreCard"));
			myClasses.add(new XmlClass("com.main.ZSN.CreateEvent"));

			;		
			break;	


		case "FlexiForm":
			myClasses.add(new XmlClass("com.main.eInvoice.CreateSCAR"));
			myClasses.add(new XmlClass("com.main.iManageFlows.PotentialSupplierFlow"));
			myClasses.add(new XmlClass("com.main.iMasterFlow.QuickSourceTest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.ContractRequest"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.RequestViaZSN"));

		}

		myTest.setXmlClasses(myClasses);

	}

	private static List<String> setSystemParams(List<String> systemParams){	
		systemParams.add("HubIP");
		systemParams.add("SSOHostedServer");
		systemParams.add("ExecutionLocation");
		systemParams.add("BrowserType");
		systemParams.add("ExecutionType");
		return systemParams;
		/*systemParams.add("DatasheetsLocation");*/
	}

	private static List<String> setConfigParams(List<String> configParams){
		configParams.add("Product");
		configParams.add("Environment");
		configParams.add("Setup");
		configParams.add("Tenant");
		configParams.add("Customer");
		configParams.add("UserAccount");
		configParams.add("UserName");
		configParams.add("Language");
		configParams.add("ReleaseTrain");
		configParams.add("LoginType");
		return configParams;
	}

	private static List<String> setConfigDetails(ZycusCoreDBConnect objConnect, String[] args, List<String> configDetails) throws Exception{
		configDetails.add(args[0]);

		productName = args[0];
		environmentFromJenkins = args[1];

		switch (environmentFromJenkins) {
		case "Prod":
			environment = "Production";
			break;
		case "AWSSingapore":
			environment = "AWS Singapore";
			break;
		case "Ausprod":
			environment = "AWS Australia Production";
			break;
		case "AUSUAT":
			environment = "AWS Australia Staging";
			break;
		case "STAGINGVMWARE":
			environment = "Staging";
			break;
		case "Awsprod":
			environment = "AWS UK";
			break;
		case "DEVINTVMWARE":
			environment = "DevInt";
			break;
		case "Rmpartner":
			environment = "RM";
			break;
		case "Partner":
			environment = "Partner";
			break;
		}


		// String environment = environmentFromJenkins.replace("_", " ");
		String setup = environment;
		configDetails.add(environment);
		configDetails.add(setup);

		String[][] params = objConnect.getExecutionParameters(environment);
		//		System.out.println("Displaying Execution Parameters");
		for (int i = 1; i <= 7; i++) {
			configDetails.add(params[0][i - 1]);
			//			System.out.println(params[0][i - 1]);
		}
		return configDetails;
	}

	private static List<String> setSystemDetails(ZycusCoreDBConnect objConnect,String environment,  List<String> systemDetails) throws Exception{
		String[][] sysParams = objConnect.getSystemParameters(environment);
				System.out.println("Displaying System Parameters");
		for (int i = 1; i <= 5; i++) {
			systemDetails.add(sysParams[0][i - 1]);
					System.out.println(sysParams[0][i - 1]);
		}
		return systemDetails;
	}

	private static XmlSuite createXMLSuite(){
		// Create an instance of XML Suite and assign a name for it.
		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("MySuite");
		mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
		mySuite.setThreadCount(15);
		return mySuite;
	}


	public static List<Class<ListenerTest>> createXMLListeners(){
		// Create an instance of XML Suite and assign a name for it.	
		List<Class<ListenerTest>> listnerClasses = new ArrayList<Class<ListenerTest>>();
		listnerClasses.add(com.aventstack.extentreports.common.ListenerTest.class);

		return listnerClasses;
	}

	private static XmlTest createXMLTest(XmlSuite mySuite, String product){
		// Create an instance of XmlTest and assign a name for it.
		XmlTest myTest = new XmlTest(mySuite);
		myTest.setName("MyTest_"+product);
		myTest.setParallel(XmlSuite.ParallelMode.CLASSES);
		return myTest;
	}

	private static String[] getListOfProducts(String productList){
		return productList.split(",");
	}
}
