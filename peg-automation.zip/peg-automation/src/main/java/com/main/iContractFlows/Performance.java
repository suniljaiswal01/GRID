package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Performance.SpendByContractingParty;
import com.zycus.IContract.Performance.SpendByContracts;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;;

public class Performance extends CommonTests1{
	
	iContract_CommonFunctions objFunctions;
	
	
	public Performance() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	

	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginPerformance() throws Exception {
		
		displayStyle =getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class,dataProvider = "SpendByContractingParty", description = "",dependsOnMethods = "loginPerformance")
	@TestDetails(TestID="iContract_10")
	public void SpendByContractingParty(String searchBy,String searchValue) throws Exception {
		SpendByContractingParty objParty = new SpendByContractingParty(driver, logger,searchBy,searchValue); 
		objParty.searchContracts(searchBy, searchValue);
	}
	
	@Test(dependsOnMethods = {"SpendByContractingParty","com.main.iContractFlows.CreateContractTest.AuthorContract_Negotiate"})
	@TestDetails(TestID="iContract_11")
	public void SpendByContracts() throws Exception {
		String searchBy = "Contract Title";
		SpendByContracts objContracts = new SpendByContracts(driver, logger,searchBy,CreateContractTest.contractTitle); 
		objContracts.searchContracts(searchBy, CreateContractTest.contractTitle);
	}
	
}