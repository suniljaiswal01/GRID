package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Dashboard.AlertsReminders;
//import com.main.iSource.CommonTests1;
import com.zycus.IContract.Dashboard.CommonDashboard;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;;

public class ReportsAndDashboard extends CommonTests1{
	
	public ReportsAndDashboard() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}

	//private ExtentTest logger;
	private String Product = "iContract";
	iContract_CommonFunctions objFunctions;
	private String newDashboardName;
	private String dashboardName;
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReportAndDashBoard() throws Exception {
	
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	
	@Test(dependsOnMethods = "loginReportAndDashBoard")
	@TestDetails(TestID="iContract_13")
	public void CommonDashboard() throws Exception {
		String dashboardLayout = "50:50";
		String report1 = "All Expired Contracts";
		String report2 = "Clause Usage Statistics";
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		dashboardName = objCustomDashboard.saveNewDashboardToMyDashboard(dashboardLayout, report1, report2);
	}
	
	@Test(dependsOnMethods = "CommonDashboard")
	@TestDetails(TestID="iContract_14")
	public void alertAndReminders() throws Exception {
		AlertsReminders alertReminders = new AlertsReminders(driver, logger);
		alertReminders.checkIfReminderIsVisible();
		alertReminders.checkIfAlertIsVisible();
	}
	
}