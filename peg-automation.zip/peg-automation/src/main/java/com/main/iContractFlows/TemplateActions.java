package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Templates.Templates;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;;

public class TemplateActions extends CommonTests1{
	
	public TemplateActions() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	
	//private ExtentTest logger;
	private String Product = "iContract";
	iContract_CommonFunctions objFunctions;
	private String templateName;
	
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginTemplateAction() throws Exception {	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = {"loginTemplateAction","com.main.iContractFlows.CreateClauseTest.createClause"},alwaysRun=true,dataProviderClass = iContract_DataProviderTestNG.class, dataProvider = "ClauseCategory")
	@TestDetails(TestID = "iContract_5")
	public void createTemplate(String clauseCategory,String reviewerName,String accocBaseType,String language) throws Exception {
		
		Templates createTemplate = new Templates(driver, logger);
		templateName = createTemplate.createTemplate(CreateClauseTest.clauseName);	
	}
	
	
	@Test(dependsOnMethods = "createTemplate")
	@TestDetails(TestID="iContract_5")
	public void viewEditTemplate() throws Exception {
		Templates objTemplates = new Templates(driver, logger); 	
		objTemplates.filterByText("Template No. - Name", templateName);
		
		objTemplates.selectActionTemplate("View/Edit");
		String templateEdited= objTemplates.viewEditTemplate();
		
		objTemplates.filterByText("Template No. - Name", templateEdited);
		objTemplates.selectActionTemplate("Download Template");
		objTemplates.downloadTemplate(templateEdited);
		
		objTemplates.filterByText("Template No. - Name",templateEdited);
		objTemplates.selectActionTemplate("Deactivate");
		objTemplates.filterByText("Template No. - Name",templateEdited);
		objTemplates.deactivateActivateTemplate(templateEdited, "Deactive");
		
		objTemplates.filterByText("Template No. - Name",templateEdited);
		objTemplates.selectActionTemplate("Activate");
		objTemplates.filterByText("Template No. - Name",templateEdited);
		objTemplates.deactivateActivateTemplate(templateEdited, "Active");
		
		objTemplates.filterByText("Template No. - Name",templateEdited);
		objTemplates.selectActionTemplate("Delete");
		objTemplates.deleteTemplate();
		
	}
	
}