package com.main.iContractFlows.copy;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.main.CommonTests1;
import com.main.TestDetails;
//import com.main.iSource.CommonTests1;
import com.zycus.IContract.Dashboard.CommonDashboard;
import com.zycus.IContract.Reports.Reports;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.eInvoice_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;;

public class ReportsAndDashboard extends CommonTests1{
	
	public ReportsAndDashboard() throws Exception {
		super();
	}

	private ExtentTest logger;
	private String Product = "iContract";
	eInvoice_CommonFunctions objFunctions;
	private String newDashboardName;
	private String dashboardName;
	
	@BeforeClass
	public void beforeClass(){
		parentLogger = parent.createNode(Product);
	}
	/*
	@BeforeMethod
	public void beforeMethod(Method method){
		TestDetails set = method.getAnnotation(TestDetails.class);
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		loginCredentials = objConnect.getLoginCredentials(set.TestID());
		logger = parentLogger.createNode(method.getName());
	}*/
	
	@Test(groups = "Login", dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login",alwaysRun = true, priority =1)
	@TestDetails(TestID="iContract_1")
	public void login(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		 
		driver = startSession(this.getClass().getName());
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		displayStyle =getDisplayStyle(driver, logger, loginCredentials);
		//displayStyle = "Rainbow";
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "addReportToNewDashboard", 
			dataProvider = "", 
			priority = 7)
	@TestDetails(TestID="iContract_3")
	//public void addReportToExistingDashboard(String dashboardFolder, String existingDashboardName, String reportName, String...navigationTabs) throws Exception {
	public void addReportToExistingDashboard() throws Exception {
		String reportName = "All Expired Contracts";
		String existingDashboardName = newDashboardName;
		String dashboardFolder = "MyDashboard";
		
		objFunctions.navigateToMainPage(displayStyle, Product, "Reports");
		Reports objReports = new Reports(driver, logger);
		//try{
			objReports.addReportToExistingDashboard(reportName, dashboardFolder, existingDashboardName);
			objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard", "Common Dashboard");
			CommonDashboard objDashboard = new CommonDashboard(driver, logger);
			if(objDashboard.verifyReportExistInDashboard(existingDashboardName, reportName))
				logger.pass(reportName +" added to Dashboard "+ existingDashboardName);
			else
				logger.fail(reportName +" not added to Dashboard "+ existingDashboardName);
		/*}catch(Exception e){
			e.printStackTrace();
			logger.fail(reportName +" not added to Dashboard "+ existingDashboardName);
		}*/
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "login", 
			dataProvider = "", 
			priority = 3)
	@TestDetails(TestID="iContract_4")
	//public void addReportToNewDashboard(String dashboardFolder, String layout, String reportName, String...navigationTabs) throws Exception {
	public void addReportToNewDashboard() throws Exception {
		//********************Commenting it as product selction button is not displayed after addition of Report to Dashboard*************************//
		
		String reportName = "Clause Usage Statistics";
		String dashboardFolder = "MyDashboard";
		String layout ="50:50";
		
		objFunctions.navigateToMainPage(displayStyle, Product, "Reports");
		Reports objReports = new Reports(driver, logger);
		//try{
			newDashboardName = objReports.addReportToNewDashboard(reportName, dashboardFolder, layout);
			objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard", "Common Dashboard");
			CommonDashboard objDashboard = new CommonDashboard(driver, logger);
			if(objDashboard.verifyReportExistInDashboard(newDashboardName, reportName))
				logger.pass(reportName +" added to Dashboard "+ newDashboardName);
			else
				logger.fail(reportName +" not added to New Dashboard");
		/*}catch(Exception e){
			e.printStackTrace();
			logger.fail(reportName +" not added to New Dashboard");
		}*/
		//newDashboardName = "NewDashboard_129425";
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 4)
	@TestDetails(TestID="iContract_13")
	public void CommonDashboard(String... navigationTabs) throws Exception {
		String dashboardLayout = "50:50";
		String report1 = "All Expired Contracts";
		String report2 = "Clause Usage Statistics";
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		//dashboardName = objCustomDashboard.addNewDashboard(dashboardLayout, report1, report2);
		dashboardName = objCustomDashboard.saveNewDashboardToMyDashboard(dashboardLayout, report1, report2);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 5)
	@TestDetails(TestID="iContract_13")
	
	public void verifyReportInDashboard(String... navigationTabs) throws Exception {
		String report1 = "Clause Usage Statistics";
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.verifyReportExistInDashboard(dashboardName, report1);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 6)
	@TestDetails(TestID="iContract_13")
	public void exportdashbaord(String... navigationTabs) throws Exception {
		String exportFormat = "Excel";
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.exportDashboard(dashboardName, exportFormat);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 8)
	@TestDetails(TestID="iContract_13")
	public void markAsDefault(String... navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.markDashboardAsDefault(dashboardName);
		logger.pass("Dashboard "+dashboardName+" marked as default");
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 9)
	@TestDetails(TestID="iContract_13")
	public void deleteDashboard(String... navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		if(objCustomDashboard.deleteDashboard(dashboardName))
			logger.pass("Dashboard : "+ dashboardName + " deleted");
		else
			logger.fail("Dashboard : "+ dashboardName + " not deleted");
	}
	
}