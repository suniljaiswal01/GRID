package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Search.ContractSearch;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;;

public class ContractSearches extends CommonTests1{
	
	public ContractSearches() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	
	/*private ExtentTest logger;*/
	private String Product = "iContract";
	iContract_CommonFunctions objFunctions;

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginContactSearch() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class,dataProvider = "TypeSubType",dependsOnMethods = "com.main.iContractFlows.CreateContractTest.AuthorContract_Negotiate")
	@TestDetails(TestID="iContract_16")
	public void searchContract(String contractType, String contractSubType) throws Exception {
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.searchContract(contractType, "Contract Number", CreateContractTest.contractNumber);
	}
	
	@Test(dependsOnMethods = "searchContract")
	@TestDetails(TestID="iContract_16")
	public void MostViewedContracts() throws Exception {
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.verifyTopFiveContractsDisplayed();
	}
	
	@Test(dependsOnMethods = "MostViewedContracts")
	@TestDetails(TestID="iContract_16")
	public void RecentSearches() throws Exception {
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.verifyTopFiveRecentSearchesDisplayed();
	}
	
}