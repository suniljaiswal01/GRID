package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Reports.Reports;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;

public class iContractReport extends CommonTests1{

//	private ExtentTest logger;
	/*private String Product = "iSave";
	eInvoice_CommonFunctions objFunctions;*/

	String projectType = null;

	public iContractReport() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginReport() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class,dependsOnMethods = "loginReport",dataProvider = "Reports")
	@TestDetails(TestID="iContract_18")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}

	/*@Test(dataProviderClass = iContract_DataProviderTestNG.class, dependsOnMethods = "Reports",dataProvider = "ModifyReports")
	@TestDetails(TestID="iContract_18")
	public void ModifyReport(String report) throws Exception {

		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
	}*/
}
