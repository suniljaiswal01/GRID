package com.main.iContractFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Setup.ProductConfig.ProdConfig;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;;

public class iContract_FlexiForms extends CommonTests1{
	
	public iContract_FlexiForms() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	
	iContract_CommonFunctions objFunctions;
	String sectionName;
	
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginFlexiForm() throws Exception {	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(dependsOnMethods = "loginFlexiForm", dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "Flexiform")
	@TestDetails(TestID="iContract_15")
	public void flexiForm(String sectionDesc, String sectionLayout, String fieldDefaulVal, String fieldMaxChar,String isFieldMandatory) throws Exception {
		ProdConfig objConfig = new ProdConfig(driver, logger); 
		int fieldMaxCharInt = Integer.parseInt(fieldMaxChar);
		boolean isFieldMandatoryBoolean = Boolean.parseBoolean(isFieldMandatory);
		sectionName= objConfig.addFlexiForm(sectionDesc, sectionLayout, fieldDefaulVal, fieldMaxCharInt, isFieldMandatoryBoolean);	
	}
	
	@Test(dependsOnMethods = "flexiForm")
	@TestDetails(TestID="iContract_12")
	public void verifyFlexifForminContract() throws Exception {
		if(sectionName!=null){
			ProdConfig objConfig = new ProdConfig(driver, logger); 
			objConfig.verifyFlexiFormInContract(sectionName);
		}else
			throw new SkipException("Unable to edit flexiform");
		
	}
}