package com.main.iContractFlows.copy;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Search.ContractSearch;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;;

public class ContractSearches extends CommonTests1{
	
	public ContractSearches() throws Exception {
		super();
	}
	
//	private ExtentTest logger;
	private String Product = "iContract";
	eInvoice_CommonFunctions objFunctions;
	
	
	@Test(groups = "Login", dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login",alwaysRun = true, priority =1)
	@TestDetails(TestID="iContract_1")
	public void login(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		
		driver = startSession(this.getClass().getName());
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		//displayStyle = "Rainbow";
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(description = "",
			dependsOnMethods = "login",
			priority = 2)
	@TestDetails(TestID="iContract_14")
	public void MostViewedContracts() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Search");
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.verifyTopFiveContractsDisplayed();
	}
	
	@Test(description = "",
			dependsOnMethods = "login",
			priority = 3)
	@TestDetails(TestID="iContract_15")
	public void RecentSearches() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Search");
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.verifyTopFiveRecentSearchesDisplayed();
	}
	
}