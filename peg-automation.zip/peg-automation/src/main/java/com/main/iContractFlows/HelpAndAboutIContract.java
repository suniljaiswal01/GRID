package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.Help.AboutIContract;
import com.zycus.IContract.Help.AdminOnlineHelp;
import com.zycus.IContract.Help.HelpVideos;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;
import common.UserProfile.UserProfile;;

public class HelpAndAboutIContract extends CommonTests1{
	
	public HelpAndAboutIContract() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	//private ExtentTest logger;
	private String Product = "iContract";
	eInvoice_CommonFunctions objFunctions;
	
	
	/*@BeforeClass
	public void beforeClass(){
		parentLogger = parent.createNode(Product);
	}
	
	@BeforeMethod
	public void beforeMethod(Method method){
		TestDetails set = method.getAnnotation(TestDetails.class);
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		loginCredentials = objConnect.getLoginCredentials(set.TestID());
		logger = parentLogger.createNode(method.getName());
	}*/
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginHelpAndAbout() throws Exception {
		 
		driver = startSession(this.getClass().getName());
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		//displayStyle = "Rainbow";
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(dependsOnMethods = "loginHelpAndAbout",
			priority = 5)
	@TestDetails(TestID="iContract_1")
	public void aboutIContract() throws Exception {
		//String version = "18.10.1.1";
		/*JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("$(\"#ui-id-2\").animate({ scrollTop: \""+300+"px\" })");*/
		
		/*Actions actions = new Actions(driver);
		WebElement mainMenu = driver.findElement(By.id("mCSB_9_container"));
		actions.moveToElement(mainMenu);*/
		
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","About iContract");
		AboutIContract objAbout = new AboutIContract(driver, logger);
		objAbout.verifyVersion();
	}
	
	@Test(dependsOnMethods = "loginHelpAndAbout",
			priority = 2)
	@TestDetails(TestID="iContract_1")
	public void adminOnlineHelp() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","Admin Online Help");
		AdminOnlineHelp objOnlineHelp = new AdminOnlineHelp(driver, logger);
		objOnlineHelp.verifyOnlineHelpPage();
	}
	
	@Test(dependsOnMethods = "loginHelpAndAbout",
			priority = 3)
	@TestDetails(TestID="iContract_1")
	public void helpVideos() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","Help Videos");
		HelpVideos objhelpVideo = new HelpVideos(driver, logger);
		objhelpVideo.checkReleaseVideos();
		logger.pass("Release Videos verified");
	}
	
	/*@Test(dependsOnMethods = "login",
			priority = 8)
	@TestDetails(TestID="iContract_13")
	public void onlineHelp() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","Online Help");
		OnlineHelp objOnlineHelp = new OnlineHelp(driver, logger);
		objOnlineHelp.verifyOnlineHelpPage();
	}*/
	
	@Test(description = "",
			dependsOnMethods = "loginHelpAndAbout",
			priority = 4)
	@TestDetails(TestID="iContract_1")
	public void checkUserProfile() throws Exception {
		UserProfile objProfile = new UserProfile(driver, logger);
		objProfile.verifyUserProfile();
		logger.pass("User Profile verified");
	}
	
	/*@AfterClass
	public void afterClass(){
		//driver.quit();
	}*/
	
}