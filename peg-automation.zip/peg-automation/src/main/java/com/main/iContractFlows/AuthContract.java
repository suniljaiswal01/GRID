package com.main.iContractFlows;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.main.ZycusCoreDriver;
import com.zycus.IContract.ManageContracts.AuthorContract;
import com.zycus.IContract.ManageContracts.ContractSummary;
import com.zycus.IContract.ManageContracts.ContractingParty;
import com.zycus.IContract.ManageContracts.ContractsPendingReview;
import com.zycus.IContract.ManageContracts.CreateContract;
import com.zycus.IContract.ManageContracts.Documents;
import com.zycus.ZSN.MyContracts.ViewContracts;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class AuthContract extends CommonTests1{
	String templateName = "Contract_Automation_Template";
	boolean isExternalTemplateAvailable = false;
	
	//boolean byPassAuthorStage = false;
	boolean byPassAuthorStage;
	//boolean commonWorkFlowNotEnabled = true;
	boolean commonWorkFlowNotEnabled;
	boolean authWorkflowAvailable = true;
	boolean signOffWorkflowAvailable = true;
	boolean isTouchFreeContract = true;
	
	boolean isNegotiating = true;
			
	public AuthContract() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}
	
	
	/**
	 * @param contractNumber
	 *            the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	eInvoice_CommonFunctions objFunctions;
	private String contractNumber;
	private String contractTitle;
	private String Product = "iContract";
	private boolean isSignoffWorkflowActive = false;
	private boolean isFileDownloaded;
	private boolean isFileSaved;
	private String contractType;
	private String contractSubType;
	
	/*//ZCS production - Navisite
	//private String clauseCategory = "Test";
	//ZCS RM
	//private String clauseCategory = "Category 1";
	private String clauseTitle;
	private String templateName;
	private String contractTitle = null;
	private boolean isFileDownloaded = true;
	private String newDashboardName;
	private String dashboardName;
	
	private boolean isNegotiationAllowed = false;
	private boolean isExternalTemplateAvailable = false;
	
	private boolean sendForSigning = true;
	
	//Verify if signoffWorkflow is active or not
	private boolean isSignoffWorkflowActive = false;*/
	
	@Test(dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login")
	@TestDetails(TestID="iContract_1")
	public void Login_AuthContract(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		ZycusCoreDriver objZCD = new ZycusCoreDriver(); 
		displayStyle = objZCD.getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	/*@Test(dataProviderClass = iContract_DataProviderTestNG.class, dataProvider = "TypeSubType", description = "",
			dependsOnMethods = "Login_AuthContract")
	@TestDetails(TestID="iContract_13")
	public void verifyByPassAuth(String contractType, String contractSubType) throws Exception {
		this.contractType = contractType;
		this.contractSubType = contractSubType;
		ProdConfig objProdConfig = new ProdConfig(driver,logger);
		objProdConfig.navigateToAppSettings();
		byPassAuthorStage = objProdConfig.verifyByPassAuthSelected();
		System.out.println("Bypass Auth Stage : "+byPassAuthorStage);
		commonWorkFlowNotEnabled = objProdConfig.verifyCommonWorkflowNotEnabled();
		System.out.println("Common Workflow Not Enabled : "+commonWorkFlowNotEnabled);
	}
	
	
	@Test(description = "",
			dependsOnMethods = "verifyByPassAuth")
	@TestDetails(TestID="iContract_2")
	public void authorContract_Negotiate() throws Exception {
		AuthorContract objAuthor = new AuthorContract(driver, logger, contractType, contractSubType);
		objAuthor.createContract(templateName, isNegotiating, isExternalTemplateAvailable);
		
		//Verify Yellow btn- Draft in Progress
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		contractTitle = objSummary.getContractTitle();
		contractNumber = objSummary.getContractNum();
		System.out.println("Contract Number created here is :"+ contractNumber);
		objContract.closeContract();
		//Check row created with status as 'Draft in Progress'
		objAuthor.verifyContractStatusInGrid(contractNumber,"Draft in Progress");
	}*/
	
	@Test(description = "",
			dependsOnMethods = "authorContract_Negotiate")
	@TestDetails(TestID="iContract_4")
	public void addContractingParties() throws Exception {
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigateToStage(contractNumber, "Author");
		//Contracting Party
		ContractingParty objContParty = new ContractingParty(driver, logger);
		objContract.navigate_ContractSubTabs("Contracting Party");
		objContParty.addContractingParties();
	}
	
	/*@Test(description = "",
			dependsOnMethods = "addContractingParties", priority = 4)
	@TestDetails(TestID="iContract_4")
	public void proceedToAuthApproval() throws Exception {
		ContractSummary objSummary = new ContractSummary(driver, logger);
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		objSummary.proceedToNegotiate();
	}
	
	@Test(description = "",
			dependsOnMethods = "proceedToAuthApproval", priority = 4)
	@TestDetails(TestID="iContract_4")
	public void intiateAuthWorkflow() throws Exception {
		if(!byPassAuthorStage){
			ContractSummary objSummary = new ContractSummary(driver, logger);
			String workflowApprover = objSummary.getWorkflowApprover_AuthStage();
			System.out.println("Approver : "+workflowApprover);
			driver.quit();
			ZycusCoreDriver1 objZCD = new ZycusCoreDriver1(); 
            WebDriver driver2 = objZCD.startSession(this.getClass().getName());
            displayStyle = objZCD.getDisplayStyle(driver2, logger, loginCredentials,workflowApprover); 
            driver=driver2;
		}else
			throw new SkipException("Auth Workflow not active");			
	}*/
	
	@Test(description = "",
			dependsOnMethods = "intiateSignOffWorkflow", priority = 7)
	@TestDetails(TestID="iContract_9")
	public void approveAuth() throws Exception {
		if(!byPassAuthorStage){
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
			driver.quit();
		}else
			throw new SkipException("Auth Workflow not active");		
	}
	
	/*@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 6)
	@TestDetails(TestID="iContract_4")
	public void addContractOutline() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Outline");
		ContractOutline objOutline = new ContractOutline(driver, logger);
		objOutline.createVersion();
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractOutline",
			priority = 7)
	@TestDetails(TestID="iContract_4")
	public void addLineItems() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Line Items
		objContract.navigate_ContractSubTabs("Line Items");
		LineItems objItems = new LineItems(driver, logger);
		objItems.createLineItem();
	}
	
	@Test(description = "",
			dependsOnMethods = "addLineItems",
			priority = 8)
	@TestDetails(TestID="iContract_4")
	public void uploadDocuments() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Line Items
		objContract.navigate_ContractSubTabs("Documents");
		Documents objDoc = new Documents(driver, logger);
		//provide no of documents to upload 
		objDoc.selectDocuments(2);
	}
	
	@Test(description = "",
			dependsOnMethods = "addLineItems",
			priority = 9)
	@TestDetails(TestID="iContract_4")
	public void addMilestones() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Add Milestones
		objContract.navigate_ContractSubTabs("Milestones");
		Milestone objMilestone = new Milestone(driver, logger);
		objMilestone.addMilestone();
	}
	
	@Test(description = "",
			dependsOnMethods = "addMilestones",
			priority = 10)
	@TestDetails(TestID="iContract_4")
	public void createVersion() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		Thread.sleep(5000);
		objContract.navigate_ContractSubTabs("Timeline");
		Timeline objTimeline = new Timeline(driver, logger, contractTitle);
		if(objTimeline.verifyVersionCreated())
			logger.pass("Version created and Downloaded");
		else
			logger.fail("Version not created or Downloaded");
		
		//if(isDocUploaded){
		if(objTimeline.verifyDocumentCreated())
			logger.pass("Document visible in timeline and Downloaded");
		else
			logger.fail("Document not visible or Downloaded in timeline");
	}*/
	
	//If negotaiation is allowed then only Contract can be sent for Internal review
	/*@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 12)
	@TestDetails(TestID="iContract_4")
	public void sendForInternalReview() throws Exception {
		//boolean sendForInternalReview = false;
		//if(sendForInternalReview){
		if(isNegotiationAllowed){
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.navigate_ContractSubTabs("Contract Summary");
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.sendForApproval();
			objContract.navigate_ContractSubTabs("Author Review");
			objSummary.authorReview();
			
			objFunctions.closeBrowser();
			
			Login objLogin = new Login(driver, logger);
			objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
			objFunctions.switchToWindow("Rainbow Home");
			objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Authoring Stage", contractNumber, "Approve");
			objFunctions.closeBrowser();
		}else
			throw new SkipException("Skipping this exception");
	}
	*/
	@Test(description = "",
			dependsOnMethods = "addContractingParties", priority = 5)
	@TestDetails(TestID="iContract_4")
	public void sendForInternalReview() throws Exception {
		//boolean sendForInternalReview = false;
		//if(sendForInternalReview){
		
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.navigate_ContractSubTabs("Contract Summary");
			ContractSummary objSummary = new ContractSummary(driver, logger);
		if(isNegotiating){
			objSummary.sendForNegotiation("negotiation Comment");
			Thread.sleep(2500);
			objSummary.sendToContractingParty();
			Thread.sleep(2500);
		}else{
			objSummary.sendForApproval();
			Thread.sleep(2500);
			objSummary.sendToContractingParty();
			Thread.sleep(2500);
			objFunctions.closeBrowser();
			
			Login objLogin = new Login(driver, logger);
			objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
			objFunctions.switchToWindow("Rainbow Home");
			objFunctions.navigateToMainPage(displayStyle, Product , "Manage Contracts", "Contract Pending Review");
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Authoring Stage", contractNumber, "Approve");
			objFunctions.closeBrowser();
		}
			//throw new SkipException("Skipping this exception");
	}
	
	@Test(dependsOnMethods = "sendForInternalReview", dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "ContractingParty", priority = 5)
	@TestDetails(TestID="iContract_5")
	public void Login_ZSN_AuthContract(String supplierEmail, String supplierPassword, String SupplierContactName, String SupplierCompanyName) throws Exception{
		driver1 = objFrameworkUtility.getWebDriverInstance(
					System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		Login objLogin = new Login(driver1, logger, supplierEmail, supplierPassword);
		callAndLog(driver1, logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
	}
	
	/*@Test(description = "",
			dependsOnMethods = "Login_ZSN_AuthContract", priority = 5)
	@TestDetails(TestID="iContract_6")
	public void saveSupplierCopy() throws Exception {
		//Download Contract in ZSN
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		isFileSaved  = objViewContracts.saveContract(contractNumber, contractTitle, "docx");
	}
	
	@Test(description = "",
			dependsOnMethods = "saveSupplierCopy", priority = 5)
	@TestDetails(TestID="iContract_5")
	public void uploadSupplierCopy() throws Exception {
		if(isFileSaved){
		try{
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.uploadSupplierCopy(contractTitle.replace("+", " ").replace(":", "_"));
			}catch(Exception e){
				Documents objDoc1 = new Documents(driver, logger);
				objDoc1.addDocument_ForEnd(contractTitle);
			}
		}else
			throw new SkipException("Skipping this exception");
	}*/
	
	/*@Test(dependsOnMethods = "Login_ZSN_AuthContract")
	@TestDetails(TestID="iContract_6")
	public void markAsReviewed() throws Exception {
		ViewContracts objContracts = new ViewContracts(driver1, logger);
		objContracts.performAction(contractNumber, "Mark as Reviewed");
	}*/
	
	/*@Test(description = "",
			dependsOnMethods = "uploadSupplierCopy", priority = 5)
	@TestDetails(TestID="iContract_4")
	public void proceedToSignOff() throws Exception {
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.proceedToNegotiate();
	}*/
	
	/*@Test(description = "",
			dependsOnMethods = "proceedToSignOff", priority = 6)
	@TestDetails(TestID="iContract_4")
	public void intiateSignOffWorkflow() throws Exception {
		ContractSummary objSummary = new ContractSummary(driver, logger);
		if(isSignoffWorkflowActive){
			String workflowApprover = objSummary.getWorkflowApprover_Signoff();
			System.out.println("Approver : "+workflowApprover);
			driver.quit();
			ZycusCoreDriver1 objZCD = new ZycusCoreDriver1(); 
            WebDriver driver2 = objZCD.startSession(this.getClass().getName());
            displayStyle = objZCD.getDisplayStyle(driver2, logger, loginCredentials,workflowApprover); 
            driver=driver2;
		}else
			throw new SkipException("Sign off Workflow not active");			
	}*/
	
	@Test(description = "",
			dependsOnMethods = "intiateSignOffWorkflow", priority = 7)
	@TestDetails(TestID="iContract_9")
	public void approveContract() throws Exception {
		if(isSignoffWorkflowActive){
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
			driver.quit();
		}else
			throw new SkipException("Sign off Workflow not active");		
	}
	
	@Test(description = "",
			dependsOnMethods = "approveContract", priority = 8)
	@TestDetails(TestID="iContract_4")
	public void intiateSigningProcess() throws Exception {
		if(isSignoffWorkflowActive){
			ZycusCoreDriver objZCD = new ZycusCoreDriver(); 
			WebDriver driver3 = objZCD.startSession(this.getClass().getName());
	        displayStyle = objZCD.getDisplayStyle(driver3, logger, loginCredentials); 
	        driver=driver3;
		}else
			throw new SkipException("Sign off Workflow not active");
	}
	
	@Test(description = "",
			dependsOnMethods = "intiateSigningProcess", priority = 9)
	@TestDetails(TestID="iContract_10")
	public void navigateToContractForSignOff() throws Exception {
		if(isSignoffWorkflowActive){
			AuthorContract objAuthor = new AuthorContract(driver, logger);
			objAuthor.navigateToStage(contractNumber, "Sign off");
		}else
			throw new SkipException("Sign off Workflow not active");
	}
	
	/*@Test(description = "",
			dependsOnMethods = "uploadSupplierCopy",priority = 8)
	@TestDetails(TestID="iContract_4")
	public void proceedToSignOff() throws Exception {
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.proceedToSignOff();
	}*/
	
	@Test(description = "",
			dependsOnMethods = "proceedToSignOff", priority = 10)
	@TestDetails(TestID="iContract_11")
	public void sendForSigning() throws Exception {
		/*AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.navigateToStage(contractNumber, "Sign off");*/
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.sendForSigning(isSignoffWorkflowActive,"Offline Signing");		
	}
	
	@Test(description = "",
			dependsOnMethods = "sendForSigning", priority = 10)
	@TestDetails(TestID="iContract_6")
	public void downloadContract() throws Exception {
		//Download Contract in ZSN
		driver1.navigate().refresh();
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		isFileDownloaded  = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
	}
	
	@Test(description = "",
			dependsOnMethods = "downloadContract", priority = 10)
	@TestDetails(TestID="iContract_5")
	public void uploadContract() throws Exception {
		if(isFileDownloaded){
		try{
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.uploadContract(contractTitle);
			}catch(Exception e){
				Documents objDoc1 = new Documents(driver, logger);
				objDoc1.addDocument_ForEnd(contractTitle);
			}
		}else
			throw new SkipException("Skipping this exception");
	}
	
/*
	@Test(description = "",
			dependsOnMethods = "uploadContract", priority = 11)
	@TestDetails(TestID="iContract_5")
	public void addToRepository() throws Exception {
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.addContractToRepository();
		//Check row created with status as 'Added to Repository'
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.verifyContractStatusInGrid(contractNumber,"Added to Repository");
	}
	
	@Test(description = "",
			dependsOnMethods = "addToRepository", priority = 12)
	@TestDetails(TestID="iContract_12")
	public void activateContract() throws Exception {
		Repository objRepo = new Repository(driver, logger);
		objRepo.verifyContractAddedToRepository(contractNumber);
		objRepo.navigateToContractSummary(contractNumber);
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Details");
		ContractDetails objDetails = new ContractDetails(driver, logger);
		objDetails.activateContract("Active","Master Agreement");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.publishContract();
	}*/
	
	/*@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 14)
	@TestDetails(TestID="iContract_4")
	public void approveSignOffStage() throws Exception {
		if(sendForSigning){
			if(isSignoffWorkflowActive){
				Login objLogin = new Login(driver, logger);
				objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
				objFunctions.switchToWindow("Rainbow Home");
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
				ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
				objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
				objFunctions.closeBrowser();
			}else
				throw new SkipException("Skipping this exception");
		}else{
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.skipSigning();
		}
			
	}*/
	
	/*@Test(description = "",
			dependsOnMethods = "proceedToSignOff")
	@TestDetails(TestID="iContract_4")
	public void sendForOfflineSigning() throws Exception {
		//boolean isSignoffWorkflowActive = true;
		objLogin.loginWithUserAcct_PwdMgr("GDQA-P2P@zycus.com");
		objFunctions.switchToWindow("Rainbow Home");
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		objAuthor.clrAllFilters();
		Thread.sleep(2000);
		objAuthor.filterByContractNum(contractNumber);
		objAuthor.navigateToStage(contractNumber, "Sign off");
	
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.sendForSigning(isSignoffWorkflowActive, "Offline Signing");
	}*/
	/*
	@Test(description = "",
			dependsOnMethods = "sendForOfflineSigning",
			priority = 16)
	@TestDetails(TestID="iContract_4")
	public void downloadContractInZSN() throws Exception {
		//Download Contract in ZSN
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		Login objLogin = null;
		if(configurationProperties.getProperty("environment").equals("Production"))
			objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
		else if(configurationProperties.getProperty("environment").equals("RM"))
			objLogin = new Login(driver1, logger, "gauri.joshi@zycus.com", "Right@123");
		
		callAndLog(driver1, logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		isFileDownloaded  = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
	}
	
	@Test(description = "",
			dependsOnMethods = "sendForOfflineSigning",
			priority = 17)
	@TestDetails(TestID="iContract_4")
	public void uploadContract() throws Exception {
		if(isFileDownloaded){
		try{
				ContractSummary objSummary = new ContractSummary(driver, logger);
				objSummary.uploadContract(contractTitle);
			}catch(Exception e){
				Documents objDoc1 = new Documents(driver, logger);
				objDoc1.addDocument_ForEnd(contractTitle);
			}
		}else
			throw new SkipException("Skipping this exception");
	}
	*/
}
