package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.WordConnect.WordConnect;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;;

public class WordConnectTest extends CommonTests1{
	
	public WordConnectTest() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	
	iContract_CommonFunctions objFunctions;
	String sectionName;
	
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginWordConnect() throws Exception {	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}	
	
	@Test(dependsOnMethods = "loginWordConnect")
	@TestDetails(TestID="iContract_6")
	public void wordConnect() throws Exception {
		WordConnect objWordConnect = new WordConnect(driver, logger); 
		if(objWordConnect.wordConnectConfig()) {
			LogScreenshot("PASS","Wordconnect file has downloaded successfully");
		}else {
			LogScreenshot("warning","Wordconnect file has not downloaded successfully");
		}
	}
	
	@Test(dependsOnMethods = "wordConnect",alwaysRun=true)
	@TestDetails(TestID="iContract_8")
	public void viewSentMails() throws Exception {
		WordConnect objWordConnect = new WordConnect(driver, logger); 
		objWordConnect.verifySentMailsPage();	
	}
	
	/*@Test(dependsOnMethods = "viewSentMails",alwaysRun=true)
	@TestDetails(TestID="iContract_7")
	public void OOOAssignment() throws Exception {
		WordConnect objWordConnect = new WordConnect(driver, logger); 
		objWordConnect.verifyOOOAssignmentPage();	
	}*/
	
	@Test(dependsOnMethods = "viewSentMails",alwaysRun=true)
	@TestDetails(TestID="iContract_17")
	public void masterData() throws Exception {
		WordConnect objWordConnect = new WordConnect(driver, logger); 
		objWordConnect.masterDataPage();	
	}
	
	@Test(dependsOnMethods = "masterData",alwaysRun=true)
	@TestDetails(TestID="iContract_19")
	public void manageContractingParties() throws Exception {
		WordConnect objWordConnect = new WordConnect(driver, logger); 
		objWordConnect.manageContractingPartiesPage();
	}
		
}