package com.main.iContractFlows;


import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.ManageContracts.Amendment;
import com.zycus.IContract.ManageContracts.Repository;

import DataProviders.Common_DataProviderTestNG;

public class RepositoryTest extends CommonTests1{

	public static String contractId=null;
	
	public RepositoryTest() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginRepository() throws Exception {	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginRepository")
	@TestDetails(TestID = "iContract_12")
	public void uploadContract() throws Exception {	
		Repository repository = new Repository(driver, logger);
		contractId =repository.uploadContract();
	}
	

	@Test(dependsOnMethods = "uploadContract")
	@TestDetails(TestID = "iContract_12")
	public void cloneInRepository() throws Exception {
		Repository repository = new Repository(driver, logger);
		repository.cloneInRepository(contractId);
	}
	
	@Test(dependsOnMethods = "cloneInRepository")
	@TestDetails(TestID = "iContract_12")
	public void createAmendment() throws Exception {
		Amendment amendment = new Amendment(driver,logger);
		amendment.createAmendment(contractId);
	}
	
	@Test(dependsOnMethods = "createAmendment")
	@TestDetails(TestID = "iContract_12")
	public void delegateAmendment() throws Exception {
		Amendment amendment = new Amendment(driver,logger);
		amendment.delegateAmendment(contractId);
	}
	
	@Test(dependsOnMethods = "delegateAmendment")
	@TestDetails(TestID = "iContract_2")
	public void deleteAmendment() throws Exception {
		Amendment amendment = new Amendment(driver,logger);
		amendment.deleteAmendment(contractId);
	}
	
	@Test(dependsOnMethods = "deleteAmendment")
	@TestDetails(TestID = "iContract_12")
	public void deleteContract() throws Exception {	
		Repository repository = new Repository(driver, logger);
		repository.deleteContract(contractId);
	}
	
}

