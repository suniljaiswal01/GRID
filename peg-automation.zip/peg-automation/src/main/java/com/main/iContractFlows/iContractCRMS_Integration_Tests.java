package com.main.iContractFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
import common.Functions.iContract_CommonFunctions;

public class iContractCRMS_Integration_Tests extends CommonTests1 {
	//private ExtentTest logger;
	public String Product = "iContract";
	iContract_CommonFunctions objFunctions;



	public iContractCRMS_Integration_Tests() throws Exception {
		super();
		setProduct("iContract");
		setClassToLoad("common.Functions.iContract_CommonFunctions");
	}



	@Test(groups = "Login", dependsOnMethods="com.main.iContractFlows.CreateContractTest.AuthorContract_Negotiate",  alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginCRMSIntegration() throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = {"loginCRMSIntegration","com.main.iContractFlows.CreateContractTest.AuthorContract_Negotiate"},dataProviderClass = iContract_DataProviderTestNG.class, dataProvider = "crms_Integration", alwaysRun = true)
	@TestDetails(TestID = "iContract_CRMSIntegration")
	public void crms_reportGeneration(String category, String...data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		if(createNewReport.selectProduct(Product)) {
			createNewReport.selectParams(category,data);
			VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
			verifyReportsField.iContractFieldCheck(category);
			verifyReportsField.exportReport();
			verifyReportsField.backToReportListing();
		}
	}

}
