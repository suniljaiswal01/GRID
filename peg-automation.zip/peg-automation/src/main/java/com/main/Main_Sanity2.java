package com.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class Main_Sanity2 extends JFrame implements ItemListener,ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6178073956726186435L;
	static String environment = null;
	static String productName = null;
	static String environmentFromJenkins = null;
	static JComboBox productBox, environmentBox; 
	static JButton executeButton;
	static String selectedProduct = null;
	static String selectedEnvironment= null;
	static List<String> configDetails = new ArrayList<String>();
	static List<String> configParams = new ArrayList<String>();
	static List<String> systemParams = new ArrayList<String>();
	static List<String> systemDetails = new ArrayList<String>();

	static volatile boolean guiRunning = true;
	
	public static void main(String[] args) throws Exception {

		// Create an instance on TestNG
		TestNG myTestNG = new TestNG();

		String productList[] = {"iSave", "iManage","SIM","eInvoice","iPerform","iRequest","TMS"};
		String evn[] = {"Ausprod","AWSSingapore","Awsprod","Prod","Devint","Rmpartner", "AUSUAT","Staging"};

	/*	Main_Sanity2 mainSanity = new Main_Sanity2();
		
		JFrame f = new JFrame("frame"); 
		
		productBox = new JComboBox(productList);
		environmentBox = new JComboBox(evn);
		executeButton = new JButton("Execute");
		
		productBox.setSelectedItem(0);
		environmentBox.setSelectedItem(0);
		
		productBox.addItemListener(mainSanity);
		environmentBox.addItemListener(mainSanity);
		executeButton.addActionListener(mainSanity);
		
		productBox.setEditable(true);
		environmentBox.setEditable(true);
		
		
		JPanel p = new JPanel(); 
		p.add(productBox);
		p.add(environmentBox);
		p.add(executeButton);
		
		p.setLayout(new FlowLayout()); 
		
		f.add(p); 

		// set the size of frame 
		f.setSize(400, 400); 

		f.show(); 

		while(true) {
				if(!guiRunning) {
					f.dispose();
					System.out.println("Breaking");
					break;
				}
		}
		System.out.println("check");*/
		String selectedProduct= (String)JOptionPane.showInputDialog(null,"Select Product:" , "ComboBox Dialog", JOptionPane.QUESTION_MESSAGE , null, productList, productList[0]);
		String selectedEnvironment= (String)JOptionPane.showInputDialog(null,"Select Environment:" , "ComboBox Dialog", JOptionPane.QUESTION_MESSAGE , null, evn, evn[0]);

		System.out.println("Product:"+selectedProduct+"  Environment:"+selectedEnvironment);

		String data[] = {selectedProduct,selectedEnvironment};

		setSystemParams();
		setConfigParams();

		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();

		setConfigDetails(objConnect, data);
		ConfigFileCreation objConfig = new ConfigFileCreation();
		objConfig.createConfig(configParams, configDetails);

		ConfigFileCreation objSysConfig = new ConfigFileCreation();
		setSystemDetails(objConnect,environment);
		objSysConfig.createSystemConfig(systemParams, systemDetails);

		System.out.println("Product Name is : " + productName);

		String[] productsList = getListOfProducts(productName);

		XmlSuite mySuite = createXMLSuite();

		// Create a list of XmlTests
		List<XmlTest> myTests = new ArrayList<XmlTest>();
		for(String product : productsList){
			XmlTest myTest = createXMLTest(mySuite, product);		
			addClassesToTest(myTest, product);

			// Print the parameter values
			Map<String, String> params1 = myTest.getAllParameters();
			for (Map.Entry<String, String> entry : params1.entrySet()) {
				System.out.println(entry.getKey() + " => " + entry.getValue());
			}

			// Add the Xmltest you created earlier to list of XmlTests
			myTests.add(myTest);
		}

		// add the list of tests to your Suite.
		mySuite.setTests(myTests);

		// Add the suite to the list of suites.
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(mySuite);

		// Set the list of Suites to the testNG object you created earlier.
		myTestNG.setXmlSuites(mySuites);
		mySuite.setFileName("testng.xml");
		mySuite.setThreadCount(10);
		myTestNG.run();

		// Create physical XML file based on the virtual XML content
		for (XmlSuite suite : mySuites) {
			createXmlFile(suite);
		}


	}
	
	
	 @Override
     public void actionPerformed(ActionEvent e) {
		 	
		 guiRunning = false;
		 
		 
     } 
	
	public void itemStateChanged(ItemEvent e) 
	{ 
		// if the state combobox 1is changed 
		if (e.getSource() == productBox) { 

			selectedProduct = (String) productBox.getSelectedItem();
		} 
		if (e.getSource() == environmentBox) { 

			selectedEnvironment = (String) environmentBox.getSelectedItem();
		}
		
	} 

	// This method will create an Xml file based on the XmlSuite data
	public static void createXmlFile(XmlSuite mSuite) {
		try {
			FileWriter writer = new FileWriter(new File("testng.xml"));
			writer.write(mSuite.toXml());
			writer.flush();
			writer.close();
			System.out.println(new File("testng.xml").getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void addClassesToTest(XmlTest myTest, String productName){
		// Create a list which can contain the classes that you want to run.
		List<XmlClass> myClasses = new ArrayList<XmlClass>();
		switch (productName) {
		case "iSource":
			myClasses.add(new XmlClass("com.main.iSourceFlows.RFIEvent"));
			myClasses.add(new XmlClass("com.main.iSourceFlows.RFPEvent"));
			/*
			 * myClasses.add(new XmlClass("com.main.iSourceFlows.RFQEvent"));
			 * myClasses.add(new XmlClass("com.main.iSourceFlows.EngAuction"));
			 * myClasses.add(new XmlClass("com.main.iSourceFlows.JPNAuction"));
			 * myClasses.add(new
			 * XmlClass("com.main.iSourceFlows.TwoBiddingEnvelope"));
			 */
			break;
		case "iContract":
			// myClasses.add(new
			// XmlClass("com.main.TestingIContractCaseByCase"));

			/*
			 * myClasses.add(new
			 * XmlClass("com.main.iContractFlows.ContractSearches"));
			 * myClasses.add(new
			 * XmlClass("com.main.iContractFlows.HelpAndAboutIContract"));
			 * myClasses.add(new
			 * XmlClass("com.main.iContractFlows.Performance"));
			 * myClasses.add(new
			 * XmlClass("com.main.iContractFlows.ReportsAndDashboard"));
			 * myClasses.add(new
			 * XmlClass("com.main.FlowIContract_ExternalTemplate_Negotiation"));
			 */

			/*
			 * myClasses.add(new
			 * XmlClass("com.main.FlowIContract_TemplateCreation_NoNegotiate"));
			 * myClasses.add(new XmlClass("com.main.FlowIContract"));
			 */
			myClasses.add(new XmlClass("com.main.FlowIContract_WithoutSSO"));
			// myClasses.add(new
			// XmlClass("com.main.FlowIContract_TemplateCreation_NoNegotiate"));
			break;
		case "iSave":
			myClasses.add(new XmlClass("com.main.iSaveFlows.ISaveReport"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.QuickProject"));
			myClasses.add(new XmlClass("com.main.iSaveFlows.StrategicProjectFlow"));
			break;
		case "iManage":
			// myClasses.add(new XmlClass("com.main.FlowIManage"));
			myClasses.add(new XmlClass("com.main.iManageFlows.ConfigurationSettings"));
			myClasses.add(new XmlClass("com.main.iManageFlows.QuickProjectIntegration"));
			myClasses.add(new XmlClass("com.main.iManageFlows.StrategicProjectIntegration"));
			myClasses.add(new XmlClass("com.main.iManageFlows.FlexiForms"));
			myClasses.add(new XmlClass("com.main.iManageFlows.NewTemplateCreation"));
			myClasses.add(new XmlClass("com.main.iManageFlows.StrategicProject_WorkbenchApproval"));
			myClasses.add(new XmlClass("com.main.iManageFlows.StrategicProjectCreation"));
			break;
		case "SIM":
		case "iSupplier":
			// myClasses.add(new XmlClass("com.main.FlowISupplier"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.GeneralSIM"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.OperationalSupplierFlow"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.PotentialSupplierFlow"));
			myClasses.add(new XmlClass("com.main.iSupplierFlows.SupplierSearch"));
			break;
		case "iRequest":
			// myClasses.add(new XmlClass("com.main.FlowiRequest_new"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.ContractRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.iManageRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.SourcingRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.CommonNavigation"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.NoneRequest"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.RequestViaZSN"));
			myClasses.add(new XmlClass("com.main.iRequestFlows.CRMS_Integration_iRequest"));
			break;
		case "SPM":
		case "iPerform":
			myClasses.add(new XmlClass("com.main.iPerformFlows.KPI"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.ScoreCard"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CreateEvent"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CreateSCAR"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CreateProgram"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.Analyze"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.CRMS_Integration"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.DashboardTest"));
			myClasses.add(new XmlClass("com.main.iPerformFlows.Define"));
			// myClasses.add(new
			// XmlClass("com.main.iPerformFlows.SmokeiPerform"));
			break;
		case "ZSN":
			break;
		case "eProcurement":
		case "eProc":
			break;
		case "eInvoice":
			myClasses.add(new XmlClass("com.main.eInvoice.Approval_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.Invoice_Tests"));
//			myClasses.add(new XmlClass("com.main.eInvoice.Payment_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.PO_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.Reconciliation_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.Reports_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.Uploads_Tests"));
//			myClasses.add(new XmlClass("com.main.eInvoice.Workflow_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.ZSNIntegration_Tests"));
			myClasses.add(new XmlClass("com.main.eInvoice.InvoiceWithReferencePO_Tests"));



			break;

		case "Product1":
			myClasses.add(new XmlClass("com.main.Product1.Flow1"));

			break;

		case "Product2":
			myClasses.add(new XmlClass("com.main.Product2.Flow2"));

			break;

		case "TMS":
			myClasses.add(new XmlClass("com.main.TMS.CreateRole"));
			myClasses.add(new XmlClass("com.main.TMS.UserListing_Tests"));
			myClasses.add(new XmlClass("com.main.TMS.PreferenceTest"));
			myClasses.add(new XmlClass("com.main.TMS.ReportTest"));
			myClasses.add(new XmlClass("com.main.TMS.iMasterFlow"));
			break;
		}




		// Assign that to the XmlTest Object created earlier.
		myTest.setXmlClasses(myClasses);

	}

	private static void setSystemParams(){
		systemParams.add("HubIP");
		systemParams.add("SSOHostedServer");
		systemParams.add("ExecutionLocation");
		systemParams.add("BrowserType");
		systemParams.add("ExecutionType");
		/*systemParams.add("DatasheetsLocation");*/
	}

	private static void setConfigParams(){
		configParams.add("Product");
		configParams.add("Environment");
		configParams.add("Setup");
		configParams.add("Tenant");
		configParams.add("Customer");
		configParams.add("UserAccount");
		configParams.add("UserName");
		//configParams.add("Language");
	}

	private static void setConfigDetails(ZycusCoreDBConnect objConnect, String[] args) throws Exception{
		configDetails.add(args[0]);

		productName = args[0];
		environmentFromJenkins = args[1];

		switch (environmentFromJenkins) {
		case "Prod":
			environment = "Production";
			break;
		case "AWSSingapore":
			environment = "AWS Singapore";
			break;
		case "Ausprod":
			environment = "AWS Australia Production";
			break;
		case "AUSUAT":
			environment = "AWS Australia Staging";
			break;
		case "Staging":
			environment = "Staging";
			break;
		case "Awsprod":
			environment = "AWS UK";
			break;
		case "Devint":
			environment = "DevInt";
			break;
		case "Rmpartner":
			environment = "RM Partner";
			break;
		}

		// String environment = environmentFromJenkins.replace("_", " ");
		String setup = environment;
		configDetails.add(environment);
		configDetails.add(setup);

		String[][] params = objConnect.getExecutionParameters(environment);
		//		System.out.println("Displaying Execution Parameters");
		for (int i = 1; i <= 4; i++) {
			configDetails.add(params[0][i - 1]);
			//			System.out.println(params[0][i - 1]);
		}
	}

	private static void setSystemDetails(ZycusCoreDBConnect objConnect,String environment) throws Exception{
		String[][] sysParams = objConnect.getSystemParameters(environment);
		//		System.out.println("Displaying System Parameters");
		for (int i = 1; i <= 5; i++) {
			systemDetails.add(sysParams[0][i - 1]);
			//			System.out.println(sysParams[0][i - 1]);
		}
	}

	private static XmlSuite createXMLSuite(){
		// Create an instance of XML Suite and assign a name for it.
		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("MySuite");
		// mySuite.setParallel(XmlSuite.ParallelMode.METHODS);
		//mySuite.setParallel(XmlSuite.ParallelMode.CLASSES);
		mySuite.setParallel(XmlSuite.ParallelMode.CLASSES);
		mySuite.setThreadCount(10);
		return mySuite;
	}

	private static XmlTest createXMLTest(XmlSuite mySuite, String product){
		// Create an instance of XmlTest and assign a name for it.
		XmlTest myTest = new XmlTest(mySuite);
		myTest.setName("MyTest_"+product);
		myTest.setParallel(XmlSuite.ParallelMode.CLASSES);
		return myTest;
	}

	private static String[] getListOfProducts(String productList){
		return productList.split(",");
	}
}
