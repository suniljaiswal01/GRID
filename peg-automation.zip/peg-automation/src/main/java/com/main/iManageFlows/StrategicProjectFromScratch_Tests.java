package com.main.iManageFlows;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;


public class StrategicProjectFromScratch_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	static String programName;
	static String projectStrategic;
	static String projectStrategicScratch;
	static String projectStrategicExistingProject;
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public StrategicProjectFromScratch_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}



	@Test(groups = "Login", alwaysRun=true)
	@TestDetails(TestID="login")
	public void login_StrategicProjectScratch() throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "WorkbenchTrack", dependsOnMethods = "login_StrategicProjectScratch", alwaysRun = true)
	@TestDetails(TestID="iManage_2")
	public void createProgram() throws Exception {
		Track objTrack = new Track(driver, logger);
		programName = objTrack.createNewEntity("Program");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "WorkbenchTrack", dependsOnMethods = "createProgram", alwaysRun = true)
	@TestDetails(TestID="iManage_2")
	public void StrategicProjectScratch() throws Exception {
		Track objTrack = new Track(driver, logger);
		projectStrategicScratch=objTrack.createNewEntity("Strategic Project", "Strategic Project from Scratch", programName);
	}

}


