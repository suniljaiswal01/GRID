package com.main.iManageFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;

public class LinkQuickProjectToSource_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	public static String quickProject;
	String eventIDToLink;
	
	

	public LinkQuickProjectToSource_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_QuickSource() throws Exception {	
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dependsOnMethods = {"login_QuickSource","com.main.iManageFlows.QuickProjectCreation_Tests.QuickProject"})
	@TestDetails(TestID="iManage_24")
	public void LinkActivity_iSource() throws Exception {
		String entityTitle = QuickProjectCreation_Tests.quickProject;
		if(entityTitle!=null) {
		String eventType = "RFI";
		Track objTrack = new Track(driver,logger);
		System.out.println("Filter by Entity: "+entityTitle);
		objTrack.clearAllFilters();
		Thread.sleep(1500);
		objTrack.clearTxtFilter();
		Thread.sleep(2000);
		objTrack.filterByEntityTitle(entityTitle);
		objTrack.linkActivity(eventType, eventIDToLink);
	}else
		throw new SkipException("Skipping Approving Invoice PO");
	}
	

}
