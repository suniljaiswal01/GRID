package com.main.iManageFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.MyConfiguration.MassUpdate;
import com.zycus.iManage.MyConfiguration.MassUpload;
import com.zycus.iManage.MyConfiguration.OwnershipManagement;
import com.zycus.iManage.MyConfiguration.SyncTMSUser;
import com.zycus.iManage.MyConfiguration.TaskProgressSetting;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;



public class Configuration_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";


	public Configuration_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_ConfigurationSettings() throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_ConfigurationSettings", dataProvider = "TaskProgressSetting")
	@TestDetails(TestID="iManage_10")
	public void ConfigurationTaskProgressSetting() throws Exception {
		TaskProgressSetting objTaskProg = new TaskProgressSetting(driver, logger);
		callAndLog(logger, objTaskProg.validatePage(), "Task Progress Setting table displayed", "Task Progress Setting table not displayed");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_ConfigurationSettings", dataProvider = "MassUpload")
	@TestDetails(TestID="iManage_11")
	public void ConfigurationMassUpload() throws Exception {
		MassUpload objMassUpload = new MassUpload(driver, logger);
		callAndLog(logger, objMassUpload.uploadDocument("upload_xls_path"), "able to upload doc in Mass Upload",
				"unable to upload doc in Mass Upload");
	}



	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_ConfigurationSettings", dataProvider = "MassUpdate")
	@TestDetails(TestID="iManage_12")
	public void ConfigurationMassUpdate() throws Exception {
		MassUpdate objMassUpdate = new MassUpdate(driver, logger);
		callAndLog(logger, objMassUpdate.massUpdate("upload_xls_path"), "able to upload doc in Mass Update",
				"unable to upload doc in Mass Update");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_ConfigurationSettings", dataProvider = "OwnershipManagement")
	@TestDetails(TestID="iManage_27")
	public void OwnershipManagement(String user) throws Exception {
		OwnershipManagement objOwnershipManage = new OwnershipManagement(driver, logger);
		callAndLog(logger, objOwnershipManage.validatePageAndSearchUsers(user), "User is able to open Ownership Management page and all data is displayed correctly",
				"User is unable to open Ownership Management page and all data is displayed correctly");

	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_ConfigurationSettings")
	@TestDetails(TestID="iManage_28")
	public void SyncTMSUser() throws Exception {
		SyncTMSUser objSyncTMS = new SyncTMSUser(driver, logger);
		callAndLog(logger, objSyncTMS.validatePageAndSynchTMS(), "User is able to open and perform Sync TMS update action successfully", 
				"User is unable to open and perform Sync TMS update action successfully");	
	}




}
