package com.main.iManageFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.MyTemplates.MyTemplates;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;


public class NewTemplateCreation_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	String dashboardName;

	public NewTemplateCreation_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_NewTemplate() throws Exception {		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "MyTemplates", dependsOnMethods = "login_NewTemplate", alwaysRun = true)
	@TestDetails(TestID="iManage_7")
	public void CreateNewTemplatefromExistingTemplate() throws Exception {
		MyTemplates objTemplate = new MyTemplates(driver, logger);
		objTemplate.createNewTemplate("Existing Template");
	}
	 
	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "MyTemplates", dependsOnMethods = "login_NewTemplate" ,alwaysRun = true)
	@TestDetails(TestID="iManage_8")
	public void CreateNewTemplatefromExistingProject() throws Exception {
		MyTemplates objTemplate = new MyTemplates(driver, logger);
		objTemplate.createNewTemplate("Existing Project");
	}

	 
	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "MyTemplates", dependsOnMethods = "login_NewTemplate", alwaysRun = true)
	@TestDetails(TestID="iManage_9")
	public void CreateNewTemplatefromScratch() throws Exception {
		MyTemplates objTemplate = new MyTemplates(driver, logger);
		objTemplate.createNewTemplate("Scratch");
	}

}
