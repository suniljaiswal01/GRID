package com.main.iManageFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;

public class LinkStrategicProjectToSave_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	public static String quickProject;
	String eventIDToLink;
	
	

	public LinkStrategicProjectToSave_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true, dependsOnMethods= "com.main.iManageFlows.StrategicProjectFromScratch_Tests.StrategicProjectScratch")
	@TestDetails(TestID="login")
	public void login_StrategicSave() throws Exception {	
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	

	@Test(dependsOnMethods = {"login_StrategicSave","com.main.iManageFlows.StrategicProjectFromScratch_Tests.StrategicProjectScratch"})
	@TestDetails(TestID="iManage_2")
	public void linkStrategicProjectToStrategicSavings() throws Exception {
		String entityTitle = StrategicProjectFromScratch_Tests.projectStrategicScratch;
		if(entityTitle!=null) {
		Track objTrack = new Track(driver,logger);
		System.out.println("Filter by Entity: "+entityTitle);
		objTrack.clearAllFilters();
		Thread.sleep(1500);
		objTrack.clearTxtFilter();
		Thread.sleep(2000);
		objTrack.filterByEntityTitle(entityTitle);
		objTrack.linkActivityiSaveToStrategicProject(eventIDToLink,"Create_Strategic_Savings");
		objTrack.createSavingsProject("Create_Strategic_Savings");
		objTrack.createSavingsProject("Create_Quick_Savings");				
		objTrack.linkSavingsProject(eventIDToLink,"Link_Savings_Project");
	}else
		throw new SkipException("Skipping Approving Invoice PO");
	}
	 
}
