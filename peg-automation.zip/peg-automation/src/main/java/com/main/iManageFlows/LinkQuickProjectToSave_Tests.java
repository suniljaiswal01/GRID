package com.main.iManageFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;
import IntegrationClasses.DataStoreClass;

public class LinkQuickProjectToSave_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	public static String quickProject;
	String eventIDToLink;
	
	

	public LinkQuickProjectToSave_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_QuickSave() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	
	
	@Test(dependsOnMethods = {"login_QuickSave","com.main.iManageFlows.QuickProjectCreation_Tests.QuickProject"})
	@TestDetails(TestID="iManage_26")
	public void linkQuickProjectToStrategicSavings() throws Exception {	
		String entityTitle = QuickProjectCreation_Tests.quickProject;
		if(entityTitle!=null) {
		Track objTrack = new Track(driver,logger);
		System.out.println("Filter by Entity: "+entityTitle);
		objTrack.clearAllFilters();
		Thread.sleep(1500);
		objTrack.clearTxtFilter();
		Thread.sleep(2000);
		objTrack.filterByEntityTitle(entityTitle);
		System.out.println("Event ID to link would be "+DataStoreClass.iSourceEvent);
		objTrack.linkActivityiSavetoQuickProject(eventIDToLink,"Create_Strategic_Savings");
		objTrack.createSavingsProject("Create_Strategic_Savings");	
		objTrack.createSavingsProject("Create_Quick_Savings");			
		objTrack.linkSavingsProject(eventIDToLink,"Link_Savings_Project");
	}else
		throw new SkipException("Skipping Approving Invoice PO");
}
	
	 
}
