package com.main.iManageFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Admin.AdminTasks;
import com.zycus.iManage.Admin.NewCompany;
import com.zycus.iManage.Admin.PerformStatusTasks;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;



public class Admin_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	

	public Admin_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_Admin() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Admin", dataProvider = "AdminPerformCheck")
	@TestDetails(TestID="iManage_13")
	public void AdminPerformCheck() throws Exception {
		PerformStatusTasks objPerformStatusTasks = new PerformStatusTasks(driver, logger);
		if(objPerformStatusTasks.validateStatus())		
			callAndLog(logger, objPerformStatusTasks.validateStatus(), "able to validate status",
					"unable to validate status");
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Admin", dataProvider = "AdminTasks")
	@TestDetails(TestID="iManage_14")
	public void AdminTasks() throws Exception {
		AdminTasks objAdminTasks = new AdminTasks(driver, logger);
		if(objAdminTasks.performAdminTasks("Perform DB Check"))
			callAndLog(logger, objAdminTasks.performAdminTasks("Perform DB Check"), "able to perform Admin Tasks",
					"unable to perform Admin Tasks");			
	}



	@Test(dependsOnMethods = "login_Admin")
	@TestDetails(TestID="iManage_15")
	public void AdminNewCompany() throws Exception {
		NewCompany objNewCompany = new NewCompany(driver, logger);
		if(objNewCompany.importCategoryTree())
			callAndLog(logger, objNewCompany.importCategoryTree(), "able to import Category tree",
					"unable to import Category tree");

	}


}
