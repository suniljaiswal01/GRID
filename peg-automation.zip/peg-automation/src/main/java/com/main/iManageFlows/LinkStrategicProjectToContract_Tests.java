package com.main.iManageFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;

public class LinkStrategicProjectToContract_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	public static String quickProject;
	String eventIDToLink;
	
	

	public LinkStrategicProjectToContract_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true, dependsOnMethods = "com.main.iManageFlows.StrategicProjectFromScratch_Tests.StrategicProjectScratch")
	@TestDetails(TestID="login")
	public void login_StrategiciContract() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "Tasks", dependsOnMethods = {"login_StrategiciContract","com.main.iManageFlows.StrategicProjectFromScratch_Tests.StrategicProjectScratch"})
	@TestDetails(TestID="iManage_2")
	public void linkStrategicProjectiContract(String taskTitle,String assignResource,String startDate, String endDate,String taskDescription) throws Exception {
		String entityTitle = StrategicProjectFromScratch_Tests.projectStrategicScratch;
		if(entityTitle!=null) {
		String eventType = "Contract";	
		Track objTrack = new Track(driver,logger);
		System.out.println("Filter by Entity: "+entityTitle);
		objTrack.clearAllFilters();
		Thread.sleep(1500);
		objTrack.clearTxtFilter();
		Thread.sleep(2000);
		objTrack.filterByEntityTitle(entityTitle);
		objTrack.linkActivityStrategic(eventType,taskTitle,assignResource, eventIDToLink,startDate,endDate,taskDescription);
	}else
		throw new SkipException("Skipping Strategic Project Integration");
	}

}
