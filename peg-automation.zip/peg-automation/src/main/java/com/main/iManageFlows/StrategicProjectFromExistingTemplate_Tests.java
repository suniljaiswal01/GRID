package com.main.iManageFlows;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Approval;
import com.zycus.iManage.Workbench.ManageProject;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;


public class StrategicProjectFromExistingTemplate_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	static String projectStrategic;
	static String projectStrategicScratch;
	static String projectStrategicExistingProject;
	String taskName;
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public StrategicProjectFromExistingTemplate_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun=true)
	@TestDetails(TestID="login")
	public void login_StrategicProjectExistingTemplate() throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "WorkbenchTrack", dependsOnMethods = {"login_StrategicProjectExistingTemplate","com.main.iManageFlows.StrategicProjectFromScratch_Tests.createProgram"})
	@TestDetails(TestID="iManage_2")
	public void StrategicProjectExistingTemplate() throws Exception {
		Track objTrack = new Track(driver, logger);
		projectStrategic = objTrack.createNewEntity("Strategic Project", "Strategic Project from Existing Template", StrategicProjectFromScratch_Tests.programName);
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "Tasks", dependsOnMethods = "StrategicProjectExistingTemplate")
	@TestDetails(TestID="iManage_2")
	public void EditTask(String taskTitle,String assignResource,String startDate, String endDate,String taskDescription) throws Exception {
		Track objTrack = new Track(driver, logger); 
		ManageProject objProj = new ManageProject(driver, logger);
		try {
			objTrack.clearAllFilters();
			objTrack.clearTxtFilter();
			objTrack.filterByEntityTitle(projectStrategic);
			objTrack.takeActionStrategicProject("Manage Initiated Project", projectStrategic,"Manage Project");				
			taskName=objProj.addNewTask(taskTitle, startDate, endDate, assignResource);
		}catch(Exception e) {
			if(driver.findElement(By.xpath("//a[@title='Cancel'][contains(@onclick,'clearAndClosePopup()')]")).isDisplayed()) {
				driver.findElement(By.xpath("//a[@title='Cancel'][contains(@onclick,'clearAndClosePopup()')]")).click();
			}	
			WebElement objBackBtn=  driver.findElement(By.xpath("//a[text()='Back']"));
			if(objBackBtn.isDisplayed())
				js.executeScript("arguments[0].click();", objBackBtn);	
		}
	}


	@Test(dependsOnMethods = "StrategicProjectExistingTemplate")
	@TestDetails(TestID="iManage_2")
	public void takeActionOnProject() throws Exception {
		Track objTrack = new Track(driver,logger);
		System.out.println("Filter by Entity: "+projectStrategic);
		objTrack.clearAllFilters();
		objTrack.clearTxtFilter();
		objTrack.filterByEntityTitle(projectStrategic);
		objTrack.takeActionStrategicProject("Manage Initiated Project", projectStrategic,"Project Journal");
		objTrack.clearAllFilters();
		objTrack.clearTxtFilter();
		objTrack.filterByEntityTitle(projectStrategic);
		objTrack.takeActionStrategicProject("Quick Edit", projectStrategic,"");		
		objTrack.clearAllFilters();
		objTrack.clearTxtFilter();
		objTrack.filterByEntityTitle(projectStrategic);
		objTrack.takeActionStrategicProject("Manage Initiated Project", projectStrategic,"Project Summary");

	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, 
			dataProvider = "WorkbenchApproval", 
			dependsOnMethods = "EditTask")
	@TestDetails(TestID="iManage_4")
	public void WorkbenchApproval_ApproveTask() throws Exception {
		Approval objApproval = new Approval(driver, logger);
		objApproval.approveTask(projectStrategic);	
	}


}


