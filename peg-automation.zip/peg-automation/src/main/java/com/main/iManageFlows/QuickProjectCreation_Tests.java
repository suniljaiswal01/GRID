package com.main.iManageFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Track;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;

public class QuickProjectCreation_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	public static String quickProject;
	String eventIDToLink;
	String quickProjectType= getLanguageProperty("Quick Project");
	String strategicProjectType= getLanguageProperty("Strategic Project");
	

	public QuickProjectCreation_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_QuickProject() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dataProvider = "WorkbenchTrack", dependsOnMethods = {"login_QuickProject","com.main.iManageFlows.StrategicProjectFromScratch_Tests.createProgram"},alwaysRun = true)
	@TestDetails(TestID="iManage_16")
	public void QuickProject() throws Exception {
		Track objTrack = new Track(driver, logger);
		quickProject = objTrack.createNewEntity(quickProjectType,"", StrategicProjectFromScratch_Tests.programName);
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "QuickProject")
	@TestDetails(TestID="iManage_16")
	public void trackProgressOfProject() throws Exception {
		if(quickProject!=null) {
		Track objTrack = new Track(driver, logger);
		String entityTitle = quickProject;
		objTrack.clearAllFilters();
		objTrack.clearTxtFilter();
		objTrack.filterByEntityTitle(entityTitle);
		callAndLog(logger,objTrack.getProgressofProject(entityTitle), "Project progress is displayed", "Project progress is not displayed");
	}else
		throw new SkipException("Skipping Approving Invoice PO");
	}

	
}
