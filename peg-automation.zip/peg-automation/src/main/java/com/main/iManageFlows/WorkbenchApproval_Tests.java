package com.main.iManageFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Workbench.Approval;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;
import common.Functions.eInvoice_CommonFunctions;


public class WorkbenchApproval_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	String programName;
	String projectStrategic;
	eInvoice_CommonFunctions objFunctions;
	

	public WorkbenchApproval_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}

	
	@Test(groups = "Login", alwaysRun=true)
	@TestDetails(TestID="login")
	public void login_WorkbenchApproval() throws Exception {
			
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dataProviderClass = iManage_DataProviderTestNG.class, 
			dataProvider = "WorkbenchApproval", 
			dependsOnMethods = "login_WorkbenchApproval")
	@TestDetails(TestID="iManage_3")
	public void WorkbenchApproval_ApprovePhase() throws Exception {
		Approval objApproval = new Approval(driver, logger);
		objApproval.approvePhase();
	}
	
	
	@Test(dataProviderClass = iManage_DataProviderTestNG.class, 
			dependsOnMethods = "login_WorkbenchApproval")
	@TestDetails(TestID="iManage_33")
	public void ReviewTask() throws Exception {
		Approval objApproval = new Approval(driver, logger);
		objApproval.reviewTask();
	}

	@Test(dependsOnMethods = "login_WorkbenchApproval")
	@TestDetails(TestID="iManage_34")
	public void aboutIManage() throws Exception {
		if(displayStyle.equals("Rainbow")){
			Approval objApproval = new Approval(driver, logger);
			objApproval.verifyVersion();
		}else
			throw new SkipException("Help tab not available in Classic View");
	}
	
}
