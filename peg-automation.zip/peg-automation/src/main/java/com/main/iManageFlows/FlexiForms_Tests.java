package com.main.iManageFlows;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.FlexiFormStudio.FormListingPage;
import com.zycus.iManage.MyConfiguration.ProjectConfiguration;
import com.zycus.iManage.Workbench.ManageProject;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;
import Framework.CommonUtility;



public class FlexiForms_Tests extends CommonTests1{


	/*private ExtentTest logger;*/
	private String Product = "iManage";
	CommonUtility objCommon;
	StrategicProjectFromExistingTemplate_Tests objStrategic = new StrategicProjectFromExistingTemplate_Tests();

	public FlexiForms_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_Flexi() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Flexi", dataProvider = "FlexiForm")
	@TestDetails(TestID="iManage_22")
	public void flexiFormIntegrationWithProjectTemplate(String sectionDesc, String sectionLayout, String fieldDefaulVal, String fieldMaxChar, String isFieldMandatory, String ProjectTemplate,String ProgramTemplate) throws Exception {
		ProjectConfiguration objProjConf= new ProjectConfiguration(driver, logger);
		ManageProject objProj = new ManageProject(driver, logger);
		driver.findElement(By.id("containerConfig")).click();
		String customProjectType=objProjConf.addCustomProjectType();
		FormListingPage objflexi= new FormListingPage(driver, logger);	
		int fieldMaxCharInt = Integer.parseInt(fieldMaxChar);
		boolean isFieldMandatoryBoolean = Boolean.parseBoolean(isFieldMandatory);
		callAndLog(logger,objflexi.createNewFlexiForm(sectionDesc, sectionLayout, fieldDefaulVal, fieldMaxCharInt, isFieldMandatoryBoolean), "Default flexiform for Project created successfully","Default flexiform for Project creation failed");		
		objProjConf.selectDefaultCustomProjectType(customProjectType);
		objProjConf.navigateToMainPage(displayStyle, Product, "Workbench","Track");
		objProj.verifyFlexiFormOnQuickProjectPage(com.zycus.FlexiFormStudio.FormListingPage.sectionName);
	}
	

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Flexi", dataProvider = "FlexiForm")
	@TestDetails(TestID="iManage_21")
	public void flexiFormProgram(String sectionDesc, String sectionLayout, String fieldDefaulVal, String fieldMaxChar, String isFieldMandatory, String ProjectTemplate,String ProgramTemplate) throws Exception {	
		ProjectConfiguration objProjConf= new ProjectConfiguration(driver, logger);
		objProjConf.addDefaultFlexiForm(ProgramTemplate);
		FormListingPage objflexi= new FormListingPage(driver, logger);
		int fieldMaxCharInt = Integer.parseInt(fieldMaxChar);
		boolean isFieldMandatoryBoolean = Boolean.parseBoolean(isFieldMandatory);
		callAndLog(logger,objflexi.createNewFlexiForm(sectionDesc, sectionLayout, fieldDefaulVal, fieldMaxCharInt, isFieldMandatoryBoolean), "Default flexiform for Program created successfully","Default flexiform for Program creation failed");
		//callAndLog(logger,objProjConf.delinkDefaultFlexiForm(ProgramTemplate),ProgramTemplate +"Form Delinked sucessfully",ProgramTemplate +"Form Delink Failed");
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Flexi", dataProvider = "FlexiForm")
	@TestDetails(TestID="iManage_22")
	public void createCustomTaskType(String sectionDesc, String sectionLayout, String fieldDefaulVal, String fieldMaxChar, String isFieldMandatory, String ProjectTemplate,String ProgramTemplate) throws Exception {
		int fieldMaxCharInt = Integer.parseInt(fieldMaxChar);
		boolean isFieldMandatoryBoolean = Boolean.parseBoolean(isFieldMandatory);
		ProjectConfiguration objProjConf= new ProjectConfiguration(driver, logger);
		objProjConf.addCustomTaskType();	
		FormListingPage objflexi= new FormListingPage(driver, logger);		
		callAndLog(logger,objflexi.createNewFlexiForm(sectionDesc, sectionLayout, fieldDefaulVal, fieldMaxCharInt, isFieldMandatoryBoolean), "Default flexiform for Task created successfully","Default flexiform for Task creation failed");
			
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Flexi", dataProvider = "FlexiForm")
	@TestDetails(TestID="iManage_22")
	public void createFormCustomProjectType(String sectionDesc, String sectionLayout, String fieldDefaulVal, String fieldMaxChar, String isFieldMandatory, String ProjectTemplate,String ProgramTemplate) throws Exception {
		int fieldMaxCharInt = Integer.parseInt(fieldMaxChar);
		boolean isFieldMandatoryBoolean = Boolean.parseBoolean(isFieldMandatory);
		ProjectConfiguration objProjConf= new ProjectConfiguration(driver, logger);
		String customProjectType=objProjConf.addCustomProjectType();
		FormListingPage objflexi= new FormListingPage(driver, logger);	
		callAndLog(logger,objflexi.createNewFlexiForm(sectionDesc, sectionLayout, fieldDefaulVal, fieldMaxCharInt, isFieldMandatoryBoolean), "Default flexiform for Task created successfully","Default flexiform for Task creation failed");
		callAndLog(logger,objProjConf.selectDefaultCustomProjectType(customProjectType),customProjectType +" Default Custom project Type is selected",customProjectType +" Default Custom project Type is not selected");	
	}
	
	

}

