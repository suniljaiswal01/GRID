package com.main.iManageFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iManage.Dashboard.CommonDashboard;
import com.zycus.iManage.MyReports.ReportDetail;
import com.zycus.iManage.MyReports.Reports;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iManage_DataProviderTestNG;


public class Dashboard_Tests extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "iManage";
	String dashboardName;

	public Dashboard_Tests() throws Exception {
		super();
		setProduct("iManage");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}


	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_Dashboard() throws Exception {	
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "login_Dashboard", alwaysRun = true)
	@TestDetails(TestID="iManage_5")
	public void CommonDashboard() throws Exception {
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		dashboardName= objCustomDashboard.addNewDashboard("50:50", "Overall Savings", "Project Count");
		objCustomDashboard.saveNewDashboardToMyDashboard("50:50", "Overall Savings", "Project Count");
	}

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "CommonDashboard")
	@TestDetails(TestID="iManage_5")
	public void exportCommonDashboard() throws Exception {
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.exportDashboard("Excel");
		objCustomDashboard.exportDashboard("Word");
		objCustomDashboard.exportDashboard("PowerPoint");
		objCustomDashboard.exportDashboard("PDF");
	}
	

	@Test(dataProviderClass = iManage_DataProviderTestNG.class, dependsOnMethods = "exportCommonDashboard", dataProvider = "MyReports", alwaysRun = true)
	@TestDetails(TestID="iManage_6")
	public void Reports(String reportType, String reportName) throws Exception {
		Reports objReports = new Reports(driver, logger);
		if (objReports.searchReport(reportType, reportName)) {
			if (objReports.viewReportDetails(reportName)) {
				ReportDetail objRepDetail = new ReportDetail(driver, logger);
				try {
					objRepDetail.exportReportToPDF("In PDF");
					objRepDetail.exportReportToPDF("In Excel");
					objReports.LogScreenshot("warning", "Report viewed and exported");	
				}catch(Exception e) {
					objReports.LogScreenshot("warning", "Report not exported");
				}
				objRepDetail.closeReportDetails();
			}
			else
				objReports.LogScreenshot("warning", "Report not viewed");							
		}
		else {
			objReports.LogScreenshot("warning", "Report not searched");		
		}
	}

	
}
