package com.main;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.common.ExtentManager;
import com.aventstack.extentreports.common.ExtentTestManager;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.main.iSourceFlows.SendMail;

import Framework.CommonUtility;
import Framework.ConfigurationProperties;
import Framework.FrameworkUtility;

public class CommonTests2 {

	public WebDriver driver;
	public WebDriver driver1;
	//public static ExtentTest startingTest;
	public static ExtentTest parent;
	public ExtentTest parentLogger;
	public static HashMap<String, String> loginCredentials;
	public String displayStyle;
	protected FrameworkUtility objFrameworkUtility = new FrameworkUtility();
	protected ConfigurationProperties configurationProperties = ConfigurationProperties.getInstance();
	public static String testStatus;
	
	
	public static HashMap <String, ExtentTest> ExtentTestProductMap = new HashMap<String,ExtentTest>();
	
	
	private String classToLoad;
	
	
	public ExtentTest logger;
	private String Product;
	private ExtentTest parentTest;
	
	public String getProduct() {
		return Product;
	}

	public void setProduct(String product) throws Exception {
		
		ConfigurationProperties config = ConfigurationProperties.getInstance();
		if((config.getProperty("Setup").contains("Staging") || config.getProperty("Setup").contains("DevInt")) && config.getProperty("Product").contains("eInvoice"))
		Product = "Invocus";
		else
		Product = product;
	}

	public CommonTests2() throws Exception{
		super();
	}
	
	@BeforeSuite
	public void beforeSuite() throws Exception {
		ZycusCoreReporter.createReportFile();
		//startingTest = ExtentTestManager.createTest("Automation Execution");
	}
	
	
	//************************************Uncomment it*******************************
	
	public ExtentTest getParent() {
		return parent;
	}

	public void setParent(ExtentTest parent) {
		this.parent = parent;
	}

	@BeforeTest
	public void startTest() throws Exception {
		//parent = ExtentTestManager.createTest(configurationProperties.getProperty("Product"));
		parent = ExtentTestManager.createTest(Product);
		ExtentTestProductMap.put(Product, parent);
		//parent = startingTest.createNode(Product);
		//ExtentTestProductMap.put(Product, parent);
		System.out.println(ExtentTestProductMap);
	}
	
	@AfterClass
	public void afterClass(){
		//ExtentManager.getInstance().flush();
		//driver.quit();
		//if(driver1!=null)
			//driver1.quit();
		//ZycusCoreDriver1 objZCD = new ZycusCoreDriver1(); 
		//objZCD.deleteSession();
	}
	
	@AfterTest
	public void afterTest(){
//		ExtentManager.getInstance().flush();
		//driver.quit();
		System.out.println("Test Status "+ExtentTestManager.getTest().getStatus());
		//if(driver1!=null)
			//driver1.quit();
	}
	
	@AfterSuite
    public void tearDown1() {
        ExtentManager.getInstance().flush();
        SendMail objMail = new SendMail();
        //objMail.sendMail(fileName);
        //driver.quit();
    }
	
	public void callAndLog(ExtentTest logger,  boolean condition, String passMsg, String failMsg) throws Exception {
		String msg = condition ? passMsg : failMsg;
		String status = condition ? "Pass" : "Fail";
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.LogScreenshot(status, msg);
	}
	
	public void callAndLog(WebDriver driver,ExtentTest logger,  boolean condition, String passMsg, String failMsg) throws Exception {
		String msg = condition ? passMsg : failMsg;
		String status = condition ? "Pass" : "Fail";
		CommonUtility objUtility = new CommonUtility(driver, logger);
		objUtility.LogScreenshot(status, msg);
	}
		
	@AfterMethod
    public void getResult(ITestResult result) throws Exception {
        if(result.getStatus() == ITestResult.FAILURE) {
        	
        	CommonUtility objUtility = new CommonUtility(driver, logger);
    		objUtility.LogScreenshot("fail", "failure Reason");
            logger.fail(MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
            logger.fail(result.getThrowable());

        }
        else if(result.getStatus() == ITestResult.SUCCESS) {
        	//logger.pass(MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
        }
        else {
        	logger.skip(MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
        	logger.skip(result.getThrowable());
        }
    }
	
	/*@BeforeClass
	public void beforeClass() throws Exception{
		//parent = ExtentTestManager.createTest(Product);
		ZycusCoreDriver1 objZCD = new ZycusCoreDriver1(); 
//		System.out.println("Class to execute with "+ExtentTestProductMap.get(Product)+" "+this.getClass().getName()+" "+objZCD);
		driver = objZCD.startSession(this.getClass().getName());
		parentLogger = ExtentTestProductMap.get(Product).createNode(this.getClass().getName());
	}*/

	/*public ExtentTest getParentTest() {
		return parentTest;
	}

	public void setParentTest(ExtentTest parentTest) {
		this.parentTest = parentTest;
	}*/

	/*@BeforeMethod
	public void beforeMethod(Method method) throws Exception{
		TestDetails set = method.getAnnotation(TestDetails.class);
		//logger = parentLogger.createNode(method.getName());
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		System.out.println(set.TestID());
		loginCredentials = objConnect.getLoginCredentials(set.TestID());		
	}*/
	
	@BeforeMethod
	public void beforeMethod(Method method) throws Exception{
		TestDetails set = method.getAnnotation(TestDetails.class);
		//logger = parentLogger.createNode(method.getName());
		ZycusCoreDBConnect objConnect = new ZycusCoreDBConnect();
		loginCredentials = objConnect.getLoginCredentials(set.TestID());
		
	}

	public String getClassToLoad() {
		return classToLoad;
	}

	public void setClassToLoad(String classToLoad) {
		this.classToLoad = classToLoad;
	}

}
