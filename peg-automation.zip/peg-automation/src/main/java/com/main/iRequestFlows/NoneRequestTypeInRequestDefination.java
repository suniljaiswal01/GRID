package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.EmailTemplate;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.NewRequestDef;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;

public class NoneRequestTypeInRequestDefination extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	public static String newNoneReqType;
	public static String newNoneReqDef;
	public static String newRequest;
	public static String endPoint = "None";
	public NewRequestDef newRequestDef = null;
	
	public NoneRequestTypeInRequestDefination() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}
	
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginNoneInRequestDefination() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
		
	@Test(dependsOnMethods = "loginNoneInRequestDefination")
	@TestDetails(TestID="iRequest_3")
	public void createNoneRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newNoneReqDef = objDef.addNewRequestTypeInRequestDefination(endPoint, externalUsers);
		newNoneReqType = objDef.getRequestType("request definition", newNoneReqDef);
	}
	
	@Test(dependsOnMethods = "createNoneRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger, Product);
		newRequest = objRequests.addNewRequest(newNoneReqType, newNoneReqDef);
	}
		
	@Test(dependsOnMethods="addNewRequest", alwaysRun = true)
	@TestDetails(TestID="iRequest_2")
	public void emailTemplate() throws Exception {
		
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToEmailTemplate();
		EmailTemplate emailTemplate = new EmailTemplate(driver, logger);
		emailTemplate.verifyEmailTemplate();
	}
	
	@Test(dependsOnMethods="emailTemplate")
	@TestDetails(TestID="iRequest_2")
	public void deactivateRequestType() throws Exception {
		
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToRequestTypeConfig();
		RequestType objType = new RequestType(driver, logger);
		objType.deactivateRequestType(newNoneReqType);
	}
	
	
}
