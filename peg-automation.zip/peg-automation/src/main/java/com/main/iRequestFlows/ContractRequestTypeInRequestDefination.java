package com.main.iRequestFlows;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

public class ContractRequestTypeInRequestDefination extends CommonTests1{

	private String Product = "iRequest";
	public static String newContractReqType;
	public static String newContractReqDef;
	public static String newRequest;
	public static String endPoint = "Contract";
	
	
	public ContractRequestTypeInRequestDefination() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}
	
	
	@Test(groups = "Login" , alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginContractInRequestDefination() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
		
	@Test(dependsOnMethods = "loginContractInRequestDefination")
	@TestDetails(TestID="iRequest_3")
	public void createContractRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newContractReqDef = objDef.addNewRequestTypeInRequestDefination(endPoint, externalUsers);
		newContractReqType = objDef.getRequestType("request definition", newContractReqDef);
	}
	
	@Test(dependsOnMethods = "createContractRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger, Product);
		newRequest = objRequests.addNewRequest(newContractReqType, newContractReqDef);
	}
	
	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_3")
	public void viewRequestDefinition() throws Exception {
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		objDef.viewReqDefinition(newContractReqDef, "View");
		objDef.deActivateReqDefinition(newContractReqDef, "Deactivate");
		objDef.editReqDefinition(newContractReqDef, "Edit");
		objDef.deleteReqDefinition(newContractReqDef, "Delete");
	}
	
	
	@Test(dependsOnMethods = "viewRequestDefinition")
	@TestDetails(TestID = "iRequest_5")
	public void printAndSaveFromAllWorkbench() throws Exception {
		AllWorkbench objWorkbench = new AllWorkbench(driver, logger);
		objWorkbench.clearAllFilters();
		objWorkbench.waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		String reqNo = objWorkbench.getRequestNumber("Request Name", newRequest);
		objWorkbench.clearAllFilters();
		objWorkbench.waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		objWorkbench.markRequestCompleteOrReturn(newRequest, "approve", "Marking request as complete");
		objWorkbench.printAndSaveRequest(newRequest,reqNo);
		
	}
	
}
