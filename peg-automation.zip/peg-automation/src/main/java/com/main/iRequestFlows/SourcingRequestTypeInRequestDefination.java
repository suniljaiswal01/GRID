package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.NewRequestDef;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.MyWorkbench;

public class SourcingRequestTypeInRequestDefination extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	public static String newSourcingReqType;
	public static String newSourcingReqDef;
	public static String newRequest;
	public static String endPoint = "Sourcing";
	public NewRequestDef newRequestDef = null;
	
	
	String actionOption[] = {"Mark Complete","Return","Create Activity","Review"};
	
	public SourcingRequestTypeInRequestDefination() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}
	
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginSourcingInRequestDefination() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
		
	@Test(dependsOnMethods = "loginSourcingInRequestDefination")
	@TestDetails(TestID="iRequest_3")
	public void createSourcingRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newSourcingReqDef = objDef.addNewRequestTypeInRequestDefination(endPoint, externalUsers);
		newSourcingReqType = objDef.getRequestType("request definition", newSourcingReqDef);
	}
	
	@Test(dependsOnMethods = "createSourcingRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger, Product);
		newRequest = objRequests.addNewRequest(newSourcingReqType, newSourcingReqDef);
	}
	
	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_5")
	public void viewRequest() throws Exception {
		
		MyWorkbench myWorkBench = new MyWorkbench(driver, logger);
		myWorkBench.checkForActionButtonOptions(newRequest,actionOption);
	}
	
	@Test(dependsOnMethods = "viewRequest")
	@TestDetails(TestID="iRequest_5")
	public void reviewRequest() throws Exception {
		
		MyWorkbench myWorkBench = new MyWorkbench(driver, logger);
		myWorkBench.reviewRequest(newRequest, "Review","Reviewing request");
	}
	
}
