package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.iRequest_DataProviderTestNG;
import common.Functions.NavigationViaMenu;
import common.Functions.iRequest_CommonFunctions;

public class FlowIRequest_Sanity extends CommonTests1 {

	private ExtentTest logger;
	private String Product = "iRequest";
	iRequest_CommonFunctions objFunctions;
	private String potentialSupplierName = "";
	private String supplierName;
	String title= null;

	
	public FlowIRequest_Sanity() throws Exception {
		super();
	}
	
	
	
	@Test(groups = "Login",alwaysRun = true, priority = 1)
	@TestDetails(TestID="login")
	public void loginNavigate() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(description = "", priority = 2, dataProviderClass =iRequest_DataProviderTestNG.class, dataProvider = "navigateViaSideMenu", dependsOnMethods = "loginNavigate")
	@TestDetails(TestID = "iSupplier_1")
	public void navigateViaSideMenu(String... tabInfo) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, tabInfo);
		NavigationViaMenu navigateViaMenu = new NavigationViaMenu(driver, logger);
		navigateViaMenu.validateNavigation(Product,tabInfo);
	}
}
