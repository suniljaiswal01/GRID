package com.main.iRequestFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyApprovals.MyApprovals;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

public class iRequestWorkflow extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iRequest";
	private String newReqStatus = null;
	//iRequest_CommonFunctions objFunctions;
	public static String newContractReqType = "Auto_RT_Workflow";
	public static String newContractReqDef =  "Auto_RD_Workflow";
	public static String newRequest;
	public static String endPoint = "Contract";
	
	public iRequestWorkflow() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");

	}
		
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginContract() throws Exception {
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	@Test(dependsOnMethods = "loginContract")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger);
		newRequest = objRequests.addNewRequest(newContractReqType, newContractReqDef);
		try{
			newReqStatus = objRequests.getRequestStatus(newRequest);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID = "iRequest_8")
	public void requestApproval() throws Exception {
		if(!(newReqStatus.equals("With RM"))){
			MyApprovals myApprovals = new MyApprovals(driver, logger);
			myApprovals.printAndSaveRequest(newRequest);
			myApprovals.approveRequest(newRequest);
		}else
			throw new SkipException("Request pending with RM, as CWF is enabled for the environment");

	}
	
}
