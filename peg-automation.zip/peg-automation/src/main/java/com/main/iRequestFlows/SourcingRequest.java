package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

public class SourcingRequest extends CommonTests1 {

	//private ExtentTest logger;
	public String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	public static String newSrcReqType;
	public static String newSrcReqDef;
	public static String newRequest;
	public static String endPoint = "Sourcing";

	public SourcingRequest() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
		
	}
	
	@Test(groups = "Login",  alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginSourcing()
			throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginSourcing")
	@TestDetails(TestID = "iRequest_2")
	public void createSourcingRequestType() throws Exception {
		String endPoint = "Sourcing";
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToRequestTypeConfig();
		RequestType objType = new RequestType(driver, logger);
		newSrcReqType = objType.createNewRequestType(endPoint);
	}

	@Test(dependsOnMethods = "createSourcingRequestType")
	@TestDetails(TestID = "iRequest_3")
	public void createSourcingRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newSrcReqDef = objDef.addNewRequestDefinition(endPoint, newSrcReqType, externalUsers);
	}

	@Test(dependsOnMethods = "createSourcingRequestDefinition")
	@TestDetails(TestID = "iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger, Product);
		newRequest = objRequests.addNewRequest(newSrcReqType, newSrcReqDef);
	}

	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID = "iRequest_7")
	public void createActivity_AllWorkbench() throws Exception {
		AllWorkbench objWorkbench = new AllWorkbench(driver, logger);
		String reqNo = objWorkbench.getRequestNumber("Request Name", newRequest);
		objWorkbench.createActivity(reqNo);
		objWorkbench.createEvent();
	}
}
