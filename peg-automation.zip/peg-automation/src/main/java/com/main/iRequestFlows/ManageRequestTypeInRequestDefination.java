package com.main.iRequestFlows;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.MyApprovals.MyApprovals;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.MyWorkbench;

import DataProviders.Common_DataProviderTestNG;

public class ManageRequestTypeInRequestDefination extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	public static String newManageReqType;
	public static String newManageReqDef;
	public static String newRequest;
	public static String endPoint = "iManage";
	
	
	String actionOption[] = {"Mark Complete","Return","Review","Create Activity"};
	
	public ManageRequestTypeInRequestDefination() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}
	
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginManageInRequestDefination() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
		
	@Test(dependsOnMethods = "loginManageInRequestDefination")
	@TestDetails(TestID="iRequest_3")
	public void createManageRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newManageReqDef = objDef.addNewRequestTypeInRequestDefination(endPoint, externalUsers);
		newManageReqType = objDef.getRequestType("request definition", newManageReqDef);
	}
		
	
	@Test(dependsOnMethods = "createManageRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger, Product);
		newRequest = objRequests.addNewRequest(newManageReqType, newManageReqDef);
	}
	
	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_5")
	public void viewRequestDefinition() throws Exception {
		
		MyWorkbench myWorkBench = new MyWorkbench(driver, logger);
		myWorkBench.clearAllFilters();
		myWorkBench.waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		myWorkBench.checkForActionButtonOptions(newRequest,actionOption);
	}
	
	@Test(dependsOnMethods = "viewRequestDefinition")
	@TestDetails(TestID="iRequest_5")
	public void returnRequestDefinition() throws Exception {
		
		MyWorkbench myWorkBench = new MyWorkbench(driver, logger);
		myWorkBench.clearAllFilters();
		myWorkBench.waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		myWorkBench.markRequestCompleteOrReturn(newRequest, "Return","Returning request");
	}
	
}
