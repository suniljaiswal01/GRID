package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.iRequest_DataProviderTestNG;

public class CRMS_Integration_iRequest  extends CommonTests1 {
	//private ExtentTest logger;
	public String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;

	public CRMS_Integration_iRequest() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}



	@Test(groups = "Login", dependsOnMethods = "com.main.iRequestFlows.NoneRequest.createActivity_AllWorkbench", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginCRMSIntegration()
			throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow","Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginCRMSIntegration", dataProviderClass = iRequest_DataProviderTestNG.class, dataProvider ="crms_reportGeneration",alwaysRun=true)
	@TestDetails(TestID = "iRequest_CRMSIntegration")
	public void crms_reportGeneration(String category, String... data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		createNewReport.selectProduct(Product);
		createNewReport.selectParams(category, data);
		VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
		String[] endpoints = {NoneRequest.endPoint};
		for(String s : endpoints) {
			verifyReportsField.iRequestFieldCheck(category, s);
			//		verifyReportsField.saveReport();
			verifyReportsField.exportReport();
			verifyReportsField.backToReportListing();
		}
	}
}
