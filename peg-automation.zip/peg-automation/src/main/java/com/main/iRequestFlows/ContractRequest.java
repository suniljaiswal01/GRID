package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

public class ContractRequest extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	public static String newContractReqType = null;
	public static String newContractReqDef =  null;
	public static String newRequest;
	public static String endPoint = "Contract";
	
	public ContractRequest() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");

	}
		
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginContract() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	@Test(dependsOnMethods = "loginContract")
	@TestDetails(TestID="iRequest_2")
	public void createContractRequestType() throws Exception {
		String endPoint = "Contract";
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToRequestTypeConfig();
		RequestType objType = new RequestType(driver, logger);
		newContractReqType = objType.createNewRequestType(endPoint);
		
	}
	
	
	@Test(dependsOnMethods = "createContractRequestType")
	@TestDetails(TestID="iRequest_3")
	public void createContractRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newContractReqDef = objDef.addNewRequestDefinition(endPoint, newContractReqType, externalUsers);
	}
	
	@Test(dependsOnMethods = "createContractRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger);
		newRequest = objRequests.addNewRequest(newContractReqType, newContractReqDef);
	}
	
	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_7")
	public void createActivity_AllWorkbench() throws Exception {
		AllWorkbench objWorkbench = new AllWorkbench(driver, logger);
		String reqNo = objWorkbench.getRequestNumber("Request Name", newRequest);
		objWorkbench.createActivity(reqNo);
		objWorkbench.createContract();
		
	}
}
