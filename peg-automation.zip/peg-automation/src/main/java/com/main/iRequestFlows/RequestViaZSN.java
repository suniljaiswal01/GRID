package com.main.iRequestFlows;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

import DataProviders.iRequest_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;

public class RequestViaZSN extends CommonTests1 {

	//private ExtentTest logger;
	public String Product = "iRequest";
	private String newSrcReqType;
	private String newSrcReqDef;
	private String newRequest;
	String endPoint = "None";
	//	WebDriver driver1 = null;

	public RequestViaZSN() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}

	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginNoneZSN() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "loginNoneZSN")
	@TestDetails(TestID="iRequest_2")
	public void createNoneRequestType() throws Exception {
		String endPoint = "None";
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToRequestTypeConfig();
		RequestType objType = new RequestType(driver, logger);
		newSrcReqType = objType.createNewRequestType(endPoint);
	}

	@Test(dependsOnMethods = "createNoneRequestType")
	@TestDetails(TestID="iRequest_3")
	public void createNoneRequestDefinition() throws Exception {
		boolean externalUsers = true;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newSrcReqDef = objDef.addNewRequestDefinition(endPoint, newSrcReqType, externalUsers);
	}

	@Test(dependsOnMethods = "createNoneRequestDefinition")
	@TestDetails(TestID="iRequest_1")
	public void addNewRequest() throws Exception {	

		WebDriver driver1 = null;
		CommonFunctions1 objZSNFunctions  = null;
		try {
			String customer = configurationProperties.getProperty("Tenant");
			driver1= objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String username = supplierDetails.getSupplierEmail();
			String password = supplierDetails.getSupplierPassword();
			Login objLogin = new Login(driver1, logger, username, password);
			callAndLog(driver1,logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
			objZSNFunctions= new CommonFunctions1(driver1, logger);

			objZSNFunctions.navigate_path1("My Requests", "Create new Request",customer);
			MyRequests objRequests = new MyRequests(driver1, logger, Product);
			newRequest = objRequests.addNewRequestZSN(newSrcReqType, newSrcReqDef);
			objLogin.logout();
		}catch (Exception e) {
			objZSNFunctions.LogScreenshot("fail","Request not created");
		}
		driver1.quit();
	}

	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_7")
	public void createActivity_AllWorkbench() throws Exception {
		AllWorkbench objWorkbench = new AllWorkbench(driver, logger);
		//		String reqNo = objWorkbench.getRequestNumber("Request Name", newRequest);
		objWorkbench.markRequestCompleteOrReturn(newRequest, "approve", "Marking request as complete");
	}

}
