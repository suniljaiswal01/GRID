package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iRequest_DataProviderTestNG;

public class iManageRequest extends CommonTests1{

	public static String newManageReqType;
	public static String newManageReqDef;
	public static String newRequest;
	public static String endPoint = "iManage";
	
	public iManageRequest() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}
	
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginManage() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = "loginManage")
	@TestDetails(TestID="iRequest_2")
	public void createManageRequestType() throws Exception {
		String endPoint = "iManage";
		
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToRequestTypeConfig();
		RequestType objType = new RequestType(driver, logger);
		newManageReqType = objType.createNewRequestType(endPoint);
	}
	
	@Test(dependsOnMethods = "createManageRequestType")
	@TestDetails(TestID="iRequest_3")
	public void createManageRequestDefinition() throws Exception {
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newManageReqDef = objDef.addNewRequestDefinition(endPoint, newManageReqType, externalUsers);
	}
	
	@Test(dependsOnMethods = "createManageRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger);
		newRequest = objRequests.addNewRequest(newManageReqType, newManageReqDef);
	}
	
	@Test(dataProviderClass = iRequest_DataProviderTestNG.class, dataProvider = "createActivity_AllWorkbench", dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_7")
	public void createActivity_AllWorkbench(String category, String businessUnit, String startDate, String endDate) throws Exception {
		AllWorkbench objWorkbench = new AllWorkbench(driver, logger);
		String reqNo = objWorkbench.getRequestNumber("Request Name", newRequest);
		objWorkbench.createActivity(reqNo);
		objWorkbench.createProject(category, businessUnit, startDate, endDate);
	}
	
}
