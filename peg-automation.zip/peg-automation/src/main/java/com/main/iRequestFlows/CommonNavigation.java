package com.main.iRequestFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Reports.Reports;

import DataProviders.iRequest_DataProviderTestNG;

public class CommonNavigation extends CommonTests1 {

	private String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	//private ExtentTest logger;
	
	public CommonNavigation() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");

	}
	
	
	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginNavigation() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = "loginNavigation",dataProviderClass = iRequest_DataProviderTestNG.class, dataProvider = "reportCreation")
	@TestDetails(TestID="iRequest_6")
	public void exportReport(String reportName) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.selectReport(reportName);
	}
	
	@Test(dataProviderClass = iRequest_DataProviderTestNG.class,dependsOnMethods = "exportReport",dataProvider = "Reports")
	@TestDetails(TestID="iRequest_6")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}
}
