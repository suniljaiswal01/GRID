package com.main.iRequestFlows;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.iRequest.Configuration.Customize;
import com.zycus.iRequest.Configuration.RequestType;
import com.zycus.iRequest.MyRequests.MyRequests;
import com.zycus.iRequest.RequestDefinition.RequestDefinition;
import com.zycus.iRequest.Workbench.AllWorkbench;

public class NoneRequest extends CommonTests1{

	//private ExtentTest logger;
	public String Product = "iRequest";
	//iRequest_CommonFunctions objFunctions;
	public static String newNoneReqType;
	public static String newNoneReqDef;
	public  static String newRequest;
	public static String endPoint = "None";
	
	public NoneRequest() throws Exception {
		super();
		setProduct("iRequest");
		setClassToLoad("common.Functions.iRequest_CommonFunctions");
	}
	
	
	@Test(groups = "Login",alwaysRun = true)
	@TestDetails(TestID="login")
	public void loginNone() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(driver,logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = "loginNone")
	@TestDetails(TestID="iRequest_2")
	public void createNoneRequestType() throws Exception {
		String endPoint = "None";
		Customize objCustom = new Customize(driver, logger);
		objCustom.navigateToRequestTypeConfig();
		RequestType objType = new RequestType(driver, logger);
		newNoneReqType = objType.createNewRequestType(endPoint);
	}
	
	@Test(dependsOnMethods = "createNoneRequestType")
	@TestDetails(TestID="iRequest_3")
	public void createNoneRequestDefinition() throws Exception {
//		newSrcReqType = "AutoReqType_946634";
		boolean externalUsers = false;
		RequestDefinition objDef = new RequestDefinition(driver, logger);
		newNoneReqDef = objDef.addNewRequestDefinition(endPoint, newNoneReqType, externalUsers);
	}
	
	@Test(dependsOnMethods = "createNoneRequestDefinition")
	@TestDetails(TestID="iRequest_4")
	public void addNewRequest() throws Exception {
		MyRequests objRequests = new MyRequests(driver, logger, Product);
		newRequest = objRequests.addNewRequest(newNoneReqType, newNoneReqDef);
	}
	
	@Test(dependsOnMethods = "addNewRequest")
	@TestDetails(TestID="iRequest_7")
	public void createActivity_AllWorkbench() throws Exception {
		AllWorkbench objWorkbench = new AllWorkbench(driver, logger);
		objWorkbench.clearAllFilters();
		objWorkbench.waitUntilInvisibilityOfElement(By.xpath("//div[@class='blockUI blockOverlay']"));
		objWorkbench.markRequestCompleteOrReturn(newRequest, "approve", "Marking request as complete");
	}
}
