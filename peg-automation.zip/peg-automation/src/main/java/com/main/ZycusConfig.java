/*
 * Package is used for getting and setting global configuration : 
 *  
 */

package com.main;

import java.io.FileInputStream;
import java.util.Properties;

public class ZycusConfig {

	private String Environment;
	private String Setup;
	private static String ExecutionLocation;
	private String BrowserType;
	private String ExecutionType;
	private String DatasheetsLocation;
	private boolean LoginWithPwdMgr;
	private boolean LoginWithSSO;
	private static String Tenant;
	private static String Customer;
	private static String UserAccount;
	private static String User;
	private static String Pwd;

	protected String user_dir = System.getProperty("user.dir"); 
	protected Properties prop = new Properties();
	protected Properties sysProp = new Properties();
	protected Properties langProp = new Properties();



	private static String HubIP;
	private static String SSOHostedServer;

	public ZycusConfig() {
		try {
			ZycusCoreConstants zycusCoreConstents = ZycusCoreConstants.getInstance();			
			FileInputStream configFile = new FileInputStream(zycusCoreConstents.CONFIG_FILE_PATH);  
			if (configFile !=null) 
			{
				prop.load(configFile);
				configFile.close();
			}
			FileInputStream sysConfigFile = new FileInputStream(zycusCoreConstents.SYS_CONFIG_FILE_PATH);  
			if (sysConfigFile !=null) 
			{
				sysProp.load(sysConfigFile);
				sysConfigFile.close();
			}

			try {
				FileInputStream langConfigFile = new FileInputStream(zycusCoreConstents.LANG_CONFIG_FILE_PATH);  
				if (langConfigFile !=null) 
				{
					langProp.load(langConfigFile);
					langConfigFile.close();
				}
			}catch (Exception e) {
				System.out.println("File not Present");
			}
			
		} 
		catch(Exception e) {			 
			e.printStackTrace();
			System.out.println("Error Loading Configuration properites: File system Error "+e.getStackTrace());
			System.exit(1);
		}

		Environment 		= prop.getProperty("Environment");
		Setup 				= prop.getProperty("Setup");
		ExecutionLocation 	= sysProp.getProperty("ExecutionLocation");
		BrowserType 		= sysProp.getProperty("BrowserType");
		ExecutionType 		= sysProp.getProperty("ExecutionType");
		DatasheetsLocation = sysProp.getProperty("DatasheetsLocation");

		/*setDatasheetsLocation(sysProp.getProperty("DatasheetsLocation"));*/

		setHubIP(sysProp.getProperty("HubIP"));
		setSSOHostedServer(sysProp.getProperty("SSOHostedServer"));

		LoginWithPwdMgr 	= Boolean.parseBoolean(prop.getProperty("LoginWithPwdMgr"));
		LoginWithSSO 		= LoginWithPwdMgr?false:true;
		setTenant(prop.getProperty("Tenant"));
		setCustomer(prop.getProperty("Customer"));
		setUserAccount(prop.getProperty("UserAccount"));
		setUser(prop.getProperty("UserName"));
		setPwd(prop.getProperty("Pwd"));
	}


	public Properties getLangProp() {
		return langProp;
	}

	public String getExecutionType() {
		return ExecutionType;
	}

	public void setExecutionType(String executionType) {
		ExecutionType = executionType;
	}

	public boolean isLoginWithSSO() {
		return LoginWithSSO;
	}

	public void setLoginWithSSO(boolean loginWithSSO) {
		LoginWithSSO = loginWithSSO;
	}

	/** ----------------------------------------------Setter and getter methods for all the Parameters-----------------------------------------------------**/

	public String getEnvironment() {
		return Environment;
	}

	public void setEnvironment(String environment) {
		Environment = environment;
	}

	public static String getExecutionLocation() {
		return ExecutionLocation;
	}

	public void setExecutionLocation(String executionLocation) {
		ExecutionLocation = executionLocation;
	}

	public String getBrowserType() {
		return BrowserType;
	}

	public void setBrowserType(String browserType) {
		BrowserType = browserType;
	}


	public String getUser() {
		return User;
	}

	public void setUser(String user) {
		User = user;
	}

	public String getPwd() {
		return Pwd;
	}

	public void setPwd(String pwd) {
		Pwd = pwd;
	}

	/**
	 * @return the setup
	 */
	public String getSetup() {
		return Setup;
	}

	/**
	 * @param setup the setup to set
	 */
	public void setSetup(String setup) {
		Setup = setup;
	}

	/**
	 * @return the loginWithPwdMgr
	 */
	public boolean isLoginWithPwdMgr() {
		return LoginWithPwdMgr;
	}

	/**
	 * @param loginWithPwdMgr the loginWithPwdMgr to set
	 */
	public void setLoginWithPwdMgr(boolean loginWithPwdMgr) {
		LoginWithPwdMgr = loginWithPwdMgr;
	}

	/**
	 * @return the tenant
	 */
	public String getTenant() {
		return Tenant;
	}

	/**
	 * @param tenant the tenant to set
	 */
	public void setTenant(String tenant) {
		Tenant = tenant;
	}

	/**
	 * @return the customer
	 */
	public String getCustomer() {
		return Customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(String customer) {
		Customer = customer;
	}

	/**
	 * @return the userAccount
	 */
	public String getUserAccount() {
		return UserAccount;
	}

	/**
	 * @param userAccount the userAccount to set
	 */
	public void setUserAccount(String userAccount) {
		UserAccount = userAccount;
	}

	public static String getHubIP() {
		return HubIP;
	}

	public void setHubIP(String hubIP) {
		HubIP = hubIP;
	}

	public static String getSSOHostedServer() {
		return SSOHostedServer;
	}

	public void setSSOHostedServer(String sSOHostedServer) {
		SSOHostedServer = sSOHostedServer;
	}

	public String getDatasheetsLocation() {
		return DatasheetsLocation;
	}

	public void setDatasheetsLocation(String datasheetsLocation) {
		DatasheetsLocation = datasheetsLocation;
	}


}