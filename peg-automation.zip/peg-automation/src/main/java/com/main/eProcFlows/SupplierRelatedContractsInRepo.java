package com.main.eProcFlows;

import java.util.List;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.ManageContracts.Repository;

import DataProviders.Common_DataProviderTestNG;

public class SupplierRelatedContractsInRepo extends CommonTests1 {

  public static List<String> contractsList;
  
  public SupplierRelatedContractsInRepo() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.iContract_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_Repository() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }
  
  @Test(dependsOnMethods = "Login_Repository")
  @TestDetails(TestID = "iContract_12")
  public void searchContractInRepository() throws Exception {
    Repository objRepository = new Repository(driver, logger);
    objRepository.filterByContractingParty();
    contractsList = objRepository.getFilteredContractsListWithSingleContParty();
  }

  
}
