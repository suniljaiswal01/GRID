package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.eForms.AllForms;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class CategoryFormsCreation extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  public static String newCategoryForm;
  private String newCategoryFormAsDraft;
  
  public CategoryFormsCreation() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_CategoryForm() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = "Login_CategoryForm")
  @TestDetails(TestID = "eProcurement_18")
  public void createCategoryForm() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    newCategoryForm = objForms.selectNewFormCreationProcess("Online Editor");
  }
  
  @Test(dependsOnMethods = "createCategoryForm")
  @TestDetails(TestID = "eProcurement_18")
  public void deactivateCategoryForm() throws Exception {
    if (newCategoryForm != null){
      AllForms objForms = new AllForms(driver, logger);
      objForms.deactivateForm(newCategoryForm);
    } else throw new SkipException("New Category Form not created");
  }
  
  @Test(dependsOnMethods = "deactivateCategoryForm")
  @TestDetails(TestID = "eProcurement_18")
  public void activateCategoryForm() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    objForms.activateForm(newCategoryForm);
  }
  
  @Test(dependsOnMethods = "createCategoryForm")
  @TestDetails(TestID = "eProcurement_18")
  public void exportCategoryForms() throws Exception {
    if (newCategoryForm != null) {
      AllForms objForms = new AllForms(driver, logger);
      objForms.exportForm("Category Form",newCategoryForm);
    } else
      throw new SkipException("");
  }
  
  @Test(dependsOnMethods = "createCategoryForm")
  @TestDetails(TestID = "eProcurement_18")
  public void copyCategoryForms() throws Exception {
    if (newCategoryForm != null) {
      AllForms objForms = new AllForms(driver, logger);
      objForms.copyCategoryForm(newCategoryForm);
    } else
      throw new SkipException("");
  }
  
  @Test(dependsOnMethods = "Login_CategoryForm")
  @TestDetails(TestID = "eProcurement_18")
  public void saveCategoryFormAsDraft() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    newCategoryFormAsDraft = objForms.saveFormAsDraft("Online Editor","Category Form");
  }
  
  @Test(dependsOnMethods = "saveCategoryFormAsDraft")
  @TestDetails(TestID = "eProcurement_18")
  public void deleteCategoryForm() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    objForms.deleteForm(newCategoryFormAsDraft);
  }

}
