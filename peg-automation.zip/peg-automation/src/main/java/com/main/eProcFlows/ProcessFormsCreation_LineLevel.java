package com.main.eProcFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.eForms.AllForms;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class ProcessFormsCreation_LineLevel extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  private String newProcessForm_LineLvl;
  
  public ProcessFormsCreation_LineLevel() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_ProcessForm() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }
  
  
  @Test(dependsOnMethods = "Login_ProcessForm")
  @TestDetails(TestID = "eProcurement_3")
  public void createProcessForm_LineLevel() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    newProcessForm_LineLvl = objForms
        .selectNewFormCreationProcess("Online Editor","Line level form");
  }
  
 /* @Test(dependsOnMethods = "Login_ProcessForm")
  @TestDetails(TestID = "eProcurement_3")
  public void deleteForm_LineLevel() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    
    objForms.deleteAllForm();
    
  }*/
}
