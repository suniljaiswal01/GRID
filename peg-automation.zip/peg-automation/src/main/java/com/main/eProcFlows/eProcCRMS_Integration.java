package com.main.eProcFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.eProc_DataProviderTestNG;

public class eProcCRMS_Integration extends CommonTests1 {
	
	public String Product = "eProc";
	String types[] = {"PO","PR"};

	public eProcCRMS_Integration() throws Exception {
		super();
		setProduct("eProcurement");
		setClassToLoad("common.Functions.eProc_CommonFunctions");
	}

	@Test()
	@TestDetails(TestID = "login")
	public void LoginCRMSIntegration() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = {"LoginCRMSIntegration","com.main.eProcFlows.PurchaseOrderCreation_WithInvoice.createPurchaseOrder","com.main.eProcFlows.Requisition_Receipt.approveRequisition"} ,dataProviderClass = eProc_DataProviderTestNG.class, dataProvider ="crms_reportGeneration", alwaysRun=true)
	@TestDetails(TestID = "eProcurement_CRMSIntegration")
	public void crms_reportGeneration(String category, String...data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		if(createNewReport.selectProduct(Product)) {
			createNewReport.selectParams(category, data);
			VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
			for(String type : types) {
				verifyReportsField.eProcFieldCheck(type);
			}
			verifyReportsField.backToReportListing();	
		}
	}
}
