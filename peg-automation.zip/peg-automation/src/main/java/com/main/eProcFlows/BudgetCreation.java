package com.main.eProcFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Budget.Budgets;

import common.Functions.eProc_CommonFunctions;

public class BudgetCreation extends CommonTests1 {

  eProc_CommonFunctions objFunctions;
 public static String budgetLineName=null;
 
  
  public BudgetCreation() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test(alwaysRun = true)
  @TestDetails(TestID = "login")
  public void Login_Budget() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = "Login_Budget", alwaysRun = true)
  @TestDetails(TestID = "eProcurement_17")
  public void createBudget() throws Exception {
  Budgets objBudget= new Budgets(driver, logger);
  budgetLineName= objBudget.createNewBudget_ByAddbtn();
  
  }
  
 /* @Test(dependsOnMethods = "Login_Budget")
  @TestDetails(TestID = "eProcurement_17")
  public void deactivateBUdgetBudget() throws Exception {
  Budgets objBudget= new Budgets(driver, logger);
  
  objBudget.filterByStatus("In use");
  objBudget.filterByReservedAmount(50,100);
  objBudget.selectAction("Deactivate");
  }
  
  */
  
}
