package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.PO.PurchaseOrders;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class BlanketPurchaseOrderCreation extends CommonTests1 {

  eProc_CommonFunctions objFunctions;
  private String blanketPO;
  
  public BlanketPurchaseOrderCreation() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_BPO() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = {"Login_BPO","com.main.eProcFlows.BudgetCreation.createBudget"},alwaysRun=true)
  @TestDetails(TestID = "eProcurement_8")
  public void createBlanketPurchaseOrder() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    blanketPO = objOrders.addPO("Blanket PO");
  }
  
  
  @Test(dependsOnMethods = "createBlanketPurchaseOrder")
  @TestDetails(TestID = "eProcurement_13")
  public void approveBlanketPurchaseOrder() throws Exception {
    if (blanketPO != null) {
      Approval objApproval = new Approval(driver,logger);
      Approval.Blanket_PO objBPO = objApproval.new Blanket_PO(driver, logger);
      objBPO.clrAllFilters();
      objBPO.filterByPONo(blanketPO);
      objBPO.approveBlanketPO(blanketPO);    
      System.out.println("Blanket PO approved");
    } else 
      throw new SkipException("Purchase Order not created");
  }
  
  @Test(dependsOnMethods = "approveBlanketPurchaseOrder")
  @TestDetails(TestID = "eProcurement_8")
  public void createReleaseForBPO() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    objOrders.filterByPONumber(blanketPO);
    objOrders.takeActionForBPO(blanketPO, "Create Release");
  }
}
