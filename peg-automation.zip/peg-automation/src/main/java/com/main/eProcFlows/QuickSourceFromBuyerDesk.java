package com.main.eProcFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.BuyersDesk.QuickSourceEvent;

import common.Functions.SupplierDetails;


public class QuickSourceFromBuyerDesk extends CommonTests1 {
	
	String eventName = null;

	public QuickSourceFromBuyerDesk() throws Exception {
		super();
		setProduct("eProcurement");
		setClassToLoad("common.Functions.eProc_CommonFunctions");
	}

	@Test()
	@TestDetails(TestID = "login")
	public void LoginQuickSourceIntegration() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}
	
	@Test(dependsOnMethods = "LoginQuickSourceIntegration")
	@TestDetails(TestID = "eProcurement_11")
	public void createQuickSource() throws Exception {
		
		QuickSourceEvent quickSource = new QuickSourceEvent(driver, logger);
		SupplierDetails supplierDetails = new SupplierDetails();
		supplierDetails.setSupplierData(0);
		String supplierEmail = supplierDetails.getSupplierEmail();
		String SupplierCompanyName = supplierDetails.getCompanyName();
		String SupplierContactName = supplierDetails.getContactingPerson();
		eventName= quickSource.createInquiry(supplierEmail,SupplierCompanyName,SupplierContactName);	
	}
	
	@Test(dependsOnMethods = "createQuickSource")
	@TestDetails(TestID = "iSource_3")
	public void verifyQuickSource() throws Exception{

		QuickSourceEvent quickSource = new QuickSourceEvent(driver, logger);
		quickSource.verifyEventIniSource(eventName);
		
		
	}
}
