package com.main.eProcFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Category_FreeTextItem;
import com.zycus.eProc.Requisition.OnlineStore;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class RequisitionCreation extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  private String requisitionNum;
  
  public RequisitionCreation() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test(alwaysRun = true)
  @TestDetails(TestID = "login")
  public void Login_Requisition() throws Exception {
    
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  // Search Item from Catalog and add it to Cart
  /*@Test(dataProviderClass = eProc_DataProviderTestNG.class, dependsOnMethods = "Login", dataProvider = "OnlineStore", alwaysRun = true)
  @TestDetails(TestID = "eProcurement_15")
  public void OnlineStore(String searchItem, String quantity) throws Exception {
    OnlineStore objReqOnline = new OnlineStore(driver, logger);
    if (objReqOnline.searchItemFromCatalog(searchItem))
      System.out.println("Catalog item searched");
    OnlineStore_SearchResults objSearchRes = new OnlineStore_SearchResults(driver, logger);
    if (objSearchRes.addItemToCart(Integer.parseInt(quantity)))
      System.out.println(quantity + " items added to cart");
  }*/
  
  /*@Test(dependsOnMethods = "Login")
  @TestDetails(TestID = "eProcurement_17")
  public void CreateBudget() throws Exception {
    Budgets objBudget = new Budgets(driver, logger);
    if(objBudget.createNewBudget_ByAddbtn())
      logger.log(Status.INFO, "Budget Added successfully");
    else
      logger.log(Status.INFO, "Budget not added");
  }*/
  
  /*@Test(dependsOnMethods = "Login_Requisition")
  @TestDetails(TestID = "eProcurement_8")
  //public void CreateReceiptAgainstPO(String PONum) throws Exception {
  public void CreateReceiptAgainstPO() throws Exception {
    PurchaseOrders objPO = new PurchaseOrders(driver, logger);
    //if(objPO.createReceiptAgainstPO(PONum))
    objPO.filterByStatus("Not Delivered");
    Thread.sleep(3000);
    String newReceipt= objPO.createReceiptAgainstPO();
    if(newReceipt!=null)
      objPO.LogScreenshot("Pass","Receipt Created successfully");
    else
      objPO.LogScreenshot("Fail","Receipt not created");
  }*/
  
  /*@Test(dependsOnMethods = "Login")
  @TestDetails(TestID = "eProcurement_16")
  //public void CreateReceiptAgainstRequisition(String RequisitionNum) throws Exception {
  public void CreateReceiptAgainstRequisition() throws Exception {
    MyRequisitions objRequistion = new MyRequisitions(driver, logger);
    //if(objRequistion.createReceiptAgainstRequisition(RequisitionNum))
    if(objRequistion.createReceiptAgainstRequisition("[prod1] blue sanity -> 1430"))
      logger.log(Status.INFO, "Receipt Created successfully");
    else
      logger.log(Status.INFO, "Receipt not created");
  }*/
  
  // Search Item from Catalog and add it to Cart
  @Test(dataProviderClass = iSource_DataProviderTestNG.class, 
      dataProvider = "SupplierContacts", dependsOnMethods = 
      {"Login_Requisition","com.main.eProcFlows.CategoryFormsCreation.activateCategoryForm","com.main.eProcFlows.BudgetCreation.createBudget"},alwaysRun=true)
  @TestDetails(TestID = "eProcurement_15")
  public void createRequisition_1(String supplierEmail,String supplierPassword,
      String supplierContactName,String supplierCompanyName) throws Exception {
    OnlineStore objReqOnline = new OnlineStore(driver, logger);
    objReqOnline.emptyCart();
    //Waiting time for eForms to display
    Thread.sleep(60000);
    objReqOnline.viewAllGuidedProcurements();
    objReqOnline.selectEFormFromAllForms(CategoryFormsCreation.newCategoryForm);
    Category_FreeTextItem objItem = new Category_FreeTextItem(driver, logger);
    objItem.createFreeTextItem("Need a quote");
    objItem.selectExistingSupplier(supplierCompanyName);
    objItem.addItemToCart();
    requisitionNum = objItem.checkOut();
  }
  
}
