package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.PO.PurchaseOrders;
import com.zycus.eProc.PO.ReceiptsList;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class PurchaseOrderCreation_WithReceiptCreation extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  public static String standardPO;
  private String createdReceipt;
  private String newReceiptInDraft;
  private String newReturnNoteInDraft;
  private String createdReturnNote;
private String receiptStatus;
private String returnNoteStatus;
  
  public PurchaseOrderCreation_WithReceiptCreation() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test(alwaysRun=true)
  @TestDetails(TestID = "login")
  public void login_PO_WithReceipt() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = {"login_PO_WithReceipt","com.main.eProcFlows.BudgetCreation.createBudget"},alwaysRun=true)
  @TestDetails(TestID = "eProcurement_8")
  public void createPurchaseOrder_WithReceipt() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    standardPO = objOrders.addPO("Standard PO");
  }
  
  @Test(dependsOnMethods = "createPurchaseOrder_WithReceipt")
  @TestDetails(TestID = "eProcurement_13")
  public void approvePurchaseOrder_WithReceipt() throws Exception {
    if (standardPO != null) {
      Approval objApproval = new Approval(driver,logger);
      Approval.Standard_PO objStdPO = objApproval.new Standard_PO(driver, logger);
      objStdPO.clrAllFilters();
      if (!objStdPO.filterByPONo(standardPO)) {
        objStdPO.clrAllFilters();
        refreshAndWait();
        objStdPO.filterByPONo(standardPO);
      }
      objStdPO.approveStandardPO(standardPO);
    } else 
      throw new SkipException("Purchase Order not created");
  }
  
  @Test(dependsOnMethods = "approvePurchaseOrder_WithReceipt")
  @TestDetails(TestID = "eProcurement_8")
  public void createReceiptAgainstPO() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    createdReceipt = objOrders.createReceiptAgainstPO(standardPO);
    receiptStatus = objOrders.getReceiptStatus(createdReceipt);
  }
  
  @Test(dependsOnMethods = "createReceiptAgainstPO")
  @TestDetails(TestID = "eProcurement_13")
  public void approveReceipt() throws Exception {
	if(!(receiptStatus.equals("Confirmed"))){
	    Approval objApproval = new Approval(driver,logger);
	    Approval.Receipts objReceipt = objApproval.new Receipts(driver, logger);
	    objReceipt.clrAllFilters();
	    //objReceipt.filterByRecieptNo(createdReceipt);
	    objReceipt.approveReceipt(createdReceipt);
	}else
		throw new SkipException("Receipt already in Confirmed Status");
  }
  
  
  @Test(dependsOnMethods = "approveReceipt")
  @TestDetails(TestID = "eProcurement_8")
  public void saveReturnNoteAsDraft() throws Exception {
    ReceiptsList objReceipt = new ReceiptsList(driver, logger);
    newReturnNoteInDraft = objReceipt.saveNewReturnNoteAsDraft(standardPO);
  }
  
  @Test(dependsOnMethods = "saveReturnNoteAsDraft")
  @TestDetails(TestID = "eProcurement_1")
  public void deleteReturnNote() throws Exception {
    if(newReturnNoteInDraft!=null){
      ReceiptsList objReceipt = new ReceiptsList(driver, logger);
      objReceipt.deleteReturnNote(newReturnNoteInDraft);
    }else
      throw new SkipException("Return Note not saved as Draft");
  }
  
  @Test(dependsOnMethods = "deleteReturnNote")
  @TestDetails(TestID = "eProcurement_8")
  public void createReturnNote() throws Exception {
    ReceiptsList objOrders = new ReceiptsList(driver, logger);
    createdReturnNote = objOrders.submitNewReturnNote(standardPO);
    PurchaseOrders objOrders1 = new PurchaseOrders(driver, logger);
    returnNoteStatus = objOrders1.getReceiptStatus(createdReturnNote);
  }
  
  @Test(dependsOnMethods = "createReturnNote")
  @TestDetails(TestID = "eProcurement_13")
  public void approveReturnNote() throws Exception {
	if(!(returnNoteStatus.equals("Returned"))){
	    Approval objApproval = new Approval(driver,logger);
	    Approval.Receipts objReceipt = objApproval.new Receipts(driver, logger);
	    objReceipt.clrAllFilters();
	    //objReceipt.filterByRecieptNo(createdReceipt);
	    objReceipt.approveReceipt(createdReturnNote);
	}else
		throw new SkipException("Return note already in Returned state");
  }
  
  /*@Test(dependsOnMethods = "approveReturnNote")
  @TestDetails(TestID = "eProcurement_8")
  public void cancelReceipt() throws Exception {
    if(createdReceipt!=null){
      PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
      objOrders.viewPO(standardPO);
      PurchaseOrder objOrder = new PurchaseOrder(driver, logger);
      objOrder.navigateToPOTabs("Receipt");
      ReceiptsList objReceipt = new ReceiptsList(driver, logger);
      objReceipt.cancelReceipt(createdReceipt);
    }else
      throw new SkipException("Receipt not created");
  }
  */
  
  @Test(dependsOnMethods = "approveReturnNote")
  @TestDetails(TestID = "eProcurement_8")
  public void downloadReturnNote() throws Exception {
    ReceiptsList objReceipt = new ReceiptsList(driver, logger);
    //newReturnNote = objReceipt.submitNewReturnNote(standardPO);
    objReceipt.downloadReturnNote(createdReturnNote, standardPO);
  }
  
  @Test(dependsOnMethods = "downloadReturnNote")
  @TestDetails(TestID = "eProcurement_8")
  public void saveReceiptAsDraft() throws Exception {
    ReceiptsList objReceipt = new ReceiptsList(driver, logger);
    newReceiptInDraft = objReceipt.saveNewReceiptAsDraft(standardPO);
  }
  
  @Test(dependsOnMethods = "saveReceiptAsDraft")
  @TestDetails(TestID = "eProcurement_1")
  public void deleteDraftedReceipt() throws Exception {
    if (newReceiptInDraft != null) {
      ReceiptsList objReceipt = new ReceiptsList(driver, logger);
      objReceipt.deleteReceipt(newReceiptInDraft);
    } else
      throw new SkipException("Receipt not saved as Draft");
  }
  
 
  
}
