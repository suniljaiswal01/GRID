package com.main.eProcFlows;

import org.testng.annotations.Test;
import com.main.CommonTests1;
import com.main.TestDetails;
import DataProviders.eProc_DataProviderTestNG;
import com.zycus.eProc.Reports.Reports;


public class EprocReports extends CommonTests1{

	public EprocReports() throws Exception {
		super();
		setProduct("eProcurement");
		setClassToLoad("common.Functions.eProc_CommonFunctions");
	}

	@Test()
	@TestDetails(TestID = "login")
	public void Login_Report() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}

	@Test(dataProviderClass = eProc_DataProviderTestNG.class,dependsOnMethods = "Login_Report",dataProvider = "Reports")
	@TestDetails(TestID="eProcurement_22")
	public void Reports(String...reports) throws Exception {
		Reports objReports = new Reports(driver, logger);
		objReports.searchInvoicePrePackagedReports(reports);
	}

	@Test(dataProviderClass = eProc_DataProviderTestNG.class, dependsOnMethods = "Reports",dataProvider = "ModifyReports")
	@TestDetails(TestID="eProcurement_22")
	public void ModifyReport(String report) throws Exception {

		Reports objReports = new Reports(driver, logger);
		objReports.modifyReport(report);
	}

}
