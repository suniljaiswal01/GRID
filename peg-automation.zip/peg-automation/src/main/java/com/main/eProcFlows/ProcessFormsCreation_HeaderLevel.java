package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.eForms.AllForms;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class ProcessFormsCreation_HeaderLevel extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  private String newProcessForm_headerLvl;
  private String newProcessForm_headerLvlAsDraft;
  
  public ProcessFormsCreation_HeaderLevel() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_ProcessForm() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = "Login_ProcessForm")
  @TestDetails(TestID = "eProcurement_2")
  public void createProcessForm_headerLevel() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    newProcessForm_headerLvl = objForms
        .selectNewFormCreationProcess("Online Editor", "Header level form");
  }
  
  @Test(dependsOnMethods = "createProcessForm_headerLevel")
  @TestDetails(TestID = "eProcurement_2")
  public void deactivateProcessForm_headerLevel() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    objForms.deactivateForm(newProcessForm_headerLvl);
  }
  
  @Test(dependsOnMethods = "deactivateProcessForm_headerLevel")
  @TestDetails(TestID = "eProcurement_2")
  public void activateProcessForm_headerLevel() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    objForms.activateForm(newProcessForm_headerLvl);
  }
  
  @Test(dependsOnMethods = "activateProcessForm_headerLevel")
  @TestDetails(TestID = "eProcurement_2")
  public void exportProcessForm_headerLevel() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    objForms.exportForm("Process Form",newProcessForm_headerLvl);
  }
  
  @Test(dependsOnMethods = "exportProcessForm_headerLevel")
  @TestDetails(TestID = "eProcurement_2")
  public void copyProcessForms() throws Exception {
    if (newProcessForm_headerLvl != null){
      AllForms objForms = new AllForms(driver, logger);
      objForms.copyProcessForm(newProcessForm_headerLvl);
    } else
        throw new SkipException("Header Level Process form not created");
  }
  
  @Test(dependsOnMethods = "copyProcessForms")
  @TestDetails(TestID = "eProcurement_2")
  public void saveHeaderLvlProcessFormAsDraft() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    newProcessForm_headerLvlAsDraft = objForms.saveFormAsDraft("Online Editor","Process Form");
  }
  
  @Test(dependsOnMethods = "saveHeaderLvlProcessFormAsDraft")
  @TestDetails(TestID = "eProcurement_2")
  public void deleteHeaderLvlProcessForm() throws Exception {
    AllForms objForms = new AllForms(driver, logger);
    objForms.deleteForm(newProcessForm_headerLvlAsDraft);
  }
}
