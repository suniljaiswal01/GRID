package com.main.eProcFlows;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Pcard.NewPcard;

import common.Functions.eProc_CommonFunctions;

public class PCardCreation extends CommonTests1 {

  eProc_CommonFunctions objFunctions;
  static String newCatalog;
  
  public PCardCreation() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_Pcard() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = "Login_Pcard")
  @TestDetails(TestID = "eProcurement_21")
  public void createPCard() throws Exception {
  
	  NewPcard newPcard = new NewPcard(driver, logger); 
	  newPcard.addNewPcard("Master Card");
	  newPcard.addNewPcard("Visa");
	  newPcard.addNewPcard("Amex");
	  
  }
  
}
