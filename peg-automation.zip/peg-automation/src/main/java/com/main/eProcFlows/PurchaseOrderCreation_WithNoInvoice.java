package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.PO.PurchaseOrders;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class PurchaseOrderCreation_WithNoInvoice extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  private String standardPO;
  
  public PurchaseOrderCreation_WithNoInvoice() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_POWithNoInvoice() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = {"Login_POWithNoInvoice","com.main.eProcFlows.BudgetCreation.createBudget"},alwaysRun=true)
  @TestDetails(TestID = "eProcurement_8")
  public void createPurchaseOrderWithNoInvoice() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    standardPO = objOrders.addPO("Standard PO");
  }
  
  @Test(dependsOnMethods = "createPurchaseOrderWithNoInvoice")
  @TestDetails(TestID = "eProcurement_13")
  public void approvePurchaseOrderWithNoInvoice() throws Exception {
    if (standardPO != null) {
      Approval objApproval = new Approval(driver,logger);
      Approval.Standard_PO objStdPO = objApproval.new Standard_PO(driver, logger);
      objStdPO.clrAllFilters();
      objStdPO.filterByPONo(standardPO);
      objStdPO.approveStandardPO(standardPO);
    } else 
      throw new SkipException("Purchase Order not created");
  }
  
  @Test(dependsOnMethods = "createPurchaseOrderWithNoInvoice")
  @TestDetails(TestID = "eProcurement_8")
  public void closePurchaseOrderWithNoInvoiceCreation() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    objOrders.closePOAndVerifyInvoiceNotAllowed(standardPO);
  }
  
  @Test(dependsOnMethods = "approvePurchaseOrderWithNoInvoice")
  @TestDetails(TestID = "eProcurement_8")
  public void downloadPurchaseOrder() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    objOrders.downloadPO(standardPO);
  }
  
}
