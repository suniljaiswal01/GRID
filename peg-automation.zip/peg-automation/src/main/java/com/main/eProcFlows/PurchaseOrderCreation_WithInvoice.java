package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyOrders.PurchaseOrderZSN;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.PO.PurchaseOrders;
import com.zycus.eProc.Setup.Customize;

import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.SupplierDetails;
import common.Functions.eProc_CommonFunctions;

public class PurchaseOrderCreation_WithInvoice extends CommonTests1 {

	private String Product = "eProcurement";
	eProc_CommonFunctions objFunctions;
	public static String standardPO;
	private int allowedItemPricePercent;
	private int allowedItemQtyPercent;

	public PurchaseOrderCreation_WithInvoice() throws Exception {
		super();
		setProduct("eProcurement");
		setClassToLoad("common.Functions.eProc_CommonFunctions");
	}

	@Test(alwaysRun = true)
	@TestDetails(TestID = "login")
	public void Login_PO() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}

	 @Test(dependsOnMethods = {"Login_PO","com.main.eProcFlows.BudgetCreation.createBudget"},alwaysRun=true)
	@TestDetails(TestID = "eProcurement_8")
	public void createPurchaseOrder() throws Exception {
		PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
		standardPO = objOrders.addPO("Standard PO");
	}

	@Test(dependsOnMethods = "createPurchaseOrder")
	@TestDetails(TestID = "eProcurement_13")
	public void approvePurchaseOrder() throws Exception {
		if (standardPO != null){
			Approval objApproval = new Approval(driver,logger);
			Approval.Standard_PO objStdPO = objApproval.new Standard_PO(driver, logger);
			objStdPO.clrAllFilters();
			objStdPO.filterByPONo(standardPO);
			objStdPO.approveStandardPO(standardPO);

		} else
			throw new SkipException("Purchase Order not created");
	}


	@Test(dependsOnMethods = "approvePurchaseOrder")
	@TestDetails(TestID="eProcurement_8")
	public void confirmPurchaseOrderForZSN() throws Exception {

		PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
		objOrders.clrAllFilters();
		objOrders.filterByPONumber(standardPO);

		String status = objOrders.getPOStatus(standardPO);

		if(status.equals("Released")) {
			driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
			SupplierDetails supplierDetails = new SupplierDetails();
			supplierDetails.setSupplierData(0);
			String externalSupplier = supplierDetails.getSupplierEmail();
			String externalPass = supplierDetails.getSupplierPassword();
			Login objLogin = new Login(driver1, logger, externalSupplier, externalPass);
			callAndLog(driver1,logger,objLogin.login(configurationProperties), "login successful", "Not logged in");
			CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
			objZSNFunctions.navigate_path1("My Orders", "View Orders", configurationProperties.getProperty("Tenant"));
			PurchaseOrderZSN purchaseOrder = new PurchaseOrderZSN(driver1, logger);
			purchaseOrder.confirmPurchaseOrder(standardPO);
			purchaseOrder.shipmentNotice(standardPO);
			objLogin.logout();
			driver1.quit();
		}else {
			LogScreenshot("info","PO Not in Release status. Current Status of PO is: "+status);
		}		
	}



	@Test(dependsOnMethods = "approvePurchaseOrder")
	@TestDetails(TestID = "eProcurement_20")
	public void getAllowedItemAmountQtyRangeOnAmendingPO() throws Exception {
		Customize objCustomize = new Customize(driver, logger);
		objCustomize.navigateToSettingsPage("Purchase Order");
		allowedItemPricePercent = objCustomize.getAllowedItemPriceOnAmendingPO();
		allowedItemQtyPercent = objCustomize.getAllowedItemQtyOnAmendingPO();
	}

	@Test(dependsOnMethods = "getAllowedItemAmountQtyRangeOnAmendingPO")
	@TestDetails(TestID = "eProcurement_8")
	public void amendPurchaseOrderByItemAmount() throws Exception {
		PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
		objOrders.amendPOByItemAmount(standardPO, "greater than allowed", allowedItemPricePercent);
	}

	@Test(dependsOnMethods = "getAllowedItemAmountQtyRangeOnAmendingPO")
	@TestDetails(TestID = "eProcurement_8")
	public void amendPurchaseOrderByItemQty() throws Exception {
		PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
		objOrders.amendPOByItemQty(standardPO, "greater than allowed", allowedItemQtyPercent);
	}

	@Test(dependsOnMethods = "amendPurchaseOrderByItemQty")
	@TestDetails(TestID = "eProcurement_8")
	public void closePurchaseOrderWithInvoiceCreation() throws Exception {
		PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
		objOrders.closePOAndAddInvoice(standardPO);
	}

	/*@Test(dependsOnMethods = "closePurchaseOrderWithInvoiceCreation")
  @TestDetails(TestID = "eProcurement_8")
  public void reOpenPurchaseOrder() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    objOrders.closePOAndAddInvoice(standardPO);
  }*/

}
