package com.main.eProcFlows;

import java.util.List;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.IContract.ManageContracts.Repository;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.Catalog.Catalog;

import common.Functions.eProc_CommonFunctions;

public class CatalogCreationWithContract extends CommonTests1 {

  eProc_CommonFunctions objFunctions;
  private String newCatalog;
  public static List<String> contractsList;
  
  public CatalogCreationWithContract() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_CatalogWithContract() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }
  
  
  @Test(dependsOnMethods = "Login_CatalogWithContract")
  @TestDetails(TestID = "iContract_12")
  public void searchContractInRepository() throws Exception {
    Repository objRepository = new Repository(driver, logger);
    objRepository.filterByContractingParty();
    objRepository.filterByContractSource("Repository");
    contractsList = objRepository.getFilteredContractsListWithSingleContParty();
  }

  @Test(dependsOnMethods = "searchContractInRepository")
  @TestDetails(TestID = "eProcurement_4")
  public void createCatalogWithContract() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    if(contractsList.size()>0){
      newCatalog = objCatalog.addCatalog(contractsList.get(0), false);
      System.out.println("New Catalog created");
    }
    else
      throw new SkipException("No Contract related to the supplier");
  }
  
  @Test(dependsOnMethods = "createCatalogWithContract")
  @TestDetails(TestID = "eProcurement_13")
  public void approveCatalogWithContract() throws Exception {
    if(newCatalog!=null){
      Approval objApproval = new Approval(driver,logger);
      Approval.Catalog objCatalog = objApproval.new Catalog(driver, logger);
      objCatalog.filterBycatalogName(newCatalog);
      objCatalog.takeAction(newCatalog, "Approve");
    }else
      throw new SkipException("New Catalog not created");
  }
  
}
