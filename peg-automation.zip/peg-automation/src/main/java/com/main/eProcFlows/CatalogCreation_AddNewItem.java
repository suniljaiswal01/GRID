package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.Catalog.Catalog;

import DataProviders.Common_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class CatalogCreation_AddNewItem extends CommonTests1 {

  eProc_CommonFunctions objFunctions;
  static String newCatalog;
  
  public CatalogCreation_AddNewItem() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_Catalog() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = "Login_Catalog")
  @TestDetails(TestID = "eProcurement_4")
  public void createCatalog() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    newCatalog = objCatalog.addCatalog(false);
    System.out.println("New Catalog created");
  }
  
  @Test(dependsOnMethods = "createCatalog")
  @TestDetails(TestID = "eProcurement_13")
  public void approveCatalog() throws Exception {
    if (newCatalog != null){
      Approval objApproval = new Approval(driver,logger);
      Approval.Catalog objCatalog = objApproval.new Catalog(driver, logger);
      objCatalog.filterBycatalogName(newCatalog);
      objCatalog.takeAction(newCatalog, "Approve");
      System.out.println("Catalog filtered");
    } else
      throw new SkipException("New Catalog not created");
  }
  
}
