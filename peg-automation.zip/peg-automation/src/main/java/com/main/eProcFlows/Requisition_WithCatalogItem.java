package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.BuyersDesk.Requisitions;
import com.zycus.eProc.PO.PurchaseOrders;
import com.zycus.eProc.Requisition.OnlineStore;
import com.zycus.eProc.Requisition.OnlineStore_SearchResults;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.eProc_DataProviderTestNG;
import common.Functions.eProc_CommonFunctions;

public class Requisition_WithCatalogItem extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  private String requisitionNum ;
  private String requisitionName;
  private String createdPO;
  private String requisitionStatus;
  private String poStatus;
  
  
  public Requisition_WithCatalogItem() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test(alwaysRun = true)
  @TestDetails(TestID = "login")
  public void Login_ReqReceiptWithCatalog() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  // Search Item from Catalog and add it to Cart
  @Test(dataProviderClass = eProc_DataProviderTestNG.class, dependsOnMethods = {"Login_ReqReceiptWithCatalog", "com.main.eProcFlows.CatalogCreation_AddNewItem.approveCatalog","com.main.eProcFlows.BudgetCreation.createBudget"},alwaysRun=true , dataProvider = "SearchItemFromCatalog")
  @TestDetails(TestID = "eProcurement_15")
  public void createRequisitionWithCatalog(String searchItem, String quantity) throws Exception {
    OnlineStore objReqOnline = new OnlineStore(driver, logger);
    objReqOnline.emptyCart();
    objReqOnline.selectCatalog(CatalogCreation_AddNewItem.newCatalog);
    //objReqOnline.selectCatalog("14June");
    OnlineStore_SearchResults objSearchRes = new OnlineStore_SearchResults(driver, logger);
    if (objSearchRes.addItemToCart(Integer.parseInt(quantity),searchItem)) {
      LogScreenshot("pass",quantity + " items added to cart");
      requisitionName = objSearchRes.checkOut();
      Requisitions objReq = new Requisitions(driver, logger);
      requisitionStatus = objReq.getRequisitionStatusByName(requisitionName);
      LogScreenshot("Info", "Requisition "+requisitionName + " created with status as "+requisitionStatus);
    }
  }
   
  
  @Test(dependsOnMethods = "createRequisitionWithCatalog")
  @TestDetails(TestID = "eProcurement_9")
  public void editRequisitionAtBuyersDesk() throws Exception {
	if (requisitionStatus.equals("Sent for Buyer Review") && requisitionName != null) {
		Requisitions objReq = new Requisitions(driver, logger);
	    objReq.clrAllFilters();
	    requisitionNum = objReq.getRequisitionNumber(requisitionName);
	    objReq.filterByRequisitionNo(requisitionNum);
	    objReq.editRequisition(requisitionNum);
	}else
	 throw new SkipException("Requisition not created or not in 'Sent for Buyer Review' status");
  }
  
 
  @Test(dependsOnMethods = "editRequisitionAtBuyersDesk", alwaysRun = true)
  @TestDetails(TestID = "eProcurement_13")
  public void approveCatalogBasedRequisition() throws Exception {
    Approval objApproval = new Approval(driver,logger);
    Approval.Requisition objReq = objApproval.new Requisition(driver, logger);
    /*objReq.clrAllFilters();
    objReq.filterByRequisitionName(requisitionName);*/
    //objReq.filterByRequisitionNo(requisitionNum);
    objReq.approveRequisitionByName(requisitionName);    
    requisitionNum = objReq.getRequisitionNumber(requisitionName);
    System.out.println("Requisition Number: "+requisitionNum+" fully approved");
  }
  
  @Test(dependsOnMethods = "approveCatalogBasedRequisition")
  @TestDetails(TestID = "eProcurement_9")
  public void convertReqToPOatBuyersDesk() throws Exception {
    Requisitions objReq = new Requisitions(driver, logger);
    objReq.clrAllFilters();
    objReq.filterByRequisitionNo(requisitionNum);
    createdPO = objReq.convertToPO(requisitionNum);
  }
  
  @Test(dependsOnMethods = "convertReqToPOatBuyersDesk")
  @TestDetails(TestID = "eProcurement_8")
  public void verifycreatedPOInAppovalState() throws Exception {
    PurchaseOrders objOrders = new PurchaseOrders(driver, logger);
    objOrders.clrAllFilters();
    objOrders.filterByPONumber(createdPO);
    poStatus = objOrders.getPOStatus(createdPO);
    if (poStatus.equals("In Approval"))
      objOrders.LogScreenshot("Pass", "PO created in 'In Approval' state");
    else if (poStatus.equals("Released"))
    		objOrders.LogScreenshot("Info", "PO directly moved to 'Released' state");
    else
    	objOrders.LogScreenshot("Fail", "PO not created in 'In Approval' state");
  }
  
  @Test(dependsOnMethods = "verifycreatedPOInAppovalState")
  @TestDetails(TestID = "eProcurement_13")
  public void approvePOCreated() throws Exception {
	if(!(poStatus.equals("Released"))){
	    Approval objApproval = new Approval(driver,logger);
	    Approval.Standard_PO objStdPO = objApproval.new Standard_PO(driver, logger);
	    objStdPO.clrAllFilters();
	    objStdPO.filterByPONo(createdPO);
	    objStdPO.approveStandardPO(createdPO);    
	    System.out.println("Standard PO approved");
	}else
		throw new SkipException("PO already in Released state");
  }
  
  
  /*@Test(dependsOnMethods = "Login", priority = 2)
  @TestDetails(TestID = "eProcurement_16")
  //public void CreateReceiptAgainstRequisition(String RequisitionNum) throws Exception {
  public void CreateReceiptAgainstRequisition() throws Exception {
    MyRequisitions objRequistion = new MyRequisitions(driver, logger);
    //if(objRequistion.createReceiptAgainstRequisition(RequisitionNum))
    if(objRequistion.createReceiptAgainstRequisition("1459"))
      logger.pass("Receipt Created successfully");
    else
      logger.fail("Receipt not created");
  }*/
  
}
