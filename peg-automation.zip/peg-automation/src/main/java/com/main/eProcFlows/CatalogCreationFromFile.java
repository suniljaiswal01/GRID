package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.Catalog.Catalog;

import common.Functions.eProc_CommonFunctions;

public class CatalogCreationFromFile extends CommonTests1 {

  private String Product = "eProcurement";
  eProc_CommonFunctions objFunctions;
  private String newCatalog;
private String catalogStatus;
  
  public CatalogCreationFromFile() throws Exception {
    super();
    setProduct("eProcurement");
    setClassToLoad("common.Functions.eProc_CommonFunctions");
  }

  @Test()
  @TestDetails(TestID = "login")
  public void Login_FileBasedCatalog() throws Exception {
    displayStyle = getDisplayStyle(driver, logger, loginCredentials);
    callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
        "Display style is not rainbow");
  }

  @Test(dependsOnMethods = "Login_FileBasedCatalog")
  @TestDetails(TestID = "eProcurement_4")
  public void createCatalogFromFile() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    newCatalog = objCatalog.addCatalog(true);
    Thread.sleep(60000);
    catalogStatus = objCatalog.getCatalogStatus(newCatalog);
  }
  
  @Test(dependsOnMethods = "createCatalogFromFile")
  @TestDetails(TestID = "eProcurement_4")
  public void recallCatalogInApproval() throws Exception {
	  if(!(catalogStatus.equals("Published")||catalogStatus=="null")){
	    Catalog objCatalog = new Catalog(driver, logger);
	    objCatalog.recallApprovalRequest(newCatalog);
	  }else
		throw new SkipException("Catalog already published or not created");
  }
  
  @Test(dependsOnMethods = "recallCatalogInApproval")
  @TestDetails(TestID = "eProcurement_4")
  public void submitRecalledCatalog() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    objCatalog.submitDraftedCatalog(newCatalog);
  }
  
  @Test(dependsOnMethods = "submitRecalledCatalog")
  @TestDetails(TestID = "eProcurement_13")
  public void approveCatalogFromFile() throws Exception {
    Approval objApproval = new Approval(driver,logger);
    Approval.Catalog objCatalog = objApproval.new Catalog(driver, logger);
    objCatalog.filterBycatalogName(newCatalog);
    objCatalog.takeAction(newCatalog, "Approve");
  }
  
  @Test(dependsOnMethods = "approveCatalogFromFile")
  @TestDetails(TestID = "eProcurement_4")
  public void updateCatalogCreatedFromFile() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    objCatalog.updateCatalog(newCatalog);
  }
  
  @Test(dependsOnMethods = "updateCatalogCreatedFromFile")
  @TestDetails(TestID = "eProcurement_13")
  public void approveUpdatedCatalog() throws Exception {
    Approval objApproval = new Approval(driver,logger);
    Approval.Catalog objCatalog = objApproval.new Catalog(driver, logger);
    objCatalog.filterBycatalogName(newCatalog);
    objCatalog.takeAction(newCatalog, "Approve");
  }
  
  @Test(dependsOnMethods = "approveUpdatedCatalog")
  @TestDetails(TestID = "eProcurement_4")
  public void deactivateCatalogCreatedFromFile() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    objCatalog.deactivateCatalog(newCatalog);
  }
  
  @Test(dependsOnMethods = "deactivateCatalogCreatedFromFile")
  @TestDetails(TestID = "eProcurement_4")
  public void deleteFileBasedCatalog() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    objCatalog.deleteCatalog(newCatalog);
  }
  
}
