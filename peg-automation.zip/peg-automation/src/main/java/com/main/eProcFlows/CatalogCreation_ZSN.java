package com.main.eProcFlows;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.Log;
import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyCatalogs.CreateNewCatalog;
import com.zycus.ZSN.MyInvoices.CreateNonPOInvoice;
import com.zycus.eProc.Approval.Approval;
import com.zycus.eProc.Approval.ApprovalDetails;
import com.zycus.eProc.Catalog.Catalog;
import com.zycus.eProc.Catalog.NewCatalog;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.iSource_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eProc_CommonFunctions;

public class CatalogCreation_ZSN extends CommonTests1 {

	eProc_CommonFunctions objFunctions;
	private String newCatalog;
	private String catalogStatus = null;

	public CatalogCreation_ZSN() throws Exception {
		super();
		setProduct("eProcurement");
		setClassToLoad("common.Functions.eProc_CommonFunctions");
	}

	@Test()
	@TestDetails(TestID = "login")
	public void Login_Catalog_ZSN() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow") ? true : false, "Display style is Rainbow",
				"Display style is not rainbow");
	}


	/*@Test(dependsOnMethods = "Login_Catalog_ZSN", priority = 2)
  @TestDetails(TestID = "eProcurement_4")
  public void createCatalogWithContract() throws Exception {
    Catalog objCatalog = new Catalog(driver, logger);
    newCatalog = objCatalog.addCatalog("AUTO10079", false);
    System.out.println("New Catalog created");
  }*/

	@Test(dataProviderClass = iSource_DataProviderTestNG.class, alwaysRun = true)
	@TestDetails(TestID="loginZSN")
	public void Login_ZSN_CatalogCreation() throws Exception {
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(zsnDriver, logger);
		try {
			objZSNFunctions.navigate_path1("My Catalogs", "Create New Catalog", configurationProperties.getProperty("Tenant"));
			CreateNewCatalog objCatalog = new CreateNewCatalog(zsnDriver, logger);
			newCatalog = objCatalog.createCatalog_ZSN();
			catalogStatus  = objCatalog.verifyVisibilityOfCatalog(newCatalog);
		}catch (Exception e) {
			objZSNFunctions.LogScreenshot("fail","Failed during catalog creation");
		}
		zsnDriver.quit();
	}

	@Test(dependsOnMethods = "Login_ZSN_CatalogCreation",alwaysRun = true)
	@TestDetails(TestID = "eProcurement_4")
	public void editCatalogFromZSN() throws Exception {
		if (newCatalog != null){
			//if(catalogStatus!="Private" || catalogStatus!="null"){
			if(!(catalogStatus.equals("Private")||catalogStatus=="null")){
				Catalog objCatalog = new Catalog(driver, logger);
				objCatalog.editCatalogReceivedFromZSN(newCatalog);
				objCatalog.LogScreenshot("PASS", "Catalog edited successfully");
			}else
				throw new SkipException("Catalog status is private or its visibility could not be checked");
		} else
			throw new SkipException("New Catalog not created");
	}

	@Test(dependsOnMethods = "editCatalogFromZSN")
	@TestDetails(TestID = "eProcurement_13")
	public void approveCatalog() throws Exception {
		if (newCatalog != null){
			ApprovalDetails objApproval = new ApprovalDetails(driver,logger);
			objApproval.approveCatalog(newCatalog);
			
		} else
			throw new SkipException("New Catalog not created");
	}
	
	@Test(dependsOnMethods= "approveCatalog")
	@TestDetails(TestID="loginZSN")
	public void verifyCatalogStatusInZSN() throws Exception {
		String tenant = configurationProperties.getProperty("Tenant");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(zsnDriver, logger);
		objZSNFunctions.navigate_path1("My Catalogs", "View/Update Catalogs", tenant);
		CreateNewCatalog objcatalog= new CreateNewCatalog(zsnDriver, logger);
		objcatalog.verifyCatalogStatusInZSN(newCatalog);
	}


}
