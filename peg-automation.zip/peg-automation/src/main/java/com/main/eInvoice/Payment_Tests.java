package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Payment.Batches;
import com.zycus.eInvoice.Payment.NewPaymentBatch;
import com.zycus.eInvoice.Payment.NewVoucher;

import DataProviders.eInvoice_DataProviderTestNG;

public class Payment_Tests extends CommonTests1 {



	/*	private ExtentTest logger;*/
	private String Product = "eInvoice";
	String batchNo;
	

	// private Method m;

	public Payment_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	@Test(groups = "Login_Payment", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_Payment() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods = "login_Payment", dataProvider = "NewBatch")
	@TestDetails(TestID = "eInvoice_14")
	public void NewBatch(String organizationUnit, String bankAcct, String approver, String notes, String reviewer,
			String supplier, String chkNo, String voucherNo) throws Exception {
		Batches objBatches = new Batches(driver, logger);
		NewPaymentBatch objNewPayment = new NewPaymentBatch(driver, logger, organizationUnit, bankAcct);
		if (objBatches.createNewBatch(objNewPayment)) {
			NewVoucher objVoucher = new NewVoucher(driver, logger, supplier, chkNo, voucherNo);
			batchNo = objNewPayment.enterBatchDetails(approver, notes, reviewer, objVoucher);
		}
	}
	
	@Test(dependsOnMethods = "NewBatch")
	@TestDetails(TestID = "eInvoice_14")
	public void IssuePaymentForNewBatch() throws Exception {
		Batches objBatches = new Batches(driver, logger);
		objBatches.issuePayment(batchNo);
		objBatches.verifyBatchStatus(batchNo,"Paid");
	}
	
	@Test(dependsOnMethods = "IssuePaymentForNewBatch", alwaysRun=true)
	@TestDetails(TestID = "eInvoice_14")
	public void EditBatchinDraft() throws Exception {
		Batches objBatches = new Batches(driver, logger);
		objBatches.editBatch();		
		}
	
		
	}

