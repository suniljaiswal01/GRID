package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;

public class InvoiceNonPOCreation_Tests extends CommonTests1{


	String invoiceNo;
	public static String invoiceNonPO;
	String copiedInvoice;
	String invStatus;
	String copiedInvStatus;



	public InvoiceNonPOCreation_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	@Test(groups = "Login_Invoices", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_InvoicesInvoiceNonPO() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");

	}
	@Test(dependsOnMethods= "login_InvoicesInvoiceNonPO", dataProviderClass = eInvoice_DataProviderTestNG.class,
			dataProvider = "InvoiceNonPONew")
	@TestDetails(TestID="eInvoice_12")
	public void invoiceNonPO(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType,String headerLevelTaxRate) throws Exception {		
		Invoices objInvoice = new Invoices(driver, logger);	
		try{
			invoiceNonPO = objInvoice.createInvoiceNonPO(supplierSelectCategory, supplierName, paymentTerm, currency_value,  invoiceOrCreditMemoDate, purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headerLevelTaxRate);
			invStatus= objInvoice.verifyCreditMemoOrInvoiceStatus(invoiceNonPO);
		}catch(Exception e){
			if(driver.findElements(By.id("cancelInvoice")).size()>0)
				driver.findElement(By.id("cancelInvoice")).click();
			LogScreenshot("FAIL","Invoice is not created");
			e.printStackTrace();	
			throw e;
		}	 
	}
	
	@Test(dependsOnMethods= "invoiceNonPO")
	@TestDetails(TestID="eInvoice_2")	
	public void approveInvoiceNonPO() throws Exception {
		if(invoiceNonPO != null) {
			if(!invStatus.equals("Approved")) {
			Invoices objInvoice = new Invoices(driver, logger);
			try {
				objInvoice.approveInvoice(invoiceNonPO);
			}catch(Exception e){
				e.printStackTrace();
			}
			}else
				throw new SkipException("Invoice is already approved");
		}else
			throw new SkipException("Skipping Approving Invoice Non PO");
	}

	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class,
			dataProvider = "InvoiceNonPONew",alwaysRun=true,dependsOnMethods= "approveInvoiceNonPO")
	@TestDetails(TestID="eInvoice_12")
	public void copyNonPOInvoice(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType, String headerLevelTaxRate) throws Exception {		
		Invoices objInvoice = new Invoices(driver, logger);
		try{
			copiedInvoice= objInvoice.copyInvoice(invoiceNonPO);
			if(copiedInvoice!=null) {
				copiedInvStatus=objInvoice.verifyCreditMemoOrInvoiceStatus(copiedInvoice);
			}else {
			LogScreenshot("FAIL","Invoice is not copied");
			}
		}catch(Exception e){
			LogScreenshot("FAIL","Copying Invoice failed");
			e.printStackTrace();
		}
	}

	@Test(dependsOnMethods= "copyNonPOInvoice")
	@TestDetails(TestID="eInvoice_2")
	public void approveCopiedInvoice() throws Exception {		
		if(copiedInvoice!=null) {
			if(!copiedInvStatus.equals("Approved")) {
			Invoices objInvoice = new Invoices(driver, logger);
			try {
				objInvoice.approveInvoice(copiedInvoice);
			}catch(Exception e){
				e.printStackTrace();
			}
		}else{
			throw new SkipException("Copied Invoice is already approved");
		}
			}
		else
			throw new SkipException("Invoice not copied");
	}
	


	@Test(dependsOnMethods= "approveCopiedInvoice")
	@TestDetails(TestID="eInvoice_8")
	public void void_Invoice() throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		Thread.sleep(3000);
		objInvoice.clearAllFilters();
		Thread.sleep(3000);
		objInvoice.filterByDocNo(copiedInvoice);	
		if(objInvoice.takeActionOnInvoice("Void Invoice")) 
			LogScreenshot("PASS", "Able to void invoice");	
	}



}
