package com.main.eInvoice;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.PO.PurchaseOrder;
import com.zycus.eInvoice.Workflow.Workflow;
import com.zycus.eInvoice.Workflow.WorkflowWizard;

import DataProviders.eInvoice_DataProviderTestNG;

public class Workflow_PO_Tests extends CommonTests1{



	/*	private ExtentTest logger;*/
	private String Product = "eInvoice";

	public Workflow_PO_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	 /**
	 * @param Product
	 * @param Username
	 * @param Password
	 * @param Customer
	 * @throws Exception
	 */	
	@Test(groups = "Login_Workflow_PO" ,alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_Workflow_PO() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods = "login_Workflow_PO", dataProvider = "PurchaseOrders")
	@TestDetails(TestID = "eInvoice_15")
	public void searchPurchaseOrders(String PONumber, String supplierSelectCategory, String SupplierName,
			String BuyerName, String HeaderLevelTaxType) throws 	Exception {
		PurchaseOrder objPurchaseOrder = new PurchaseOrder(driver, logger);
	/*	callAndLog(logger, objPurchaseOrder.filterByPONumber(PONumber), "able to search by PO number",
				"unable to search by PO number");*/
		objPurchaseOrder.clrAllFilters();
		Thread.sleep(3000);

		callAndLog(logger, objPurchaseOrder.filterBySupplier(SupplierName), "able to search by supplier name",
				"unable to search by supplier name");
		objPurchaseOrder.clrAllFilters();
		Thread.sleep(3000);

		callAndLog(logger, objPurchaseOrder.filterByBuyer(BuyerName), "able to search by buyer name",
				"unable to search by buyer name");
	}

	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class,
			dependsOnMethods = "searchPurchaseOrders", 
			dataProvider = "Workflow")
	@TestDetails(TestID="eInvoice_29")
	public void Workflow(String workflowProcess, String workflowDescription, String workflowType, String approveMoreThanOnce) throws Exception {
		Workflow objWorkflow = new Workflow(driver, logger);
		objWorkflow.clickCreateWorkflow();
		WorkflowWizard objWizard = new WorkflowWizard(driver, logger, workflowProcess);
		objWizard.createWorkflow(workflowDescription, workflowType, Boolean.parseBoolean(approveMoreThanOnce));
	}
	
	

}
