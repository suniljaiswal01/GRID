package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyInvoices.CreateNonPOInvoice;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class ZSNCreateNonPO_Tests extends CommonTests1 {

	private String Product = "eInvoice";
	eInvoice_CommonFunctions objFunctions;
	String invoiceNonPO;
	String creditMemoNonPO;
	String invoicePO;
	String creditMemoPO;
	WebDriver driver1= null;
	String invStatus;

	String title = null;
	public ZSNCreateNonPO_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginZSNcreateNonPOInvoice()
			throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle =getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dataProvider="ZSN_IntegrationInvoiceNonPO", dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods="loginZSNcreateNonPOInvoice")
	@TestDetails(TestID = "loginZSN")
	public void createNonPOInvoice(String environment,String username, String password,String companyCode,String businessUnit,String location,String costCentre,String	currency,String	paymentTerms,String	headerLevelTaxType,String headerLevelTaxName,String lineItemLevelTaxType,String lineItemLevelTaxName, String SupplierCompany) throws Exception {
		String tenant = configurationProperties.getProperty("Tenant");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(zsnDriver, logger);
		objZSNFunctions.navigate_path1("My Invoices", "Create Non PO Invoice",tenant);
		CreateNonPOInvoice objInvoice= new CreateNonPOInvoice(zsnDriver, logger);
		invoiceNonPO=objInvoice.createNonPOInvoiceCreditMemo("invoice", tenant,companyCode, businessUnit, location, costCentre,currency,paymentTerms,headerLevelTaxType, headerLevelTaxName, lineItemLevelTaxType, lineItemLevelTaxName,SupplierCompany);		
		objInvoice.searchByDocNo(invoiceNonPO);
		zsnDriver.close();
	}

	
	@Test(dependsOnMethods= "createNonPOInvoice", dataProviderClass = eInvoice_DataProviderTestNG.class,
			dataProvider = "InvoiceNonPONew")
	@TestDetails(TestID="eInvoice_31")
	public void editInvoice(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType,String headerLevelTaxRate) throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		if(objInvoice.verifyZSNInvoiceCreditMemo(invoiceNonPO))
			LogScreenshot("PASS","Searched by " + invoiceNonPO +". Invoice-ZSN Integration passed"); 
		else
			LogScreenshot("FAIL","Not searched " + invoiceNonPO+". Invoice-ZSN Integration failed");
		objInvoice.editInvoiceFromMailBox(invoiceNonPO,supplierSelectCategory, supplierName, paymentTerm, 
				currency_value,  "", purchaseType,  company, businessUnit,  location,  costCenter,  headLvlTaxType, headerLevelTaxRate);
	
	}
	
	@Test(dependsOnMethods= "editInvoice")
	@TestDetails(TestID="eInvoice_12")
	public void verifyStatusOfInvoice() throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		 invStatus=objInvoice.verifyCreditMemoOrInvoiceStatus(invoiceNonPO);
		/*callAndLog(logger,objInvoice.verifyCreditMemoOrInvoiceStatus(invoiceNonPO, "In Approval"), "Invoice NON PO is displayed in Invoice tab",
				"Invoice NON PO is not displayed");*/
	
	}
	
	@Test(dependsOnMethods= "verifyStatusOfInvoice")
	@TestDetails(TestID="eInvoice_2")
	public void approveInvoice() throws Exception {
		if(!invStatus.equals("Approved")) {
		Invoices objInvoice = new Invoices(driver, logger);
		objInvoice.InvoiceApproval(invoiceNonPO);
		}
		else {
			LogScreenshot("INFO", invoiceNonPO+" : invoice is already approved");
		}
	}
	

	@Test(dependsOnMethods= "approveInvoice")
	@TestDetails(TestID="loginZSN")
	public void verifyInvoiceStatusInZSN() throws Exception {
		String tenant = configurationProperties.getProperty("Tenant");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(zsnDriver, logger);
		objZSNFunctions.navigate_path1("My Invoices", "View Invoices", tenant);
		CreateNonPOInvoice objInvoice= new CreateNonPOInvoice(zsnDriver, logger);
		objInvoice.verifyStatusInZSN(invoiceNonPO);
	}


}
