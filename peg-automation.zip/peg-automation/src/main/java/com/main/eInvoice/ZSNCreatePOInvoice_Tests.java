package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyInvoices.CreatePOInvoice;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class ZSNCreatePOInvoice_Tests extends CommonTests1 {

	private String Product = "eInvoice";
	eInvoice_CommonFunctions objFunctions;
	String invoiceNonPO;
	String creditMemoNonPO;
	String invoicePO;
	String creditMemoPO;
	WebDriver driver1= null;

	String title = null;
	public ZSNCreatePOInvoice_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginZSNPOInvoice()
			throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle =getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProvider="ZSN_IntegrationInvoicePO", dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods="loginZSNPOInvoice")
	@TestDetails(TestID = "eInvoice_1")
	public void createPOInvoice(String environment,String username, String password,String companyCode,String businessUnit,String location,String costCentre,String	currency,String	paymentTerms,String	headerLevelTaxType,String headerLevelTaxName,String lineItemLevelTaxType,String lineItemLevelTaxName, String SupplierCompany) throws Exception {
		String tenant = configurationProperties.getProperty("Tenant");
		driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
		Login objLogin = new Login(driver1, logger, username, password);
		callAndLog(driver1, logger, objLogin.login(configurationProperties), "login successful","Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Invoices", "Create PO Invoice",tenant);
		CreatePOInvoice objInvoicePO= new CreatePOInvoice(driver1, logger);
		invoicePO= objInvoicePO.createPOInvoice("invoice",tenant,companyCode, businessUnit, location, costCentre,currency,paymentTerms,headerLevelTaxType, headerLevelTaxName, lineItemLevelTaxType, lineItemLevelTaxName,SupplierCompany);		
		objInvoicePO.searchByDocNo(invoicePO);
		driver1.close();
	}
	
	@Test(dependsOnMethods= "createPOInvoice")
	@TestDetails(TestID="eInvoice_12")
	public void verifyInvoicePOCreated() throws Exception {		
		Invoices objInvoice = new Invoices(driver, logger);	
		if(objInvoice.verifyZSNInvoiceCreditMemo(invoicePO)) {
			LogScreenshot("PASS","Searched by " + invoicePO +". Invoice-ZSN Integration passed"); 
		}else {
			LogScreenshot("WARNING",invoicePO+ " : not present on Invoices Listing page");
			objInvoice.navigateToMainPage(displayStyle, Product, "Invoice", "e-Invoice Mailbox");
			if(objInvoice.verifyZSNInvoiceCreditMemo(invoicePO)) 
				LogScreenshot("PASS","Searched by " + invoicePO +". Invoice-ZSN Integration passed");
			else
				LogScreenshot("FAIL","Not searched " + invoicePO+". Invoice-ZSN Integration failed");
					
		}
	}

}
