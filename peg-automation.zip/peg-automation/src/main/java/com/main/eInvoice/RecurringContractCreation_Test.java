package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Invoice.Invoices;
import com.zycus.eInvoice.Invoice.RecurringContractCreation;
import com.zycus.eInvoice.RecurringContracts.ContractList;

import DataProviders.eInvoice_DataProviderTestNG;

public class RecurringContractCreation_Test extends CommonTests1{

	
	private String Product = "eInvoice";
	String contractName ;
	String contractStatus;

	public RecurringContractCreation_Test() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");		
	}
	

	@Test(groups = "Login_Approvals", alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_Contract() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	
	@Test(dependsOnMethods= "login_Contract", dataProviderClass = eInvoice_DataProviderTestNG.class,
			dataProvider = "RecurringContractDetails")
	@TestDetails(TestID="eInvoice_6")
	public void createRecurringContract(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value,String contractOwner,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headerLevelTaxType, String buyer,String requester, String notes,String description,String frequencyNo, String frequency, String headerLevelTaxRate) throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		try{
			 contractName = objInvoice.createRecurringContract(supplierSelectCategory,   supplierName, paymentTerm, 
					currency_value,  contractOwner, purchaseType,   company,  businessUnit,  location,  costCenter,  headerLevelTaxType, buyer,  requester,  notes, description, frequencyNo, frequency,headerLevelTaxRate);
			RecurringContractCreation objContract= new RecurringContractCreation(driver, logger);
			System.out.println("Contract Name"+contractName);
			contractStatus= objContract.getContractStatus(contractName);
		}catch(Exception e){
			LogScreenshot("FAIL", "Unable to create Recurring Contract");
			throw e;	
		}

	}
	
	@Test(dependsOnMethods= "createRecurringContract")
	@TestDetails(TestID="eInvoice_2")	
	public void approveContract() throws Exception {
		if(contractName != null) {
			if(!contractStatus.equals("Activated")) {
			Invoices objInvoice = new Invoices(driver, logger);
			try {
				objInvoice.contractApproval(contractName);
			}catch(Exception e){
				LogScreenshot("FAIL", "Unable to approve Recurring Contract");
				e.printStackTrace();
			}
			}else
				LogScreenshot("INFO", "Contract is already approved");
		}else
			throw new SkipException("Skipping Approving Recurring Contract as Contract not created");
	}
	
	
	@Test(dependsOnMethods = "approveContract")
	@TestDetails(TestID="eInvoice_3")
	public void ContractsAction() throws Exception {
		if(contractName!=null) {
		Thread.sleep(5000);
		ContractList objContractList = new ContractList(driver, logger);
		objContractList.clearAllFilters();
		Thread.sleep(5000);
		objContractList.filterByContractName(contractName);
		objContractList.performActionOnContract("Deactivate","");
		objContractList.clearAllFilters();
		Thread.sleep(5000);
		objContractList.filterByContractName(contractName);
		Thread.sleep(5000);
		objContractList.performActionOnContract("Activate","");
		}	else {
			throw new SkipException("Recurring Contract is not created");
	}
	}
}	




