package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;

public class CreditMemoWithoutCreation_Tests extends CommonTests1{


	private String Product = "eInvoice";

	public static String creditMemoNo;



	public CreditMemoWithoutCreation_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login_Invoices",alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_Invoices() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");

	}

	@Test(dependsOnMethods= "login_Invoices",dataProviderClass = eInvoice_DataProviderTestNG.class,
			dataProvider = "CreditMemowithoutReference")
	@TestDetails(TestID="eInvoice_10")
	public void creditMemoWithoutReference(String supplierSelectCategory,String supplierName,
			String currency_value, String creditMemoDate, String purchaseType,String itemNo, String company, String businessUnit, String location,String costCenter,String headerLevelTaxType, String headLvlTaxRate) throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		try{
			System.out.println(headLvlTaxRate);
			creditMemoNo = objInvoice.createCreditMemowithoutReference(supplierSelectCategory, supplierName,currency_value,  creditMemoDate,  purchaseType, itemNo,  company,  businessUnit,  location, costCenter, headerLevelTaxType, headLvlTaxRate);		
			System.out.println(creditMemoNo);
		}catch(Exception e){
			if(driver.findElements(By.id("cancelInvoice")).size()>0)
				driver.findElement(By.id("cancelInvoice")).click();
			LogScreenshot("FAIL","Credit Memo is not created");
			e.printStackTrace();	
			throw e;
		}		
	}	

}
