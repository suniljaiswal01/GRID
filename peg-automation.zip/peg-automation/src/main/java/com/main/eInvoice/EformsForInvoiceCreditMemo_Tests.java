package com.main.eInvoice;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.eForms.AllForms;

import DataProviders.eInvoice_DataProviderTestNG;

public class EformsForInvoiceCreditMemo_Tests extends CommonTests1{

	//private ExtentTest logger;
	private String Product = "eInvoice";

	String contracteForm= null;
	String inveForm= null;

	public EformsForInvoiceCreditMemo_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	@Test(groups = "Login_Approvals",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_E_FormsInvoiceCreditMemo() throws Exception {
			
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}


	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class,
			dependsOnMethods = "login_E_FormsInvoiceCreditMemo",
			dataProvider = "ProcessForm")
	@TestDetails(TestID="eInvoice_30")
	public void createEFormForInvoiceCreditMemo(String formCreationProcess,String formName, String formType,String formRelatedProcess,String businessUnit,String sectionName,String fieldToDisplayInSection,String fieldName,String formDescription,String sectionDescription,String sectionLayout,String defaultValue,String maxChar, String hideField,String enterSpace,String enterSplChar,String mandatory) throws Exception {
		AllForms objAllForms= new AllForms(driver, logger);
		inveForm=objAllForms.selectNewFormCreationProcess(formCreationProcess, formName, formType, "Invoice & Credit Memo Forms", businessUnit, sectionName, fieldToDisplayInSection, fieldName, formDescription, sectionDescription, sectionLayout, defaultValue, maxChar, hideField, enterSpace, enterSplChar, mandatory);
	}


	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class,
			dependsOnMethods = "createEFormForInvoiceCreditMemo",
			dataProvider = "ProcessForm")
	@TestDetails(TestID="eInvoice_30")	
	public void deleteEFormForInvoiceCreditMemo(String formCreationProcess,String formName, String formType,String formRelatedProcess,String businessUnit,String sectionName,String fieldToDisplayInSection,String fieldName,String formDescription,String sectionDescription,String sectionLayout,String defaultValue,String maxChar, String hideField,String enterSpace,String enterSplChar,String mandatory) throws Exception {
		AllForms objAllForms= new AllForms(driver, logger);
		objAllForms.searchEForm(formCreationProcess, inveForm, formType, formRelatedProcess, businessUnit, sectionName, fieldToDisplayInSection, fieldName, formDescription, sectionDescription, sectionLayout, defaultValue, maxChar, hideField, enterSpace, enterSplChar, mandatory);
		objAllForms.deactivateEForm();
		Thread.sleep(8000);
		objAllForms.deleteEForm();
	}
	

	@Test(dependsOnMethods = "login_E_FormsInvoiceCreditMemo")
	@TestDetails(TestID="eInvoice_30")	
	public void filterEForm() throws Exception {
		AllForms objAllForms= new AllForms(driver, logger);
		objAllForms.filterEForm("Line level form","Recurring Contract");
		objAllForms.filterEForm("Header level form","Recurring Contract");
		objAllForms.filterEForm("Line level form","Invoice & Credit Memo");
		objAllForms.filterEForm("Header level form","Invoice & Credit Memo");	
	}	
}







