package com.main.eInvoice;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Reconciliation.Statements;

import DataProviders.eInvoice_DataProviderTestNG;

public class Reconciliation_Tests extends CommonTests1 {



	/*	private ExtentTest logger;*/
	private String Product = "eInvoice";
	String batchNo;
	

	// private Method m;

	public Reconciliation_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	@Test(groups = "Login_Payment", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_Reconciliation() throws Exception {
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	
	
	@Test(dependsOnMethods = "login_Reconciliation")
	@TestDetails(TestID = "eInvoice_17")
	public void AddReconciliationStatements() throws Exception {
		Statements objStatements = new Statements(driver, logger);
		callAndLog(logger, objStatements.addNewStmt(), "New Statement created successfully",
				"New Statement not created");
	}

	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods = "login_Reconciliation", dataProvider = "Reconciliation")
	@TestDetails(TestID = "eInvoice_16")
	public void Statements(String batchName, String bankName, String statementDate, String actionOnStatement)
			throws Exception {
		Statements objStatements = new Statements(driver, logger);
		callAndLog(logger, objStatements.searchBatchName(batchName), "Batch Name searched successfully",
				"Batch Name not searched");
		callAndLog(logger, objStatements.searchBank(bankName), "Bank Name searched successfully",
				"Bank Name not searched");
		callAndLog(logger, objStatements.takeAction(actionOnStatement), "Report reviewed successfully",
				"Report not reviewed");

	}
	}

