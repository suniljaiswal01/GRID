package com.main.eInvoice;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Approval.Approval;
import com.zycus.eInvoice.Approval.MySettings;

import DataProviders.eInvoice_DataProviderTestNG;

public class InvoiceAction_Tests extends CommonTests1{

	
	private String Product = "eInvoice";
	String contractName ;

	public InvoiceAction_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");		
	}
	


	@Test(groups = "Login_Approvals",alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_ApprovalAction() throws Exception {
	 
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	

	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class,
			dependsOnMethods = "login_ApprovalAction",
			dataProvider = "MySettings")
	@TestDetails(TestID="eInvoice_4")
	public void MySettings_ConfigureOOO(String delegateTo) throws Exception {
		Thread.sleep(5000);
		MySettings objSetting = new MySettings(driver, logger);
		callAndLog(logger, objSetting.configureOOO(), "Able to revoke/delegate successfully", "Unable to revoke/delegate successfully");
	}
	
	
	/*@Test(dependsOnMethods = "login_ApprovalAction")
	@TestDetails(TestID="eInvoice_2")
	public void ApprovalAction() throws Exception {	
		Thread.sleep(5000);
		Approval objApproval = new Approval(driver, logger);
		Thread.sleep(5000);
		objApproval.clearAllFilters();
		Thread.sleep(5000);
		objApproval.filterByStatusForContract("Pending");
		Thread.sleep(5000);
		objApproval.performActionOnInvoice("Reject");	
		objApproval.clearAllFilters();
		Thread.sleep(5000);
		objApproval.filterByStatusForContract("Pending");
		Thread.sleep(5000);
		objApproval.performActionOnInvoice("Delegate");
	}*/
	
}	




