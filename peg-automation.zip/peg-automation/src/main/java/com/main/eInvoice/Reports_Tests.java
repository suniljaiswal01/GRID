package com.main.eInvoice;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Reports.ReportDetail;
import com.zycus.eInvoice.Reports.Reports;

import DataProviders.eInvoice_DataProviderTestNG;

public class Reports_Tests extends CommonTests1 {



	private String Product = "eInvoice";
	
	public Reports_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	/**
	 * @param Product
	 * @param Username
	 * @param Password
	 * @param Customer
	 * @throws Exception
	 */
	

	@Test(groups = "Login_Reports", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_Reports()
			throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "login_Reports")
	@TestDetails(TestID = "eInvoice_20")
	public void Reports() throws Exception {
		Reports objReports = new Reports(driver, logger);
		callAndLog(logger, objReports.searchInvoicePrePackagedReports(), "Report searched successfully","Report is not searched");

	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, dependsOnMethods = "login_Reports", dataProvider = "MyReports")
	@TestDetails(TestID = "eInvoice_22")
	public void exportMyReports(String myReportsName, String sharedUserEmail, String exportFormat) throws Exception {
		Reports objReports = new Reports(driver, logger);
		callAndLog(logger, objReports.selectMyReports(myReportsName), "Report searched & viewed successfully",
				"Report not searched & viewed ");
		ReportDetail objRepDetail = new ReportDetail(driver, logger);
		try {
		callAndLog(logger, objRepDetail.exportReport(myReportsName, "Excel"), "Report exported successfully",
				"Report is not exported");
		callAndLog(logger, objRepDetail.exportReport(myReportsName, "PDF"), "Report exported successfully",
				"Report is not exported");
		driver.findElement(By.xpath("//input[@title='Close']")).click();
		}
		catch(Exception e) {
			if (driver.findElement(By.xpath("//input[@title='Close']")).isDisplayed())
				driver.findElement(By.xpath("//input[@title='Close']")).click();
		}
	}

	
	@Test(dependsOnMethods = "login_Reports")
	@TestDetails(TestID = "eInvoice_21")
	public void ModifyReport() throws Exception {
		Reports objReports = new Reports(driver, logger);
		callAndLog(logger, objReports.modifyReport(), "Report modified successfully", "Report is not modified");
	}

	
	


}
