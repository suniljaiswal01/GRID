package com.main.eInvoice;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyInvoices.UploadsZSN;
import com.zycus.eInvoice.Uploads.Uploads;

import DataProviders.eInvoice_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;

public class Uploads_Tests extends CommonTests1{

	private String Product = "eInvoice";
	String PO;

	public Uploads_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	/**
	 * @param Product
	 * @param Username
	 * @param Password
	 * @param Customer
	 * @throws Exception
	 */

	@Test(groups = "Login_Uploads" ,alwaysRun = true)
	@TestDetails(TestID="login")
	public void login_Uploads() throws Exception {

		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = "login_Uploads")
	@TestDetails(TestID="eInvoice_23")
	public void Uploads() throws Exception {
		Uploads objUploads = new Uploads(driver, logger);
		callAndLog(logger,objUploads.uploadNewFile(), "File uploaded successfully","File not uploaded successfully");	
	}

	@Test(dependsOnMethods = "Uploads")
	@TestDetails(TestID="eInvoice_24")
	public void EditUploadFile() throws Exception {
		Uploads objUploads = new Uploads(driver, logger);	
		callAndLog(logger,objUploads.editUploadDetails(), "Uploaded file edited successfully","Uploaded file not edited");	
	}

	@Test(dataProvider="ZSN_IntegrationInvoiceNonPO", dataProviderClass = eInvoice_DataProviderTestNG.class,dependsOnMethods = "EditUploadFile",alwaysRun=true)
	@TestDetails(TestID = "eInvoice_1")
	public void uploadFileInZSN(String environment,String username, String password,String companyCode,String businessUnit,String location,String costCentre,String	currency,String	paymentTerms,String	headerLevelTaxType,String headerLevelTaxName,String lineItemLevelTaxType,String lineItemLevelTaxName, String SupplierCompany) throws Exception {
		String customer = configurationProperties.getProperty("Tenant");
		driver1 = objFrameworkUtility.getWebDriverInstance1(this.getClass().getName());
		Login objLogin = new Login(driver1, logger, username, password);
		callAndLog(driver1, logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Invoices", "View Uploads",customer);
		UploadsZSN objUpload= new UploadsZSN(driver1, logger);
		objUpload.uploadFileinZSN(SupplierCompany);
	}

	/*
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "login_Uploads", 
			dataProvider = "Uploads_Non_PO_Invoice")
	@TestDetails(TestID="eInvoice_25")
	public void uploadtoCreateInvoiceNonPO(String supplierSelectCategory,  String supplierName,String paymentTerm, 
			String currency_value, String invoiceOrCreditMemoDate,String purchaseType,  String company, String businessUnit, String location, String costCenter, String headLvlTaxType) throws Exception {	
		Uploads objUploads = new Uploads(driver, logger);
		objUploads.uploadNewFile();
		objUploads.takeAction("Create Non-PO Invoice");
		callAndLog(logger,objUploads.verifyInvoiceCreditMemoFields(), "Attachment linked to invoice Non-PO successfully","Attachment not linked to invoice Non-PO");			
	}*/
	/*
	//UAT
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "login_Uploads", 
			dataProvider = "Uploads",priority=4)
	@TestDetails(TestID="eInvoice_26")
	public void uploadtoCreateInvoiceAgainstPO() throws Exception {
		Uploads objUploads = new Uploads(driver, logger);
		objUploads.uploadNewFile();
		objUploads.takeAction("Create PO Invoice");
		PurchaseOrder objPO = new PurchaseOrder(driver, logger);
		objUploads.clrAllFilters();
		objPO.filterByType("Standard");
		objPO.filterByStatus("Released");
		objPO.filterByBuyer("GDQA");
		objUploads.selectActionPOList("Add Invoice");
		callAndLog(logger,objUploads.verifyInvoiceCreditMemoFields(),  "Attachment linked to invoice-PO successfully","Attachment not linked to invoice-PO");
	}


	//UAT
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "login_Uploads", 
			dataProvider = "Uploads",priority=5)
	@TestDetails(TestID="eInvoice_27")
	public void uploadtoCreateCreditMemoAgainstPO() throws Exception {

		Uploads objUploads = new Uploads(driver, logger);
		objUploads.uploadNewFile();
		objUploads.takeAction("Create Credit Memo");
		PurchaseOrder objPO = new PurchaseOrder(driver, logger);
		objUploads.clrAllFilters();
		objPO.filterByType("Standard");
		objPO.filterByStatus("Released");
		objPO.filterByBuyer("GDQA");
		objUploads.selectActionPOList("Add Credit Memo");
		callAndLog(logger,objUploads.verifyInvoiceCreditMemoFields(), "Attachment linked to  Credit Memo-PO successfully","Attachment not linked to  Credit Memo-PO invoice");
	}
	//UAT
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "login_Uploads", 
			dataProvider = "Uploads_Non_PO_CreditMemo",priority=6)
	@TestDetails(TestID="eInvoice_28")
	public void uploadtoCreditMemoWithoutReference(String supplierSelectCategory,String supplierName,
			String currency_value, String creditMemoDate, String purchaseType,String itemNo, String company, String businessUnit, String location,String costCenter,String headerLevelTaxType) throws Exception {
		Uploads objUploads = new Uploads(driver, logger);
		objUploads.uploadNewFile();
		objUploads.takeAction("Create Credit Memo w/o ref");		
		callAndLog(logger,objUploads.verifyInvoiceCreditMemoFields(),"Attachment linked to Credit Memo Non-PO successfully","Attachment not linked to Credit Memo Non-PO invoice");
	}

}*/



}
