package com.main.eInvoice;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.crms.reportGeneration.CreateNewReport;
import com.zycus.crms.reportGeneration.VerifyReportFields;

import DataProviders.eInvoice_DataProviderTestNG;
import common.Functions.iManage_CommonFunctions;

public class EInvoiceCRMS_Integration_Tests extends CommonTests1 {
	//private ExtentTest logger;
	public String Product = "eInvoice";
	iManage_CommonFunctions objFunctions;

	public EInvoiceCRMS_Integration_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}



	@Test(groups = "Login", dependsOnMethods="com.main.eInvoice.CreditMemoWithoutCreation_Tests.creditMemoWithoutReference")
	@TestDetails(TestID = "login")
	public void loginCRMSIntegration() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}

	@Test(dependsOnMethods = {"loginCRMSIntegration","com.main.eInvoice.CreditMemoWithoutCreation_Tests.creditMemoWithoutReference"},dataProviderClass = eInvoice_DataProviderTestNG.class, dataProvider = "crms_reportGeneration", alwaysRun = true)
	@TestDetails(TestID = "eInvoice_CRMSIntegration")
	public void crms_reportGeneration(String category, String data) throws Exception {
		CreateNewReport createNewReport = new CreateNewReport(driver, logger);
		createNewReport.navigateTocreateNewReport();
		createNewReport.selectProduct(Product);
		createNewReport.selectParams(category,data);
		VerifyReportFields verifyReportsField = new VerifyReportFields(driver, logger);
		verifyReportsField.eInvoiceFieldCheck(CreditMemoWithoutCreation_Tests.creditMemoNo);
		verifyReportsField.exportReport();
		verifyReportsField.backToReportListing();
	}
}
