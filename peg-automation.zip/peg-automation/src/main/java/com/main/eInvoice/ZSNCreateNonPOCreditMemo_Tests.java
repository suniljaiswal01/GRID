package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.ZSN.MyInvoices.CreateNonPOInvoice;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;

public class ZSNCreateNonPOCreditMemo_Tests extends CommonTests1 {

	private String Product = "eInvoice";
	eInvoice_CommonFunctions objFunctions;
	String invoiceNonPO;
	String creditMemoNonPO;
	String invoicePO;
	String creditMemoPO;

	String title = null;
	public ZSNCreateNonPOCreditMemo_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}

	@Test(groups = "Login", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void loginZSNCreditMemoWithoutReference()
			throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle =getDisplayStyle(driver, logger,loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(dataProvider="ZSN_IntegrationInvoiceNonPO", dataProviderClass = eInvoice_DataProviderTestNG.class,dependsOnMethods= "loginZSNCreditMemoWithoutReference")
	@TestDetails(TestID = "loginZSN")
	public void createCreditMemoWithoutReference(String environment,String username, String password,String companyCode,String businessUnit,String location,String costCentre,String	currency,String	paymentTerms,String	headerLevelTaxType,String headerLevelTaxName,String lineItemLevelTaxType,String lineItemLevelTaxName, String SupplierCompany) throws Exception {
		String customer = configurationProperties.getProperty("Tenant");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(zsnDriver, logger);
		objZSNFunctions.navigate_path1("My Invoices", "Create Credit Memo without reference",customer);
		CreateNonPOInvoice objInvoice= new CreateNonPOInvoice(zsnDriver, logger);
		creditMemoNonPO=objInvoice.createNonPOInvoiceCreditMemo("creditMemo",customer,companyCode, businessUnit, location, costCentre,currency,paymentTerms,headerLevelTaxType, headerLevelTaxName, lineItemLevelTaxType, lineItemLevelTaxName,SupplierCompany);		
		objInvoice.searchByDocNo(creditMemoNonPO);
		zsnDriver.close();
	}

	
	@Test(dependsOnMethods= "createCreditMemoWithoutReference")
	@TestDetails(TestID="eInvoice_31")
	public void verifyCreditMemoNonPOFromMailBox() throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		if(objInvoice.verifyZSNInvoiceCreditMemo(creditMemoNonPO)) 
			LogScreenshot("PASS","Searched by " + creditMemoNonPO +". Invoice-ZSN Integration passed"); 
			else
				LogScreenshot("FAIL","Not searched " + creditMemoNonPO+". Invoice-ZSN Integration failed");
				
		}
	}



