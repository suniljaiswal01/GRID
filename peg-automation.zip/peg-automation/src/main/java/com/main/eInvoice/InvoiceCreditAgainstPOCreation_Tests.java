package com.main.eInvoice;

import java.util.concurrent.TimeUnit;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;
import com.zycus.eInvoice.Invoice.Invoices;

import DataProviders.eInvoice_DataProviderTestNG;

public class InvoiceCreditAgainstPOCreation_Tests extends CommonTests1{


	private String Product = "eInvoice";


	private String PO;
	String invoiceNo;
	public static String invoiceNonPO;
	String[] invoiceCreditMemoPO;
	public static String creditMemoNo;
	String copiedInvoice;
	String invStatus;



	public InvoiceCreditAgainstPOCreation_Tests() throws Exception {
		super();
		setProduct("eInvoice");
		setClassToLoad("common.Functions.eInvoice_CommonFunctions");
	}


	@Test(groups = "Login_Invoices", alwaysRun = true)
	@TestDetails(TestID = "login")
	public void login_InvoicesCreditMemoAgainstPO() throws Exception {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");

	}
	@Test(dependsOnMethods= "login_InvoicesCreditMemoAgainstPO", dataProviderClass = eInvoice_DataProviderTestNG.class,
			dataProvider = "InvoiceAgainstPO")
	@TestDetails(TestID="eInvoice_11")
	public void invoiceCreditMemoAgainstPO(String buyer) throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		try{		
			invoiceCreditMemoPO = objInvoice.createInvoiceAgainstPO(PO, buyer);		
			callAndLog(logger,invoiceCreditMemoPO!=null, "Invoice against PO : "+ invoiceCreditMemoPO[0] + " created, Credit Memo Created against PO "+ invoiceCreditMemoPO[1],
					"Invoice / Credit Memo against PO not created");
		}catch(Exception e){
			e.printStackTrace();
		}	
	}


	@Test(dependsOnMethods= "invoiceCreditMemoAgainstPO")
	@TestDetails(TestID="eInvoice_12")
	public void verifyStatusOfInvoice() throws Exception {
		Invoices objInvoice = new Invoices(driver, logger);
		invStatus=objInvoice.verifyCreditMemoOrInvoiceStatus(invoiceCreditMemoPO[0]);
	}

		@Test(dependsOnMethods= "verifyStatusOfInvoice")
		@TestDetails(TestID="eInvoice_2")	
		public void approveInvoicePO() throws Exception {		
			if(invoiceCreditMemoPO[0] != null) {
				if(!invStatus.equals("Approved")) {

					Invoices objInvoice = new Invoices(driver, logger);
					try {
						objInvoice.InvoiceApproval(invoiceCreditMemoPO[0]);
					}catch(Exception e){
						e.printStackTrace();
					}
				}else
					throw new SkipException("Invoice is already approved");
			}else
				throw new SkipException("Skipping Approving Invoice PO");
		}

		@Test(dependsOnMethods= "approveInvoicePO")
		@TestDetails(TestID="eInvoice_12")	
		public void restrictPayment() throws Exception {
			if(invoiceCreditMemoPO[0] != null) {
				Invoices objInvoice = new Invoices(driver, logger);
				try {
					objInvoice.restrictPayment(invoiceCreditMemoPO[0], invoiceCreditMemoPO[1]);
				}catch(Exception e){
					e.printStackTrace();
				}
			}else
				throw new SkipException("Skipping Approving Invoice PO");
		}

		@Test(dependsOnMethods= "restrictPayment")
		@TestDetails(TestID="eInvoice_12")	
		public void AllowPayment() throws Exception {
			if(invoiceCreditMemoPO[0] != null) {
				Invoices objInvoice = new Invoices(driver, logger);
				try {
					objInvoice.allowPayment(invoiceCreditMemoPO[0]);
				}catch(Exception e){
					e.printStackTrace();
				}
			}else
				throw new SkipException("Skipping Approving Invoice PO");
		}

	}
