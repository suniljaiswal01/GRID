package com.main;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Properties;

public class ConfigFileCreation {

	Properties prop = new Properties();
	OutputStream output = null;
	public String systemDirectoryPath=  System.getProperty("user.dir");
	public String sharedDirectoryPath=  "//192.168.11.102/public/PEG-Automation";

	public void createConfig(List<String> configParams, List<String> configDetails){
		try {
			String environment = null;
			// set the properties value
			output = new FileOutputStream("config/config.properties");
			int i=0;
			for(String param : configParams){
				prop.setProperty(param, configDetails.get(i));
				if(param.equals("Environment"))
					environment = configDetails.get(i);
				i++;
			}

			prop.setProperty("LoginWithPwdMgr", "True");

			prop.setProperty("chromedriverpath", systemDirectoryPath +"/drivers/chromedriver.exe");
			prop.setProperty("firefoxdriverpath",  systemDirectoryPath +"/drivers/geckodriver.exe");
			prop.setProperty("url_PM", "https://dummy2142.zycus.net:7272/PassTrixMain.cc");
			prop.setProperty("reportpath", "/Reports");

			prop.setProperty("url_ZSN_Production", "https://zsn.zycus.com/guest");
			//prop.setProperty("url_ZSN_Partner", "https://zsn-rp.zycus.com/guest");
			prop.setProperty("url_ZSN_Staging", "https://staging-zsn.zycus.com/guest");
			prop.setProperty("url_ZSN_DevInt", "https://devint-zsn.zycus.com/guest");
			prop.setProperty("url_ZSN_RM", "https://zsn-rp.zycus.com/guest");
			prop.setProperty("url_ZSN_Partner", "https://zsn-partner.zycus.com/guest");

			prop.setProperty("filepath", "/Datasheet/ZSN_data.xlsx");
			prop.setProperty("Datasheet_ZSN", "/Datasheet/ZSN_data.xlsx");

			prop.setProperty("Datasheet_common", systemDirectoryPath + "/Datasheet/Generic/Common_data.xlsx");

			prop.setProperty("Datasheet_eProc", systemDirectoryPath +"/Datasheet/"+environment+"/eProc_data.xlsx");
			prop.setProperty("Datasheet_eInvoice", systemDirectoryPath +"/Datasheet/"+environment+"/eInvoice_data.xlsx");
			prop.setProperty("Datasheet_iContract",systemDirectoryPath +"/Datasheet/"+environment+"/iContract_data.xlsx");
			prop.setProperty("Datasheet_iSource", systemDirectoryPath + "/Datasheet/"+environment+"/iSource_data.xlsx");
			prop.setProperty("Datasheet_iSave", systemDirectoryPath +"/Datasheet/"+environment+"/iSave_data.xlsx");
			prop.setProperty("Datasheet_iPerform", systemDirectoryPath +"/Datasheet/"+environment+"/iPerform_data.xlsx");
			prop.setProperty("Datasheet_iManage", systemDirectoryPath +"/Datasheet/"+environment+"/iManage_data.xlsx");
			prop.setProperty("Datasheet_iRequest",systemDirectoryPath +"/Datasheet/"+environment+"/iRequest_data.xlsx");
			prop.setProperty("Datasheet_iSupplier",systemDirectoryPath +"/Datasheet/"+environment+"/iSupplier_data.xlsx");
			prop.setProperty("Datasheet_iSupplier_SupplierSystem", systemDirectoryPath +"/Datasheet/"+environment+"/SupplierSystem.xlsx");
			prop.setProperty("Datasheet_iSupplier_SupplierScreener", systemDirectoryPath +"/Datasheet/"+environment+"/SupplierScreener.xlsx");
			prop.setProperty("SupplierDetails", systemDirectoryPath +"/Datasheet/"+environment+"/SupplierContacts.xlsx");

			prop.setProperty("Datasheet_SupplierContacts", systemDirectoryPath +"/Datasheet/Generic/SupplierContacts.xlsx");
			prop.setProperty("Datasheet_TMS", systemDirectoryPath +"/Datasheet/"+environment+"/TMS_data.xlsx");
			//		prop.setProperty("Datasheet_iMaster", "/Datasheet/"+environment+"/TMS_iMaster.xlsx");

			prop.setProperty("upload_path",systemDirectoryPath+"/Attachments/upload.xlsx");
			prop.setProperty("upload_csv_path","/Attachments/upload_csv.csv");
			prop.setProperty("upload_file_path","/Attachments/download.png");
			prop.setProperty("upload_Jpgfile_path",systemDirectoryPath+"/Attachments/branch300.jpg");
			prop.setProperty("upload_docxfile_path", systemDirectoryPath+"/Attachments/uploadMandatory.docx");
			prop.setProperty("upload_docxfile1_path", systemDirectoryPath+"/Attachments/upload1.docx");
			prop.setProperty("upload_xls_path", systemDirectoryPath+"/Attachments/imanage_CategoryTree.xls");
			prop.setProperty("upload_template", systemDirectoryPath+"/Attachments/test.pdf");
			prop.setProperty("contractUpload", systemDirectoryPath+"/Attachments/Auto_ContractUpload.pdf");

			prop.setProperty("DocFile1", "/Attachments/upload.docx");
			prop.setProperty("DocFile2", "/Attachments/upload1.docx");

			prop.setProperty("iManage_uploadCategoryfile_path",systemDirectoryPath+"/Attachments/imanage_CategoryTree.xls");
			prop.setProperty("iManage_BusinessTreefile_path", systemDirectoryPath+"/Attachments/imanage_BusinessTree.xls");
			prop.setProperty("iManage_PhaseDocfile_path",systemDirectoryPath+ "/Attachments/upload.docx");

			prop.setProperty("eProc_CatalogItemsfile_path",systemDirectoryPath+ "/Attachments/CatalogItems.xlsx");

			// save properties to project root folder
			prop.store(output, null);


		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void createSystemConfig(List<String> configParams, List<String> configDetails){
		try(OutputStream output1 = new FileOutputStream("config/system.properties")) {
			// set the properties value
			int i=0;
			for(String param : configParams){
				prop.setProperty(param, configDetails.get(i));
				i++;
			}

			/*prop.setProperty("ExecutionLocation", "Remote");
			prop.setProperty("BrowserType", "Chrome");
			 */
			// save properties to project root folder
			prop.store(output1, null);

		} catch (IOException io) {
			io.printStackTrace();
		} 
	}


	public void createLanguageConfig(List<String> configParams, List<String> configDetails){
		try(OutputStream output1 = new FileOutputStream("config/language.properties")) {

			// set the properties value
			int i=0;
			for(String param : configParams){
				prop.setProperty(param, configDetails.get(i));
				i++;
			}
			// save properties to project root folder
			prop.store(output1, null);

		} catch (IOException io) {
			io.printStackTrace();
		} 	
	}
	
	
	
	public void createUserConfig(List<String> classNames, List<String> userAccounts,List<String> userNames){
		try(OutputStream output1 = new FileOutputStream("config/userAccount.properties")) {

			// set the properties value
			int i=0;
			for(String param : classNames){
				String userDetails = userAccounts.get(i)+","+userNames.get(i);
				prop.setProperty(param, userDetails);
				i++;
			}
			// save properties to project root folder
			prop.store(output1, null);

		} catch (IOException io) {
			io.printStackTrace();
		} 	
	}

}
