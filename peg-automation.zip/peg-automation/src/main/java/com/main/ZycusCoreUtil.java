package com.main;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

/*import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;*/

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang.time.StopWatch;
/*import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.UserAuthenticator;
import org.apache.commons.vfs2.VFS;
import org.apache.commons.vfs2.auth.StaticUserAuthenticator;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;*/
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ZycusCoreUtil extends ZycusCoreDriver {

	public ZycusCoreUtil(WebDriver driver) {
		super(driver);
	}
	
	public ZycusCoreUtil() {
		super();
	}

	public void mouseHoverJScript(WebElement HoverElement) {
		try {
			if (isElementPresent(HoverElement)) {
				String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
				((JavascriptExecutor) driver).executeScript(mouseOverScript,
						HoverElement);
			} else {
				System.out.println("Element was not visible to hover " + "\n");

			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element with " + HoverElement
					+ "is not attached to the page document"
					+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element " + HoverElement
					+ " was not found in DOM" + e.getStackTrace());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error occurred while hovering"
					+ e.getStackTrace());
		}
	}

	public void mouseHoverAndClickJScript(WebElement HoverElement) {
		try {
			JavascriptExecutor js = ((JavascriptExecutor) driver);
			if (isElementPresent(HoverElement)) {

				String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
				js.executeScript(mouseOverScript, HoverElement);
				js.executeScript("arguments[0].click()", HoverElement);
			} else {
				System.out.println("Element was not visible to hover " + "\n");

			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element with " + HoverElement
					+ "is not attached to the page document"
					+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element " + HoverElement
					+ " was not found in DOM" + e.getStackTrace());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error occurred while hovering"
					+ e.getStackTrace());
		}
	}

	public boolean isElementPresent(WebElement element) {
		boolean flag = false;
		try {
			if (element.isDisplayed() || element.isEnabled())
				flag = true;
		} catch (NoSuchElementException e) {
			flag = false;
		} catch (StaleElementReferenceException e) {
			flag = false;
		}
		return flag;
	}

	/**
	 * This function is used to get a webelement by atleast one of the locators
	 * specified using By Locators as Parameters
	 * 
	 * @param maxTimeSeconds
	 *            - Maximum time to wait for all the locators, locators - All
	 *            the By locators in an array
	 * @return WebElement - The Element which is found in the application within
	 *         the specified ones
	 */
	public WebElement waitForWebElements(int maxTimeSeconds,
			By... locators) throws Exception {
		Boolean isElementFound = false;
		StopWatch sw = new StopWatch();
		By foundLocator = null;
		sw.start();
		try {
			while (!isElementFound && sw.getTime() < maxTimeSeconds * 1000) {
				for (int i = 0; i < locators.length; i++) {
					if (driver.findElements(locators[i]).size() > 0) {
						isElementFound = true;
						foundLocator = locators[i];
						break;
					}
				}

			}
		} catch (Exception e) {
			throw new Exception();
		}
		if (!isElementFound) {
			throw new Exception();
		}
		return driver.findElement(foundLocator);
	}

	/**
	 * This function is used to get a webelement by mentioned locator within the
	 * max time specified
	 * 
	 * @param strLocatorType
	 *            - Locator type of the web element we are trying to find,
	 *            strLocator - Locator string, intMaxTime - Maximum time to wait
	 *            for the Webelement
	 * @return By foundLocator - The Locator which is found in the application
	 *         within the specified ones
	 */
	public WebElement waitForWebElement(int maxTimeSeconds, By strLocator)
			throws Exception {
		Boolean isElementFound = false;
		StopWatch sw = new StopWatch();
		sw.start();
		try {
			while (!isElementFound && sw.getTime() < maxTimeSeconds * 1000) {
				try {
					driver.findElement(strLocator);
					isElementFound = true;
					break;
				} catch (Exception e) {

				}
			}
		} catch (Exception e) {
			throw new Exception();
		}
		if (!isElementFound) {
			throw new Exception();
		}
		return driver.findElement(strLocator);
	}

	/*public boolean DownloadAndOpenDocument() {
		try {
			if (ocfg.getBrowserType().equalsIgnoreCase("IE")
					|| ocfg.getBrowserType().equalsIgnoreCase("IEXPLORE")) {
				Actions action = new Actions(driver);
				action.keyDown(Keys.CONTROL).sendKeys("j").build().perform();
				action.keyUp(Keys.CONTROL).build().perform();
				ZycusCoreSync
						.staticWait(ZycusCoreConstants.getInstance().MediumInMiliSec);
				try {
					Runtime.getRuntime()
							.exec(ZycusCoreConstants.getInstance().strIEDownloadCommand);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				ZycusCoreSync
						.staticWait(ZycusCoreConstants.getInstance().MediumInMiliSec);
				return true;
			} else {
				System.out
						.println("Browser is not IE. Hence Download is not supported yet");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}*/

	public File getLatestFilefromDir(String strDirPath) {
		File dir = new File(strDirPath);
		File[] arrFiles = dir.listFiles();
		if (arrFiles == null || arrFiles.length == 0) {
			return null;
		}

		File lastModifiedFile = arrFiles[0];
		for (int i = 1; i < arrFiles.length; i++) {
			if (lastModifiedFile.lastModified() < arrFiles[i].lastModified()) {
				lastModifiedFile = arrFiles[i];
			}
		}
		return lastModifiedFile;
	}

	public File getTheNewestFile(String strDirectory, String strExtn) {
		File theNewestFile = null;
		File dir = new File(strDirectory);
		FileFilter fileFilter = new WildcardFileFilter("*." + strExtn);
		File[] files = dir.listFiles(fileFilter);

		if (files.length > 0) {
			/** The newest file comes first **/
			Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
			theNewestFile = files[0];
		}

		return theNewestFile;
	}

	/**
	 * This function is used to get the current day
	 *
	 * @return String - current day
	 * @param String
	 *            dayFormat - Search for Required day format e.g., EEE(Mon) or
	 *            EEEE(Monday)
	 */
	public String getCurrentDay(String dayFormat) {

		SimpleDateFormat dayformat = new SimpleDateFormat(dayFormat);
		Date date = new Date();

		// Converts the current date to required day format e.g., EEE(Mon) or
		// EEEE(Monday)
		String currentDay = dayformat.format(date);

		// Return's the current day
		return currentDay;
	}

	/*public boolean uploadFile(String strFullAbsoluteFilePath) {
		try {
			*//**
			 * Create the Upload handling windows command to execute the AutoIT
			 * exe file.
			 *//*
			String strCertCommand = ZycusCoreConstants.getInstance().strWinUploadHandleCommand
					+ "," + "\"" + strFullAbsoluteFilePath + "\"";
			String[] strUploadHandleCommand = strCertCommand.split(",");

			// Create JAVA Runtime class to execute the windows command to
			// execute the AutoIT exe file to select the required Certificate
			Runtime runtime = Runtime.getRuntime();
			try {
				Process process = runtime.exec(strUploadHandleCommand);
				try {
					int value = process.waitFor();
					if (value != 0) {
						ZycusCoreReporter
								.WriteReport(
										"File Upload Command Execution Process",
										"File Upload Command Execution Process should be successful",
										"File Upload Command Execution Process terminated abnormally.",
										"Failed", "");
						return false;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
					ZycusCoreReporter
							.WriteReport(
									"File Upload Command Execution Process",
									"File Upload Command Execution Process should be successful",
									"File Upload Command Execution Process terminated abnormally. Error: "
											+ e.getMessage(), "Failed", "");
					return false;
				}
			} catch (IOException e) {
				e.printStackTrace();
				ZycusCoreReporter
						.WriteReport(
								"File Upload Command Execution Process",
								"File Upload Command Execution Process should be successful",
								"File Upload Command Execution Process terminated abnormally. Error: "
										+ e.getMessage(), "Failed", "");
				return false;
			}
			ZycusCoreSync
					.staticWait(ZycusCoreConstants.getInstance().BaseInMiliSec);
			ZycusCoreReporter
					.WriteReport(
							"File Upload Command Execution Process",
							"File Upload Command Execution Process should be successful",
							"File uploaded successfully from path:[."
									+ strFullAbsoluteFilePath + "]", "Passed",
							"");
			return true;
		} catch (Exception ex) {
			ZycusCoreReporter
					.WriteReport(
							"File Upload Command Execution Process",
							"File Upload Command Execution Process should be successful",
							"File Upload Command Execution Process terminated abnormally. Error: "
									+ ex.getMessage(), "Failed", "");
			return false;
		}
	}*/

	public boolean verifyFilePresentInDir(String strDirPath,
			String strFileName) {
		try {
			boolean blnFound = false;
			File dir = new File(strDirPath);
			FileFilter fileFilter = new WildcardFileFilter("*.*");
			File[] files = dir.listFiles(fileFilter);
			for (File thisFile : files) {
				if (thisFile.getName().equalsIgnoreCase(strFileName)) {
					blnFound = true;
					break;
				}
			}
			return blnFound;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean verifyFolderPresentInDir(String strDirPath,
			String strFolderName) {
		try {
			boolean blnFound = false;
			File dir = new File(strDirPath);
			File DirToCheck = new File(strFolderName);
			if (FileUtils.directoryContains(dir, DirToCheck)) {
				blnFound = true;
			}
			return blnFound;
		} catch (Exception e) {
			return false;
		}
	}

	public void copyAndReplaceFile(String strSourceFilePath,
			String strDestinationPath, String strFileName) throws IOException {
		File objDestnPath = new File(strDestinationPath);
		File objSrcFile = new File(strSourceFilePath + "/" + strFileName);
		// Check if both source and destination paths are available
		if ((objDestnPath.isDirectory()) && (objSrcFile.isFile())) {
			// creating object for Destination File
			File objDestnFile = new File(strDestinationPath + "/" + strFileName);
			// Already if file is exists in Destination path,
			if (objDestnFile.isFile()) {
				// delete it
				objDestnFile.delete();
				// paste file from source to Destination path with fileName as
				// value of fileName argument
				FileUtils.copyFile(objSrcFile, objDestnFile);
			} else
			// If File does not exists in Destination path.
			{
				// paste file from source to Destination path with fileName as
				// value of fileName argument
				FileUtils.copyFile(objSrcFile, objDestnFile);
			}
		}
	}

	/**
	 * This function is used to Switch to child window which doesn't contains window title (Basically which is not the Parent window) 
	 * @return boolean - True/False
	 * @param strParentHandle - String Parent window name
	 */
	public boolean switchToAnyExistingChildWindow(String strParentHandle) {
		
		boolean blnResult = false;
		try{
		//Get all the Window Handles
		Set<String> arrAllHandles = driver.getWindowHandles();
        
		//Switch to Child Window 
		if (arrAllHandles.size()>1) {
               for (String currentHandle : arrAllHandles) {
                      if (!currentHandle.trim().equalsIgnoreCase(strParentHandle.trim())) {
                             driver.switchTo().window(currentHandle);
                             blnResult = true;
                             break;
                      		}
               		}      
        	}
		return blnResult;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * This function is used to get a list of webelements by atleast one of the locators
	 * specified using By Locators as Parameters
	 * @param maxTimeSeconds
	 *            - Maximum time to wait for all the locators, locators - All
	 *            the By locators in an array
	 * @return List<WebElement> - The list of Elements first found in the application with atleast one of the locators
	 */
	public List<WebElement> waitForListOfWebElements(int maxTimeSeconds,
			By... locators) throws Exception {
		Boolean isElementFound = false;
		StopWatch sw = new StopWatch();
		By foundLocator = null;
		sw.start();
		try {
			while (!isElementFound && sw.getTime() < maxTimeSeconds * 1000) {
				for (int i = 0; i < locators.length; i++) {
					if (driver.findElements(locators[i]).size() > 0) {
						isElementFound = true;
						foundLocator = locators[i];
						break;
					}
				}

			}
		} catch (Exception e) {
			throw new Exception();
		}
		if (!isElementFound) {
			throw new Exception();
		}
		return driver.findElements(foundLocator);
	}
	
	/**
	 * roundDoubleValue - This function is used to round a double variable with specified number oafter the point
	 * @param dblValue - The Double value to round, intNumOfPlaces - Number of places required after point
	 * @return double - the rounded Double value
	 */
	public double roundDoubleValue(double dblValue, int intNumOfPlaces) {
	    if (intNumOfPlaces < 0) 
	    	throw new IllegalArgumentException();

	    long factor = (long) Math.pow(10, intNumOfPlaces);
	    dblValue = dblValue * factor;
	    long tmp = Math.round(dblValue);
	    return (double) tmp / factor;
	}
	
	/**
	 * getPreviousBusinessDay - This function is used to get the previous business day
	 * @param String dayFormat - Search for Required day format e.g., EEE(Mon) or EEEE(Monday)
	 * 		  String DateFormat - Search for Required Date Format e.g., M/d/YYYY or M/d/YY
	 * @return boolean - True/False
	 * @param N/A
	 */
	public String getPreviousBusinessDay(String strDayFormat, String strDateFormat) {
		Date strSysDate;
		try{
		
		//Convert the current date to any Date (M/d/yyyy) format
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		Date date = new Date();
		
		//Gets the current day 
		String currentDay = getCurrentDay(strDayFormat);
		
		//If current day is monday it will subtract 3 days then we will get friday (previous business day) 
		if(currentDay.equalsIgnoreCase("Monday")){
				strSysDate = DateUtils.addDays(date,-3);	
			
			//If current day is Sunday it will subtract 2 days then we will get friday (previous business day) 
			}else if(currentDay.equalsIgnoreCase("Sunday")){
				strSysDate = DateUtils.addDays(date,-2);
			
			//else it will subtract 1 day from current day then we will get the Previous business day 
			}else{
				strSysDate = DateUtils.addDays(date,-1);		
		}
		ZycusCoreSync.staticWait(ZycusCoreConstants.getInstance().MediumInMiliSec);
		
		//Converting previous business date to String
		String strpreviousBusinessDay =dateFormat.format(strSysDate);
		return 	strpreviousBusinessDay;
		
		} catch (Exception e) {
			String fail = "Problem in getting the previous Business date. Error Details: "
					+ e.getMessage();
			return fail;
			}
	}
	
	/**
	 * This function is used to accept alert dialog
	 * @param None
	 * @return boolean true/False
	 *  */
	public boolean acceptAlertDialog()
	{
		boolean blnResult=false;
		try
		{
			Alert alert = driver.switchTo().alert();
			alert.accept();
			blnResult=true;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return blnResult;
	}
}
