package com.main;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
//import com.main.iSource.CommonTests1;
import com.zycus.IContract.Dashboard.CommonDashboard;
import com.zycus.IContract.Help.AboutIContract;
import com.zycus.IContract.Help.AdminOnlineHelp;
import com.zycus.IContract.Help.HelpVideos;
import com.zycus.IContract.Help.OnlineHelp;
import com.zycus.IContract.ManageContracts.AuthorContract;
import com.zycus.IContract.ManageContracts.ContractOutline;
import com.zycus.IContract.ManageContracts.ContractSummary;
import com.zycus.IContract.ManageContracts.ContractingParty;
import com.zycus.IContract.ManageContracts.ContractsPendingReview;
import com.zycus.IContract.ManageContracts.CreateContract;
import com.zycus.IContract.ManageContracts.Documents;
import com.zycus.IContract.ManageContracts.LineItems;
import com.zycus.IContract.ManageContracts.Milestone;
import com.zycus.IContract.ManageContracts.Timeline;
import com.zycus.IContract.Performance.SpendByContractingParty;
import com.zycus.IContract.Performance.SpendByContracts;
import com.zycus.IContract.Reports.Reports;
import com.zycus.IContract.Search.ContractSearch;
import com.zycus.ZSN.MyContracts.ViewContracts;

import DataProviders.Common_DataProviderTestNG;
import DataProviders.eInvoice_DataProviderTestNG;
import DataProviders.iContract_DataProviderTestNG;
//import Framework.NavigationClass;
import SanityDefault.Login;
import common.Functions.CommonFunctions1;
import common.Functions.eInvoice_CommonFunctions;
import common.UserProfile.UserProfile;;

public class TestingIContractCaseByCase extends CommonTests1{
	
	public TestingIContractCaseByCase() throws Exception {
		super();
	}
	
	
	/**
	 * @param contractNumber
	 *            the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	private ExtentTest logger;
	private String Product = "iContract";
	private WebDriver driver1;
	eInvoice_CommonFunctions objFunctions;
	private String contractNumber;
	
	//ZCS production - Navisite
	//private String clauseCategory = "Test";
	//ZCS RM
	//private String clauseCategory = "Category 1";
	private String clauseTitle;
	private String templateName;
	private String contractTitle = null;
	private boolean isFileDownloaded = true;
	private String newDashboardName;
	private String dashboardName;
	private boolean sendForSigning = false;
	private boolean isSignoffWorkflowActive = false;
	
	
	@Test(groups = "Login", dataProviderClass = Common_DataProviderTestNG.class, 
			dataProvider = "Login",alwaysRun = true)
	@TestDetails(TestID="iContract_1")
	public void login(String Username, String Password, String Customer, String userAccount, String Environment) throws Exception {
		
		driver = startSession(this.getClass().getName());
		objFunctions = new eInvoice_CommonFunctions(driver, logger);
		//displayStyle = objZCD.getDisplayStyle(driver, loginCredentials);
		displayStyle = "Rainbow";
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	//Clause Category to create
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "ClauseCategory", description = "",
			dependsOnMethods = "login",priority = 2)
	@TestDetails(TestID="iContract_2")
	public void createClause(String clauseCategory, String reviewerName, String associatedBaseType, String language) throws Exception {
		//********************Commenting it as clause once created cannot be deleted, can only be deactivated*************************//
		
		/*objFunctions.navigateToMainPage(displayStyle, Product, "Clause Library");
		ClauseLibrary objLibrary = new ClauseLibrary(driver,logger);
		clauseTitle = objLibrary.addClause(clauseCategory, reviewerName, associatedBaseType, language);*/
		
		//********************************************
		//For ZCS Production
		//clauseTitle = "AutoClause_540646";
		//For ZCS RM
		//clauseTitle = "AutoClause_749591";]
		clauseTitle = "AutoClause_369941";
	}
	
	@Test(description = "",
			dependsOnMethods = "createClause",priority = 3)
	@TestDetails(TestID="iContract_3")
	public void createTemplateForContract() throws Exception {
		//********************Commenting it as product selction button is not displayed after creation of Template*************************//
		
		/*String templateFor = "Contract"; 	//Other values can be 'Amendment' and 'Contract And Amendment'
		objFunctions.navigateToMainPage(displayStyle, Product, "Templates");
		Templates objTemplate = new Templates(driver, logger);
		templateName = objTemplate.createTemplate(templateFor, clauseTitle);*/
		
		//For ZCS Production
		//templateName = "Auto_700780 - Template_Auto_700780";
		//For ZCS RM
		//templateName = "Auto_696126 - Template_Auto_696126";
		templateName = "Auto_263536 - Template_Auto_263536";
	}
	
	
	@Test(description = "",
			dependsOnMethods = "createTemplateForContract",
			priority = 4)
	@TestDetails(TestID="iContract_4")
	public void authorContract_noNegotiate() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		objAuthor.createContract(templateName);
		
		//Verify Yellow btn- Draft in Progress
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		ContractSummary objSummary = new ContractSummary(driver, logger);
		contractTitle = objSummary.getContractTitle();
		contractNumber = objSummary.getContractNum();
		System.out.println("Contract Number created here is :"+ contractNumber);
		objContract.closeContract();
		//Check row created with status as 'Draft in Progress'
		objAuthor.verifyContractStatusinGrid(contractNumber);
	}
	
	@Test(description = "",
			dependsOnMethods = "authorContract_noNegotiate",
			priority = 5)
	@TestDetails(TestID="iContract_4")
	public void addContractingParties() throws Exception {
		AuthorContract objAuthor = new AuthorContract(driver, logger);
		CreateContract objContract = new CreateContract(driver, logger);
		objAuthor.navigateToStage(contractNumber, "Author");
		//Contracting Party
		ContractingParty objContParty = new ContractingParty(driver, logger);
		objContract.navigate_ContractSubTabs("Contracting Party");
		objContParty.addContractingParties();
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractingParties",
			priority = 6)
	@TestDetails(TestID="iContract_4")
	public void addContractOutline() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Outline");
		ContractOutline objOutline = new ContractOutline(driver, logger);
		objOutline.createVersion();
	}
	
	@Test(description = "",
			dependsOnMethods = "addContractOutline",
			priority = 7)
	@TestDetails(TestID="iContract_4")
	public void addLineItems() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Line Items
		objContract.navigate_ContractSubTabs("Line Items");
		LineItems objItems = new LineItems(driver, logger);
		objItems.createLineItem();
	}
	
	@Test(description = "",
			dependsOnMethods = "addLineItems",
			priority = 8)
	@TestDetails(TestID="iContract_4")
	public void uploadDocuments() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Line Items
		objContract.navigate_ContractSubTabs("Documents");
		Documents objDoc = new Documents(driver, logger);
		//provide no of documents to upload 
		objDoc.selectDocuments(2);
	}
	
	@Test(description = "",
			dependsOnMethods = "addLineItems",
			priority = 9)
	@TestDetails(TestID="iContract_4")
	public void addMilestones() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		//Add Milestones
		objContract.navigate_ContractSubTabs("Milestones");
		Milestone objMilestone = new Milestone(driver, logger);
		objMilestone.addMilestone();
	}
	
	@Test(description = "",
			dependsOnMethods = "addMilestones",
			priority = 10)
	@TestDetails(TestID="iContract_4")
	public void createVersion() throws Exception {
		CreateContract objContract = new CreateContract(driver, logger);
		Thread.sleep(5000);
		objContract.navigate_ContractSubTabs("Timeline");
		Timeline objTimeline = new Timeline(driver, logger, contractTitle);
		if(objTimeline.verifyVersionCreated())
			logger.pass("Version created and Downloaded");
		else
			logger.fail("Version not created or Downloaded");
		
		//if(isDocUploaded){
		if(objTimeline.verifyDocumentCreated())
			logger.pass("Document visible in timeline and Downloaded");
		else
			logger.fail("Document not visible or Downloaded in timeline");
	}
	
	//If negotaiation is allowed then only Contract can be sent for Internal review
	@Test(description = "",
			dependsOnMethods = "createVersion",
			priority = 11)
	@TestDetails(TestID="iContract_4")
	public void sendForInternalReview() throws Exception {
		boolean sendForInternalReview = false;
		if(sendForInternalReview){
			CreateContract objContract = new CreateContract(driver, logger);
			objContract.navigate_ContractSubTabs("Contract Summary");
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.sendForApproval();
			objContract.navigate_ContractSubTabs("Author Review");
			objSummary.authorReview();
			
			objFunctions.closeBrowser();
			
			Login objLogin = new Login(driver, logger);
			objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
			objFunctions.switchToWindow("Rainbow Home");
			objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
			ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
			objReview.approveContract("Authoring Stage", contractNumber, "Approve");
			objFunctions.closeBrowser();
		}else
			throw new SkipException("Skipping this exception");
	}
	
	@Test(description = "",
			dependsOnMethods = "createVersion",
			priority = 12)
	@TestDetails(TestID="iContract_4")
	public void proceedToSignOff() throws Exception {
		boolean isSignoffWorkflowActive = false;
		CreateContract objContract = new CreateContract(driver, logger);
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objContract.navigate_ContractSubTabs("Contract Summary");
		//if(sendForSigning){
		objSummary.proceedToSignOff(isSignoffWorkflowActive);
		/*}else
			objSummary.skipSigning();*/
		objFunctions.closeBrowser();
	}
	
	@Test(description = "",
			dependsOnMethods = "createVersion",
			priority = 13)
	@TestDetails(TestID="iContract_4")
	public void approveSignOffStage() throws Exception {
		if(sendForSigning){
			if(isSignoffWorkflowActive){
				Login objLogin = new Login(driver, logger);
				objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
				objFunctions.switchToWindow("Rainbow Home");
				objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
				ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
				objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
				objFunctions.closeBrowser();
			}else
				throw new SkipException("Skipping this exception");
		}else{
			ContractSummary objSummary = new ContractSummary(driver, logger);
			objSummary.skipSigning();
		}
			
	}
	
	@Test(description = "",
			dependsOnMethods = "createVersion",
			priority = 14)
	@TestDetails(TestID="iContract_4")
	public void sendForOfflineSigning() throws Exception {
		boolean isSignoffWorkflowActive = true;
		/*objLogin.loginWithUserAcct_PwdMgr("GDQA-P2P@zycus.com");
		objFunctions.switchToWindow("Rainbow Home");
		objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
		objAuthor.clrAllFilters();
		Thread.sleep(2000);
		objAuthor.filterByContractNum(contractNumber);
		objAuthor.navigateToStage(contractNumber, "Sign off");
	*/
		ContractSummary objSummary = new ContractSummary(driver, logger);
		objSummary.sendForSigning(isSignoffWorkflowActive, "Offline Signing");
	}
	
	@Test(description = "",
			dependsOnMethods = "sendForOfflineSigning",
			priority = 15)
	@TestDetails(TestID="iContract_4")
	public void downloadContractInZSN() throws Exception {
		//Download Contract in ZSN
		this.driver1 = objFrameworkUtility.getWebDriverInstance(
				System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
		Login objLogin = null;
		if(configurationProperties.getProperty("environment").equals("Production"))
			objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
		else if(configurationProperties.getProperty("environment").equals("RM"))
			objLogin = new Login(driver1, logger, "gauri.joshi@zycus.com", "Right@123");
		
		callAndLog(driver1, logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
		CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
		objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
		ViewContracts objViewContracts = new ViewContracts(driver1, logger);
		isFileDownloaded  = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
	}
	
	@Test(description = "",
			dependsOnMethods = "sendForOfflineSigning",
			priority = 16)
	@TestDetails(TestID="iContract_4")
	public void uploadContract() throws Exception {
		if(isFileDownloaded){
		try{
				ContractSummary objSummary = new ContractSummary(driver, logger);
				objSummary.uploadContract(contractTitle);
			}catch(Exception e){
				Documents objDoc1 = new Documents(driver, logger);
				objDoc1.addDocument_ForEnd(contractTitle);
			}
		}else
			throw new SkipException("Skipping this exception");
	}
	
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "addReportToNewDashboard", 
			dataProvider = "", 
			priority = 19)
	@TestDetails(TestID="iContract_3")
	//public void addReportToExistingDashboard(String dashboardFolder, String existingDashboardName, String reportName, String...navigationTabs) throws Exception {
	public void addReportToExistingDashboard() throws Exception {
		String reportName = "All Expired Contracts";
		String existingDashboardName = newDashboardName;
		String dashboardFolder = "MyDashboard";
		
		objFunctions.navigateToMainPage(displayStyle, Product, "Reports");
		Reports objReports = new Reports(driver, logger);
		try{
			objReports.addReportToExistingDashboard(reportName, dashboardFolder, existingDashboardName);
			objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard", "Common Dashboard");
			CommonDashboard objDashboard = new CommonDashboard(driver, logger);
			if(objDashboard.verifyReportExistInDashboard(existingDashboardName, reportName))
				logger.pass(reportName +" added to Dashboard "+ existingDashboardName);
		}catch(Exception e){
			e.printStackTrace();
			logger.fail(reportName +" not added to Dashboard "+ existingDashboardName);
		}
	}
	
	@Test(dataProviderClass = eInvoice_DataProviderTestNG.class, 
			dependsOnMethods = "login", 
			dataProvider = "", 
			priority = 18)
	@TestDetails(TestID="iContract_4")
	//public void addReportToNewDashboard(String dashboardFolder, String layout, String reportName, String...navigationTabs) throws Exception {
	public void addReportToNewDashboard() throws Exception {
		//********************Commenting it as product selction button is not displayed after addition of Report to Dashboard*************************//
		
		/*String reportName = "Clause Usage Statistics";
		String dashboardFolder = "MyDashboard";
		String layout ="50:50";
		
		objFunctions.navigateToMainPage(displayStyle, Product, "Reports");
		Reports objReports = new Reports(driver, logger);
		try{
			newDashboardName = objReports.addReportToNewDashboard(reportName, dashboardFolder, layout);
			objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard", "Common Dashboard");
			CommonDashboard objDashboard = new CommonDashboard(driver, logger);
			if(objDashboard.verifyReportExistInDashboard(newDashboardName, reportName))
				logger.pass(reportName +" added to Dashboard "+ newDashboardName);
		}catch(Exception e){
			e.printStackTrace();
			logger.fail(reportName +" not added to New Dashboard");
		}*/
		newDashboardName = "NewDashboard_129425";
	}
	
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 5)
	@TestDetails(TestID="iContract_10")
	public void SpendByContractingParty(String...navigationTabs) throws Exception {
		String searchBy = "Contract Title";
		String searchValue = "My Repository Contract";
		objFunctions.navigateToMainPage(displayStyle, Product, "Performance","Spend By Contracting Party");
		SpendByContractingParty objParty = new SpendByContractingParty(driver, logger); 
		objParty.searchContracts(searchBy, searchValue);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContracts", description = "",
			dependsOnMethods = "login",
			priority = 5)
	@TestDetails(TestID="iContract_11")
	public void SpendByContracts(String...navigationTabs) throws Exception {
		String searchBy = "Contract Title";
		String searchValue = "Test78676";
		objFunctions.navigateToMainPage(displayStyle, Product, "Performance","Spend By Contracts");
		SpendByContracts objContracts = new SpendByContracts(driver, logger); 
		objContracts.searchContracts(searchBy, searchValue);
	}
	
	
	@Test(dependsOnMethods = "login",
			priority = 5)
	@TestDetails(TestID="iContract_12")
	public void aboutIContract() throws Exception {
		String version = "18.10.1.1";
		/*JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("$(\"#ui-id-2\").animate({ scrollTop: \""+300+"px\" })");*/
		
		/*Actions actions = new Actions(driver);
		WebElement mainMenu = driver.findElement(By.id("mCSB_9_container"));
		actions.moveToElement(mainMenu);*/
		
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","About iContract");
		AboutIContract objAbout = new AboutIContract(driver, logger);
		objAbout.verifyVersion(version);
	}
	
	@Test(dependsOnMethods = "login",
			priority = 6)
	@TestDetails(TestID="iContract_13")
	public void adminOnlineHelp() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","Admin Online Help");
		AdminOnlineHelp objOnlineHelp = new AdminOnlineHelp(driver, logger);
		objOnlineHelp.verifyOnlineHelpPage();
	}
	
	@Test(dependsOnMethods = "login",
			priority = 7)
	@TestDetails(TestID="iContract_13")
	public void helpVideos() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","Help Videos");
		HelpVideos objhelpVideo = new HelpVideos(driver, logger);
		objhelpVideo.verifyReleaseVideos("Release Videos");
		objhelpVideo.verifyReleaseVideos("Product Videos");
		objhelpVideo.verifyReleaseVideos("WordConnect Videos");
	}
	
	@Test(dependsOnMethods = "login",
			priority = 8)
	@TestDetails(TestID="iContract_13")
	public void onlineHelp() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Help","Online Help");
		OnlineHelp objOnlineHelp = new OnlineHelp(driver, logger);
		objOnlineHelp.verifyOnlineHelpPage();
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 5)
	@TestDetails(TestID="iContract_13")
	public void CommonDashboard(String... navigationTabs) throws Exception {
		String dashboardLayout = "50:50";
		String report1 = "All Expired Contracts";
		String report2 = "Clause Usage Statistics";
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		//dashboardName = objCustomDashboard.addNewDashboard(dashboardLayout, report1, report2);
		objCustomDashboard.saveNewDashboardToMyDashboard(dashboardLayout, report1, report2);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 6)
	@TestDetails(TestID="iContract_13")
	
	public void verifyReportInDashboard(String... navigationTabs) throws Exception {
		String report1 = "Clause Usage Statistics";
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.verifyReportExistInDashboard(dashboardName, report1);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 7)
	@TestDetails(TestID="iContract_13")
	public void exportdashbaord(String... navigationTabs) throws Exception {
		String exportFormat = "Excel";
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.exportDashboard(dashboardName, exportFormat);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 8)
	@TestDetails(TestID="iContract_13")
	public void markAsDefault(String... navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.markDashboardAsDefault(dashboardName);
	}
	
	@Test(dataProviderClass = iContract_DataProviderTestNG.class, 
			dataProvider = "SpendByContractingParty", description = "",
			dependsOnMethods = "login",
			priority = 9)
	@TestDetails(TestID="iContract_13")
	public void deleteDashboard(String... navigationTabs) throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		CommonDashboard objCustomDashboard = new CommonDashboard(driver, logger);
		objCustomDashboard.deleteDashboard(dashboardName);
	}
	
	@Test(description = "",
			dependsOnMethods = "login",
			priority = 9)
	@TestDetails(TestID="iContract_14")
	public void MostViewedContracts() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.verifyTopFiveContractsDisplayed();
	}
	
	@Test(description = "",
			dependsOnMethods = "login",
			priority = 9)
	@TestDetails(TestID="iContract_15")
	public void RecentSearches() throws Exception {
		objFunctions.navigateToMainPage(displayStyle, Product, "Dashboard","Common Dashboard");
		ContractSearch objSearch = new ContractSearch(driver, logger);
		objSearch.verifyTopFiveRecentSearchesDisplayed();
	}
	
	@Test(description = "",
			dependsOnMethods = "login",
			priority = 10)
	@TestDetails(TestID="iContract_15")
	public void checkUserProfile() throws Exception {
		UserProfile objProfile = new UserProfile(driver, logger);
		objProfile.verifyUserProfile();
	}
	
	
	
	/*verifyReportExistInDashboard
	saveNewDashboardToMydashboard/Precanned
	exportDashboard
	add/removeDashboardToFav
	deleteDashboard
	markDashboardAsdefault*/
	
	
	
	/*
	@Test(description = "",
			dependsOnMethods = "createTemplateForContract",
			priority = 3)
	@TestDetails(TestID="iContract_4")
	public void AuthorContract_Negotiate() throws Exception {
		String contractTitle = null;
		boolean isSignoffWorkflowActive = false;
		boolean sendForInternalReview = false;
		try{
			objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
			AuthorContract objAuthor = new AuthorContract(driver, logger);
			objAuthor.createContract(templateName);
			
			//Verify Yellow btn- Draft in Progress
	
			CreateContract objContract = new CreateContract(driver, logger);
			//ContractDetails objDetails = new ContractDetails(driver, logger);
			
			//Contract Details
			//objDetails.enterContractDetails();
			objContract.navigate_ContractSubTabs("Contract Summary");
			ContractSummary objSummary = new ContractSummary(driver, logger);
			contractTitle = objSummary.getContractTitle();
			contractNumber = objSummary.getContractNum();
			
			System.out.println("Contract Number created here is :"+ contractNumber);
			*//**************************Done**********************//*
			
			//Close Contract
			//Check row created with status as 'Draft in Progress'
			//Click on Author Stage - should navigate to Contracting Party page
			objContract.closeContract();
			objAuthor.verifyContractStatusinGrid(contractNumber);
			objAuthor.navigateToStage(contractNumber, "Author");
			*//************************************************//*
			
			//Contracting Party
			ContractingParty objContParty = new ContractingParty(driver, logger);
			objContract.navigate_ContractSubTabs("Contracting Party");
			if(objContParty.addContractingParties()){
				
				*//**************************Done**********************//*
				//Check in Contract Summary if Contracting party added
				
				*//**********************************************//*
				
				//Contract Outline
				objContract.navigate_ContractSubTabs("Contract Outline");
				ContractOutline objOutline = new ContractOutline(driver, logger);
				objOutline.createVersion();
				
				
				//Line Items
				objContract.navigate_ContractSubTabs("Line Items");
				LineItems objItems = new LineItems(driver, logger);
				objItems.createLineItem();
				
				
				//Documents
				//boolean isDocUploaded = false;
				
				//Commenting as it has issues uploading
				objContract.navigate_ContractSubTabs("Documents");
				Documents objDoc = new Documents(driver, logger);
				//provide no of documents to upload 
				objDoc.selectDocuments(2);
				
				
				if(objContract.navigate_ContractSubTabs("Documents")){
					Documents objDoc = new Documents(driver, logger);
					isDocUploaded = objDoc.selectDocuments();
				}
				
				
				//Add Milestones
				objContract.navigate_ContractSubTabs("Milestones");
				Milestone objMilestone = new Milestone(driver, logger);
				objMilestone.addMilestone();
				
				//Timeline
				objContract.navigate_ContractSubTabs("Timeline");
				Timeline objTimeline = new Timeline(driver, logger, contractTitle);
				if(objTimeline.verifyVersionCreated())
					logger.pass("Version created and Downloaded");
				else
					logger.fail("Version not created or Downloaded");
				
				//if(isDocUploaded){
				if(objTimeline.verifyDocumentCreated())
					logger.pass("Document visible in timeline and Downloaded");
				else
					logger.fail("Document not visible or Downloaded in timeline");
					//}
	
				//Author Review if sent for internal review during Authoring
				if(sendForInternalReview){
					objContract.navigate_ContractSubTabs("Contract Summary");
					objSummary.sendForApproval();
					objContract.navigate_ContractSubTabs("Author Review");
					objSummary.authorReview();
					
					objFunctions.closeBrowser();
					
					Login objLogin = new Login(driver, logger);
					objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
					objFunctions.switchToWindow("Rainbow Home");
					objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
					ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
					objReview.approveContract("Authoring Stage", contractNumber, "Approve");
					objFunctions.closeBrowser();
					
				}
				
				//Contract Summary
				objContract.navigate_ContractSubTabs("Contract Summary");
				
				objSummary.proceedToSignOff(isSignoffWorkflowActive);
				if(isSignoffWorkflowActive){
					objFunctions.closeBrowser();
					
					Login objLogin = new Login(driver, logger);
					objLogin.loginWithUserAcct_PwdMgr("admin.zcs@zycus.com");
					objFunctions.switchToWindow("Rainbow Home");
					objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Contract Pending Review");
					ContractsPendingReview objReview = new ContractsPendingReview(driver, logger);
					objReview.approveContract("Sign-off Stage", contractNumber, "Approve");
					objFunctions.closeBrowser();
					
					objLogin.loginWithUserAcct_PwdMgr("GDQA-P2P@zycus.com");
					objFunctions.switchToWindow("Rainbow Home");
					objFunctions.navigateToMainPage(displayStyle, Product, "Manage Contracts", "Author Contract");
					objAuthor.clrAllFilters();
					Thread.sleep(2000);
					objAuthor.filterByContractNum(contractNumber);
					objAuthor.navigateToStage(contractNumber, "Sign off");
				}
				
				
				objSummary.sendForSigning(isSignoffWorkflowActive, "Offline Signing");
	
				
				//Download Contract in ZSN
				this.driver1 = objFrameworkUtility.getWebDriverInstance(
						System.getProperty("user.dir") + configurationProperties.getProperty("chromedriverpath"));
				Login objLogin = null;
				if(configurationProperties.getProperty("environment").equals("Production"))
					objLogin = new Login(driver1, logger, "hinal.shah@zycus.com", "Nov@1234");
				else if(configurationProperties.getProperty("environment").equals("RM"))
					objLogin = new Login(driver1, logger, "gauri.joshi@zycus.com", "Right@123");
				
				callAndLog(driver1, logger, objLogin.login(configurationProperties), "login successful", "Not logged in");
				CommonFunctions1 objZSNFunctions = new CommonFunctions1(driver1, logger);
				objZSNFunctions.navigate_path1("My Contracts", "View Contracts", "ZCS");
				ViewContracts objViewContracts = new ViewContracts(driver1, logger);
				boolean isFileDownloaded = objViewContracts.downloadContract(contractNumber, contractTitle, "pdf");
				
				//Upload Downloaded Contract to 
				if(isFileDownloaded){
					driver1.quit();
					try{
						objSummary.uploadContract(contractTitle);
					}catch(Exception e){
						Documents objDoc1 = new Documents(driver, logger);
						objDoc1.addDocument_ForEnd(contractTitle);
					}
				}
			
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/
	
	
	@AfterMethod
	public void getResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			logger.fail("Test Case Failed is " + result.getName());
			logger.fail("Test Case Failed is " + result.getThrowable());
		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.skip("Test Case Skipped is " + result.getName());
		}
	}

}
