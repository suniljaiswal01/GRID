package com.main.Product1;

import java.util.Date;
import java.util.List;

import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.Common_DataProviderTestNG;



public class Flow1 extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "Product1";
	

	public Flow1() throws Exception {
		super();
		setProduct("Product1");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}
	
	
	@Test(groups = "Login", alwaysRun = true, priority = 1)
	@TestDetails(TestID="iManage_1")
	public void login_Flow1() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(groups = "Login",alwaysRun = true, priority = 2)
	@TestDetails(TestID="iManage_1")
	public void checkfail() throws Exception {
		
		LogScreenshot("pass","pass");
	}
	
	@Test(groups = "Login", alwaysRun = true, priority = 3)
	@TestDetails(TestID="iManage_1")
	public void checkskip() throws Exception {
		LogScreenshot("skip","checkskip");
	}
}
