package com.main.Product1;

import org.testng.annotations.Test;

import com.main.CommonTests1;
import com.main.TestDetails;

import DataProviders.Common_DataProviderTestNG;



public class DependentOnFlow1 extends CommonTests1{

	/*private ExtentTest logger;*/
	private String Product = "Product1";
	

	public DependentOnFlow1() throws Exception {
		super();
		setProduct("Product1");
		setClassToLoad("common.Functions.iManage_CommonFunctions");
	}
	
	
	@Test(alwaysRun = true,dependsOnMethods = {"com.main.Product1.Flow1.login_Flow1"})
	@TestDetails(TestID="iManage_1")
	public void login_Flow2() throws Exception {
		
		displayStyle = getDisplayStyle(driver, logger, loginCredentials);
		callAndLog(logger, displayStyle.equals("Rainbow")?true:false, "Display style is Rainbow", "Display style is not rainbow");
	}
	
	@Test(alwaysRun = true,dependsOnMethods = "login_Flow2")
	@TestDetails(TestID="iManage_1")
	public void checkfail2() throws Exception {
		LogScreenshot("pass","pass");
	}
	
	@Test(alwaysRun = true,dependsOnMethods = "login_Flow2")
	@TestDetails(TestID="iManage_1")
	public void checkskip2() throws Exception {
		LogScreenshot("skip","checkskip");
	}
}
