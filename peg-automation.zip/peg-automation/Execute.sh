#!/bin/bash

echo $1
echo $2
echo $3
echo $4
echo $5
echo $6
echo $7
#echo $PWD
#java -cp "$PWD/lib/*;$PWD/bin/*;$PWD/config/*;$PWD/Datasheet/*;$PWD/drivers/*;$PWD/Attachments/*" com.main.Main_Sanity ${args[0]} ${args[1]} ${args[2]} ${args[3]} ${args[4]} ${args[5]} ${args[6]}i

export CLASSPATH=$PWD/target/classes:$PWD/config/:$PWD/Datasheet/:$PWD/target/lib/*:$PWD/Attachments/:$PWD/drivers/
echo $CLASSPATH
java -cp $CLASSPATH com.main.Main_Sanity $1 $2 $3 $4 $5 $6 $7
