var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Status = require('../models/AutomationStatus.js');

/* GET STATUS FOR ALL PRODCUT*/
router.get('/', function (req, res, next) {
  Status.find(function (err, products) {
    if (err) return next(err);
    res.json(products);
  }).sort({ updated_date: -1 });
});



/* GET List of PRODCUT*/
router.get('/getProductList', function (req, res, next) {
  Status.find().distinct('product', function (err, products) {
    if (err) return next(err);
    res.json(products);
  });
});

/* GET STATUS FOR SINGLE Environment */
router.get('/:setup', function (req, res, next) {
  Status.find({ "environment": req.params.setup }, function (err, post) {
    if (err) return next(err);
    res.json(post);
  }).sort({ updated_date: -1 });
});

/* ADD STATUS TO DATABASE */
router.post('/', function (req, res, next) {
  Status.create(req.body, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});
module.exports = router;
