var mongoose = require('mongoose');
var ttl = require("mongoose-ttl");

var AutomationStatus = new mongoose.Schema({
  environment: String,
  product: String,
  totalTest : String,
  passedTest: String,
  failedTest: String,
  skippedTest: String,
  passPercentage: String,
  reportPath : String,
  updated_date: { type: Date, default: Date.now},
});

module.exports = mongoose.model('Status', AutomationStatus.plugin(ttl,{ttl:'10d'}));
