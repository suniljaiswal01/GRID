import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatTabChangeEvent } from "@angular/material/tabs";
import { animate, state, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class StatusComponent implements OnInit {

  dataSource = new MatTableDataSource();

  productDataSource = new MatTableDataSource();

  statusValue: any;
  uniqueValue : any;
  columnsToDisplay = ['product', 'totalTest', 'passedTest', 'failedTest', "passPercentage"];

  historicalcolumnsToDisplay = ['product', 'totalTest', 'passedTest', 'failedTest', "passPercentage", "reportPath", "buildNo"];


  expandedElement: String | null;

  environment: string[] = ['QC', 'PARTNER', 'USSTAGING', 'AUS_STAGING'];

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.http.get('/status/QC').subscribe(data => {
      this.statusValue = data;
      this.uniqueValue = this.fetchUniqueValue(data);
      this.dataSource = new MatTableDataSource(this.uniqueValue);
    });
  }



  fetchUniqueValue(dataValue: any) {


    var distinct = [];
    var flag = true;

    dataValue.forEach(async function (s) {
      distinct.forEach(async function (a) {
        if (a.product === s.product) {
          flag = false;
        }
      })
      if (flag) {
        distinct.push(s)
      }
      flag = true;
    })

    return distinct;

  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  applyEvnFilter(event: MatTabChangeEvent) {

    const setup = event.tab.textLabel;
    this.http.get('/status/' + setup).subscribe(data => {
      this.statusValue = data;
      this.uniqueValue = this.fetchUniqueValue(data);
      this.dataSource = new MatTableDataSource(this.uniqueValue);
    });

  }



  fetchHistoricalData(product: string) {
    console.log("Row Selected:", product);

    let productData = this.statusValue.filter(dat => dat.product === product).slice(1,6);
    this.productDataSource = new MatTableDataSource(productData as any);
  }
  getTotalTest() {
    return this.uniqueValue.map((t: { totalTest: any; }) => t.totalTest).reduce((acc: any, value: any) => parseInt(acc) + parseInt(value), 0);
  }

  getTotalPass() {
    return this.uniqueValue.map((t: { passedTest: any; }) => t.passedTest).reduce((acc: any, value: any) => parseInt(acc) + parseInt(value), 0);
  }

  getTotalFail() {
    return this.uniqueValue.map((t: { failedTest: any; }) => t.failedTest).reduce((acc: any, value: any) => parseInt(acc) + parseInt(value), 0);
  }

  getAveragePrecentage() {
    return this.uniqueValue.map((t: { passPercentage: any; }) => t.passPercentage).reduce((acc: any, value: any) => parseFloat(acc) + parseFloat(value), 0) / this.statusValue.length;
  }

}
