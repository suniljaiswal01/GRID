import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatNativeDateModule} from '@angular/material/core';

import {MAT_FORM_FIELD_DEFAULT_OPTIONS,MatFormFieldModule} from '@angular/material/form-field';
import {DemoMaterialModule} from './material-module';
import { AppComponent } from './app.component';
import { StatusComponent } from './OverallStatus/status.component';
import { HistoricalDataComponent } from './historical-data/historical-data.component';

const appRoutes: Routes = [
  {
    path: '',
    component: StatusComponent,
    pathMatch: 'full'
  }
];
@NgModule({
  declarations: [
    AppComponent,
    StatusComponent,
    HistoricalDataComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatNativeDateModule,
    DemoMaterialModule,
    HttpClientModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true,onSameUrlNavigation:"reload"},
       // <-- debugging purposes only
    )
  ],
  providers: [ { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'fill' } },],
  bootstrap: [AppComponent]
})
export class AppModule { }
