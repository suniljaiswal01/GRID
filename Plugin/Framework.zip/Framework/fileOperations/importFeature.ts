var FormData = require('form-data');
const fs = require('fs')
const path = require('path')
const axios = require('axios')
import { fileSystemOperation } from "./fs_ops";
import { xray_ImportCucumberApiRequest } from "../Xray_Api/xray_ImportFeature_Request";
import { Startup } from "../FrameworkUtilities/Startup/Startup";
const request = require('request')
var zipFolder = require('zip-folder');
let filesList = new Array<string>();
/*compressed folder*/

export class fileSystemOperationImport {

    static async importFeature(projectKey: string, productName: string) {

        await xray_ImportCucumberApiRequest.generateAuthToken().then(async function (authToken) {

            const fileList = getListOfFile('src/zsn/features/Venus/');
            console.log("List of feature Files:", fileList);
            for (const files of fileList) {
                await updateSpecialCharaterInScenario(files)
                var data = new FormData();
                data.append('file', fs.createReadStream(files));
                let finalToken: string = 'Bearer ' + authToken.replace(/(\")/gm, "")
                var options = {
                    method: 'post',
                    timeout: 1000 * 60,
                    url: 'https://xray.cloud.xpand-it.com/api/v1/import/feature?projectKey=' + projectKey,
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        'Authorization': finalToken,
                        ...data.getHeaders()
                    },
                    data: data
                };
                console.log("Doing POST request for:", files);
                await axios(options).then(async function (response: any) {
                    if (response.status != 202) {
                        if (response.data.errors.length > 0) {
                            console.log("Error in File:", response.data.errors);
                        }
                        let jiraID: any = response.data;
                        for (const sample of jiraID["updatedOrCreatedTests"]) {
                            console.log("Issue under update ", sample["key"]);
                            var options = {
                                'method': 'GET',
                                'url': 'https://pdtzycus.atlassian.net/rest/api/3/issue/' + sample["key"],
                                'headers': {
                                    'Authorization': 'Basic SklSQS1ib3R1c2VyQHp5Y3VzLmNvbTpRbnhXTVRKd0pQc0Q4aGpNMFdoVjlENTM='
                                }
                            };
                            await axios(options).then(async function (response: any) {
                                let userStoryKey: string = "";
                                let linkedIssues: any = response.data["fields"]["issuelinks"]
                                for (const link of linkedIssues) {
                                    if (link["type"]["name"] == "Test") {
                                        userStoryKey = userStoryKey + link["outwardIssue"]["key"]
                                    }
                                }
                                console.log("User story key for above issue", userStoryKey)
                                if (userStoryKey != undefined) {
                                    var options = {
                                        'method': 'PUT',
                                        'url': 'https://pdtzycus.atlassian.net/rest/api/3/issue/' + sample["key"],
                                        'headers': {
                                            'Accept': 'application/json',
                                            'Content-Type': 'application/json',
                                            'Authorization': 'Basic SklSQS1ib3R1c2VyQHp5Y3VzLmNvbTpRbnhXTVRKd0pQc0Q4aGpNMFdoVjlENTM=',
                                        },
                                        data: JSON.stringify({ "update": {}, "fields": { "customfield_10128": { "value": productName }, "customfield_19004": userStoryKey } })
                                    };

                                    await axios(options).then(async function (response1: any) {
                                        var scenarioName = response.data["fields"]["summary"]
                                        console.log("Updated the product and user story key for xray test id ", sample["key"] ,"against scenario :",scenarioName);
                                        Startup.finalScenarioLabel_map.set(scenarioName, sample["key"])
                                    }).catch((error: any) => {
                                        console.log(error.response.data);
                                        throw new Error(error);
                                    });
                                }
                            }).catch((error: any) => {
                                console.log(error.response.data);
                                throw new Error(error);
                            });
                        }
                    } else {
                        console.log("Issue In " + files + ":" + response.data.error);
                    }
                }).catch((error: any) => {
                    console.log(error.response.data);
                    throw new Error(error);
                });
                console.log("************End Of Feature File:" + files + "************");
            }
            await fileSystemOperation.mapTagsToFeature(fileList);
        })
    }
}

async function updateSpecialCharaterInScenario(filepath: string) {
    await fs.readFile(filepath, "utf-8", async (err: any, data: any) => {
        let data1 = data.split(' ').join(' ');
        let regexForScenario: any = new RegExp(/(Scenario: [A-Z a-z \\d \" -]*)/gm);
        let scenarioList: any = data1.match(regexForScenario)
        if (scenarioList != null) {
            for (let i = 0; i < scenarioList.length; i++) {
                await replaceSpecialCharacters(data1, scenarioList[i]).then(async function (result: any) {
                    data1 = result;
                    if (i == scenarioList.length - 1) {
                        await fs.writeFile(filepath, data1, (err: any) => {
                            if (err) console.log(err);
                            console.log("Successfully Written to File after making changes to the special characters in a file:" + filepath);
                        });
                    }
                });
            }
        }
    });
}

async function replaceSpecialCharacters(data: any, orgScenario: any) {
    if (orgScenario.match(/"/gm) != null && orgScenario.match(/\\"/gm) == null) {
        let updatedScenario: String = orgScenario.replace(/"/gm, '\\"')
        return data.replace(orgScenario, updatedScenario);
    }
    else {
        return data;
    }
}
function getListOfFile(directorypath: string) {

    fs.readdirSync(directorypath).forEach((fileName: string) => {
        const Absolute: string = path.join(directorypath, fileName);
        if (fs.statSync(Absolute).isDirectory()) getListOfFile(Absolute);
        else filesList.push(Absolute);
    });
    return filesList
}

fileSystemOperationImport.importFeature("ZSN", "ZSN");
