const mysql = require('mysql');
const parser = require('mssql-connection-string');
import { Helper } from  "codeceptjs";
import { Startup } from "../FrameworkUtilities/Startup/Startup";
const prop = require("../FrameworkUtilities/config").prop;
const logger = require("../FrameworkUtilities/Logger/logger").logger;
import {generate} from "randomstring";
class MyHelper extends Helper {

  // before/after hooks
  /**
   * @protected
   */
  _before() {
    // remove if not used
  }

  /**
   * @protected
   */
  _after() {
    // remove if not used
  }

  // async getCookie(){
  //   const I = this;
  //   const browser = this.helpers['WebDriver'].browser;
  //   let SAAS_TOKEN ;
  //   return new Promise(async function(resolve, reject){
  //    (await browser.getCookies()).forEach(async function(a : any)  {
  //      if(a.name == "SAAS_COMMON_BASE_TOKEN_ID"){
  //       SAAS_TOKEN = a.value;
  //       resolve (SAAS_TOKEN);
  //      }
  //     });
  //   })
    
  // }
  // add custom methods here
  // If you need to access other helpers
  // use: this.helpers['helperName']
  // async clickIfVisible(selector: any, ...options : any) {
  //   const I = this;
  //   const helper = this.helpers['WebDriver'];
  //   try {
  //     const numVisible = await helper.grabNumberOfVisibleElements(selector);

  //     if (numVisible) {
  //       return helper.click(selector, ...options);
  //     }
  //   } catch (err) {
  //     console.log('Skipping operation as element is not visible');
  //   }
  // }
  // async getElement(elementKey : any) {
  //   const I = this;
  //   const element = Startup.uiElements.get(elementKey);
  //   return element;
  // }
  // async getData(key: any) {
  //   const I = this;
  //   var value;
  //   var index = 0;
  //   if (key.includes("[") && key.includes("]")) {
  //     let startindex = key.indexOf("[");
  //     let endtindex = key.indexOf("]");
  //     index = key.substring(startindex + 1, endtindex);
  //     key = key.substring(0, startindex);
  //   }
  //   else {
  //     logger.info("warning : no index in key so it will return 0 index value");
  //   }

  //   let mapValue = Startup.testData.get(key);
  //   if (typeof mapValue == 'undefined') {
  //     logger.info("Error : Getting null from testData for given field : " + key);
  //   }
  //   else {
  //     let arrayVal = mapValue.split("||");
  //     if (index < arrayVal.length) {
  //       value = arrayVal[index];
  //     }
  //     else {
  //       logger.info("warning : index is greater then size returning 0 index value");
  //       value = arrayVal[0];
  //     }
  //   }
  //   return value;
  // }
  // async waitForLoadingSymbolNotDisplayed()
  // {
  //   const I = this;
  //   const helper = this.helpers['WebDriver'];
  //     await helper.waitForInvisible("//div[@class='spinner']", 60);
  //     // logger.info("Waited for Loading Symbol to go off");
  // }
  async checkIfVisible(selector :any, ...options : any) {
    const I = this;
    const helper = this.helpers['WebDriver'];
    try {
       if( await helper.grabNumberOfVisibleElements(selector)){
    return true;
       };
    } catch (err) {
      console.log(err);
    }
   }

   async startBrowser() {
    try {
      console.log("========================>Stop the Browser");
      await this.helpers['WebDriver']._startBrowser();
     
    } catch (err) {
      console.log("========================>ERROR"+err);
      console.log("========================>Stopping the Browser Failed...");
     
    }

  }

  async stopBrowser() {
    try {
      console.log("========================>Stop the Browser");
      await this.helpers['WebDriver']._stopBrowser();
     
    } catch (err) {
      console.log("========================>ERROR"+err);
      console.log("========================>Stopping the Browser Failed...");
     
    }

  }

//   async insertIntoDB(key : any,value : any){
//     const I = this;
//     // const prop = global.confi_prop;

//     const connectionString = "Data Source=tcp:"+prop.DBhost+",3306;Initial Catalog="+prop.DBdatabase+";User Id="+prop.DBuser+";Password="+prop.DBpassword+";";
//     logger.info("connectionString  : " + connectionString)

//     const connectionObj = parser(connectionString);

//     const columnName = process.env.SETUP + "_" + process.env.TENANT
//     logger.info(columnName);
    
   
//     const query = `update ${prop.testdataTable} set ${columnName}='${value}' where FIELD_NAME='${key}'`
//     const connection = mysql.createConnection(connectionObj);

//     logger.info(query);
//     connection.query(query, function (error : any) {

//       if(!!error){
//         logger.info("Error in the query");
//         logger.info(error)
//         connection.destroy();
//       }else{
//         logger.info("Success");
//         connection.destroy();
//       }
//     });
// }

// async  getRandomText(length: any ) {
//   const I = this;
//   return generate(length);
// }
}

module.exports = MyHelper;
